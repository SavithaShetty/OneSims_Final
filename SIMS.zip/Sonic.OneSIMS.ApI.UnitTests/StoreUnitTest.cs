using Sonic.OneSIMS.DomailModels.Settings;
using System;
using System.Collections.Generic;
using Xunit;
using Sonic.OneSIMS.Api.IntegrationTests.MockRepository;
using Sonic.OneSIMS.DomailModels.Settings;
using Sonic.OneSIMS.BusinessLogic.Settings;

namespace Sonic.OneSIMS.ApI.UnitTests
{
    public class StoreUnitTest
    {
        [Fact]
        public void Task_Add_ValidData_MatchStoreResult()
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var controller = new StoreLogic(mockStoreRepository.Object);
            var StorList = GetStores();
            List<Store> result = new List<Store>();
            result = controller.SearchStores(StorList, 101);
            Assert.NotEmpty(result);
            Assert.NotNull(result);
            Assert.Equal(101, result[0].StoreId);

        }
        [Fact]
        public void Task_Add_ValidData_NotMatchStoreResult()
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var controller = new StoreLogic(mockStoreRepository.Object);
            var StorList = GetStores();
            List<Store> result = new List<Store>();
            result = controller.SearchStores(StorList, 10);
            Assert.Empty(result);
        }
        [Fact]
        public void Task_Add_ValidData_NotMatchStores()
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var controller = new StoreLogic(mockStoreRepository.Object);
            var StorList = GetStores();
            List<Store> result = new List<Store>();
            var results = controller.SearchStores(StorList, 217);
            Assert.NotEmpty(results);
            Assert.NotEqual(101, results[0].StoreId);
            Assert.NotNull(result);
        }
        [Theory]
        [InlineData("ITESJFKF!")]
        [InlineData("USJ")]
        [InlineData("-121")]
        public void CheckVIN_NotMatch(string VIN)
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var vinValidator = new StoreLogic(mockStoreRepository.Object);
            bool isValid = vinValidator.ValidateVIN(VIN);
            Assert.False(isValid, $"The VIN {VIN} should not be valid!");
        }
        [Theory]
        [InlineData("IRDW2ID34DW3D2ED4")]
        public void CheckVIN_Match(string VIN)
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var vinValidator = new StoreLogic(mockStoreRepository.Object);
            bool isValid = vinValidator.ValidateVIN(VIN);
            Assert.True(isValid, $"The VIN {VIN} should not be valid!");
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        [InlineData(15000)]
        public void CheckMilage_NotMatch(int Mileage)
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var passwordValidator = new StoreLogic(mockStoreRepository.Object);
            bool isValid = passwordValidator.ValidMileage(Mileage);
            Assert.False(isValid, $"The Milage {Mileage} should not be valid!");
        }
        [Theory]
        [InlineData(1)]
        [InlineData(100)]
        [InlineData(2000)]
        public void CheckMilage_Match(int Mileage)
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var passwordValidator = new StoreLogic(mockStoreRepository.Object);
            bool isValid = passwordValidator.ValidMileage(Mileage);
            Assert.True(isValid, $"The Milage {Mileage} should not be valid!");
        }
    
        [Fact]
        public void ValidPassword()
        {
            //Arrange
            var mockStoreRepository = new MockUnitStoreRepository();
            var passwordValidator = new StoreLogic(mockStoreRepository.Object);
            const string password = "Th1sIsapassword!";

            //Act
            bool isValid = passwordValidator.IsValidpassword(password);

            //Assert
            Assert.True(isValid, $"The password {password} is not valid");
        }
        [Fact]
        public void NotValidPassword()
        {
            //Arrange
            var mockStoreRepository = new MockUnitStoreRepository();
            var passwordValidator = new StoreLogic(mockStoreRepository.Object);
            const string password = "thisIsaPassword";

            //Act
            bool isValid = passwordValidator.IsValidpassword(password);

            //Assert
            Assert.False(isValid, $"The password {password} should not be valid!");
        }

        [Theory]
        [InlineData("p")]
        [InlineData("O;Malley")]
        [InlineData("O,Malley")]
        public void CheckInvalidPassword(string password)
        {
            var mockStoreRepository = new MockUnitStoreRepository();
            var passwordValidator = new StoreLogic(mockStoreRepository.Object);
            bool isValid = passwordValidator.IsValidpassword(password);
            Assert.False(isValid, $"The password {password} should not be valid!");
        }
        private List<Store> GetStores()
        {
            return new List<Store>()
            {
                new Store()
                {
                   StoreId =101,
                   StoreName ="Acura surromonte"
                },
                new Store()
                {
                   StoreId =102,
                   StoreName ="Honda serramonte"
                },
                 new Store()
                {
                   StoreId =216,
                   StoreName ="Town and Country Toyota"
                },
                  new Store()
                {
                   StoreId =217,
                   StoreName ="Town and Country Toyota"
                },
            };
        }
    }
}
