﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Entities
{
    public class MakeCarFaxRequest:CarFaxRequest
    {        
    }

    public class StoreValidator : AbstractValidator<MakeCarFaxRequest>
    {
        public StoreValidator()
        {
            RuleFor(m => m.CarFaxCPWSURL).NotNull().NotEmpty()
            .WithMessage("CarFax URL is requred");
            RuleFor(m => m.CarFaxInstantReportLink).NotNull().NotEmpty()
            .WithMessage("CarFax Instant URL is requred");
            RuleFor(m => m.CarFaxPartnerCode).NotNull().NotEmpty()
            .WithMessage("CarFax Parent Code is requred");
            RuleFor(m => m.CarFaxProductCodeId).NotNull().NotEmpty()
                .WithMessage("CarFax Product Code  ID is requred");
            RuleFor(m => m.CarFaxPurChaseType).NotEmpty().NotEmpty()
                .WithMessage("CarFax Purchanse Type is requred");
            RuleFor(m => m.IsOnline).NotEmpty().NotEmpty()
               .WithMessage("CarFax IsOnline bit is requred");

        }
    }
}
