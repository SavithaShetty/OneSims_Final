﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.DTOs.Enum
{
    public enum CarfaxPriority
    {
        CarFaxDefault = 0,
        MajorProblemIndicator = 10,
        FrameDamageIndicator = 20,
        DamageIndicator = 30,
        AccidentIndicator = 40,
        ZeroOwnersIndicator = 50,
        OneOwnersIndicator = 51,
        TwoOwnersIndicator = 52,
        ThreeIndicator = 53,
        FourIndicator = 54,
        FourPlusIndicator = 55,
        BBGIndicator = 60,
        NumberOfServicerecordsIndicator = 70,
        BadVinException = 80,
        OtherException = 90
    }
}
