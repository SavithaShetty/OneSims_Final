﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Entities
{
    public class CarFaxRequest
    {
        public string UserID
        {
            get;
            set;
        }
        public string Password
        {
            get;
            set;
        }
        public string VIN
        {
            get;
            set;
        }
        public string CarFaxCPWSURL
        {
            get;
            set;
        }
        public string CarFaxInstantReportLink
        {
            get;
            set;
        }
        public string CarFaxPartnerCode
        {
            get;
            set;
        }

        public string CarFaxProductCodeId
        {
            get;
            set;
        }
        public string CarFaxPurChaseType
        {
            get;
            set;
        }
        public string IsOnline
        {
            get;
            set;
        }
    }
}
