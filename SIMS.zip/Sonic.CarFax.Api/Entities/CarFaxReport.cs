﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Entities
{
    public class CarfaxReport
    {
        /// <summary>
        /// Carfax Report
        /// </summary>
        public string VIN
        {
            get;
            set;

        }

        public string ReportProvider
        {
            get;
            set;

        }
        /// <summary>
        ///  If the report is not existing in the carfax inventory, then we are showing default.
        /// </summary>

        public string  Report
        {
            get;
            set;

        }
        /// <summary>
        ///  If the report is not existing in the carfax inventory, expire date as current date  + 30
        ///  </summary>
        public DateTime ExpireDate
        {
            get;
            set;

        }
        public string CarFaxURL
        {
            get;
            set;

        }
        public string CarFaxErrorMsg
        {
            get;
            set;

        }

    }
}
