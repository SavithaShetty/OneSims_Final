﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.CarFax.Api.Configuration;
using Sonic.CarFax.Api.DTOs;
using Sonic.CarFax.Api.Entities;
using Sonic.CarFax.Api.Helpers;
using Sonic.CarFax.Api.Security;
using Sonic.CarFax.Api.Services.Interfaces;

namespace Sonic.CarFax.Api.Controllers
{
    [ApiVersion("1")]
    //[ApiVersion("3")]
    [Route("api/v{version:apiVersion}/CarFaxReport")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    public class PurChaseCarFax : ControllerBase
    {
        private readonly ICarFaxWrapper _carFaxWrapper;
        public IConfiguration _configuration { get; }

        public PurChaseCarFax(ICarFaxWrapper carfaxservice, IConfiguration configuration)
        {
            _carFaxWrapper = carfaxservice;
            _configuration = configuration;
        }
        /// <summary>
        /// Constructor to initiate configuration and rest client
        /// </summary>
        /// <param name="configuration"></param>
        //public PurChaseCarFax(IConfiguration configuration) 
        //{
        //}
        /// <summary>
        ///This end point is used to get Purchase CarFax Report, For every hit to this service is Chargeable..
        /// </summary>
        /// <remarks>This end point is used to  get Purchase CarFax Report, For every hit to this service is Chargeable.</remarks>
        /// <param name="UserID">This UserID is provided by CarFax Vendor</param>
        /// <param name="Password">This Password is  provided by CarFax Vendor</param>
        ///  <param name="VIN">This VIN length should be 17</param>
        ///  <param name="isVehicleOnline">isVehicleOnline Flag should be 'N' or 'Y'('N'=Vehicle is not in online 'Y' =Vehicle is in Online)</param>
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains CarFax Reports and error list will be empty</li>
        /// <li> For invalid payload request the response will have empty Report and contains the error list returns from CarFax service</li>
        /// </ul>
        /// </remarks>  
        /// </response>     
        /// <response code="404">Purchange of CarFax Not Found</response>   
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>   
        [HttpGet("GetCarFaxReport/{UserID}/{Password}/{VIN}/{isVehicleOnline}")]
        [MapToApiVersion("1")]
        [ApiConventionMethod(typeof(DefaultApiConventions), nameof(DefaultApiConventions.Get))]
        public async Task<CarfaxReport> GetCarFaxReport(string UserID,string Password,string VIN,string isVehicleOnline)
        {
            CarfaxReport __CarfaxReport = new CarfaxReport();
            if (UserID != null && Password != null && VIN != null && isVehicleOnline != null)
                {
                if (Convert.ToString(VIN).Length == 17 && (isVehicleOnline.ToLower()=="n" || isVehicleOnline.ToLower() == "y"))
                {
                    CarFaxRequest _carfaxRequest = new CarFaxRequest();
                    _carfaxRequest.UserID = UserID;
                    _carfaxRequest.Password = Password;
                    _carfaxRequest.VIN = VIN;
                    _carfaxRequest.IsOnline = isVehicleOnline;
                    __CarfaxReport = _carFaxWrapper.PurchaseCarFaxReport(_carfaxRequest);
                }

            }
                return __CarfaxReport;
           
        }
    }
}
