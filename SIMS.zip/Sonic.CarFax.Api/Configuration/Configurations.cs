﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Configuration
{
    public class Configurations
    {
        public IConfiguration _configuration { get; }

        public Settings settingObj;
        public Configurations(IConfiguration configuration)
        {
            _configuration = configuration;
            settingObj = _configuration.GetSection("Settings").Get<Settings>();
        }
        public string GetCarfaxCode()
        {
            return settingObj.carFaxAccountDetails.CarfaxCode;
        }
        public string GetCarFaxReportType()
        {
            return settingObj.carFaxAccountDetails.CarFaxReportType;
        }
        public string GetCarFaxPartner()
        {
            return settingObj.carFaxAccountDetails.Partner;
        }
        public string GetCarFaxInstantReportLink()
        {
            return settingObj.carFaxAccountDetails.CarFaxInstantReportLink;
        }
        public string GetCarFaxPartnerWebServiceURL()
        {
            return settingObj.carFaxAccountDetails.CarFaxPartnerWebServiceURL;
        }
        public string GetCarFaxProductDataId()
        {
            return settingObj.carFaxAccountDetails.ProductDataId;
        }
        

    }
}
