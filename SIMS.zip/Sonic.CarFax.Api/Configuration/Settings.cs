﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Configuration
{
    public class Settings
    {        
        public CarFaxAccountDetails carFaxAccountDetails { get; set; }
        public List<User> users { get; set; }
    }
}
