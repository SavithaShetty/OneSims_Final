﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Configuration
{
    public class CarFaxAccountDetails
    {
    public string CarfaxCode { get; set; }
    public string CarFaxReportType { get; set; }
    public string Partner { get; set; }
    public string CarFaxInstantReportLink { get; set;   }
    public string CarFaxPartnerWebServiceURL { get; set; }
    public string ProductDataId { get; set; }
    }
}
