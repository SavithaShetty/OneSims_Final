﻿using Sonic.CarFax.Api.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Services.Interfaces
{
    public interface ICarFaxWrapper
    {
         CarfaxReport PurchaseCarFaxReport(CarFaxRequest request);
    }
}
