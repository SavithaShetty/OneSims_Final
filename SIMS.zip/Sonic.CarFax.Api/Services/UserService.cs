﻿using Microsoft.Extensions.Options;
using Sonic.CarFax.Api.Configuration;
using Sonic.CarFax.Api.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CarFax.Api.Services
{
    public class UserService : IUserService
    {
        private List<User> _users;
        public UserService(IOptions<Settings> settings)
        {
            _users = settings.Value.users;

        }                

        async Task<Boolean> IUserService.Authenticate(string username, string password)
        {
            var user = await Task.Run(() => _users.SingleOrDefault(x => x.Username == username && x.Password == password));
           
            if (user == null)
                return false;

            return true;
        }
    }
}
