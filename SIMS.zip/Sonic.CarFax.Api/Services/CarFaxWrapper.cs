﻿using Microsoft.Extensions.Configuration;
using Sonic.CarFax.Api.Configuration;
using Sonic.CarFax.Api.DTOs;
using Sonic.CarFax.Api.DTOs.Enum;
using Sonic.CarFax.Api.Entities;
using Sonic.CarFax.Api.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Sonic.CarFax.Api.Controllers
{
    public class CarFaxWrapper: ICarFaxWrapper
    {
        private const string PARAMETER_NAME = "id=";
        private const string ENCRYPTION_KEY = "keySIMSv1.0";
        readonly static byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());
        Configurations _configSettings = null;
        public CarFaxWrapper(IConfiguration configuration)
        {
            _configSettings = new Configurations(configuration);
        }
        #region CARFAX Partner Webservice Call
        /// <summary>
        /// To purchase a new CARFAX report
        /// </summary>
        /// <param name="carFaxRequest">Its contain all required webservice params</param>
        /// <returns>CarfaxReport -</returns>
        public CarfaxReport PurchaseCarFaxReport(CarFaxRequest carFaxRequest)
        {
            CarfaxReport carfaxReport = null;
            // string CarFaxInstantReportLink = "http://www.carfaxonline.com/cfm/Display_Dealer_Report.cfm";
            //string partner = "SNC_0";
            //carFaxRequest.CarFaxProductCodeId = "D5AFFFE76831C34B";
            // carFaxRequest.CarFaxCPWSURL = "https://secured.CARFAX.com/partner/service.cfx";
            carFaxRequest.CarFaxInstantReportLink = _configSettings.GetCarFaxInstantReportLink();
            carFaxRequest.CarFaxPartnerCode = _configSettings.GetCarFaxPartner();
            carFaxRequest.CarFaxProductCodeId= _configSettings.GetCarFaxProductDataId();
            carFaxRequest.CarFaxCPWSURL=_configSettings.GetCarFaxPartnerWebServiceURL();
            try
            {
                // Create a request using a URL that can receive a post. 
                WebRequest request = WebRequest.Create(carFaxRequest.CarFaxCPWSURL);
                // Set the Method property of the request to POST.
                request.Method = "POST";
                // Create POST data and convert it to a byte array.
                string postData = @"<carfax-request>
                                <vin>" + carFaxRequest.VIN.ToUpper() + @"</vin>
                                <product-data-id>" + carFaxRequest.CarFaxProductCodeId.ToUpper() + @"</product-data-id>
                                <username>" + carFaxRequest.UserID + @"</username>
                                <password>" + carFaxRequest.Password + @"</password>
                                <purchase>Y</purchase>
                                <report-type>VHR</report-type>
                                <online-listing>" + carFaxRequest.IsOnline + @"</online-listing>
                                </carfax-request>";
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                // Set the ContentType property of the WebRequest.
                request.ContentType = "application/x-www-form-urlencoded";
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = byteArray.Length;
                // Get the request stream.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Stream dataStream = request.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                dataStream.Close();
                // Get the response.
                WebResponse response = request.GetResponse();
                // Display the status.
                string res = (((HttpWebResponse)response).StatusDescription);
                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                string responseFromServer = reader.ReadToEnd();
                //Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();
                XDocument carfaxresponseXML = XDocument.Parse(responseFromServer);
                string iconIndicator=null ; // To hold the priority icon numeric indicator, The value will be assign only once
                DateTime expDate = new DateTime();
                var responseList = carfaxresponseXML.Descendants("vin-info").ToList();

                carfaxReport = new CarfaxReport();
                if (responseList.Count > 0)
                {
                    carfaxReport.VIN = carFaxRequest.VIN;
                    carfaxReport.CarFaxURL= carFaxRequest.CarFaxInstantReportLink + "?partner=" + carFaxRequest.CarFaxPartnerCode + "&UID=" + carFaxRequest.UserID + "&vin=" + carFaxRequest.VIN;
                    carfaxReport.VIN = carFaxRequest.VIN;
                    carfaxReport.ReportProvider = "Carfax";
                   XElement inInventory = null;
                    try
                    {
                        inInventory = carfaxresponseXML.Descendants("in-inventory").First();
                    }
                    catch (Exception ex)
                    {
                        throw ex;// Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                    }
                    if (inInventory != null && inInventory.Value == "N")
                    {
                        // If the report is not existing in the carfax inventory, then we are showing default icon and 
                        // expire date as current date  + 30
                        iconIndicator = nameof(CarfaxPriority.CarFaxDefault);
                       // iconIndicator = "Default";
                         expDate = DateTime.Now.AddDays(30);
                    }
                    else
                    {
                        try
                        {
                            var problem = carfaxresponseXML.Descendants("major-problem-value").First();

                            if (problem != null && problem.Value == "Y")
                            {
                                iconIndicator = nameof(CarfaxPriority.MajorProblemIndicator);
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;// Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var damage = carfaxresponseXML.Descendants("frame-damage-value").First();

                                if (damage != null && damage.Value == "Y")
                                {
                                    iconIndicator = nameof(CarfaxPriority.FrameDamageIndicator);
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex; //Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }
                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var branded = carfaxresponseXML.Descendants("branded-title-indicator-value").First();

                                if (branded != null && branded.Value == "Y")
                                {
                                    iconIndicator = nameof(CarfaxPriority.FrameDamageIndicator); // To show any red indicator - FrameDamageIndicator is a red icon
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex; //Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }
                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var dIndicator = carfaxresponseXML.Descendants("damage-indicator-value").First();

                                if (dIndicator != null && dIndicator.Value == "Y")
                                {
                                    iconIndicator = nameof(CarfaxPriority.AccidentIndicator); // As per the CR from Mark, we need to show the accident icon(yellow) for damage.
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex; //Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }
                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var accident = carfaxresponseXML.Descendants("accident-indicator").First();

                                if (accident != null && accident.Value == "Y")
                                {
                                    iconIndicator = nameof(CarfaxPriority.AccidentIndicator);
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex; // Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }
                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var owners = carfaxresponseXML.Descendants("number-of-owners-indicator-value").First();
                                if (owners != null)
                                {
                                    int intNoOfOwners = Convert.ToInt16(owners.Value);

                                    if (intNoOfOwners == 1)
                                        iconIndicator = nameof(CarfaxPriority.OneOwnersIndicator);

                                    else if (intNoOfOwners == 2)
                                        iconIndicator = nameof(CarfaxPriority.TwoOwnersIndicator);

                                    else if (intNoOfOwners == 3)
                                        iconIndicator = nameof(CarfaxPriority.ThreeIndicator);

                                    else if (intNoOfOwners == 4)
                                        iconIndicator = nameof(CarfaxPriority.FourIndicator);

                                    else if (intNoOfOwners > 4) // We are showing the same icon (fourplus) for 4 or more owners.
                                        iconIndicator = nameof(CarfaxPriority.FourPlusIndicator);
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex; //Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }

                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var bbg = carfaxresponseXML.Descendants("bbg-indicator-value").First();

                                if (bbg != null && bbg.Value == "Y")
                                {
                                    iconIndicator = "BBG";// (int)CarfaxPriority.BBGIndicator;
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;// Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }
                        }
                        if (iconIndicator == null)
                        {
                            try
                            {
                                var service = carfaxresponseXML.Descendants("number-of-service-records-indicator").First();
                                if (service != null)
                                {
                                    var node = service.Element("value");
                                    if (node != null && node.Value != "0")
                                    {
                                        iconIndicator = "NumberOfServicerecords";// (int)CarfaxPriority.NumberOfServicerecordsIndicator;
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;// Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                            }
                        }
                        try
                        {
                            var inventory = carfaxresponseXML.Descendants("inventory").First();

                            if (inventory != null)
                            {
                                var node = inventory.Element("expire-date");
                                if (node != null)
                                {
                                    DateTime MyDateTime = Convert.ToDateTime(node.Value);
                                    expDate = MyDateTime;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex; // Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + ":" + ex);
                        }

                    }
                }

                else
                {
                    try
                    {
                        var inventory = carfaxresponseXML.Descendants("errors").First();
                        if (inventory != null)
                        {
                            if (inventory.FirstAttribute.ToString().Contains("107"))
                                iconIndicator = "BadVinException";// (int)CarfaxPriority.BadVinException;
                            else
                                iconIndicator = "OtherException";// (int)CarfaxPriority.OtherException;
                            //Logging has to be removed once the issue is fixed.
                            //Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN + " : " + inventory.Value);
                            //carfaxReport.CarFaxErrorCode = inventory.FirstAttribute.ToString(); 
                            carfaxReport.CarFaxErrorMsg = inventory.Value;
                            expDate = DateTime.Now.AddDays(30);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                        //Logger.LogError(ConfigSettings.GetCurrentStore().ToString(), "Carfax service error on " + carFaxRequest.VIN, ex);
                    }

                }
                carfaxReport.ExpireDate = expDate;
                carfaxReport.Report = iconIndicator;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carfaxReport;
        }

        /// <summary>
        /// Decrypts a previously encrypted string.
        /// </summary>
        /// <param name="inputText">The encrypted string to decrypt.</param>
        /// <returns>A decrypted string.</returns>
        public static string Decrypt(string inputText)
        {
            using (RijndaelManaged rijndaelCipher = new RijndaelManaged())
            {

                byte[] encryptedData = Convert.FromBase64String(inputText);
                using (PasswordDeriveBytes secretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT))
                {
                    using (ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
                    {
                        using (MemoryStream memoryStream = new MemoryStream(encryptedData))
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                byte[] plainText = new byte[encryptedData.Length];
                                int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                                return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                            }
                        }
                    }
                }
            }
        }
    }


    #endregion
}
