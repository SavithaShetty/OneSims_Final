using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Sonic.CarFax.Api.Configuration;
using Sonic.CarFax.Api.Controllers;
using Sonic.CarFax.Api.Extensions;
using Sonic.CarFax.Api.Helpers;
using Sonic.CarFax.Api.Middlewares;
using Sonic.CarFax.Api.Security;
using Sonic.CarFax.Api.Services;
using Sonic.CarFax.Api.Services.Interfaces;

namespace Sonic.CarFax.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));

            services.AddControllers(config =>
            {
                config.ReturnHttpNotAcceptable = true;
                config.Filters.Add(typeof(ValidateModelStateAttribute));
            })
             .AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());


            services.AddAuthentication(BasicAuthenticationHandler.SchemeName)
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.SchemeName, null);


            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ICarFaxWrapper, CarFaxWrapper>();
            services.AddVersionService();

            services.AddSwaggerService();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();
            app.AddSwaggerMidleware(apiVersionDescriptionProvider);
            app.UseMiddleware<ErrorHandlerMiddleware>();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
