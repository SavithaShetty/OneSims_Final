using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OneSIMS.Pricing.API.Configuration;
using OneSIMS.Pricing.API.Extensions;
using OneSIMS.Pricing.API.Helpers;
using OneSIMS.Pricing.API.Middlewares;
using OneSIMS.Pricing.API.Security;
using OneSIMS.Pricing.API.Services;
using OneSIMS.Pricing.Services;
using OneSIMS.Pricing.Services.Interfaces;
using OneSIMS.Pricing.API.DataAccess;
using Sonic.OneSIMS.Infrastructure.Persistence;

namespace OneSIMS.Pricing.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
          //  services.AddMvc().AddNewtonsoftJson();//(x => x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));
            
            services.AddControllers(config =>
            {
                config.ReturnHttpNotAcceptable = true;
                config.Filters.Add(typeof(ValidateModelStateAttribute));
            })
            .AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());

            services.AddAuthentication(BasicAuthenticationHandler.SchemeName)
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.SchemeName, null);


            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IAppraisalPricingService, AppraisalPricingService>();
            services.AddVersionService();

            services.AddScoped<IAppraisalPricingRepository, AppraisalPricingRepository>();
            services.AddSwaggerService();
            ConfigureDatabase(services);

        }

        public virtual void ConfigureDatabase(IServiceCollection services)
        {
            // Add functionality to inject IOptions<T>
            services.AddOptions();

            // Add our Config object so it can be injected
            services.Configure<DataConnection>(Configuration.GetSection("ConnectionStrings"));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,
           IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthorization();
            app.AddSwaggerMidleware(apiVersionDescriptionProvider);

            app.UseMiddleware<ErrorHandlerMiddleware>();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
