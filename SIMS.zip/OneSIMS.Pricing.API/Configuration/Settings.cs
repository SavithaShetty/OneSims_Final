﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OneSIMS.Pricing.API.Configuration
{
    public class Settings
    {        

        public List<User> users { get; set; }

        public AppraisalPricingModel appraisalPricingModel { get; set; }

    }
}
