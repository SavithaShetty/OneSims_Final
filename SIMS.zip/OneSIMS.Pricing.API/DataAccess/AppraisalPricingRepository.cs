﻿using Microsoft.Extensions.Options;
using System;
using Sonic.OneSIMS.Infrastructure.Persistence;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using OneSIMS.Pricing.API.Entities;

namespace OneSIMS.Pricing.API.DataAccess
{
    public class AppraisalPricingRepository : BaseRespository, IAppraisalPricingRepository
    {
        public AppraisalPricingRepository(IOptions<DataConnection> dataConnection) : base(dataConnection) { }

        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing)
        {
            IDataReader dataReader = null;
            bool _priceResponse = false;
            try
            {

                SqlCommand query = _database.GetStoredProcSqlCommand("PRC_Update_SuggestionPriceFromRetailPricing");
                _database.AddInSqlParameter(query, "@Vehicle_Id", SqlDbType.BigInt, appraisalPricing.vehicle_id);
                _database.AddInSqlParameter(query, "@Store_Id", SqlDbType.SmallInt, appraisalPricing.store_id);
                _database.AddInSqlParameter(query, "@Invtr_Id", SqlDbType.SmallInt, appraisalPricing.invtr_id);
                _database.AddInSqlParameter(query, "@Price", SqlDbType.Decimal, appraisalPricing.price);
                _database.AddInSqlParameter(query, "@Confidence", SqlDbType.VarChar, appraisalPricing.confidence);
                _database.AddInSqlParameter(query, "@request_id", SqlDbType.BigInt, appraisalPricing.request_id);
                _database.AddInSqlParameter(query, "@request_type", SqlDbType.VarChar, appraisalPricing.request_type);
                _database.AddInSqlParameter(query, "@price_type", SqlDbType.VarChar, appraisalPricing.price_type);
                dataReader = _database.ExecuteReader(query);
                while (dataReader.Read())
                {
                    _priceResponse = Convert.ToBoolean(dataReader["SUCCESS"]);
                }

                return _priceResponse;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
            }
            return _priceResponse;
        }

        public PushPriceRequest GetAppraisalPricingRequest(short CID, long VID, short SID, short IID)
        {
            IDataReader dataReader = null;
            PushPriceRequest pushPriceRequest = new PushPriceRequest();
            try
            {
                SqlCommand query = _database.GetStoredProcSqlCommand("PRC_Get_AppraisalPricingRequest");
                _database.AddInSqlParameter(query, "@CompanyID", SqlDbType.SmallInt, CID);
                _database.AddInSqlParameter(query, "@VehicleID", SqlDbType.BigInt, VID);
                _database.AddInSqlParameter(query, "@StoreID", SqlDbType.SmallInt, SID);
                _database.AddInSqlParameter(query, "@InvtrID", SqlDbType.SmallInt, IID);
                dataReader = _database.ExecuteReader(query);
                while (dataReader.Read())
                {
                    //pricepush.request_id = SQLAdapter.GetLong(dataReader, "Apraisal_id");
                    pushPriceRequest.Pricing_Market_Id = Convert.ToInt16(dataReader["PRICING_MARKET_ID"]);
                    pushPriceRequest.autocheck = Convert.ToInt32(dataReader["AutoCheck"]);
                    pushPriceRequest.request_type = Convert.ToString(dataReader["type"]);
                    pushPriceRequest.Curr_Status_ID = Convert.ToInt16(dataReader["Curr_Status_ID"]);
                    pushPriceRequest.vin = Convert.ToString(dataReader["vin"]);
                    pushPriceRequest.uvc = Convert.ToInt32(String.IsNullOrEmpty(dataReader["UVC"].ToString()) ? 0 : dataReader["UVC"]);
                    pushPriceRequest.odometer = Convert.ToInt32(dataReader["Mileage"]);
                    pushPriceRequest.kbb_id = Convert.ToInt32(dataReader["KBB_ID"]);
                    pushPriceRequest.chrome_style_id = Convert.ToString(dataReader["CHROME_STYLE_ID"]);
                    pushPriceRequest.callback = Convert.ToString(dataReader["callback"]);
                    pushPriceRequest.server = Convert.ToString(dataReader["server"]);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
            }
            return pushPriceRequest;
        }
    }
}
