﻿using OneSIMS.Pricing.API.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneSIMS.Pricing.API.DataAccess
{
    public interface IAppraisalPricingRepository
    {
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing);

        public PushPriceRequest GetAppraisalPricingRequest(short CID, long VID, short SID, short IID);
    }
}
