﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OneSIMS.Pricing.API.Entities;
using Newtonsoft.Json;
using AutoMapper;
using System.Text;
using OneSIMS.Pricing.API.Helpers;
using OneSIMS.Pricing.Services.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace OneSIMS.Pricing.API.Controllers
{
    [ApiVersion("1")]
    [ApiController]
    [Route("api/v{version:apiVersion}/AppraisalPrice")]
    [Produces("application/json")]


    public class AppraisalPriceController : ControllerBase
    {

        ////private readonly IMapper _mapper;

        public readonly AutoMapper.Configuration.IConfiguration _configuration;
        public IAppraisalPricingService _appraisalPricingLogic;

        public AppraisalPriceController(IAppraisalPricingService appraisalPricing)
        {
            _appraisalPricingLogic = appraisalPricing;
        }

        ///<summary>
        ///  This endpoint will be called by Sonic pricing team to acknowledge the appraisal pricing request 
        ///</summary>
        /// <remarks> 
        ///   After OneSIMS application placed a appraisal price request to Sonic pricing team endpoint
        ///   Sonic Pricing team call this endpoint with price value for requested vehicle
        ///</remarks>        
        ///<response code = "200" >
        ///<remarks>
        ///    Service Response details
        ///    <ul>
        ///      <li> Returns true for success</li>
        ///      <li> Returns false for failed</li>
        ///    </ul>
        /// </remarks>
        /// </response>
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>           
        [HttpPost("Response")]
        public ActionResult<bool> PushPrice([FromBody] AppraisalPricingResponse AppraisalPricing)
        {

            bool _priceRequest = false;
            _priceRequest = _appraisalPricingLogic.AppraisalPriceResponse(AppraisalPricing);
            return StatusCode(200, AppraisalPricing);


        }


        /// <summary>
        ///    This endpoint will place a On-Demand appraisal price request to Sonic Pricing endpoint
        /// </summary>
        ///   <remarks>This endpoint accepts the vehicle identity details as payload request then fetch required details from OneSIMS database and place pricing request</remarks>        
        ///<response code = "200" >
        /// <remarks>
        ///      Service Response details
        ///      <ul>
        ///        <li> Returns true if request placed successfully to Sonic Pricing endpoint</li>
        ///        <li> Returns false if request failed </li>
        ///      </ul>
        /// </remarks>
        /// </response>
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>           
        [HttpPost("Request")]
        public ActionResult<String> PushPriceToPricingModel([FromBody] VehicleParams vehicleParams)
        {
            String respResult = "";

            respResult = _appraisalPricingLogic.PushPriceToPricingModel(vehicleParams);

            return StatusCode(200, respResult);
        }

        [HttpGet("Test")]
        public ActionResult<String> Test()
        {
            String respResult = "Got Response from App3/Pricing";

         //   respResult = _appraisalPricingLogic.PushPriceToPricingModel(vehicleParams);

            return StatusCode(200, respResult);
        }
    }
}
