﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.AspNetCore.Mvc;
using OneSIMS.Pricing.API;
using Swashbuckle.AspNetCore.Swagger;
using FluentValidation;

namespace OneSIMS.Pricing.API.Extensions
{
    public static class SwaggerExtension
    {
        public static IServiceCollection AddSwaggerService(this IServiceCollection services)
        {

            var basicSecurityScheme= new OpenApiSecurityScheme
            {
                Description = "Input Basic authentication Username and Password",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.Http,
                Scheme = "basic",
                Reference=new OpenApiReference()
                {
                    Id="BasicAuth",                    
                    Type = ReferenceType.SecurityScheme
                }
               
            };
           
            services.AddSwaggerGen(setupAction=>
            {
                var provider = services.BuildServiceProvider();
                var service = provider.GetRequiredService<IApiVersionDescriptionProvider>();

                foreach (ApiVersionDescription description in service.ApiVersionDescriptions)
                {
                    setupAction.SwaggerDoc(description.GroupName, new OpenApiInfo()
                    {
                        Title = "Appraisal OnDemand Pricing Services",
                        Version = description.ApiVersion.ToString(),
                        Description = "Appraisal Pricing - API operations"
                    });
                    
                }

                setupAction.AddSecurityDefinition(basicSecurityScheme.Reference.Id, basicSecurityScheme);

                setupAction.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        basicSecurityScheme,
                        new List<string>()
                    }
                });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.XML";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                //... and tell Swagger to use those XML comments.
                setupAction.IncludeXmlComments(xmlPath);

            });

            return services;
        }

        public static IApplicationBuilder AddSwaggerMidleware(this IApplicationBuilder app, IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            //app.UseSwagger(c =>
            //{
            //    c.RouteTemplate = "/swagger/{documentName}/swagger.json";
            //});

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                foreach (ApiVersionDescription description in apiVersionDescriptionProvider.ApiVersionDescriptions)
                {
                    c.SwaggerEndpoint($"../swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                }

                // deep linking
                c.DefaultModelExpandDepth(2);
                c.EnableDeepLinking();
               // c.DisplayOperationId();
            });

           
            return app;
        }
    }
}
