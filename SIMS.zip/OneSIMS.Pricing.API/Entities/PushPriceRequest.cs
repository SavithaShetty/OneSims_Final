﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OneSIMS.Pricing.API.Entities
{
    public class PushPriceRequest
    {
        public string vin { get; set; }
        public string request_type { get; set; }
        public Int64 uvc { get; set; }
        public int odometer { get; set; }
        public int autocheck { get; set; }
        public int Pricing_Market_Id { get; set; }
        public long vehicle_id { get; set; }
        public short invtr_id { get; set; }
        public short Curr_Status_ID { get; set; }
        public long request_id { get; set; }
        public int kbb_id { get; set; }
        public string chrome_style_id { get; set; }
        public string callback { get; set; }
        public string server { get; set; }
        public PriceRequestedBy Requested_By { get; set; }
    }

    public enum PriceRequestedBy
    {
        Web,
        Online,
        Carcash
    }
}
