﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OneSIMS.Pricing.API.Entities
{
    public class VehicleParams
    {
        public short CID { get; set; }
        public long VID { get; set; }
        public short SID { get; set; }
        public short IID { get; set; }
    }
}
