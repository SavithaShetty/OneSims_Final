﻿using Microsoft.Extensions.Options;
using OneSIMS.Pricing.API.Configuration;
using OneSIMS.Pricing.API.DataAccess;
using OneSIMS.Pricing.API.Entities;
using OneSIMS.Pricing.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace OneSIMS.Pricing.Services
{
    public class AppraisalPricingService : IAppraisalPricingService
    {
        private readonly IAppraisalPricingRepository _appraisalPricingRepository;
        private AppraisalPricingModel _appraisalPricing;
        public AppraisalPricingService(IAppraisalPricingRepository appraisalPricingRepository, IOptions<Settings> settings)
        {
            _appraisalPricingRepository = appraisalPricingRepository;
            _appraisalPricing = settings.Value.appraisalPricingModel;
        }
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing)
        {
            bool _priceResponse = false;
            try
            {
                if (appraisalPricing.request_id != 0 && appraisalPricing.vehicle_id != 0
               && appraisalPricing.store_id != 0 && appraisalPricing.invtr_id != 0)
                {
                    _priceResponse = _appraisalPricingRepository.AppraisalPriceResponse(appraisalPricing);
                }
            }
            catch (Exception ex)
            {
                throw ex;
                // "Pushprice", "error on push price "+ Newtonsoft.Json.JsonConvert.SerializeObject(appraisalPricing).ToString()
            }
            return _priceResponse;
        }


        public string PushPriceToPricingModel(VehicleParams vehicleParams)
        {

            PushPriceRequest pushPriceRequest = new PushPriceRequest();
            pushPriceRequest = _appraisalPricingRepository.GetAppraisalPricingRequest(vehicleParams.CID, vehicleParams.VID, vehicleParams.SID, vehicleParams.IID);
            String respResult = "";
            StringBuilder strbuilder = new StringBuilder();
            strbuilder.Append("vin=" + pushPriceRequest.vin);
            strbuilder.Append("&request_type=" + pushPriceRequest.request_type);
            strbuilder.Append("&uvc=" + pushPriceRequest.uvc);
            strbuilder.Append("&odometer=" + pushPriceRequest.odometer);
            strbuilder.Append("&autocheck=" + pushPriceRequest.autocheck);
            strbuilder.Append("&pricing_market_id=" + pushPriceRequest.Pricing_Market_Id);
            strbuilder.Append("&vehicle_id=" + vehicleParams.VID);
            strbuilder.Append("&invtr_id=" + vehicleParams.IID);
            strbuilder.Append("&kbb_id=" + pushPriceRequest.kbb_id);
            strbuilder.Append("&request_id=" + pushPriceRequest.request_id);
            strbuilder.Append("&chrome_style_id=" + pushPriceRequest.chrome_style_id);
            strbuilder.Append("&callback=" + pushPriceRequest.callback);
            strbuilder.Append("&server=" + pushPriceRequest.server);

            try
            {

                //string URI = _appraisalPricing.BaseURL;
                //string userName = _appraisalPricing.UserName;
                //string password = _appraisalPricing.Password;
                string URI = "https://vpapi-uat.sonicautomotive.com/appraisals";
                string userName = "S!mscaller";
                string password = "Sonic123!";

                string myParameters = strbuilder.ToString();

                using (WebClient wc = new WebClient())
                {
                    // for SSL by pass
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                    wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                    string strcredential = string.Format("{0}:{1}", userName, password);
                    wc.Headers[HttpRequestHeader.Authorization] = string.Format("Basic {0}",
                    Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(strcredential)));
                    respResult = wc.UploadString(URI, myParameters);

                }

            }
            catch (Exception ex)
            {
                respResult = ex.Message;
            }
            return respResult;
        }
    }
}
