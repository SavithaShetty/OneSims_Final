﻿using System;
using System.Collections.Generic;
using System.Text;
using OneSIMS.Pricing;
using OneSIMS.Pricing.API.Entities;

namespace OneSIMS.Pricing.Services.Interfaces
{
  public  interface IAppraisalPricingService
    {
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing);

        public String PushPriceToPricingModel(VehicleParams vehicleParams);
    }

   
}
