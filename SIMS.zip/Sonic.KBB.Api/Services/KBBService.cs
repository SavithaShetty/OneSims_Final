﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Sonic.KBB.Api.Services
{
    public class KBBService : BaseService, IKBBService
    {
        public KBBService(IConfiguration configuration) : base(configuration)
        {
        }

        public object Applyconfiguration(ApplyConfigRequet applyConfigRequest)
        {
            return base.POST_ApplyConfig_Request(applyConfigRequest);
        }

        public object BookValues(BookValuesRequest booksRequest)
        {
            return base.POST_Books_Request(booksRequest);
        }

        public object DecodeVIN(DecodeVINRequest decoreRequest)
        {
            InputParams inputParameter = new InputParams();
            inputParameter.RequestSource = decoreRequest.RequestSource;
            inputParameter.VIN = decoreRequest.VIN;
           
            return base.Get_Http_Response_Object(inputParameter, KBBRestEndpoints.Decode);
        }

        public ResponseModel GetEquipmentOptionsByVehicleId(VehOptionRequest vehOptionRequest)
        {
            InputParams inputParameter = new InputParams();
            inputParameter.RequestSource = vehOptionRequest.RequestSource;
            inputParameter.VehicleId = vehOptionRequest.VehicleId;
            inputParameter.AppCategory = vehOptionRequest.AppCategory;
            return base.Get_Http_Response(inputParameter, KBBRestEndpoints.Options);
        }

        public ResponseModel GetMakeIDByYearID(string RequestSource, int YearId)
        {
            InputParams inputParameter = new InputParams();
            inputParameter.RequestSource = RequestSource;
            inputParameter.yearId = YearId;
           return base.Get_Http_Response(inputParameter, KBBRestEndpoints.Make);
          
        }

        public ResponseModel GetModelIDByMake_YearID(ModelRequest modelRequest)
        {
            InputParams inputParameter = new InputParams();
            inputParameter.RequestSource = modelRequest.RequestSource;
            inputParameter.yearId = modelRequest.YearId;
            inputParameter.makeid = modelRequest.MakeId;
            return base.Get_Http_Response(inputParameter, KBBRestEndpoints.Model);
        }

        public ResponseModel GetModelYearID_ByMake_Model_YearID(ModelYearRequest modelYearRequest)
        {
            InputParams inputParameter = new InputParams();
            inputParameter.RequestSource = modelYearRequest.RequestSource;
            inputParameter.yearId = modelYearRequest.YearId;
            inputParameter.makeid = modelYearRequest.MakeId;
            inputParameter.modelId = modelYearRequest.ModelId;
            return base.Get_Http_Response(inputParameter, KBBRestEndpoints.ModelYear);
        }

        public ResponseModel GetTrim_By_Year_Make_Model_ModelYearID(TrimRequest trimRequests)
        {
            InputParams inputParameter = new InputParams();
            inputParameter.RequestSource = trimRequests.RequestSource;
            inputParameter.yearId = trimRequests.YearId;
            inputParameter.makeid = trimRequests.MakeId;
            inputParameter.modelId = trimRequests.ModelId;
            inputParameter.modelYearId = trimRequests.ModelYearID;
            return base.Get_Http_Response(inputParameter, KBBRestEndpoints.Trim);
        }

        public ResponseModel getYearList()
        {
            return base.Get_Http_Response(null, KBBRestEndpoints.Year);
        }
         
    }
}
