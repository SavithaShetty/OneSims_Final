﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public interface IKBBService
    {
        ResponseModel GetMakeIDByYearID(string RequestSource, int YearId);
        ResponseModel getYearList();
        ResponseModel GetModelIDByMake_YearID(ModelRequest modelRequest);
        ResponseModel GetModelYearID_ByMake_Model_YearID(ModelYearRequest modelYearRequest);
        ResponseModel GetTrim_By_Year_Make_Model_ModelYearID(TrimRequest trimRequests);
        object DecodeVIN(DecodeVINRequest decoreRequest);
        ResponseModel GetEquipmentOptionsByVehicleId(VehOptionRequest vehOptionRequest);
        object Applyconfiguration(ApplyConfigRequet applyConfigRequest);
        object BookValues(BookValuesRequest booksRequest);
    }
}
