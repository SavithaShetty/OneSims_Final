﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.KBB.Api.Helpers;
using Sonic.KBB.Api.Security;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using System.Web.Http;

namespace Sonic.KBB.Api.Controllers
{
    [ApiVersion("1")]
    [Microsoft.AspNetCore.Mvc.Route("api/v{version:apiVersion}/KBB")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Microsoft.AspNetCore.Authorization.Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    public class KBBController : BaseController
    {
        ResponseData responseData = null;
        private readonly IKBBService _kbbService;
        /// <summary>
        /// Constructor to initiate configuration and rest client
        /// </summary>
        /// <param name="configuration"></param>
        public KBBController(IConfiguration configuration, IKBBService kbbService) : base(configuration)
        {
            responseData = new ResponseData();
            this._kbbService = kbbService;

        }

        /// <summary>
        /// Get years list
        /// </summary>
        /// <param name="RequestSource">Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..</param>
        /// <remarks>Get the years</remarks>
        /// <response code="200">Returns the years</response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("years")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(YearResponse[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> GetYearsList([FromQuery][Required] string RequestSource)
        {
            try
            { 
                return Ok(_kbbService.getYearList().items);
            }
            catch (Exception ex)
            {
                throw new Exception("Call to GetYears method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Get the list of Makes for the provided YearId 
        /// </summary>         
        /// <remarks>Get list of Makes for the provided YearID, RequestSource is to categorize the request payload from different source and log the same if necessary.
        /// <br />     
        /// <br /> 
        /// RequestSource = Empty or YearId less than or equal to 0  --- Bad Request 
        /// <br /> 
        /// RequestSource != Empty and YearId greater than 0  --- Successful Result
        /// </remarks>
        /// <response code="200">Success: Returns list of Makes for the provided YearId successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>     
        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("makes")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(MakeResponse[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> GetMakeIDByYearID([Microsoft.AspNetCore.Mvc.FromQuery] MakeRequest makeRequest)
        {
            try
            {
                return Ok(_kbbService.GetMakeIDByYearID(makeRequest.RequestSource, makeRequest.YearId).items);
            }
            catch (Exception ex)
            {
                throw new Exception("Call to makes method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Get Model list by passing Make ID and Year ID
        /// </summary>
        /// <remarks>Get the list of Models</remarks>
        /// <response code="200">Success: Returns list of Model for the provided Make ID and Year ID successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("models")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ModelResponse[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> GetModelIDByMake_YearID([Microsoft.AspNetCore.Mvc.FromQuery] ModelRequest modelRequest)
        {
            try
            {
                return Ok(_kbbService.GetModelIDByMake_YearID(modelRequest).items);
            }
            catch (Exception ex)
            {
                throw new Exception("Call to models method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Get ModelYearID by passing Make ID, Model ID and Year ID
        /// </summary>
        /// <remarks>Get ModelYearID by passing Make ID, Model ID and Year ID</remarks>
        /// <response code="200">Success: Returns ModelYearID for the provided Make ID, Model ID and Year ID successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("modelyears")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ModelYearResponse[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> GetModelYearID_ByMake_Model_YearID([FromQuery] ModelYearRequest modelYearRequest)
        {
            try
            {
                return Ok(_kbbService.GetModelYearID_ByMake_Model_YearID(modelYearRequest).items);
            }
            catch (Exception ex)
            {
                throw new Exception("Call to modelyears method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Get list of TrimId by passing Make ID, Model ID, Year ID and ModelYearID
        /// </summary>
        /// <remarks>Get list of TrimId by passing Make ID, Model ID, Year ID and ModelYearID</remarks>
        /// <response code="200">Success: Returns list of TrimId for the provided  Make ID, Model ID, Year ID and ModelYearID successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("GetTrim")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(TrimResponse[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> GetTrim_By_Year_Make_Model_ModelYearID([FromQuery] TrimRequest trimRequests)
        {
            try
            {
                return Ok(_kbbService.GetTrim_By_Year_Make_Model_ModelYearID(trimRequests).items);
            }
            catch (Exception ex)
            {
                throw new Exception("Call to GetTrim method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Decode VIN
        /// </summary>
        /// <remarks>Decode the VIN Details</remarks>
        /// <response code="200">Success: Returns list of decoded details for the provided VIN successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("DecodeVIN")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(DecodeResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> DecodeVIN([FromQuery] DecodeVINRequest decodeRequest)
        {
            try
            {
                return Ok(_kbbService.DecodeVIN(decodeRequest));
            }
            catch (Exception ex)
            {
                throw new Exception("Call to DecodeVIN method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Get Vehicle options which includes Engine, DriveTrain, Transmission and Options based on different CategoryName and OptionType
        /// </summary>
        /// <remarks>Get Vehicle options which includes Engine, DriveTrain, Transmission and Options based on different CategoryName and OptionType Ex:
        /// <br />
        /// <br />
        /// For Engine -- "optionType": "Equipment" and "CategoryName": "Engine"
        /// <br />
        /// <br />
        /// For Transmission -- "optionType": "Equipment" and "CategoryName": "Transmission"
        /// <br />
        /// For DriveTrain -- "optionType": "Equipment" and "CategoryName": "Drivetrain"
        /// <br />
        /// <br />
        /// For Factory Options -- "optionType": "Option"
        /// <br />
        /// </remarks>
        /// <response code="200">Success: Returns list of vehicle Options for the provided VehicleId successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpGet("GetEquipmentOptionsByVehicleId")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VehOptionsResponse[]))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEquipmentOptionsByVehicleId([FromQuery] VehOptionRequest vehOptionRequest)
        {
            try
            {
                return Ok(_kbbService.GetEquipmentOptionsByVehicleId(vehOptionRequest).items);
            }
            catch (Exception ex)
            {
                throw new Exception("Call to GetEquipmentOptionsByVehicleId method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Post Vehicle options into configuration to get final configuration options
        /// </summary>
        /// <remarks>Post Vehicle options into configuration to get final configuration options
        /// <br />
        /// If endpoint is getting called for the first time then vehicleOptionIds will be sent as [] i.e  vehicleOptionIds: [] for the provided VehicleId
        /// <br />
        /// For the subsequent endpoint calls Response of the first time endpoint call will be sent as startingconfiguration with parameter name called VehicleOptionIds.
        /// </remarks>
        /// <response code="200">Success: Returns list of VehicleOptionIds for the provided VehicleId successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpPost("Applyconfiguration")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ApplyConfigResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> Applyconfiguration([Microsoft.AspNetCore.Mvc.FromBody] ApplyConfigRequet applyConfigRequest)
        {
            try
            {
                return Ok(_kbbService.Applyconfiguration(applyConfigRequest));
            }
            catch (Exception ex)
            {
                throw new Exception("Call to Applyconfiguration method failed. " + ex.Message);
            }
        }

        /// <summary>
        /// Post the book values along with configuration
        /// </summary>
        /// <remarks>Post the book values along with configuration to get price values for differnt price types
        /// <br />
        /// <br />
        ///  vehicleOptionIds : Response of applyconfiguration enpoint for the provided VehicleId.
        /// </remarks>
        /// <response code="200">Success: Returns list of price values for the provided configuration successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [MapToApiVersion("1")]
        [Microsoft.AspNetCore.Mvc.HttpPost("bookvalues")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(BookResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(ValidationProblemDetails))]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(ProblemDetails))]
        public async Task<IActionResult> BookValues([Microsoft.AspNetCore.Mvc.FromBody] BookValuesRequest booksRequest)
        {
            try
            {
                return Ok(_kbbService.BookValues(booksRequest));
            }
            catch (Exception ex)
            {
                throw new Exception("Call to bookvalues method failed. " + ex.Message);
            }
        }
    }
}
