﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Sonic.KBB.Api.Controllers
{
    [ApiVersion("10")]
    [Route("api/v{version:apiVersion}/KBB")]
    [ApiController]
    //[ApiExplorerSettings(GroupName = "Unit Testing")]
    [AllowAnonymous]
    public class UnitTestController : Controller
    {
        KBBController _kbbService = null;

        public UnitTestController(IConfiguration config)
        {
            //_kbbService = new KBBController(config);
        }
        [HttpGet("GetYearsList")]
        //[Route("/years")]
        public virtual IActionResult GetYearsList()
        {            
           object response = _kbbService.GetYearsList(null);
            return Json(response);
        }

        [HttpGet("GetMakebyYearID")]
        //[Route("/years")]
        public virtual IActionResult GetMakebyYearID()
        {
           // object response = _kbbService.GetMakeIDByYearID("SIMS",2018);
            return Ok(null);
        }
    }
}
