﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Sonic.OneSIMS.Infrastructure;
using System;
using System.Threading.Tasks;

namespace Sonic.KBB.Api.Controllers
{
    public class BaseController : Controller
    {
        string URL = string.Empty;
        string api_key = "";
        string baseUrl = "";
        ConfigSettings _configSettings = null;
        KBBRestClient _Client = null;
        public BaseController(IConfiguration configuration)
        {
            _configSettings = new ConfigSettings(configuration);            
            baseUrl = _configSettings.GetKBBRestClientURL();
            api_key = _configSettings.GetKBBRestClientAPIKey();
            _Client = new KBBRestClient(configuration);
        }
        protected object Get_Http_Response(InputParams inputParameters, KBBRestEndpoints kbbEndPoint)
        {
            URL = GetURL(inputParameters, kbbEndPoint);
            Task<ResponseModel> response = HTTPClientWrapper<ResponseModel>.Get(URL);
            //var response = _Client.Get(URL);
            return response.Result.items;
        }

        private string GetURL(InputParams inputParams, KBBRestEndpoints endpoint)
        {

            switch ((int)endpoint)
            {
                case 1:
                    //Decode
                    //https://sandbox.api.kbb.com/idws/vehicle/vin/id/WBA3B9C57FF589991?api_key=68065627c9de4a25a1888b371&limit=1000
                    URL = "vehicle/vin/id/" + inputParams.VIN + "?api_key=" + api_key;
                    break;
                case 2:
                    //Year
                    //vehicle/years?api_key=68065627c9de4a25a1888b371
                    URL = "vehicle/years?api_key=" + api_key;
                    break;
                case 3:
                    //Make
                    //https://sandbox.api.kbb.com/idws/vehicle/makes?api_key=68065627c9de4a25a1888b371&yearId=2001&limit=1000 
                    URL = "vehicle/makes?api_key=" + api_key + "&yearId=" + inputParams.yearId;
                    break;
                case 4:
                    //Model
                    //https://sandbox.api.kbb.com/idws/vehicle/models?api_key=68065627c9de4a25a1888b371&makeid=5&yearId=2009&limit=1000
                    URL = "vehicle/models?api_key=" + api_key + "&makeid=" + inputParams.makeid + "&yearId=" + inputParams.yearId;
                    break;
                case 5:
                    //Trim
                    //https://sandbox.api.kbb.com/idws/vehicle/trims?api_key=68065627c9de4a25a1888b371&modelId=14&yearId=2009&limit=1000
                    // URL = "vehicle/trims?api_key=" + api_key + "&modelId=" + inputParams.modelId + "&yearId=" + inputParams.yearId;
                    //https://sandbox.api.kbb.com/idws/vehicle/vehicles?api_key=68065627c9de4a25a1888b371&limit=50&yearId=2014&makeId=4&modelId=4&modelYearId=90893
                    URL = "vehicle/vehicles?api_key=" + api_key + "&yearId=" + inputParams.yearId + "&makeid=" + inputParams.makeid + "&modelId=" + inputParams.modelId + "&modelYearId=" + inputParams.modelYearId;
                    break;
                case 6:
                    //Engine
                    //https://sandbox.api.kbb.com/idws/vehicle/vehicleoptions?api_key=68065627c9de4a25a1888b371&VehicleId=434436&limit=100
                    URL = "vehicle/vehicleoptions?api_key=" + api_key + "&VehicleId=" + inputParams.VehicleId;
                    break;
                case 7:
                    //Drivetrain
                    //https://sandbox.api.kbb.com/idws/vehicle/vehicleoptions?api_key=68065627c9de4a25a1888b371&VehicleId=434436&limit=100
                    URL = "vehicle/vehicleoptions?api_key=" + api_key + "&VehicleId=" + inputParams.VehicleId;

                    break;
                case 8:
                    //Transmission
                    //https://sandbox.api.kbb.com/idws/vehicle/vehicleoptions?api_key=68065627c9de4a25a1888b371&VehicleId=434436&limit=100
                    URL = "vehicle/vehicleoptions?api_key=" + api_key + "&VehicleId=" + inputParams.VehicleId;
                    break;
                case 9:
                    //Options
                    //https://sandbox.api.kbb.com/idws/vehicle/vehicleoptions?api_key={{apiKey}}&limit=100&VehicleId=434436&ApplicationFilter=Consumer
                    URL = "vehicle/vehicleoptions?api_key=" + api_key + "&VehicleId=" + inputParams.VehicleId + "&ApplicationFilter=" + GetApplicationCategory(inputParams.AppCategory);
                    break;
                case 10:
                    //Books post call
                    //https://sandbox.api.kbb.com/idws/vehicle/values?api_key=68065627c9de4a25a1888b371
                    URL = "vehicle/values?api_key=" + api_key;
                    break;
                case 11:
                    //ModelYearID to Get Series
                    //https://sandbox.api.kbb.com/idws/vehicle/modelyears?api_key=68065627c9de4a25a1888b371&yearId=2019&makeid=783&modelid=27905&limit=50
                    URL = "vehicle/modelyears?api_key=" + api_key + "&yearId=" + inputParams.yearId + "&makeid=" + inputParams.makeid + "&modelId=" + inputParams.modelId;
                    break;
                case 12:
                    //ModelYearID to Get Series
                    //https://sandbox.api.kbb.com/idws/vehicle/modelyears?api_key=68065627c9de4a25a1888b371&yearId=2019&makeid=783&modelid=27905&limit=50
                    URL = "vehicle/applyconfiguration?api_Key=" + api_key;
                    break;
                default:
                    Console.WriteLine("Default case");
                    break;
            }
            return (baseUrl + URL + "&limit=1000");
        }

        internal IActionResult ThrowInternalServerException(Exception ex)
        {
           return this.StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }

        private string GetApplicationCategory(int appCategory)
        {
            switch (appCategory)
            {
                case 1:
                    {
                        return "Dealer";
                    }
                case 2:
                    {
                        return "Consumer";
                    }
                default:
                    {
                        return "Dealer";
                    }
            }

        }

        internal object POST_ApplyConfig_Request(ApplyConfigRequet requestParameters)
        {
            try
            {
                URL = GetURL(null, KBBRestEndpoints.ApplyConfig);
                string applyConfigBody = JsonConvert.SerializeObject(requestParameters);
                var response = HTTPClientWrapper<object>.PostRequest(URL, applyConfigBody);
                if (response != null)
                    return response.Result;
                else
                    return "Unable to evaluate the request";
            }
            catch (Exception ex)
            {
                return "Unable to evaluate the request";
            }
        }

        internal object POST_Books_Request(BookValuesRequest requestParameters)
        {
            try
            {
                URL = GetURL(null, KBBRestEndpoints.Books);
                string applyConfigBody = JsonConvert.SerializeObject(requestParameters);
                var response = HTTPClientWrapper<object>.PostRequest(URL, applyConfigBody);
                if (response != null)
                    return response.Result;
                else
                    return "Unable to evaluate the request";
            }
            catch (Exception ex)
            {
                return "Unable to evaluate the request";
            }
        }
    }
    public enum KBBRestEndpoints
    {
        Decode = 1,
        Year = 2,
        Make = 3,
        Model = 4,
        Trim = 5,
        Engine = 6,
        Drivetrain = 7,
        Transmission = 8,
        Options = 9,
        Books = 10,
        ModelYear = 11,
        ApplyConfig = 12,
    }
}
