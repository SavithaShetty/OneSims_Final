﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class VehOptionsResponse
    {
        public int VehicleOptionId { get; set; }

        public int vehicleId { get; set; }

        public string optionType { get; set; }

        public string optionName { get; set; }

        public string categoryName { get; set; }

        public string categoryGroup { get; set; }

        public int sortOrder { get; set; }

        public bool isConsumer { get; set; }

        public bool isTypical { get; set; }

        public bool isConfigurable { get; set; }

        public bool hasRelationships { get; set; }
    }
}
