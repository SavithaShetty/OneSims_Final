﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class MakeResponse
    {
        public int makeId { get; set; }
        public string makeName { get; set; }
    }
}
