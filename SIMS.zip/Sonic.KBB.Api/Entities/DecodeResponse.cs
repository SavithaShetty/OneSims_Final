﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class VehicleOption
    {
        public bool isVinDecoded { get; set; }
        public int vehicleOptionId { get; set; }
        public int vehicleId { get; set; }
        public string optionType { get; set; }
        public string optionName { get; set; }
        public string categoryName { get; set; }
        public string categoryGroup { get; set; }
        public int sortOrder { get; set; }
        public bool isConsumer { get; set; }
        public bool isTypical { get; set; }
        public bool isConfigurable { get; set; }
        public bool hasRelationships { get; set; }
    }

    public class VinResult
    {
        public int vehicleId { get; set; }
        public string vehicleClass { get; set; }
        public string vehicleName { get; set; }
        public int yearId { get; set; }
        public int makeId { get; set; }
        public string makeName { get; set; }
        public int modelId { get; set; }
        public string modelName { get; set; }
        public int modelYearId { get; set; }
        public int trimId { get; set; }
        public string trimName { get; set; }
        public string modelPlusTrimName { get; set; }
        public int doors { get; set; }
        public string bodyStyle { get; set; }
        public string genericBodyStyle { get; set; }
        public string oemBodyStyle { get; set; }
        public int sortOrder { get; set; }
        public bool isConsumer { get; set; }
        public List<VehicleOption> vehicleOptions { get; set; }
    }
    public class DecodeResponse
    {
        public List<VinResult> vinResults { get; set; }
    }
}
