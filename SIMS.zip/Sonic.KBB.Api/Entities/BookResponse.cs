﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class BookResponse
    {
        public EquipmentPrices[] prices { get; set; }
    }

    public class EquipmentPrices
    {
        public int priceTypeId { get; set; }

        public string priceTypeDisplay { get; set; }

        public decimal mileageAdjustment { get; set; }

        public decimal optionAdjustment { get; set; }

        public decimal configuredValue { get; set; }

        public OptionPrices[] optionPrices { get; set; }

        public DateTime valuationDate { get; set; }

        public int typicalMileage { get; set; }

    }
    public class OptionPrices
    {
        public int vehicleOptionId { get; set; }

        public decimal price { get; set; }

        public bool removalAdjustment { get; set; }
    }
}
