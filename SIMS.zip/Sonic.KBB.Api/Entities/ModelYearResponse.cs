﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class ModelYearResponse
    {
        public int modelYearId { get; set; }
        public int yearId { get; set; }
        public int makeId { get; set; }
        public string makeName { get; set; }
        public int modelId { get; set; }
        public string modelName { get; set; }
    }
}
