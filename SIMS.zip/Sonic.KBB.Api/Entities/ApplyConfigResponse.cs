﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class ApplyConfigResponse
    {
        public ApplyConfigResponse()
        {
            this.finalConfiguration = new FinalConfiguration();
        }

        public FinalConfiguration finalConfiguration { get; set; }
    }
    public class FinalConfiguration
    {
        public int VehicleId { get; set; }

        public List<int> vehicleOptionIds { get; set; }
    }
}
