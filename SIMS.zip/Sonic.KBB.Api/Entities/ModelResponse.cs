﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class ModelResponse
    {
        public int modelId { get; set; }
        public string modelName { get; set; }
    }
}
