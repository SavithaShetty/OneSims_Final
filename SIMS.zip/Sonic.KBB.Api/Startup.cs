using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Sonic.KBB.Api.Configuration;
using Sonic.KBB.Api.Extensions;
using Sonic.KBB.Api.Helpers;
using Sonic.KBB.Api.Security;
using Sonic.KBB.Api.Services;

namespace Sonic.KBB.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        { 
            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));

            services.AddControllers(config =>
            {
                config.ReturnHttpNotAcceptable = true;
                config.Filters.Add(typeof(ValidateModelStateAttribute));
            }).AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());


            services.AddAuthentication(BasicAuthenticationHandler.SchemeName)
               .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.SchemeName, null);


            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IKBBService, KBBService>();

            services.AddVersionService();

            services.AddSwaggerService();

            services.AddControllers().AddNewtonsoftJson();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,
            IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();
          

            app.UseAuthorization();
            app.AddSwaggerMidleware(apiVersionDescriptionProvider);
            app.UseMiddleware<ErrorHandlerMiddleware>();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
