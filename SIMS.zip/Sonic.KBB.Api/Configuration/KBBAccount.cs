﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api.Configuration
{
    public class KBBAccount
    {
        public string apiKey { get; set; }

        public string baseURL { get; set; }

        public string mediaType { get; set; }
    }
}
