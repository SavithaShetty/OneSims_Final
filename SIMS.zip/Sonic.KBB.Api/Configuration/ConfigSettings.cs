﻿using Microsoft.Extensions.Configuration;
using Sonic.KBB.Api.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class ConfigSettings
    {
        public IConfiguration _configuration { get; }

        public Settings settingObj;
        public ConfigSettings(IConfiguration configuration)
        {
            _configuration = configuration;
            settingObj = _configuration.GetSection("Settings").Get<Settings>();
        }
        public string GetKBBRestClientAPIKey()
        {
            return settingObj.kbbAccount.apiKey;
        }
        public string GetKBBRestClientURL()
        {
            return settingObj.kbbAccount.baseURL;
        }
        public string GetMediaType()
        {
            return settingObj.kbbAccount.mediaType;
        }

        public string GetKBBAuthUserName()
        {
            return settingObj.users.Select(x=>x.Username).FirstOrDefault();
        }

        public string GetKBBAuthPassword()
        {
            return settingObj.users.Select(x => x.Password).FirstOrDefault();
        }
    }
}
