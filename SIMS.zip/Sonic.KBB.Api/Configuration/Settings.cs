﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api.Configuration
{
    public class Settings
    {
        public KBBAccount kbbAccount { get; set; }

        public List<User> users { get; set; }
    }
}
