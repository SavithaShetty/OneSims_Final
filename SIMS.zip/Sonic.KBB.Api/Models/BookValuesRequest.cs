﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
   public class BookValuesRequest
    {
        public BookValuesRequest()
        {
            this.Configuration = new VehConfiguration();
        }
        public VehConfiguration Configuration { get; set; }

        public DateTime ValuationDate { get; set; }

        public int zipcode { get; set; }

        public int Mileage { get; set; }
    }
    public class BookValueValidator: AbstractValidator<BookValuesRequest>
    {
        public BookValueValidator()
        {
            RuleFor(x => x.Mileage).NotEmpty().NotEqual(0);
            RuleFor(x => x.zipcode).NotEmpty();
            RuleFor(x => x.ValuationDate).NotEmpty().LessThan(DateTime.Today);
            RuleFor(x => x.Configuration.VehicleId).NotEmpty().NotEqual(0);
            RuleFor(x => x.Configuration.VehicleOptionIds.GetValue(0)).NotEqual(0).WithMessage("Vehicle option Ids cannot be empty or zero").WithName("VehicleOptionIds");
        }
    }

    public class VehConfiguration
    {
        public int VehicleId { get; set; }

        public int[] VehicleOptionIds { get; set; }
    }
}
