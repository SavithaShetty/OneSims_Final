﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class ApplyConfigRequet 
    {
        public ApplyConfigRequet()
        {
            this.StartingConfiguration = new ApplyConfiguration();
            this.ConfigurationChanges = new List<ConfigurationChange>();
        }
        public ApplyConfiguration StartingConfiguration { get; set; }

        public List<ConfigurationChange> ConfigurationChanges { get; set; }
    }

    public class ApplyConfigValidator : AbstractValidator<ApplyConfigRequet>
    {
        public ApplyConfigValidator()
        {
            RuleFor(x => x.StartingConfiguration.VehicleId).NotEmpty().NotEqual(0);
        }
    }

    public class ConfigurationChange
    {
        public int Sequence { get; set; }

        public int VehicleOptionId { get; set; }

        public string Action { get; set; }
    }

    public class ApplyConfiguration
    {
        public int VehicleId { get; set; }

        public int[] vehicleOptionIds { get; set; }
    }
}
