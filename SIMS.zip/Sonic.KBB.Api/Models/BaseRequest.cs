﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class BaseRequest
    { 
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..
        /// </summary>
        public string RequestSource { get; set; }
        ///// <summary>
        ///// Application category ex: 0 - Consumer, 1 - Dealer
        ///// </summary>
        //public int AppCategory { get; set; }
        ///// <summary>
        ///// Vehicle Class ex: 0 - NewCar, 1 - UsedCar
        ///// </summary>
        //public int VehicleClass { get; set; }
        ///// <summary>
        ///// Date on which records gets retrieved from service, Default - Today date
        ///// </summary>
        //public DateTime Date { get; set; }
        ///// <summary>
        ///// Region Id
        ///// </summary>
        //public string regionId { get; set; }
    }

    public enum ApplicationCategory
    {
        Consumer = 0,
        Dealer = 1,
    }

    public enum VehicleClassEnum
    {
        NewCar = 0,
        UsedCar = 1
    }
}
