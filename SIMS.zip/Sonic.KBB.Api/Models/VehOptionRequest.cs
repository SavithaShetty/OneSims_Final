﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class VehOptionRequest 
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// Trim Id will be passed as Vehicle Id
        /// </summary>
        public int VehicleId { get; set; }
        /// <summary>
        /// Application category ex: 0 - Consumer, 1 - Dealer
        /// </summary>
        public int AppCategory { get; set; }
    }

    public class VehOptionValidator : AbstractValidator<VehOptionRequest>
    {
        public VehOptionValidator()
        {
            RuleFor(x => x.RequestSource).NotEmpty();
            RuleFor(x => x.VehicleId).NotEmpty().NotEqual(0);
        }
    }
}
