﻿using System;

namespace Sonic.KBB.Api
{
    public class InputParams
   {
        public string Api_Key { get; set; }
        public int AppCategory { get; set; }
        public int VehicleClass { get; set; }
        public string VIN { get; set; }
        public DateTime Date { get; set; }
        public int VehicleId { get; set; }
        public int yearId { get; set; }
        public int makeid { get; set; }
        public int modelId { get; set; }

        public string regionId { get; set; }
        public int Mileage { get; set; }
        public int modelYearId { get; set; }

        public string RequestSource { get; set; }

    }
}

