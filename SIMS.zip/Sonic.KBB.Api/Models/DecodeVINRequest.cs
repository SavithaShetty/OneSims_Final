﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class DecodeVINRequest 
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// VIN to be decoded
        /// </summary>
        public string VIN { get; set; } 
    }

    public class DecodeVinValidator : AbstractValidator<DecodeVINRequest>
    {
        public DecodeVinValidator()
        {
            RuleFor(x => x.RequestSource).NotEmpty();
            RuleFor(x => x.VIN).NotEmpty().Length(17);

        }
    }
}
