﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Sonic.KBB.Api
{
    public class JsonResponseData
    {
        [JsonProperty("data")]
        public object Data { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
    }

    public class ResponseData
    {
        
        /// <summary>
        /// Contains data
        /// </summary>
        [JsonProperty("data")]
        public object Data { get; set; }
        /// <summary>
        /// Contains Message
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <summary>
        /// Contains Status Code
        /// </summary>
        [JsonProperty("statusCode")]
        public HttpStatusCode StatusCode { get; set; }
    }

    public class Errors
    {
        public string code { get; set; }

        public string message { get; set; }
    }

    public class ResponseModel
    {
        public string href { get; set; }
        public int limit { get; set; }
        public int count { get; set; }
        public List<object> items { get; set; }
    }
    
}
