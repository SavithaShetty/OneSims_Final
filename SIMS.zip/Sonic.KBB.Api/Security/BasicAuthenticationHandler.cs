﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Sonic.KBB.Api.Services;
using System;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace Sonic.KBB.Api.Security
{
    /// <summary>
    /// class to handle basic authentication.
    /// </summary>
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {

        /// <summary>
        /// scheme name for authentication handler.
        /// </summary>
        public const string SchemeName = "Basic";

        private readonly IUserService _userService;

        public BasicAuthenticationHandler(
            IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger, UrlEncoder encoder,
            ISystemClock clock,
            IUserService userService)
            : base(options, logger, encoder, clock)
        {
            _userService = userService;
        }

        /// <summary>
        /// verify that require authorization header exists and handle decode data.
        /// </summary>
        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {

            // skip authentication if endpoint has [AllowAnonymous] attribute
            var endpoint = Context.GetEndpoint();
            if (endpoint?.Metadata?.GetMetadata<IAllowAnonymous>() != null)
                return AuthenticateResult.NoResult();
            ProblemDetails problemDetails = new ProblemDetails();
            problemDetails.Title = "Authorization Error";
            if (!Request.Headers.ContainsKey("Authorization"))
            {

                if (!Context.Response.HasStarted)
                {
                    Context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    Context.Response.ContentType = "application/json";
                    problemDetails.Status = StatusCodes.Status401Unauthorized;
                    problemDetails.Detail = "Request doesn't contains header";
                    var result = JsonConvert.SerializeObject(problemDetails);
                    await Context.Response.WriteAsync(result);
                }
                return AuthenticateResult.Fail("Missing Authorization Header");
            }

            Boolean isAuthenticated = false;
            try
            {
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(':');
                string username = credentials[0];
                string password = credentials[1];
                isAuthenticated = await _userService.Authenticate(username, password);
            }
            catch
            {
                if (!Context.Response.HasStarted)
                {
                    Context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    Context.Response.ContentType = "application/json";
                    problemDetails.Status = StatusCodes.Status401Unauthorized;
                    problemDetails.Detail = "Invalid Authorization Header";
                    var result = JsonConvert.SerializeObject(problemDetails);
                    await Context.Response.WriteAsync(result);
                }
                return AuthenticateResult.Fail("Invalid Authorization Header");
            }

            if (!isAuthenticated)
            {
                if (!Context.Response.HasStarted)
                {
                    Context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    Context.Response.ContentType = "application/json";
                    problemDetails.Status = StatusCodes.Status401Unauthorized;
                    problemDetails.Detail = "Invalid Username or Password";
                    var result = JsonConvert.SerializeObject(problemDetails);
                    await Context.Response.WriteAsync(result);
                }
                return AuthenticateResult.Fail("Invalid Username or Password");
            }

            //var claims = new[] {
            //        new Claim(ClaimTypes.NameIdentifier, user.Username),
            //        new Claim(ClaimTypes.Name, user.Username),
            //    };

            //var identity = new ClaimsIdentity(claims, Scheme.Name);

            var identity = new ClaimsIdentity(Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return AuthenticateResult.Success(ticket);
        }
    }
}
