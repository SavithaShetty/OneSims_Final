﻿using Microsoft.Extensions.Configuration;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Http;

namespace Sonic.KBB.Api
{
    public class KBBRestClient : ApiController
    {
        string baseUrl = "";// ConfigSettings.GetKBBRestClientURL();
        string api_key = ""; // ConfigSettings.GetKBBRestClientAPIKey();
        ConfigSettings _configSettings = null;

        public KBBRestClient(IConfiguration configuration)
        {
            _configSettings = new ConfigSettings(configuration);
            baseUrl = _configSettings.GetKBBRestClientURL();
            api_key = _configSettings.GetKBBRestClientAPIKey();
        }
        public HttpClient GetHttpClient()
        {
            var client = new HttpClient();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11;
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            
            return client;
        }

        public IHttpActionResult Get(string URL)
        {
            ResponseData httpResponse = new ResponseData();
            httpResponse.Data = null;
            string message = string.Empty;
            try
            {
                using (var client = GetHttpClient())
                {
                    client.BaseAddress = new Uri(baseUrl + URL + "&limit=1000");
                    HttpResponseMessage response = client.GetAsync(client.BaseAddress).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var result = response.Content.ReadAsStringAsync().Result;
                        httpResponse.Data = result;
                        httpResponse.StatusCode = HttpStatusCode.OK;
                        httpResponse.Message = "Success";
                        return Ok(httpResponse);
                    }
                }
            }
            catch (Exception ex)
            {
                httpResponse.Data = new HttpError(ex, true);
                httpResponse.StatusCode = HttpStatusCode.InternalServerError;
                httpResponse.Message = "Failure";
              // Logger.LogError(ConfigSettings.GetCurrentUsername(), "AdvanceSearch", ex);
                return Content(HttpStatusCode.InternalServerError, httpResponse);
            }
            return Ok(httpResponse);
        }
        public IHttpActionResult Post(string URL,string postData)
        {

            ResponseData httpResponse = new ResponseData();
            httpResponse.Data = null;
            string message = string.Empty;
            try
            {
                using (var client = GetHttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    client.BaseAddress = new Uri(baseUrl + URL);
                    System.Net.Http.HttpContent content = new StringContent(postData, Encoding.UTF8, "application/json");
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("api_key", "68065627c9de4a25a1888b371");
                    HttpResponseMessage response = client.PostAsync(new Uri(baseUrl + URL), content).Result;
                    string description = string.Empty;
                    if (response.IsSuccessStatusCode)
                    {                         
                        var result = response.Content.ReadAsStringAsync().Result;
                        httpResponse.Data = result;
                        httpResponse.StatusCode = HttpStatusCode.OK;
                        httpResponse.Message = "Success";
                        return Ok(httpResponse);
                    }
                }
            }
            catch (Exception ex)
            {
                httpResponse.Data = new HttpError(ex, true);
                httpResponse.StatusCode = HttpStatusCode.InternalServerError;
                httpResponse.Message = "Failure";
               // Logger.LogError(ConfigSettings.GetCurrentUsername(), "AdvanceSearch", ex);
                return Content(HttpStatusCode.InternalServerError, httpResponse);
            }
            return Ok(httpResponse);
        }
    }

 

}



