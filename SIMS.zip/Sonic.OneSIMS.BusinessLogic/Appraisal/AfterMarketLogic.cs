﻿using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sonic.OneSIMS.BusinessLogic.Appraisal
{
    public class AfterMarketLogic : IAfterMarketLogic
    {
        private readonly IAfterMarketRepository _afterMarketRepository;

        public AfterMarketLogic(IAfterMarketRepository afterMarketRepository)
        {
            _afterMarketRepository = afterMarketRepository;
        }
                
        public bool AddAfterMarketAnswers(AMFO afterMarketQuestions)
        {
            return this._afterMarketRepository.AddAfterMarketAnswers(afterMarketQuestions);
        }        

        public List<AfterMarketQuestions> GetAfterMarketQuestions(long VehicleId, short StoreId, short InventoryId)
        {
            return this._afterMarketRepository.GetAfterMarketQuestions(VehicleId, StoreId, InventoryId);
        }
    }
}
