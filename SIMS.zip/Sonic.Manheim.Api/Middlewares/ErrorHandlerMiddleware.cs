﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using Sonic.Manheim.Api.Exceptions;
using System.Collections;
using System.Collections.Specialized;

namespace Sonic.Manheim.Api.Middlewares
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        //static readonly ILogger logger = Serilog.Log.ForContext<ErrorHandlerMiddleware>();
        //private string sourceName = "OneSIMSPortalAPI";
        //private string userName;
        //private string methodName;
        //private string customMessage;
        //Dictionary<string, string> servicedetils = new Dictionary<string, string>();
        public ErrorHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                var response = context.Response;
                response.ContentType = "application/json";
                var responseModel = new ProblemDetails();
                responseModel.Title = "Exception Occured";

                switch (error)
                {
                    case Exceptions.ApiException e:
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        responseModel.Status= (int)HttpStatusCode.InternalServerError;
                        responseModel.Title = responseModel.Title + "- " + e.Message;
                        responseModel.Detail = e.StackTrace;
                        
                        break;

                    case Exceptions.ValidationException e:
                        // custom validation error, so need to return validationProblem details
                        response.StatusCode = (int)HttpStatusCode.UnprocessableEntity;
                        //responseModel.ValidationErrors = e.Errors;
                        break;

                    case KeyNotFoundException e:
                        // not found error
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                        break;


                    default:

                        //ILogger logger = Log.ForContext<SQLWarpper>();
                        //SQLWarpper sQLWarpper=new SQLWarpper(logger);
                        //if (error.Data.Count >0) {
                        //    DictionaryEntry[] myArr = new DictionaryEntry[error.Data.Count];
                        //    error.Data.CopyTo(myArr, 0);
                        //    for (int i = 0; i < myArr.Length; i++)
                        //    {
                        //        if (i == 0) userName = myArr[0].Value.ToString();
                        //        if (i == 1) methodName = myArr[1].Value.ToString();
                        //        if (i == 2) customMessage = myArr[2].Value.ToString(); 
                        //    }
                        //    // Displays the values in the array.

                        //}
                        //sQLWarpper.Error(userName, sourceName, methodName, customMessage, error);
                        response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        responseModel.Status = (int)HttpStatusCode.InternalServerError;
                        responseModel.Title = responseModel.Title + "- " + error.Message;
                        responseModel.Detail = error.StackTrace;                       
                        break;
                }

                var result = JsonSerializer.Serialize(responseModel);

                await response.WriteAsync(result);
            }
        }
    }
}
