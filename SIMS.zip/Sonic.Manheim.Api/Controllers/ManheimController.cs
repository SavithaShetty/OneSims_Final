﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Sonic.Manheim.Api.Entities;
using Sonic.Manheim.Api.Entities.DecodeVin;
using Sonic.Manheim.Api.Entities.MakeModelTrim;
using Sonic.Manheim.Api.Entities.Transaction;
using Sonic.Manheim.Api.Helpers;
using Sonic.Manheim.Api.Security;
using Sonic.Manheim.Api.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Controllers
{
    /// <summary>
    /// Get Manheim related data.
    /// </summary>
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/Manheim")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    public class ManheimController : ControllerBase
    {
        private readonly IManheimService _manheimService;

        public ManheimController(IManheimService manheimService)
        {
            _manheimService = manheimService;
        }

        /// <summary>
        /// Get manheim transaction data based on manheim id and region.
        /// </summary>
        /// <param name="manheimId">Manheim Id Ex: 201301766060786</param>
        /// <param name="region">Region Ex: RE</param>        
        /// <param name="source">source Ex: Internal</param> 
        /// <response code="200">Returns Transaction Data</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>         
        [HttpGet("GetTransactionData/{manheimId}/{region}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<IEnumerable<ManheimTransactionData>>> GetTransactionData(string manheimId, string region, string source)
        {
            List<ManheimTransactionData> manheimTransactionData = _manheimService.GetTransactionData(manheimId, region, source);
            return Ok(manheimTransactionData);
        }

        /// <summary>
        /// Get full manheim transaction data based on manheim id and region.
        /// </summary>
        /// <param name="manheimId">Manheim Id Ex: 201301766060786</param>
        /// <param name="region">Region Ex: RE</param> 
        /// <param name="source">source Ex: Internal</param> 
        /// <response code="200">Returns Transaction Data</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetFullTransactionData/{manheimId}/{region}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<Transaction>> GetFullTransactionData(string manheimId, string region, string source)
        {
            Transaction manheimTransactionDatas = _manheimService.GetFullTransactionData(manheimId, region, source);
            return Ok(manheimTransactionDatas);
        }

        /// <summary>
        /// Get location details based on the location id.
        /// </summary>
        /// <param name="locationId">Location Id Ex: OAA</param>   
        /// <param name="source">source Ex: Internal</param> 
        /// <response code="200">Returns Location details</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetLocationDetails/{locationId}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<LocationDetails>> GetLocationDetails(string locationId, string source)
        {
            LocationDetails locationDetails = _manheimService.GetLocationDetails(locationId, source);
            return Ok(locationDetails);
        }

        /// <summary>
        /// Get Makes based on the year.
        /// </summary>
        /// <param name="year">year Ex: 2015</param>       
        /// <param name="source">source Ex: Internal</param>  
        /// <response code="200">Returns Makes</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetMakes/{year}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<Makes>> GetMakes(string year, string source)
        {
            Makes makes = _manheimService.GetMakes(year, source);
            return Ok(makes);
        }

        /// <summary>
        /// Get Models based on year and make.
        /// </summary>
        /// <param name="year">year Ex: 2015</param>  
        /// <param name="make">make Ex: ACURA</param>  
        /// <param name="source">source Ex: Internal</param>  
        /// <response code="200">Returns Models</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetModels/{year}/{make}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<Models>> GetModels(string year, string make, string source)
        {
            Models models = _manheimService.GetModels(year, make, source);
            return Ok(models);
        }

        /// <summary>
        /// Get Trims based on year, make and Model.
        /// </summary>
        /// <param name="year">year Ex: 2015</param>  
        /// <param name="make">make Ex: ACURA</param>  
        /// <param name="model">model Ex: ILX</param>  
        /// <param name="source">source Ex: Internal</param>  
        /// <response code="200">Returns Trims</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetTrims/{year}/{make}/{model}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<Trims>> GetTrims(string year, string make, string model, string source)
        {
            Trims trims = _manheimService.GetTrims(year, make, model, source);
            return Ok(trims);
        }

        /// <summary>
        /// Get Decoded Vin based on vin, region and mileage.
        /// </summary>
        /// <param name="vin">vin Ex: 2G2WS542841256074</param>  
        /// <param name="region">region Ex: RE</param>  
        /// <param name="mileage">mileage Ex: 255000</param>  
        /// <param name="source">source Ex: Internal</param>  
        /// <response code="200">Returns Decoded Vin details</response>                
        /// <response code="204">Decode Failure</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetDecodedVin/{vin}/{region}/{mileage}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<VinVehicleDetail>> GetDecodedVin(string vin, string region, int mileage, string source)
        {
            VinVehicleDetail vinVehicleDetail = _manheimService.GetDecodedVin(vin, region, mileage, source);
            return Ok(vinVehicleDetail);
        }

        /// <summary>
        /// Get book value based on vin, manheimId, region, mileage, color and source.
        /// </summary>
        /// <param name="vin">vin Ex: 2G2WS542841256074</param>        
        /// <param name="region">region Ex: RE</param>
        /// <param name="mileage">mileage Ex: 255000</param>
        /// <param name="color">Color Ex: Red</param>
        /// <param name="source">source Ex: Internal</param>
        /// <response code="200">Returns Book value details</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetBookValue/{vin}/{region}/{mileage}/{color}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<VinVehicleDetail>> GetBookValue(string vin, string region, int mileage, string color, string source)
        {
            VinVehicleDetail vinVehicleDetail = _manheimService.GetBookValue(vin, region, mileage, color, source);
            return Ok(vinVehicleDetail);
        }

        /// <summary>
        /// Get book value based on year, make, model, mileage, region, color and source.
        /// </summary>
        /// <param name="year">year Ex: 2015</param>  
        /// <param name="make">make Ex: ACURA</param>  
        /// <param name="model">model Ex: ILX</param> 
        /// <param name="mileage">mileage Ex: 255000</param>
        /// <param name="region">region Ex: RE</param>
        /// <param name="color">Color Ex: Red</param>
        /// <param name="source">source Ex: Internal</param>
        /// <response code="200">Returns Book value details</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetBookValue/{year}/{make}/{model}/{mileage}/{region}/{color}/{source}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<VinVehicleDetail>> GetBookValue(string year, string make, string model, int mileage, string region, string color, string source)
        {
            VinVehicleDetail vinVehicleDetail = _manheimService.GetBookValue(year, make, model, mileage, region, color, source);
            return Ok(vinVehicleDetail);
        }
    }
}
