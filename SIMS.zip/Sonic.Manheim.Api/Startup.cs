using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Sonic.Manheim.Api.Configuration;
using Sonic.Manheim.Api.Extensions;
using Sonic.Manheim.Api.Helpers;
using Sonic.Manheim.Api.Middlewares;
using Sonic.Manheim.Api.Security;
using Sonic.Manheim.Api.Services;
using Sonic.Manheim.Api.Services.Interfaces;

namespace Sonic.Manheim.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {            
            services.AddControllers();
            ConfigureSettings(services);
        }

        public virtual void ConfigureSettings(IServiceCollection services)
        {
            // Add functionality to inject IOptions<T>
            services.AddOptions();

            // Add our Config object so it can be injected
            services.Configure<ManheimSettings>(Configuration.GetSection("Manheim"));
            services.Configure<Settings>(Configuration.GetSection("settings"));

            services.AddControllers(config =>
            {
                config.ReturnHttpNotAcceptable = true;
                config.Filters.Add(typeof(ValidateModelStateAttribute));
            }).AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());            

            services.AddAuthentication(BasicAuthenticationHandler.SchemeName)
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.SchemeName, null);

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IManheimService, ManheimService>();

            services.AddVersionService();
            services.AddSwaggerService();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.AddSwaggerMidleware(apiVersionDescriptionProvider);

            app.UseMiddleware<ErrorHandlerMiddleware>();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
