﻿namespace Sonic.Manheim.Api.Configuration
{
    public class ManheimSettings
    {
        public string ManheimAPIUrl { get; set; }
        public string ManheimAPIUserName { get; set; }
        public string ManheimAPIPassword { get; set; }
        public string ManheimAPICompanyId { get; set; }
        public string ManheimMediaType { get; set; }
    }
}
