﻿using System.Collections.Generic;

namespace Sonic.Manheim.Api.Configuration
{
    public class Settings
    {
        public List<User> users { get; set; }
    }
}
