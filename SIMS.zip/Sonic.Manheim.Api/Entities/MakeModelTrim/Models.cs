﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.MakeModelTrim
{
    public class Models
    {
        public string href { get; set; }
        public int count { get; set; }
        public List<Model> items { get; set; }

    }
}
