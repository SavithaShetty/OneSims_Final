﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.MakeModelTrim
{
    /// <summary>
    /// Model
    /// </summary>
    public class Model
    {
        public string href { get; set; }
        public string model { get; set; }
        public Trim trims { get; set; }
    }
}
