﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.MakeModelTrim
{
    public class Trim
    {
        public string href { get; set; }
        public string trim { get; set; }
    }
}
