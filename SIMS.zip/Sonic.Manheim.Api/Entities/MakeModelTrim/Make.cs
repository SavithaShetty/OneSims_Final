﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.MakeModelTrim
{
    /// <summary>
    /// A Make model
    /// </summary>
    public class Make
    {
        public string href { get; set; }
        public string make { get; set; }
        public Model models { get; set; }
    }
}
