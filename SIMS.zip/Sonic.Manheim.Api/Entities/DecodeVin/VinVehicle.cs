﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.DecodeVin
{
    public class VinVehicle
    {
        public string href { get; set; }
        public Description description { get; set; }
        public AdjustedPricing adjustedPricing { get; set; }
        public Wholesale wholesale { get; set; }
        public int averageOdometer { get; set; }
        public string odometerUnits { get; set; }
        public int averageGrade { get; set; }
        public string currency { get; set; }
        public string sampleSize { get; set; }
        public bool bestMatch { get; set; }
        public Samples samples { get; set; }
    }
}
