﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.DecodeVin
{
    public class VinVehicleDetail
    {
        public string href { get; set; }
        public int count { get; set; }
        public List<VinVehicle> items { get; set; }
    }
}
