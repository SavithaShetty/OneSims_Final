﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.DecodeVin
{
    public class Wholesale
    {
        public int above { get; set; }
        public int average { get; set; }
        public int below { get; set; }
    }
}
