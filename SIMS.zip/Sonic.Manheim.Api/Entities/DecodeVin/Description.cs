﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.DecodeVin
{
    public class Description
    {
        public int year { get; set; }
        public string make { get; set; }
        public string model { get; set; }
        public string trim { get; set; }
        public string subSeries { get; set; }
    }
}
