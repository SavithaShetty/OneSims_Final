﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.DecodeVin
{
    public class AdjustedPricing
    {
        public Wholesale wholesale { get; set; }
        public AdjustedBy adjustedBy { get; set; }
    }
}
