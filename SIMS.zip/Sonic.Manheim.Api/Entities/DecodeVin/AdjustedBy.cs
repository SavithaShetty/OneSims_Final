﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Entities.DecodeVin
{
    public class AdjustedBy
    {
        public string Odometer { get; set; }
    }
}
