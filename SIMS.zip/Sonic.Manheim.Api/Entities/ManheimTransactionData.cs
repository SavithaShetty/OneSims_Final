﻿using System;

namespace Sonic.Manheim.Api.Entities
{
    public class ManheimTransactionData
    {
        public DateTime? PurchaseDate { get; set; }
        public string AuctionName { get; set; }
        public string SaleType { get; set; }
        public decimal PurchasePrice { get; set; }
        public int Odometer { get; set; }
        public string BookCondition { get; set; }
        public string ExteriorColor { get; set; }
        public string Engine { get; set; }
        public string Transmission { get; set; }
        public string InSampleFlag { get; set; }
    }
}
