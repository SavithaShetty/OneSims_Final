﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class LocationDetails
    {
        public string href { get; set; }        
        public string locationType { get; set; }
        public string operatedBy { get; set; }
        public string locationName { get; set; }
        public string locationCode { get; set; }
        public Address address { get; set; }
        public string contactPhone { get; set; }
        public Contact contact { get; set; }
        public string timeZone { get; set; }
        public bool locationActive { get; set; }
        public string hrLocationCode { get; set; }
        public int numberOfLanes { get; set; }
        public bool auctionConverted { get; set; }
        public string convertedDate { get; set; }
    }
}
