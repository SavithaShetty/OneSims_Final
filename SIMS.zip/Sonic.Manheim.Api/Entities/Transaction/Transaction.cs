﻿using System.Collections.Generic;

namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class Transaction
    {
        public string href { get; set; }
        public int count { get; set; }
        public List<Item> items { get; set; }
        public string odometerUnits { get; set; }
        public string currency { get; set; }
    }
}
