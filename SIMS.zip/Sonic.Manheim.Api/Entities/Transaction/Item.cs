﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class Item
    {
        public Location location { get; set; }
        public Region region { get; set; }
        public string purchaseDate { get; set; }
        public int purchasePrice { get; set; }
        public VehicleDetails vehicleDetails { get; set; }
        public string saleType { get; set; }
        public string inSample { get; set; }
    }
}
