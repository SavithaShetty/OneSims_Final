﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class Contact
    {
        public string phone { get; set; }
        public string fax { get; set; }
        public string email { get; set; }
        public string homeUrl { get; set; }
    }
}
