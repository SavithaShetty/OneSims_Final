﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class Address
    {
        public string address1 { get; set; }
        public string city { get; set; }
        public string stateProvinceRegion { get; set; }
        public string country { get; set; }
        public string postalCode { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
    }
}
