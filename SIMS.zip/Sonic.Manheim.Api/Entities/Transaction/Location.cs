﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class Location
    {
        public string href { get; set; }
    }
}
