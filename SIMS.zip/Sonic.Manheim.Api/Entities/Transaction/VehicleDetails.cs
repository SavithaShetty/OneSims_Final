﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class VehicleDetails
    {
        public string engine { get; set; }
        public string transmission { get; set; }
        public string color { get; set; }
        public int odometer { get; set; }
        public string grade { get; set; }
        public string condition { get; set; }
    }
}
