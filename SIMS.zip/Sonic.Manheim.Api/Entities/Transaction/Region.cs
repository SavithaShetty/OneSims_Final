﻿namespace Sonic.Manheim.Api.Entities.Transaction
{
    public class Region
    {
        public string href { get; set; }
    }
}
