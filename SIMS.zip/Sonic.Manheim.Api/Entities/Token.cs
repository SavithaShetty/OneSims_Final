﻿namespace Sonic.Manheim.Api.Entities
{
    public class ManheimToken
    {
        public string tokenType { get; set; }
        public string accessToken { get; set; }
    }    
}
