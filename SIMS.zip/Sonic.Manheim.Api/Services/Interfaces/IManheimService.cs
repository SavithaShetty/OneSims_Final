﻿using Sonic.Manheim.Api.Entities;
using Sonic.Manheim.Api.Entities.DecodeVin;
using Sonic.Manheim.Api.Entities.MakeModelTrim;
using Sonic.Manheim.Api.Entities.Transaction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Services.Interfaces
{
    public interface IManheimService
    {
        List<ManheimTransactionData> GetTransactionData(string manheimId, string region, string source);

        Transaction GetFullTransactionData(string manheimId, string region, string source);

        LocationDetails GetLocationDetails(string locationId, string source);

        Makes GetMakes(string year, string source);

        Models GetModels(string year, string make, string source);

        Trims GetTrims(string year, string make, string model, string source);

        VinVehicleDetail GetDecodedVin(string vin, string region, int mileage, string source);

        VinVehicleDetail GetBookValue(string vin, string region, int mileage, string color, string source);
        
        VinVehicleDetail GetBookValue(string year, string make, string model, int mileage, string region, string color, string source);
    }
}
