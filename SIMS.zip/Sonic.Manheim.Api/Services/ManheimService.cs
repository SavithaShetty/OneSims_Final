﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Sonic.Manheim.Api.Configuration;
using Sonic.Manheim.Api.Entities;
using Sonic.Manheim.Api.Entities.DecodeVin;
using Sonic.Manheim.Api.Entities.MakeModelTrim;
using Sonic.Manheim.Api.Entities.Transaction;
using Sonic.Manheim.Api.Services.Interfaces;
using Sonic.OneSIMS.Infrastructure;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Sonic.Manheim.Api.Services
{
    /// <summary>
    /// Manheim Service
    /// </summary>
    public class ManheimService : IManheimService
    {
        private readonly IOptions<ManheimSettings> _manheimSettings;

        public ManheimService(IOptions<ManheimSettings> manheimSettings)
        {
            _manheimSettings = manheimSettings;
        }

        #region Private Methods
        private async Task<object> GetMaheimAuthToken()
        {
            byte[] authToken = Encoding.ASCII.GetBytes($"{_manheimSettings.Value.ManheimAPIUserName}:{_manheimSettings.Value.ManheimAPIPassword}");
            AuthenticationHeaderValue authenticationHeaderValue = new AuthenticationHeaderValue("Basic",
                    Convert.ToBase64String(authToken));
            string companyDetails = @"{""companyId"":""" + _manheimSettings.Value.ManheimAPICompanyId + "\"}";
            return await HTTPClientWrapper<object>.PostRequest($"{_manheimSettings.Value.ManheimAPIUrl}" + "oauth2/token", authenticationHeaderValue, new MediaTypeWithQualityHeaderValue(_manheimSettings.Value.ManheimMediaType), companyDetails);
        }

        private async Task<object> GetManheimDataWithToken(ManheimToken token, string url)
        {
            AuthenticationHeaderValue authenticationHeaderValue = new AuthenticationHeaderValue(token.tokenType, token.accessToken);
            return await HTTPClientWrapper<object>.Get(url, authenticationHeaderValue, new MediaTypeWithQualityHeaderValue(_manheimSettings.Value.ManheimMediaType));
        }

        private async Task<object> GetManheimData(string url)
        {
            var httpResponseMessage = GetMaheimAuthToken();
            var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());
            AuthenticationHeaderValue authenticationHeaderValue = new AuthenticationHeaderValue(token.tokenType, token.accessToken);
            return await HTTPClientWrapper<object>.Get(url, authenticationHeaderValue, new MediaTypeWithQualityHeaderValue(_manheimSettings.Value.ManheimMediaType));
        }
        #endregion Private Methods

        #region Public Methods
        public List<ManheimTransactionData> GetTransactionData(string manheimId, string region, string source)
        {
            try
            {
                List<ManheimTransactionData> manheimTransactionDatas = new List<ManheimTransactionData>();
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuation-samples/id/" + manheimId + "?region=" + region + "&orderBy=purchaseDate desc";
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                var transaction = JsonConvert.DeserializeObject<Transaction>(httpResponseMessage.Result.ToString());
                if (transaction.count > 0)
                {
                    for (int i = 0; i < transaction.count; i++)
                    {
                        string auctionHref = transaction.items[i].location.href;

                        httpResponseMessage = GetManheimDataWithToken(token, auctionHref);
                        LocationDetails location = null;
                        if (httpResponseMessage.Status != TaskStatus.Faulted)
                            location = JsonConvert.DeserializeObject<LocationDetails>(httpResponseMessage.Result.ToString());
                        string auctionName = (location == null ? string.Empty : location.locationName);

                        manheimTransactionDatas.Add(new ManheimTransactionData()
                        {
                            AuctionName = auctionName,
                            PurchaseDate = DateTime.Parse(transaction.items[i].purchaseDate),
                            BookCondition = transaction.items[i].vehicleDetails.condition,
                            Engine = transaction.items[i].vehicleDetails.engine,
                            ExteriorColor = transaction.items[i].vehicleDetails.color,
                            InSampleFlag = transaction.items[i].inSample,
                            Odometer = transaction.items[i].vehicleDetails.odometer,
                            PurchasePrice = transaction.items[i].purchasePrice,
                            SaleType = transaction.items[i].saleType,
                            Transmission = transaction.items[i].vehicleDetails.transmission
                        });
                    }
                }
                return manheimTransactionDatas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Transaction GetFullTransactionData(string manheimId, string region, string source)
        {
            try
            {
                List<ManheimTransactionData> manheimTransactionDatas = new List<ManheimTransactionData>();
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuation-samples/id/" + manheimId + "?region=" + region + "&orderBy=purchaseDate desc";
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                var transaction = JsonConvert.DeserializeObject<Transaction>(httpResponseMessage.Result.ToString());

                return transaction;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LocationDetails GetLocationDetails(string locationId, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "locations/id/" + locationId;
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);

                return JsonConvert.DeserializeObject<LocationDetails>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Makes GetMakes(string year, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuations/years/" + year + "/makes";
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                return JsonConvert.DeserializeObject<Makes>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Models GetModels(string year, string make, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuations/years/" + year + "/makes/" + make + "/models";
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                return JsonConvert.DeserializeObject<Models>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Trims GetTrims(string year, string make, string model, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuations/years/" + year + "/makes/" + make + "/models/" + model + "/trims";
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                return JsonConvert.DeserializeObject<Trims>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public VinVehicleDetail GetDecodedVin(string vin, string region, int mileage, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuations/vin/" + vin + "?odometer=" + mileage + "&region=" + region;
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                if (httpResponseMessage.Status == TaskStatus.Faulted)
                    return null;
                return JsonConvert.DeserializeObject<VinVehicleDetail>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public VinVehicleDetail GetBookValue(string vin, string region, int mileage, string color, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuations/vin/" + vin + "?odometer=" + mileage + "&region=" + region + "&color=" + color;
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                return JsonConvert.DeserializeObject<VinVehicleDetail>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public VinVehicleDetail GetBookValue(string year, string make, string model, int mileage, string region, string color, string source)
        {
            try
            {
                string url = _manheimSettings.Value.ManheimAPIUrl + "valuations/search/" + year + "/" + make + "/" + model + "?odometer=" + mileage + "&region=" + region + "&color=" + color;
                var httpResponseMessage = GetMaheimAuthToken();
                var token = JsonConvert.DeserializeObject<ManheimToken>(httpResponseMessage.Result.ToString());

                httpResponseMessage = GetManheimDataWithToken(token, url);
                return JsonConvert.DeserializeObject<VinVehicleDetail>(httpResponseMessage.Result.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion Public Methods
    }
}
