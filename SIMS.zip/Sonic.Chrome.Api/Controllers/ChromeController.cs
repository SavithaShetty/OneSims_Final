﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.Chrome.Api.Helpers;
using Sonic.Chrome.Api.Security;
using Sonic.Chrome.Api.Entities;
using Sonic.Chrome.Api.Services;
using Microsoft.Extensions.Configuration;
using Sonic.Chrome.Api.Services.Interfaces;
using System.ComponentModel.DataAnnotations;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Sonic.Chrome.Api.Controllers
{


    [ApiVersion("1")]
    [ApiVersion("3")]
    [Route("api/v{version:apiVersion}/Chrome")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class ChromeController : ControllerBase
    {
        //private readonly IConfiguration configuration;
        private readonly IChromeService _chromeService;

        public ChromeController(IChromeService chromeService)
        {
            _chromeService = chromeService;
            //this.configuration = configuration;
        }

        /// <summary>
        /// Get Year List From Chrome Services
        /// </summary>
        /// <remarks>Get Year List From Chrome Services </remarks>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <response code="200">Returns the Year list </response>                    
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>   
        [HttpGet("years/{RequestSource}")]
        [MapToApiVersion("1")]
        [ApiConventionMethod(typeof(DefaultApiConventions), nameof(DefaultApiConventions.Get))]
        public async Task<ActionResult<IEnumerable<Year>>> GetYears([FromRoute][Required] string RequestSource)
        {
            var res = await _chromeService.GetChromeYears(RequestSource);
            return Ok(res);
        }

        /// <summary>
        /// Get Makes based on the specific year provided.
        /// </summary>
        /// <remarks>Get Makes based on the specific year provided.</remarks>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <param name="year">year Ex: 2016</param>       
        /// <response code="200">Returns Makes</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>   
        [HttpGet("makes")]
        [MapToApiVersion("1")]
        [ApiConventionMethod(typeof(DefaultApiConventions), nameof(DefaultApiConventions.Get))]
        //[ApiConventionMethod(typeof(SIMSConventions),nameof(SIMSConventions.Get))]
        //[ProducesResponseType(StatusCodes.Status404NotFound)]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(StatusCodes.Status200OK,Type=typeof(Make))]
        public async Task<ActionResult<IEnumerable<Make>>> GetMakes([Microsoft.AspNetCore.Mvc.FromQuery] MakeRequest makeRequest)
        {

            var res = await _chromeService.GetChromeMakes(makeRequest);
            return Ok(res);


        }

        /// <summary>
        /// Get models for specific year and make
        /// </summary>
        /// <remarks>Get models for specific year and make</remarks>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <param name="year">The Id of Year Ex:2016</param>
        /// <param name="makeid">The Id of Make Ex:BMW,Acura</param>
        /// <response code="200">Returns the models for specific year and make</response>
        /// <response code="404">Models not found for given year and make</response>
        /// <response code="400">Bad Request</response>                    
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("models")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<IEnumerable<Model>>> GetModels([FromQuery] ModelRequest modelRequest)
        {
            var res = await _chromeService.GetChromeModels(modelRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get trims styles by id for a specific model
        /// </summary>
        /// <remarks>Get trims styles by id for a specific model</remarks>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <param name="modelid">The Id of Model Ex:46 </param>
        /// <response code="200">Returns the trims for specific model</response>
        /// <response code="404">Trims not found for specific model</response>
        /// <response code="400">Bad Request</response>                    
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("styles")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<IEnumerable<Trim>>> GetTrims([FromQuery] StyleRequest styleRequest)
        {
            var res = await _chromeService.GetChromeStyles(styleRequest);
            return Ok(res);
        }

        /// <summary>
        /// Method to get list of Trims(style Trim and style name combo) based on ModelYear ,Make Name ,Model Name.
        /// </summary>
        /// <remarks>Method to get list of Trims(style Trim and style name combo) based on ModelYear ,Make Name ,Model Name.</remarks>
        /// <param name="requestSource"></param>
        /// <param name="ModelYear"></param>
        /// <param name="MakeName"></param>
        /// <param name="ModelName"></param>
        /// <response code="200">Returns the trims for specific model</response>
        /// <response code="404">Trims not found for specific model</response>
        /// <response code="400">Bad Request</response>                    
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("trims")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<IEnumerable<Trim>>> GetTrims([FromQuery] TrimRequest trimRequest)
        {
            var res = await _chromeService.GetChromeTrims(trimRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get Decoded Vin based on vin.
        /// </summary>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <param name="vin">vin to decode vehicle details, for Ex:5YJXCAE46GF000944</param>
        /// <response code="200">Returns the vehicle properties for specific VIN</response>        
        /// <response code="404">Vehcile details are not found for given VIN</response>   
        /// <response code="400">Bad Request</response>   
        /// <response code="401">UnAutherized</response>
        /// <response code="500">Internal Server Error</response> 
        /// <remarks>        
        /// ### The complete vehicle properties will return as below:
        ///  Year|Make|Model|Transmission
        ///  ----|----|-----|------------
        ///  2020|BMW |BMW  |Manual 
        /// </remarks>
        [HttpGet("DecodeVIN")]
        [MapToApiVersion("1")]
        //[ValidateModelState]
        //[SwaggerOperation("DecodeVIN")]
        public async Task<ActionResult<VinVehicleDetail>> GetDecodeVIN([FromQuery] DecodeVINRequest decodeVINRequest)
        {

            var res = await _chromeService.GetDecodeVIN(decodeVINRequest);
            return Ok(res);
        }


        /// <summary>
        /// Get Decoded Vin based on vin.
        /// </summary>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <param name="vin">vin to decode vehicle details, for Ex:5YJXCAE46GF000944</param>
        /// <response code="200">Returns the vehicle properties for specific VIN</response>        
        /// <response code="404">Vehcile details are not found for given VIN</response>   
        /// <response code="400">Bad Request</response>   
        /// <response code="401">UnAutherized</response>
        /// <response code="500">Internal Server Error</response> 
        /// <remarks>        
        /// ### The complete vehicle properties will return as below:
        ///  Year|Make|Model|Transmission
        ///  ----|----|-----|------------
        ///  2020|BMW |BMW  |Manual 
        /// </remarks>
        [HttpGet("DecodeVINNonBuildData")]
        [MapToApiVersion("1")]
        //[ValidateModelState]
        //[SwaggerOperation("DecodeVIN")]
        public async Task<ActionResult<VinVehicleDetail>> GetDecodeVIN_NonBuildData([FromQuery] DecodeVINRequest decodeVINRequest)
        {
            var res = await _chromeService.GetDecodeVIN_NonBuildData(decodeVINRequest);
            return Ok(res);

        }

        /// <summary>
        /// Get Decoded Vin based on vin.
        /// </summary>
        /// <param name="requestSource">Source of the request, where it is getting called from. Ex:OneSIMS Portal,Service</param>
        /// <param name="vin">vin to decode vehicle details, for Ex:5YJXCAE46GF000944</param>
        /// <response code="200">Returns the vehicle properties for specific VIN</response>        
        /// <response code="404">Vehcile details are not found for given VIN</response>   
        /// <response code="400">Bad Request</response>   
        /// <response code="401">UnAutherized</response>
        /// <response code="500">Internal Server Error</response> 
        /// <remarks>        
        /// ### The complete vehicle properties will return as below:
        ///  Year|Make|Model|Transmission
        ///  ----|----|-----|------------
        ///  2020|BMW |BMW  |Manual 
        /// </remarks>
        [HttpGet("DecodeBadVIN")]
        [MapToApiVersion("1")]
        //[ValidateModelState]
        //[SwaggerOperation("DecodeVIN")]
        public async Task<ActionResult<VinVehicleDetail>> GetDecodeBadVIN([FromQuery] DecodeBadVINRequest _decodeBadVINRequest)
        {
            var res = await _chromeService.GetDecodeBadVIN(_decodeBadVINRequest);
            return Ok(res);

        }
    }
}
