﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Configuration
{
    public class DecodeEntity
    {
        public string DriveTrain { get; set; }
        public string BodyStyles { get; set; }
        public string ExtColors { get; set; }
        public string AllOptionIDs { get; set; }
        public string IntColor { get; set; }
        public string IntType { get; set; }
        public string Transmission { get; set; }
        public string Fuel { get; set; }
        public string ClassOfVehicle { get; set; }
        public string VehicleType { get; set; }
        public string DMVType { get; set; }
        public string DMVClass { get; set; }
    }
}