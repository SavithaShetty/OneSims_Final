﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Configuration
{
    public class Settings
    {
        public ChromeContract chromeContract { get; set; } 

        public DecodeEntity decodeEntity { get; set; }

        public List<User> users { get; set; }
    }
}
