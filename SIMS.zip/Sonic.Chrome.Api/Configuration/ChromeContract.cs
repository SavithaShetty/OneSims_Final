﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Configuration
{
    public class ChromeContract
    {
        public string ChromeNumber { get; set; }

        public string ChromeSecret { get; set; }

        public string ChromeBehalfOf { get; set; }

        public string ChromeNumberBuildData { get; set; }

        public string ChromeSecretBuildData { get; set; }

        public string ChromeBehalfOfBuildData { get; set; }

    }
}
