﻿using ChromeServiceReference;
using Sonic.Chrome.Api.Configuration;
using Sonic.Chrome.Api.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Data;
using System.Text.Json;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using Sonic.Chrome.Api.Services.Interfaces;
using Microsoft.Extensions.Options;

namespace Sonic.Chrome.Api.Services
{
    public class ChromeService : IChromeService
    {
        private DecodeEntity _decodeEntity;
        private ChromeContract _chromeContract;
        public ChromeService(IOptions<Settings> settings)
        {
            _decodeEntity = settings.Value.decodeEntity;
            _chromeContract = settings.Value.chromeContract;
        }
        public async Task<List<Year>> GetChromeYears(string requestSource)
        {
            try
            {

                Settings settings = new Settings();
                Description7aPortTypeClient decodeVIN = new Description7aPortTypeClient();

                BaseRequest modelYearsRequest = new BaseRequest();
                AccountInfo accountInfo = new AccountInfo();
                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumber.Trim();
                accountInfo.secret = _chromeContract.ChromeSecret.Trim();
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOf.Trim();
                modelYearsRequest.accountInfo = accountInfo;
                List<Year> years = new List<Year>();

                getModelYearsResponse yearResponse = new getModelYearsResponse();
                try
                {
                    yearResponse = await decodeVIN.getModelYearsAsync(modelYearsRequest);
                    // response = response1;
                    //Logger.LogDebugInfo(ConfigSettings.GetCurrentUsername(), "Time taken for Chrome GetDivisions : " + executionTime.Elapsed.ToString());
                }
                catch (Exception ex)
                {
                    //Logger.LogError( "Connection to Chrome failed. ", ex);
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }

                List<object> list = new List<object>();

                years = (from d in yearResponse.ModelYears.modelYear
                         select new Year { ID = d.ToString(), Value = d.ToString() }).ToList();
                //response = response1;
                return years;
                // }
            }
            catch (Exception ex)
            {
                //Logger.LogError("GetMakes", "Call to GetMakes method failed. ", ex);
                throw new Exception("Call to GetMakes method failed. " + ex.Message);
            }
        }

        public async Task<List<Make>> GetChromeMakes(MakeRequest _makeRequest)
        {
            try
            {

                Description7aPortTypeClient decodeVIN = new Description7aPortTypeClient();
                List<Make> makeValues = new List<Make>();
                DivisionsRequest makeRequest = new DivisionsRequest();
                AccountInfo accountInfo = new AccountInfo();
                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumber.Trim();
                accountInfo.secret = _chromeContract.ChromeSecret.Trim();
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOf.Trim();
                //int a = 2017;
                makeRequest.accountInfo = accountInfo;
                makeRequest.modelYear = Convert.ToInt32(_makeRequest.YearId);

                getDivisionsResponse makeResponse = new getDivisionsResponse();

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    makeResponse = await decodeVIN.getDivisionsAsync(makeRequest);
                    executionTime.Stop();

                    //List<int> za1 = GetYears();
                }
                catch (Exception ex)
                {
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }
                if (makeResponse.Divisions.division != null)
                {
                    #region Parsing
                    if (makeResponse.Divisions.division != null && makeResponse.Divisions.responseStatus.responseCode.ToString().Equals("Successful"))
                    {
                        makeValues = (makeResponse.Divisions.division.ToList()).ConvertAll<Make>
                                                (
                                                p =>
                                                {
                                                    Make k = new Make();
                                                    k.ID = p.id.ToString();
                                                    k.Value = p.Value;
                                                    return k;
                                                }
                                                );

                    }
                    else
                    {
                        //Logger.LogError(storeID.ToString(), "GetMake has encountered error!!!");
                        throw new Exception("GetMake has encountered error!!!");
                    }
                }
                #endregion Parsing

                return makeValues;

            }
            catch (Exception ex)
            {
                // Logger.LogError("GetMakes", "Call to GetMakes method failed. ", ex);
                throw new Exception("Call to GetMakes method failed. " + ex.Message);
            }
        }

        public async Task<List<Model>> GetChromeModels(ModelRequest _modelRequest)
        {
            try
            {
                Description7aPortTypeClient chromeProxy = new Description7aPortTypeClient();
                List<Model> modelValues = new List<Model>();
                ModelsRequest modelReq = new ModelsRequest();
                AccountInfo accountInfo = new AccountInfo();
                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumber.Trim();
                accountInfo.secret = _chromeContract.ChromeSecret.Trim();
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOf.Trim();
                modelReq.modelYear = Convert.ToInt32(_modelRequest.YearId);
                modelReq.accountInfo = accountInfo;
                modelReq.ItemElementName = ItemChoiceType.divisionId;

                if (_modelRequest.MakeId != null)
                {
                    modelReq.Item = (!string.IsNullOrEmpty(_modelRequest.MakeId.ToString())) ? Convert.ToInt32(_modelRequest.MakeId) : 0;
                }

                getModelsResponse modelsResponse = new getModelsResponse();

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    modelsResponse = await chromeProxy.getModelsAsync(modelReq);
                    executionTime.Stop();

                }
                catch (Exception ex)
                {
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }
                #region Parsing
                if (modelsResponse.Models.model != null)
                {
                    if (modelsResponse.Models.model != null && modelsResponse.Models.model.Count() > 0)
                    {
                        modelValues = (modelsResponse.Models.model.ToList()).ConvertAll<Model>
                                                (p => { Model k = new Model(); k.ID = p.id.ToString(); k.Value = p.Value; return k; });
                    }
                    else
                    {
                        throw new Exception("GetModel has encountered error!!!");
                    }
                }
                #endregion Parsing

                return modelValues;
            }
            catch (Exception ex)
            {
                throw new Exception("Call to GetModels method failed. " + ex.Message);
            }
        }

        public async Task<List<Trim>> GetChromeStyles(StyleRequest _styleRequest)
        {

            try
            {
                Description7aPortTypeClient chromeProxy = new Description7aPortTypeClient();
                List<Trim> trimlValues = new List<Trim>();

                StylesRequest trimRequest = new StylesRequest();

                AccountInfo accountInfo = new AccountInfo();
                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumber.Trim();
                accountInfo.secret = _chromeContract.ChromeSecret.Trim();
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOf.Trim();
                trimRequest.accountInfo = accountInfo;


                if (_styleRequest.ModelId != null) // Continue if not null.
                {

                    trimRequest.modelId = (!string.IsNullOrEmpty(_styleRequest.ModelId.ToString())) ? Convert.ToInt32(_styleRequest.ModelId) : 0;

                }

                getStylesResponse trimResponse = new getStylesResponse();

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    trimResponse = await chromeProxy.getStylesAsync(trimRequest);
                    executionTime.Stop();

                }
                catch (Exception ex)
                {
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }

                #region Parsing
                if (trimResponse.Styles.style != null)
                {
                    if ((trimResponse.Styles.responseStatus.responseCode.ToString().Equals("Successful", StringComparison.OrdinalIgnoreCase) && trimResponse.Styles.style != null && trimResponse.Styles.style.Count() > 0))
                    {
                        trimlValues = (trimResponse.Styles.style.ToList()).ConvertAll<Trim>
                                                 (
                                                     p =>
                                                     {
                                                         Trim k = new Trim();
                                                         k.ID = p.id.ToString();
                                                         k.Value = p.Value;
                                                         return k;
                                                     }
                                                 );
                    }
                    else
                    {
                        // throw new Exception("GetStyles has encountered error!!!");
                    }
                }
                #endregion Parsing

                return trimlValues;


            }

            catch (Exception ex)
            {
                throw new Exception("Call to GetStyles method failed. " + ex.Message);
            }

        }

        public async Task<List<Trim>> GetChromeTrims(TrimRequest _trimRequest)
        {

            try
            {
                Description7aPortTypeClient chromeProxy = new Description7aPortTypeClient();
                VehicleDescriptionRequest vehRequest = new VehicleDescriptionRequest();
                describeVehicleResponse vehicleResponse = null;
                List<Trim> trimlValues = new List<Trim>();
                var makeSelectedValue = _trimRequest.Make;
                var modelSelectedValue = _trimRequest.Model;

                AccountInfo accountInfo = new AccountInfo();
                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumber;
                accountInfo.secret = _chromeContract.ChromeSecret;
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOf;

                vehRequest.accountInfo = accountInfo;

                vehRequest.Items = new object[4];
                vehRequest.Items[0] = Convert.ToInt32(_trimRequest.Year);
                vehRequest.Items[1] = _trimRequest.Make;
                vehRequest.Items[2] = _trimRequest.Model;
                vehRequest.Items[3] = "5YJXCAE46GF000944";
                vehRequest.ItemsElementName = new ItemsChoiceType[4];
                vehRequest.ItemsElementName[0] = ItemsChoiceType.modelYear;
                vehRequest.ItemsElementName[1] = ItemsChoiceType.makeName;
                vehRequest.ItemsElementName[2] = ItemsChoiceType.modelName;
                vehRequest.ItemsElementName[3] = ItemsChoiceType.vin;
                vehRequest.@switch = new ChromeServiceReference.Switch[1];
                vehRequest.@switch[0] = ChromeServiceReference.Switch.ShowAvailableEquipment;

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    vehicleResponse = await chromeProxy.describeVehicleAsync(vehRequest);
                    executionTime.Stop();

                    //  Logger.LogDebugInfo(ConfigSettings.GetCurrentUsername(), "Time taken for Chrome GetTrims : " + executionTime.Elapsed.ToString());
                }
                catch (Exception ex)
                {
                    //Logger.LogError(storeID.ToString(), "Connection to Chrome failed. ", ex);
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }

                #region Parsing
                if (vehicleResponse.VehicleDescription.style != null)
                {
                    if ((vehicleResponse.VehicleDescription.responseStatus.responseCode.ToString().Equals("Successful", StringComparison.OrdinalIgnoreCase) && vehicleResponse.VehicleDescription.style != null && vehicleResponse.VehicleDescription.style.Count() > 0))
                    {
                        trimlValues = (vehicleResponse.VehicleDescription.style.ToList()).ConvertAll<Trim>
                                                 (
                                                     p =>
                                                     {
                                                         Trim k = new Trim();
                                                         k.ID = p.id.ToString();
                                                         k.Value = p.name;
                                                         return k;
                                                     }
                                                 );
                    }
                    else
                    {
                        throw new Exception("GetTrims has encountered error!!!");
                    }
                }
                #endregion Parsing

                return trimlValues;


            }

            catch (Exception ex)
            {
                throw new Exception("Call to GetTrims method failed. " + ex.Message);
            }


        }

        public async Task<VinVehicleDetail> GetDecodeVIN(DecodeVINRequest _decodeVINRequest)
        {
            VinVehicleDetail vehicleDetail = new VinVehicleDetail();

            try
            {
                Description7aPortTypeClient service = new Description7aPortTypeClient();
                VehicleDescriptionRequest vehRequest = new VehicleDescriptionRequest();
                AccountInfo accountInfo = new AccountInfo();

                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumberBuildData.Trim();
                accountInfo.secret = _chromeContract.ChromeSecretBuildData.Trim();
                accountInfo.behalfOf = _chromeContract.ChromeSecretBuildData.Trim();
                vehRequest.accountInfo = accountInfo;
                describeVehicleResponse vinResponse = null;
                String vinParam = String.Empty;



                vehRequest.Items = new object[1];
                vinParam = _decodeVINRequest.VIN;
                vehRequest.Items[0] = vinParam;
                vehRequest.ItemsElementName = new ItemsChoiceType[1];
                vehRequest.ItemsElementName[0] = ItemsChoiceType.vin;
                vehRequest.@switch = new ChromeServiceReference.Switch[1];
                vehRequest.@switch[0] = ChromeServiceReference.Switch.ShowAvailableEquipment;

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    var json3 = JsonConvert.SerializeObject(vehRequest);

                    vinResponse = await service.describeVehicleAsync(vehRequest);
                    executionTime.Stop();

                    //Logger.LogDebugInfo(ConfigSettings.GetCurrentUsername(), "Time taken for Chrome DecodeVin : " + executionTime.Elapsed.ToString());
                }
                catch (Exception ex)
                {
                    //Logger.LogError(storeID.ToString(), "Connection to Chrome failed. ", ex);
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }

                #region Parsing
                if (vinResponse.VehicleDescription.responseStatus.responseCode.ToString().Equals("Successful", StringComparison.OrdinalIgnoreCase) && vinResponse.VehicleDescription.bestMakeName == null)
                {
                    //throw new Exception(string.Format(ConfigSettings.GetErrorMessage(501013), VIN));
                    vehicleDetail.vin = _decodeVINRequest.VIN;

                    Make fieldValue = new Make();

                    fieldValue.ID = "0";
                    fieldValue.Value = "BAD_VIN";
                    vehicleDetail.make = new List<Make>();
                    vehicleDetail.make.Add(fieldValue);
                    List<Year> years = new List<Year>();
                    years = await GetChromeYears(_decodeVINRequest.RequestSource);
                    vehicleDetail.years = years;
                    vehicleDetail.IsDecodeSuccess = false;
                    vehicleDetail.DecodeStatus = new List<IDValues>();
                    IDValues DecodeStatus = new IDValues();
                    DecodeStatus.Value = "There is an issue decoding " + _decodeVINRequest.VIN + ". It might be a Canadian or other non - US VIN that cannot be decoded."; //string.Format(ConfigSettings.GetErrorMessage(501013), VIN);
                    DecodeStatus.ID = "There is an issue decoding " + _decodeVINRequest.VIN + ". It might be a Canadian or other non - US VIN that cannot be decoded."; //string.Format(ConfigSettings.GetErrorMessage(501013), VIN);
                    vehicleDetail.DecodeStatus.Add(DecodeStatus);

                    return vehicleDetail;
                }
                else if (!vinResponse.VehicleDescription.responseStatus.responseCode.ToString().Equals("Unsuccessful", StringComparison.OrdinalIgnoreCase))
                {
                    vehicleDetail = ParseVinResponse(vinResponse.VehicleDescription);
                }
                else
                {
                    List<Year> years = new List<Year>();
                    years = await GetChromeYears(_decodeVINRequest.RequestSource);
                    vehicleDetail.years = years;

                    //Logger.LogError("DecodeVin",
                    //                "Returns responseCode 'Unsuccessful'." + VIN,
                    //               (vinResponse.responseStatus.status != null) ? (new System.Exception(vinResponse.responseStatus.status[0].code + ": " + vinResponse.responseStatus.status[0].Value))
                    //               : null);
                    //throw new Exception("Returning responseCode as 'Unsuccessful'." + VIN);
                }

                #endregion Parsing

                return vehicleDetail;

            }
            catch (Exception ex)
            {
                // Logger.LogError("DecodeVin", "Call to DecodeVin method failed. ", ex);
                throw new Exception("Call to DecodeVin method failed. " + ex.Message);
            }
        }

        private VinVehicleDetail ParseVinResponse(VehicleDescription vinResponse)
        {
            try
            {
                VinVehicleDetail vehicleDetail = new VinVehicleDetail();

                vehicleDetail.vin = vinResponse.vinDescription.vin;
                vehicleDetail.IsDecodeSuccess = true;

                // Year
                vehicleDetail.year = Convert.ToUInt32(vinResponse.vinDescription.modelYear);

                // Cylinder
                vehicleDetail.Cylinders = vinResponse.engine != null ?
                                          Convert.ToUInt32(vinResponse.engine[0].cylinders)
                                          : 0;

                // No of Doors.
                vehicleDetail.NoOfDoors = vinResponse.style != null ?
                                         Convert.ToUInt32(vinResponse.style[0].passDoors)
                                         : 0;

                // Make
                Make fieldValueMake = new Make();
                fieldValueMake.ID = vinResponse.style != null ? vinResponse.style[0].division.id.ToString() : null;
                fieldValueMake.Value = vinResponse.bestMakeName != null ? vinResponse.bestMakeName : "BAD_VIN";
                vehicleDetail.make = new List<Make>();
                vehicleDetail.make.Add(fieldValueMake);

                // Engine
                vehicleDetail.Engine = new List<IDValues>();
                vehicleDetail.engineDetails = new List<EngineDetails>();
                List<EngineDetails> engineDetailsList = new List<EngineDetails>();
                if (vinResponse.engine != null)
                {
                    foreach (Engine engine in vinResponse.engine)
                    {
                        IDValues fieldValueEngine = new IDValues();

                        if (engine.displacement != null && engine.engineType != null && engine.horsepower != null)
                            fieldValueEngine.Value = engine.displacement.liters + " Liter " + engine.engineType.Value + ", " + engine.horsepower.value + " HP ";
                        else if (engine.displacement != null && engine.engineType == null && engine.horsepower != null)
                            fieldValueEngine.Value = engine.displacement.liters + " Liter " + ", " + engine.horsepower.value + " HP ";
                        else if (engine.displacement == null && engine.engineType != null && engine.horsepower != null)
                            fieldValueEngine.Value = engine.engineType.Value + ", " + engine.horsepower.value + " HP ";
                        else if (engine.displacement == null && engine.engineType == null && engine.horsepower != null)
                            fieldValueEngine.Value = engine.horsepower.value + " HP ";
                        else if (engine.displacement != null && engine.engineType != null && engine.horsepower == null)
                            fieldValueEngine.Value = engine.displacement.liters + " Liter " + engine.engineType.Value;

                        if (fieldValueEngine.Value != null)
                            vehicleDetail.Engine.Add(fieldValueEngine);

                        //Get additional information from Chrome
                        
                        EngineDetails engineDetails = new EngineDetails();
                        if (engine.netTorque != null)
                        {
                            engineDetails.NetTorque_RPM = engine.netTorque.rpm != null ? Convert.ToInt64(engine.netTorque.rpm) : 0;
                            engineDetails.NetTorque_Value = engine.netTorque.value != null ? Convert.ToDecimal(engine.netTorque.value) : 0;
                        }
                        if (engine.horsepower != null)
                        {
                            engineDetails.Horsepower_RPM = engine.horsepower.rpm != null ? Convert.ToDecimal(engine.horsepower.rpm) : 0;
                            engineDetails.Horsepower_Value = engine.horsepower.value != null ? Convert.ToDecimal(engine.horsepower.value) : 0;
                        }
                        if (engine.fuelEconomy != null)
                        {
                            if (engine.fuelEconomy.city != null)
                            {
                                decimal fuelEconomy_city_high = engine.fuelEconomy.city.high != null ? Convert.ToDecimal(engine.fuelEconomy.city.high) : 0;
                                decimal fuelEconomy_city_low = engine.fuelEconomy.city.low != null ? Convert.ToDecimal(engine.fuelEconomy.city.low) : 0;
                                decimal fuelEconomy_city = (fuelEconomy_city_high + fuelEconomy_city_low) / 2;
                                engineDetails.FuelEfficiencyCity = fuelEconomy_city;
                            }
                            if (engine.fuelEconomy.hwy != null)
                            {
                                decimal fuelEconomy_hwy_high = engine.fuelEconomy.hwy.high != null ? Convert.ToDecimal(engine.fuelEconomy.hwy.high) : 0;
                                decimal fuelEconomy_hwy_low = engine.fuelEconomy.hwy.low != null ? Convert.ToDecimal(engine.fuelEconomy.hwy.low) : 0;
                                decimal fuelEconomy_hwy = (fuelEconomy_hwy_high + fuelEconomy_hwy_low) / 2;
                                engineDetails.FuelEfficiencyHwy = fuelEconomy_hwy;
                            }
                            if(engine.fuelType!=null)
                            {
                                engineDetails.FuelType = Convert.ToString(engine.fuelType.Value);
                            }
                                    
                        }

                        engineDetails.displacement = fieldValueEngine.Value;

                        if (engineDetails != null)
                            //vehicleDetail.engineDetails.Add(engineDetails);
                            engineDetailsList.Add(engineDetails);

                         
                    }
                    vehicleDetail.engineDetails = engineDetailsList;
                    vehicleDetail.Engine = vehicleDetail.Engine != null ? vehicleDetail.Engine
                                                                      .GroupBy(s => s.Value)
                                                                      .Select(s => s.First()).ToList() : null;
                }
                //Get additional information from Chrome
                //vehicleDetail.DriveTrain = (from d in FetchDriveTrains()
                //                            select new IDValues { ID = d, Value = d, Selected = false }).ToList();

                // Model
                Model fieldValueModel = new Model();
                fieldValueModel.ID = vinResponse.style != null ? vinResponse.style[0].model.id.ToString() : null;
                fieldValueModel.Value = vinResponse.bestModelName;
                vehicleDetail.model = new List<Model>();
                vehicleDetail.model.Add(fieldValueModel);
 
                // BodyStyle

                //vehicleDetail.bodyStyle = (from d in FetchBodyStyles()
                //                           select new IDValues { ID = d, Value = d, Selected = false }).ToList();

                // Series/Trim, DriveTrain and BodyStyle
                vehicleDetail.series = new List<IDValues>();
                vehicleDetail.DriveTrain = new List<IDValues>();
                vehicleDetail.bodyStyle = new List<IDValues>();

                if (vinResponse.style != null)
                {
                    foreach (Style style in vinResponse.style)
                    {
                        IDValues fieldValueStyle = new IDValues();
                        fieldValueStyle.ID = style.id.ToString();
                        fieldValueStyle.Code = style.mfrModelCode != null ? style.mfrModelCode.ToString() : null;
                        fieldValueStyle.Value = (style.trim != null) ?
                                                style.trim + " (" + style.name + ")"
                                                : style.name;
                        if (style.trim != null && style.trim.Equals(vinResponse.bestTrimName, StringComparison.OrdinalIgnoreCase))
                            fieldValueStyle.Selected = true;
                        else
                            fieldValueStyle.Selected = false;
                        vehicleDetail.series.Add(fieldValueStyle);


                        IDValues driveTrain = new IDValues();
                        driveTrain.ID = style.drivetrain.ToString() != null ? style.drivetrain.ToString() : null;
                        driveTrain.Value = style.drivetrain.ToString() != null ? style.drivetrain.ToString() : null;
                       
                        if(driveTrain!=null)
                        vehicleDetail.DriveTrain.Add(driveTrain);

                        IDValues bodyStyle = new IDValues();
                        bodyStyle.ID = style.altBodyType.ToString() != null ? style.altBodyType.ToString() : null;
                        bodyStyle.Value = style.altBodyType.ToString() != null ? style.altBodyType.ToString() : null;

                        if (bodyStyle != null)
                            vehicleDetail.bodyStyle.Add(bodyStyle);

                        //IDValues bodyStyles = new IDValues();
                        //bodyStyles.ID=style.bodyType
                    }

                    vehicleDetail.series = vehicleDetail.series != null ? vehicleDetail.series
                                                                       .GroupBy(s => s.Value)
                                                                       .Select(s => s.First()).ToList() : null;
                    vehicleDetail.DriveTrain = vehicleDetail.DriveTrain != null ? vehicleDetail.DriveTrain
                                                   .GroupBy(s => s.Value)
                                                   .Select(s => s.First()).ToList() : null;

                    vehicleDetail.bodyStyle = vehicleDetail.bodyStyle != null ? vehicleDetail.bodyStyle
                                                 .GroupBy(s => s.Value)
                                                 .Select(s => s.First()).ToList() : null;

                }

                //Exterior generic color
              

                List<ColorOptions> colorOptions = new List<ColorOptions>();
                if (vinResponse.exteriorColor != null)
                {
                    foreach (Color color in vinResponse.exteriorColor)
                    {
                        ColorOptions colorOptions1 = new ColorOptions();

                        if (color.genericColor != null && color.genericColor.Count() > 0)
                        {
                            List<GenericColors> generic = new List<GenericColors>();
                            foreach (GenericColor genericColor in color.genericColor)
                            {
                                GenericColors generic1 = new GenericColors();
                                generic1.nameField = genericColor.name;
                                generic1.primaryField = genericColor.primary;
                                generic1.primaryFieldSpecified = genericColor.primarySpecified;
                                generic.Add(generic1);
                            }
                            colorOptions1.genericColorField=generic.ToArray();

                            colorOptions1.colorCodeField = color.colorCode;
                            colorOptions1.colorNameField = color.colorName;
                            colorOptions1.rgbValueField = color.rgbValue;

                            colorOptions1.styleIdField = color.styleId;
                            colorOptions.Add(colorOptions1);

                        }
                        //else
                        //{
                        //}
                    }
                }
                vehicleDetail.ExteriorColor = colorOptions;

                //Interior generic color


                List<ColorOptions> colorOptionsInterior = new List<ColorOptions>();
                if (vinResponse.exteriorColor != null)
                {
                    foreach (Color color in vinResponse.interiorColor)
                    {
                        ColorOptions colorOptions1 = new ColorOptions();

                        if (color.genericColor != null && color.genericColor.Count() > 0)
                        {
                            List<GenericColors> generic = new List<GenericColors>();
                            foreach (GenericColor genericColor in color.genericColor)
                            {
                                GenericColors generic1 = new GenericColors();
                                generic1.nameField = genericColor.name;
                                generic1.primaryField = genericColor.primary;
                                generic1.primaryFieldSpecified = genericColor.primarySpecified;
                                generic.Add(generic1);
                            }
                            colorOptions1.genericColorField = generic.ToArray();

                            colorOptions1.colorCodeField = color.colorCode;
                            colorOptions1.colorNameField = color.colorName;
                            colorOptions1.rgbValueField = color.rgbValue;

                            colorOptions1.styleIdField = color.styleId;
                            colorOptionsInterior.Add(colorOptions1);

                        }
                        else
                        {
                            GenericColors generic = new GenericColors();
                            GenericColor genericColor = new GenericColor();
                            if (color.genericColor != null)
                            {
                                generic.nameField = genericColor.name;
                                generic.primaryField = genericColor.primary;
                                generic.primaryFieldSpecified = genericColor.primarySpecified;

                                colorOptions1.genericColorField = null;
                            }
                            else
                            {
                                colorOptions1.genericColorField = null;
                            }
                            
                            colorOptions1.colorCodeField = color.colorCode;
                            colorOptions1.colorNameField = color.colorName;
                            colorOptions1.rgbValueField = color.rgbValue;

                            colorOptions1.styleIdField = color.styleId;
                            colorOptionsInterior.Add(colorOptions1);

                        }
                    }
                }
                vehicleDetail.InteriorColor = colorOptionsInterior;



                #region Standard Equipment

                List<StandardEquipment> StandardEquipment = new List<StandardEquipment>();
                if (vinResponse.standard != null && vinResponse.standard.Count() > 0)
                {
                    for (int i = 0; i < vinResponse.standard.Count(); i++)
                    {
                        StandardEquipment equipment = new StandardEquipment();
                        equipment.Mechanical = new List<Mechanical>();
                        equipment.Exterior = new List<Exterior>();
                        equipment.Entertainment = new List<Entertainment>();
                        equipment.Interior = new List<Interior>();
                        equipment.Safety = new List<Safety>();

                        if (vinResponse.standard[i].header != null)
                        {
                            if (vinResponse.standard[i].header.Value.ToLower() == "mechanical")
                            {
                                Mechanical mech = new Mechanical();
                                mech.HeaderName = vinResponse.standard[i].header.Value;
                                mech.Description = vinResponse.standard[i].description;
                                if (vinResponse.standard[i].styleId != null)
                                    mech.TrimID = vinResponse.standard[i].styleId;

                                equipment.Mechanical.Add(mech);
                            }
                            else if (vinResponse.standard[i].header.Value.ToLower() == "exterior")
                            {
                                Exterior ext = new Exterior();
                                ext.HeaderName = vinResponse.standard[i].header.Value;
                                ext.Description = vinResponse.standard[i].description;
                                if (vinResponse.standard[i].styleId != null)
                                    ext.TrimID = vinResponse.standard[i].styleId;

                                equipment.Exterior.Add(ext);
                            }
                            else if (vinResponse.standard[i].header.Value.ToLower() == "entertainment")
                            {
                                Entertainment entertain = new Entertainment();
                                entertain.HeaderName = vinResponse.standard[i].header.Value;
                                entertain.Description = vinResponse.standard[i].description;
                                if (vinResponse.standard[i].styleId != null)
                                    entertain.TrimID = vinResponse.standard[i].styleId;

                                equipment.Entertainment.Add(entertain);
                            }
                            else if (vinResponse.standard[i].header.Value.ToLower() == "interior")
                            {
                                Interior intr = new Interior();
                                intr.HeaderName = vinResponse.standard[i].header.Value;
                                intr.Description = vinResponse.standard[i].description;
                                if (vinResponse.standard[i].styleId != null)
                                    intr.TrimID = vinResponse.standard[i].styleId;

                                equipment.Interior.Add(intr);
                            }
                            else if (vinResponse.standard[i].header.Value.ToLower() == "safety")
                            {
                                Safety safty = new Safety();
                                safty.HeaderName = vinResponse.standard[i].header.Value;
                                safty.Description = vinResponse.standard[i].description;
                                if (vinResponse.standard[i].styleId != null)
                                    safty.TrimID = vinResponse.standard[i].styleId;

                                equipment.Safety.Add(safty);
                            }
                        }
                        StandardEquipment.Add(equipment);
                    }
                    vehicleDetail.StandardEquipment = StandardEquipment;
                }

                #endregion
                //Factory Options
                //Option[] factoryOptions = vinResponse.factoryOption;
                Random rnd = new Random();

                List<FactoryOptions> FactoryOptionsLst = new List<FactoryOptions>();
                if (vinResponse.factoryOption != null)
                {
                    foreach (Option option in vinResponse.factoryOption)
                    {
                        if (option.ambiguousOption != null && option.ambiguousOption.Count() > 0)
                        {
                            foreach (Option ambOption in option.ambiguousOption)
                            {
                                FactoryOptions opt = new FactoryOptions();

                                //Description
                                opt.Description = "";
                                foreach (string description in ambOption.description)
                                {
                                    opt.Description += description;
                                }

                                //Installed
                                opt.InstalledCause = ambOption.installed == null ? null : ambOption.installed.cause.ToString();

                                //OptionKindID
                                opt.OptionKindId = ambOption.optionKindId.ToString();

                                opt.optionid = rnd.Next(200000, 999999).ToString();

                                //Price
                                opt.Price = Convert.ToDecimal(ambOption.price.msrpMax);

                                //StyleId
                                opt.StyleId = ambOption.styleId;

                                //UTF
                                opt.Utf = ambOption.utf;

                                //Oem code
                                opt.OemCode = ambOption.oemCode;

                                FactoryOptionsLst.Add(opt);
                            }
                        }
                        else
                        {
                            FactoryOptions opt = new FactoryOptions();

                            //Description
                            opt.Description = "";
                            foreach (string description in option.description)
                            {
                                opt.Description += description;
                            }

                            //Installed
                            opt.InstalledCause = option.installed == null ? null : option.installed.cause.ToString();

                            //OptionKindID
                            opt.OptionKindId = option.optionKindId.ToString();

                            //Price
                            opt.Price = Convert.ToDecimal(option.price.msrpMax);
                            opt.optionid = rnd.Next(200000, 999999).ToString();
                            //StyleId
                            opt.StyleId = option.styleId;

                            //UTF
                            opt.Utf = option.utf;

                            //Oem code
                            opt.OemCode = option.oemCode;

                            FactoryOptionsLst.Add(opt);
                        }
                    }
                }
                // Preffered OptionKindID in an Array
                string[] optionKindIdList = FetchOptionkindIDs();

                //Filtering the list by OptionKindID for Additional Equipment
                List<FactoryOptions> optionList = (from b in FactoryOptionsLst
                                                   where (optionKindIdList.Contains(b.OptionKindId))
                                                   select b).ToList();
                vehicleDetail.FactoryOptions = optionList;

                //OEM Ext. color
                vehicleDetail.OEMExteriorColor = new List<IDValues>();
                IDAndValueComparer colorComparer = new IDAndValueComparer();
                if (vinResponse.exteriorColor != null)
                {
                    foreach (Color color in vinResponse.exteriorColor)
                    {
                        foreach (int id in color.styleId)
                        {
                            IDValues fieldValueExteriorColor = new IDValues();
                            fieldValueExteriorColor.ID = id.ToString();
                            fieldValueExteriorColor.Value = color.colorName;
                            if (!vehicleDetail.OEMExteriorColor.Contains(fieldValueExteriorColor, colorComparer))
                                vehicleDetail.OEMExteriorColor.Add(fieldValueExteriorColor);
                        }
                    }
                }
                //OEM Int. color
                vehicleDetail.OEMInteriorColor = new List<IDValues>();
                if (vinResponse.interiorColor != null)
                {
                    foreach (Color color in vinResponse.interiorColor)
                    {
                        foreach (int id in color.styleId)
                        {
                            IDValues fieldValueInteriorColor = new IDValues();
                            fieldValueInteriorColor.ID = id.ToString();
                            fieldValueInteriorColor.Value = color.colorName;
                            if (!vehicleDetail.OEMInteriorColor.Contains(fieldValueInteriorColor, colorComparer))
                                vehicleDetail.OEMInteriorColor.Add(fieldValueInteriorColor);
                        }
                    }
                }
                //Vehicle Base price
                vehicleDetail.VehicleMSRP = vinResponse.basePrice != null ? Convert.ToDecimal(vinResponse.basePrice.msrp.high) : 0;



                return vehicleDetail;
            }
            catch (Exception ex)
            {
                // Logger.LogError("ParseVinResponse", "Error occurred in Chrome Wrapper.", ex);
                throw new Exception("Error occurred in Chrome Wrapper. " + ex.Message);
            }
        }

        public async Task<VinVehicleDetail> GetDecodeVIN_NonBuildData(DecodeVINRequest _decodeVINRequest)
        {
            VinVehicleDetail vehicleDetail = new VinVehicleDetail();

            try
            {
                Description7aPortTypeClient service = new Description7aPortTypeClient();
                VehicleDescriptionRequest vehRequest = new VehicleDescriptionRequest();
                AccountInfo accountInfo = new AccountInfo();

                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumber.Trim();
                accountInfo.secret = _chromeContract.ChromeSecret.Trim();
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOf.Trim();
                vehRequest.accountInfo = accountInfo;
                describeVehicleResponse vinResponse = null;
                String vinParam = String.Empty;



                vehRequest.Items = new object[1];
                vinParam = _decodeVINRequest.VIN;
                vehRequest.Items[0] = vinParam;
                vehRequest.ItemsElementName = new ItemsChoiceType[1];
                vehRequest.ItemsElementName[0] = ItemsChoiceType.vin;
                vehRequest.@switch = new ChromeServiceReference.Switch[1];
                vehRequest.@switch[0] = ChromeServiceReference.Switch.ShowAvailableEquipment;

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    var json3 = JsonConvert.SerializeObject(vehRequest);

                    vinResponse = await service.describeVehicleAsync(vehRequest);
                    executionTime.Stop();

                    //Logger.LogDebugInfo(ConfigSettings.GetCurrentUsername(), "Time taken for Chrome DecodeVin : " + executionTime.Elapsed.ToString());
                }
                catch (Exception ex)
                {
                    //Logger.LogError(storeID.ToString(), "Connection to Chrome failed. ", ex);
                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }

                #region Parsing
                if (vinResponse.VehicleDescription.responseStatus.responseCode.ToString().Equals("Successful", StringComparison.OrdinalIgnoreCase) && vinResponse.VehicleDescription.bestMakeName == null)
                {
                    //throw new Exception(string.Format(ConfigSettings.GetErrorMessage(501013), VIN));
                    vehicleDetail.vin = _decodeVINRequest.VIN;

                    Make fieldValue = new Make();

                    fieldValue.ID = "0";
                    fieldValue.Value = "BAD_VIN";
                    vehicleDetail.make = new List<Make>();
                    vehicleDetail.make.Add(fieldValue);
                    List<Year> years = new List<Year>();
                    years = await GetChromeYears(_decodeVINRequest.RequestSource);
                    vehicleDetail.years = years;
                    vehicleDetail.IsDecodeSuccess = false;
                    vehicleDetail.DecodeStatus = new List<IDValues>();
                    IDValues DecodeStatus = new IDValues();
                    DecodeStatus.Value = "There is an issue decoding " + _decodeVINRequest.VIN + ". It might be a Canadian or other non - US VIN that cannot be decoded."; //string.Format(ConfigSettings.GetErrorMessage(501013), VIN);
                    DecodeStatus.ID = "There is an issue decoding " + _decodeVINRequest.VIN + ". It might be a Canadian or other non - US VIN that cannot be decoded."; //string.Format(ConfigSettings.GetErrorMessage(501013), VIN);
                    vehicleDetail.DecodeStatus.Add(DecodeStatus);

                    return vehicleDetail;
                }
                else if (!vinResponse.VehicleDescription.responseStatus.responseCode.ToString().Equals("Unsuccessful", StringComparison.OrdinalIgnoreCase))
                {
                    vehicleDetail = ParseVinResponse(vinResponse.VehicleDescription);
                }
                else
                {
                    List<Year> years = new List<Year>();
                    years = await GetChromeYears(_decodeVINRequest.RequestSource);
                    vehicleDetail.years = years;

                    //Logger.LogError("DecodeVin",
                    //                "Returns responseCode 'Unsuccessful'." + VIN,
                    //               (vinResponse.responseStatus.status != null) ? (new System.Exception(vinResponse.responseStatus.status[0].code + ": " + vinResponse.responseStatus.status[0].Value))
                    //               : null);
                    //throw new Exception("Returning responseCode as 'Unsuccessful'." + VIN);
                }

                #endregion Parsing

                return vehicleDetail;

            }
            catch (Exception ex)
            {
                // Logger.LogError("DecodeVin", "Call to DecodeVin method failed. ", ex);
                throw new Exception("Call to DecodeVin method failed. " + ex.Message);
            }
        }

        public async Task<VinVehicleDetail> GetDecodeBadVIN(DecodeBadVINRequest _decodeBadVINRequest)
        {
            VinVehicleDetail vehicleDetail = new VinVehicleDetail();
            try
            {
                Description7aPortTypeClient service = new Description7aPortTypeClient();
                AccountInfo accountInfo = new AccountInfo();
                accountInfo.country = "US";
                accountInfo.language = "en";
                accountInfo.number = _chromeContract.ChromeNumberBuildData;
                accountInfo.secret = _chromeContract.ChromeSecretBuildData;
                accountInfo.behalfOf = _chromeContract.ChromeBehalfOfBuildData;



                describeVehicleResponse vinResponse = null;
                String vinParam = String.Empty;

                VehicleDescriptionRequest vehRequest = new VehicleDescriptionRequest();
                vehRequest.accountInfo = accountInfo;
                vehRequest.Items = new object[1];

                vinParam = _decodeBadVINRequest.StyleId;
                vehRequest.Items[0] = Convert.ToInt32(vinParam);
                vehRequest.ItemsElementName = new ItemsChoiceType[1];
                vehRequest.ItemsElementName[0] = ItemsChoiceType.styleId;

                vehRequest.@switch = new ChromeServiceReference.Switch[1];
                vehRequest.@switch[0] = ChromeServiceReference.Switch.ShowAvailableEquipment;

                try
                {
                    Stopwatch executionTime = new Stopwatch();

                    executionTime.Start();
                    vinResponse = await service.describeVehicleAsync(vehRequest);

                    executionTime.Stop();

                    string str = Newtonsoft.Json.JsonConvert.SerializeObject(vinResponse);


                    if (!vinResponse.VehicleDescription.responseStatus.responseCode.ToString().Equals("Unsuccessful", StringComparison.OrdinalIgnoreCase))
                    {
                        vehicleDetail = ParseFactoryoptions(vinResponse.VehicleDescription);
                    }

                }
                catch (Exception ex)
                {

                    throw new Exception("Connection to Chrome failed. " + ex.Message);
                }
                return vehicleDetail;

            }
            catch (Exception ex)
            {
                // Logger.LogError("DecodeVin", "Call to DecodeVin method failed. ", ex);
                throw new Exception("Call to DecodeVin method failed. " + ex.Message);
            }
        }
        private VinVehicleDetail ParseFactoryoptions(VehicleDescription vinResponse)
        {
            //throw new NotImplementedException();
            //Factory Options
            //Option[] factoryOptions = vinResponse.factoryOption;
            Random rnd = new Random();
            VinVehicleDetail vehicleDetail = new VinVehicleDetail();



            List<FactoryOptions> FactoryOptionsLst = new List<FactoryOptions>();
            if (vinResponse.factoryOption != null)
            {
                foreach (Option option in vinResponse.factoryOption)
                {
                    if (option.ambiguousOption != null && option.ambiguousOption.Count() > 0)
                    {
                        foreach (Option ambOption in option.ambiguousOption)
                        {
                            FactoryOptions opt = new FactoryOptions();



                            //Description
                            opt.Description = "";
                            foreach (string description in ambOption.description)
                            {
                                opt.Description += description;
                            }



                            //Installed
                            opt.InstalledCause = ambOption.installed == null ? null : ambOption.installed.cause.ToString();



                            //OptionKindID
                            opt.OptionKindId = ambOption.optionKindId.ToString();



                            opt.optionid = rnd.Next(200000, 999999).ToString();



                            //Price
                            opt.Price = Convert.ToDecimal(ambOption.price.msrpMax);



                            //StyleId
                            opt.StyleId = ambOption.styleId;



                            //UTF
                            opt.Utf = ambOption.utf;



                            //Oem code
                            opt.OemCode = ambOption.oemCode;



                            FactoryOptionsLst.Add(opt);
                        }
                    }
                    else
                    {
                        FactoryOptions opt = new FactoryOptions();



                        //Description
                        opt.Description = "";
                        foreach (string description in option.description)
                        {
                            opt.Description += description;
                        }



                        //Installed
                        opt.InstalledCause = option.installed == null ? null : option.installed.cause.ToString();



                        //OptionKindID
                        opt.OptionKindId = option.optionKindId.ToString();



                        //Price
                        opt.Price = Convert.ToDecimal(option.price.msrpMax);
                        opt.optionid = rnd.Next(200000, 999999).ToString();
                        //StyleId
                        opt.StyleId = option.styleId;



                        //UTF
                        opt.Utf = option.utf;



                        //Oem code
                        opt.OemCode = option.oemCode;



                        FactoryOptionsLst.Add(opt);
                    }
                }
            }
            // Preffered OptionKindID in an Array
            string[] optionKindIdList = FetchOptionkindIDs();



            //Filtering the list by OptionKindID for Additional Equipment
            List<FactoryOptions> optionList = (from b in FactoryOptionsLst
                                               where (optionKindIdList.Contains(b.OptionKindId))
                                               select b).ToList();
            vehicleDetail.FactoryOptions = optionList;
            return vehicleDetail;
        }
        public string[] FetchDriveTrains()
        {
            return _decodeEntity.DriveTrain.Split(',');
        }

        public string[] FetchBodyStyles()
        {
            return _decodeEntity.BodyStyles.Split(',');
        }
        public string[] FetchExtColorList()
        {

            return _decodeEntity.ExtColors.Split(',');
        }
        public string[] FetchOptionkindIDs()
        {
            return _decodeEntity.AllOptionIDs.Split(',');
        }
        public string[] FetchIntColorList()
        {

            return _decodeEntity.IntColor.Split(',');
        }
        public string[] FetchIntTypeList()
        {

            return _decodeEntity.IntType.Split(',');
        }
    }
}
