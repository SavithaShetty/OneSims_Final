﻿using Sonic.Chrome.Api.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Services.Interfaces
{
    public interface IChromeService
    {
        public Task<List<Year>> GetChromeYears(string requestSouce);

        public Task<List<Make>> GetChromeMakes(MakeRequest makeRequest);

        public Task<List<Model>> GetChromeModels(ModelRequest modelRequest);
        
        public Task<List<Trim>> GetChromeStyles(StyleRequest styleRequest);
      
        public Task<List<Trim>> GetChromeTrims(TrimRequest trimRequest);

        public Task<VinVehicleDetail> GetDecodeVIN(DecodeVINRequest decodeVINRequest);

        public Task<VinVehicleDetail> GetDecodeVIN_NonBuildData(DecodeVINRequest decodeVINRequest);

        public Task<VinVehicleDetail> GetDecodeBadVIN(DecodeBadVINRequest _decodeBadVINRequest);
    }
}
