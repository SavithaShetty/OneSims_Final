using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Sonic.Chrome.Api.Configuration;
using Sonic.Chrome.Api.Extensions;
using Sonic.Chrome.Api.Helpers;
using Sonic.Chrome.Api.Security;
using Sonic.Chrome.Api.Services;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using Sonic.Chrome.Api.Middlewares;
using Sonic.Chrome.Api.Services.Interfaces;
using FluentValidation.AspNetCore;

//[assembly:ApiConventionType(typeof(SIMSConventions))]
namespace Sonic.Chrome.Api
{
    
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().AddNewtonsoftJson();//(x => x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));            

            services.AddControllers(config=> 
            {
                config.ReturnHttpNotAcceptable = true;
                config.Filters.Add(typeof(ValidateModelStateAttribute));
            })
            .AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());

            services.AddAuthentication(BasicAuthenticationHandler.SchemeName)
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.SchemeName, null);

            
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IChromeService, ChromeService>();
            services.AddVersionService();

            services.AddSwaggerService();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,
            IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthorization();

            app.UseSwagger();
            app.AddSwaggerMidleware(apiVersionDescriptionProvider);

            app.UseMiddleware<ErrorHandlerMiddleware>();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
