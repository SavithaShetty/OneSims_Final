﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Extensions
{
    public static class VersioningExtension
    {
        public static IServiceCollection AddVersionService(this IServiceCollection services)
        {

            services.AddVersionedApiExplorer(setupAction =>
            {
                setupAction.GroupNameFormat = "'v'V";                
                setupAction.SubstituteApiVersionInUrl = true;
            });


            services.AddApiVersioning(setupAction =>
            {
                setupAction.AssumeDefaultVersionWhenUnspecified = true;
                setupAction.DefaultApiVersion = new ApiVersion(1, 0);
                setupAction.ReportApiVersions = true;
                //setupAction.ApiVersionReader = new HeaderApiVersionReader();
                //setupAction.ApiVersionReader = new MediaTypeApiVersionReader();
            });
            return services;
        }
    }
}
