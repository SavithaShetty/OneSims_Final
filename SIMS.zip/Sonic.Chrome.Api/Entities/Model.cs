﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    /// <summary>
    /// Model
    /// </summary>
    public class Model
    {
        /// <summary>
        /// The Id of the Model
        /// </summary>
        /// <example>1</example> 
        public string ID { get; set; }
        /// <summary>
        /// The Value of Model
        /// </summary>
        public string Value { get; set; }
    }
}
