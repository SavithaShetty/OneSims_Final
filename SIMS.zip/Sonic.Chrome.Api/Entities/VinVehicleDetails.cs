﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Sonic.Chrome.Api.Entities
{
    public partial class VinVehicleDetail
    {
        // Single Values.

        public string vin { get; set; }
        public uint year { get; set; }
        public bool newVehicle { get; set; }
        public string Uvc { get; set; }
        public uint Cylinders { get; set; }
        public uint NoOfDoors { get; set; }
        public bool ClarificationNeeded { get; set; }
        public bool IsDecodeSuccess { get; set; }

        // MultiValues. May be infuture.
        public List<EngineDetails> engineDetails { get; set; }
        public List<Year> years { get; set; }
        public List<Make> make { get; set; }
        public List<IDValues> Engine { get; set; }
        public List<Model> model { get; set; }
        public List<IDValues> bodyStyle { get; set; }
        public StyleBodyType[] styleBodyTypes { get; set; }
        public List<IDValues> series { get; set; }
        public List<IDValues> Transmission { get; set; }
        public List<IDValues> DriveTrain { get; set; }
        public List<IDValues> ClassOfVehicle { get; set; }
        public List<IDValues> DecodeStatus { get; set; }
        public List<IDValues> DMVClass { get; set; }
        public List<ColorOptions> ExteriorColor { get; set; }
        public List<ColorOptions> InteriorColor { get; set; }
        //public List<IDValues> InteriorType { get; set; }
        //public List<IDValues> Fuel { get; set; }
        //public List<IDValues> VehicleType { get; set; }
        //public List<IDValues> DMVType { get; set; }
        public List<OptionValues> Options { get; set; }
        //public List<IDValues> ModelCode { get; set; }
        //public List<IDValues> DealerOption { get; set; }
        //public List<IDValues> SourceType { get; set; }

        public List<IDValues> OdometerOptions { get; set; }
        //Added for Factory Options
        public List<FactoryOptions> FactoryOptions { get; set; }
        public List<IDValues> OEMExteriorColor { get; set; }
        public List<IDValues> OEMInteriorColor { get; set; }
        public decimal VehicleMSRP { get; set; }
        public bool IsFactoryOptionRequired { get; set; }

        //Added for Standard Equipment
        public List<StandardEquipment> StandardEquipment { get; set; }

        public string Odometer { get; set; }


    }



    /// <summary>
    /// To get all engine properties.
    /// </summary>
    [Serializable]
    public class EngineDetails
    {
        public string displacement { get; set; }

        public long NetTorque_RPM { get; set; }
        public decimal NetTorque_Value { get; set; }

        public decimal Horsepower_RPM { get; set; }
        public decimal Horsepower_Value { get; set; }

        public decimal FuelEfficiencyCity { get; set; }
        public decimal FuelEfficiencyHwy { get; set; }

        public string FuelType { get; set; }
    }



    /// <summary>
    /// For comparing the objects while adding it to the list
    /// </summary>
    public class IDValueComparer : IEqualityComparer<IDValues>
    {
        public bool Equals(IDValues x, IDValues y)
        {

            if (Object.ReferenceEquals(x, y)) return true;

            if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
                return false;

            return x.ID == y.ID;
        }

        // If Equals() returns true for a pair of objects 
        // then GetHashCode() must return the same value for these objects.

        public int GetHashCode(IDValues idValues)
        {
            if (Object.ReferenceEquals(idValues, null)) return 0;

            int hashIDValuesID = idValues.ID.GetHashCode();

            return hashIDValuesID;
        }
    }


    /// <summary>
    /// For comparing the objects by considering ID and Value while adding it to the list
    /// </summary>
    public class IDAndValueComparer : IEqualityComparer<IDValues>
    {
        public bool Equals(IDValues x, IDValues y)
        {

            if (Object.ReferenceEquals(x, y)) return true;

            if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
                return false;

            return (x.ID == y.ID && x.Value == y.Value);
        }

        // If Equals() returns true for a pair of objects 
        // then GetHashCode() must return the same value for these objects.

        public int GetHashCode(IDValues idValues)
        {
            if (Object.ReferenceEquals(idValues, null)) return 0;

            int hashIDValuesID = idValues.ID.GetHashCode();

            return hashIDValuesID;
        }
    }

    /// <summary>
    /// Holds the Optional details
    /// </summary>
    [Serializable]
    public class OptionValues : IDValues
    {
        public decimal Cost { get; set; }
        public decimal TradeInCost { get; set; }
        public decimal RetailCost { get; set; }
        public string Std { get; set; }
        public string Oa { get; set; }

        public decimal TradeInXClean { get; set; }
        public decimal TradeInAbove { get; set; }
        public decimal TradeInAverage { get; set; }
        public decimal TradeInBelow { get; set; }

        public decimal RetailAbove { get; set; }
        public decimal RetailAverage { get; set; }
        public decimal RetailBelow { get; set; }

        public decimal LoanAbove { get; set; }
        public decimal LoanAverage { get; set; }
        public decimal LoanBelow { get; set; }

        //Added wholesale values
        public decimal WSaleAbove { get; set; }
        public decimal WSaleAverage { get; set; }
        public decimal WSaleBelow { get; set; }

    }

    public class StyleBodyType
    {

        public bool primaryField { get; set; }

        public bool primaryFieldSpecified { get; set; }
    }
}
