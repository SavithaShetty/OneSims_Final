﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    public class MakeRequest
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// Provide a Year to retrieve list of Makes. Ex: 2020 or 2021
        /// </summary>
        public int YearId { get; set; }

    }

    public class MakeValidator : AbstractValidator<MakeRequest>
    {
        public MakeValidator()
        {
            RuleFor(x => x.YearId).NotEqual(0).NotEmpty(); 
            RuleFor(x => x.RequestSource).NotEmpty();
        }
    }
}
