﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    public class DecodeBadVINRequest 
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: OneSIMS Portal, Service, Mobile, OnlineWidget, CDK etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// StyleId for BadVIN to be decoded
        /// </summary>
        public string StyleId { get; set; }
    }

    public class DecodeBadVINValidator : AbstractValidator<DecodeBadVINRequest>
    {
        public DecodeBadVINValidator()
        {
            RuleFor(x => x.RequestSource).NotEmpty();
            RuleFor(x => x.StyleId).NotEmpty().NotNull();
        }
    }
}
