﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    public class TrimRequest
    {
        /// <summary>
        /// Year 
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Make 
        /// </summary>
        public string Make { get; set; }

        /// <summary>
        /// Model
        /// </summary>
        public string Model { get; set; }
    }

    public class TrimRequestValidator : AbstractValidator<TrimRequest>
    {
        public TrimRequestValidator()
        {
            RuleFor(m => m.Year).NotEmpty().InclusiveBetween(1950, 3000);
            RuleFor(m => m.Make).NotNull().NotEmpty();
            RuleFor(m => m.Model).NotNull().NotEmpty();

        }
    }
}
