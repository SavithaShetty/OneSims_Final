﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    [Serializable]
    public class FactoryOptions
    {
        public string Description { get; set; }

        public string OptionKindId { get; set; }

        public decimal? Price { get; set; }

        public string InstalledCause { get; set; }

        public int[] StyleId { get; set; }

        public string OemCode { get; set; }

        public string isSelected { get; set; }
        public int Vehicle_src { get; set; }
        public string optionid { get; set; }
        public long? Option_ID { get; set; }
        public long? Style_ID { get; set; }
        public string Utf { get; set; }
        public string Option_Description { get; set; }
        public string Category_Name { get; set; }
        public decimal? MSRP { get; set; }
    }
}
