﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    /// <summary>
    /// A Make model
    /// </summary>
    public class Make
    {
        /// <summary>
        /// The ID of the Make
        /// </summary> 
        /// <example>1</example>
        public string ID { get; set; }

        /// <summary>
        /// The value of Make
        /// </summary>
        public string Value { get; set; }
    }
}
