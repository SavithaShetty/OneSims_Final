﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    /// <summary>
    ///  Trim
    /// </summary>
    public class Trim
    {
        /// <summary>
        /// The Id of the Trim 
        /// </summary>
        /// <example>1</example>
        public string ID { get; set; }
        /// <summary>
        /// The Valud of Trim
        /// </summary>
        public string Value { get; set; }
    }
}
