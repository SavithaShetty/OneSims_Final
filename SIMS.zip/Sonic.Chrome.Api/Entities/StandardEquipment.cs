﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    [Serializable]
    public partial class StandardEquipment
    {
        public List<Mechanical> Mechanical { get; set; }
        public List<Exterior> Exterior { get; set; }
        public List<Entertainment> Entertainment { get; set; }
        public List<Interior> Interior { get; set; }
        public List<Safety> Safety { get; set; }
    }
    [Serializable]
    public class Mechanical
    {
        public string HeaderName { get; set; }
        public string Description { get; set; }
        public int[] TrimID { get; set; }
    }
    [Serializable]
    public class Exterior
    {
        public string HeaderName { get; set; }
        public string Description { get; set; }
        public int[] TrimID { get; set; }
    }
    [Serializable]
    public class Entertainment
    {
        public string HeaderName { get; set; }
        public string Description { get; set; }
        public int[] TrimID { get; set; }
    }
    [Serializable]
    public class Interior
    {
        public string HeaderName { get; set; }
        public string Description { get; set; }
        public int[] TrimID { get; set; }
    }
    [Serializable]
    public class Safety
    {
        public string HeaderName { get; set; }
        public string Description { get; set; }
        public int[] TrimID { get; set; }
    }
}
