﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.Chrome.Api.Entities
{
    /// <summary>
    /// Year
    /// </summary>
    public class Year
    {
        /// <summary>
        /// The Id of the year
        /// </summary>
        /// <example>2020</example>
        public string ID { get; set; }
        /// <summary>
        /// The Value of the year
        /// </summary>
        /// <example>2020</example>
        public string Value { get; set; }
    }
}
