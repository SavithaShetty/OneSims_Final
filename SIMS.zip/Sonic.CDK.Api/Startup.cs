using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Sonic.CDK.Api.Configuration;
using Sonic.CDK.Api.Extensions;
using Sonic.CDK.Api.Helpers;
using Sonic.CDK.Api.Middlewares;
using Sonic.CDK.Api.Security;
using Sonic.CDK.Api.Services;
using Sonic.CDK.Api.Services.Interfaces;

namespace Sonic.CDK.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));

            services.AddControllers(config =>
            {
                config.ReturnHttpNotAcceptable = true;
                // config.Filters.Add(typeof(ValidateModelStateAttribute));                
            })
            .AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());
            //.ConfigureApiBehaviorOptions(options => {
            //    options.SuppressModelStateInvalidFilter = true;
            //});
            
            services.AddAuthentication(BasicAuthenticationHandler.SchemeName)
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.SchemeName, null);

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IValuationService, ValuationService>();
            services.AddScoped<IVehicleInvService, VehicleInvService>();
            services.AddScoped<IAutoCheckService, AutocheckService>();
            services.AddVersionService();

            services.AddSwaggerService();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env
            , IApiVersionDescriptionProvider apiVersionDescriptionProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.AddSwaggerMidleware(apiVersionDescriptionProvider);

            app.UseMiddleware<ErrorHandlerMiddleware>();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
