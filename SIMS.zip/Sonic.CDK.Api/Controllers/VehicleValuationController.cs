﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.Helpers;
using Sonic.CDK.Api.Security;
using Sonic.CDK.Api.Services;
using Sonic.CDK.Api.Services.Interfaces;

namespace Sonic.CDK.Api.Controllers
{    
    [ApiVersion("1")]    
    [Route("api/v{version:apiVersion}/VehcileValuation")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    public class VehicleValuationController : ControllerBase
    {
        private readonly IValuationService _valuationService;

        public VehicleValuationController(IValuationService valuationService)
        {
            _valuationService = valuationService;
        }

        /// <summary>
        /// Get make list for given year
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the make list and error list will be empty or contains the warnings</li>
        /// <li> For invalid payload request the response will have empty make list and contains the error list returns from CDK service</li>
        /// </ul>
        /// </remarks>  
        /// </response>                    
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>                   
        [HttpPost("makes")]
        [MapToApiVersion("1")]       
        public async Task<ActionResult<MakeResponse>> GetMakes([FromBody] MakeRequest makeRequest)
        {            
            var res = await _valuationService.GetMakes(makeRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get model list for given year and make values
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the model list and error list will be empty or contains the warnings</li>
        /// <li> For invalid payload request the response will have empty model list and contains the error list returns from CDK service</li>
        /// <li> Note :- Few vehciles may not have model values  </li>
        /// </ul>
        /// </remarks>  
        /// </response>   
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("models")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<ModelResponse>> GetModels([FromBody] ModelRequest modelRequest)
        {

            var res = await _valuationService.GetModels(modelRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get trim list for given year, make and model values
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the trim list and error list will be empty or contains the Warnings</li>
        /// <li> For invalid payload request the response will have empty trim list and contains the error list returns from CDK service</li>
        /// </ul>
        /// </remarks>  
        /// </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>        
        [HttpPost("trims")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<TrimResponse>> GetTrims([FromBody] TrimRequest trimRequest)
        {
            var res = await _valuationService.GetTrims(trimRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get BodyStyle list for given year, make, model and trim values
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the bodystyle list and error list will be empty</li>
        /// <li> For invalid payload request the response will have empty bodystyle list and contains the error list returns from CDK service</li>
        /// </ul>
        /// </remarks>  
        /// </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>        
        [HttpPost("bodystyles")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<BodyStyleResponse>> GetBodyStyles([FromBody] BodyStyleRequest bodyStyleRequest)
        {
            var res = await _valuationService.GetBodyStyles(bodyStyleRequest);
            return Ok(res);
        }



        /// <summary>
        /// Get the vehicle properties by VIN
        /// </summary>
        /// <remarks>
        /// ### Service requires below Contract Details with VIN
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li> 
        /// </ul>        
        /// </remarks>      
        /// <response code="200">
        /// <remarks>                
        /// Service Response Details <br />
        /// -  Given VIN may Partially or fully decode, in a response if the clarify flag is false then given VIN is fully decoded or else partially decoded and response will contains the multiple vehciles decode values in list of VinDecodeValue  <br />
        /// -  CDK service returns warrning in error list even in success case, so error can ignore if they contains only warnings. <br />
        /// -  A success response can identified based on the values in Vindecodevalue list <br />
        /// -  A Single VinDecodeValue will contains the below  values <br />        
        /// <ul>
        /// <li> VIN  </li>
        /// <li> Year </li>
        /// <li> Make  - single value</li>
        /// <li> Model - single value</li> 
        /// <li> Trim  - single vlaue</li> 
        /// <li> BodyStyle - single value </li>
        /// <li> ProviderId - the requested provider ID </li>
        /// <li> Region - value of region </li>
        /// <li> Odometer - value of odometer </li>
        /// <li> Location - value of location </li>
        /// <li> Makes  - Collection of makes with code and values</li>
        /// <li> Models - Collection of models with code and values</li> 
        /// <li> Trims  - Collection of Trims with code and values</li> 
        /// <li> BodyStyles - Collection of bodystyles with code and values </li>
        /// <li> PoviderDefCode - Provider defination code value or UVC value </li>
        /// <li> Options - Collection of option values</li>       
        /// </ul>                
        /// </remarks>
        /// </response>        
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("decodevin")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<DecodeVinResponse>> GetDecodeVIN([FromBody] DecodeVinRequest decodeVinRequest)
        {

            var res = await _valuationService.GetDecodeValues(decodeVinRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get the vehicle options list
        /// </summary>        
        /// <remarks>
        /// ### Service requires below Contract Details and additional details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li>
        /// <li> VIN, Year, Make, Model, Trim, BodyStyle, Odometer,Condition and LowVolume are optional paramter </li>
        /// <li> ProviderDefCode or BodyStyle ID is mandatory parameter </li>
        /// </ul>  
        /// </remarks>      
        /// <response code="200">
        /// <remarks>                
        /// ### Returns the options list
        /// </remarks>
        /// </response>        
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("options")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<OptionsResponse>> GetOptions([FromBody] OptionsRequest optionsRequest)
        {

            var res = await _valuationService.GetOptions(optionsRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get the book values
        /// </summary>        
        /// <remarks>
        /// ### Service requires below Contract Details and additional details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Source - identifier value of service consumer client</li>
        /// <li> Vehicle Properties  like VIN, Year, Make, Model, Trim, BodyStyle, Odometer,Condition, ProviderDefCode or BodyStyle ID parameter </li>
        /// <li> Selected Options list can also be passed</li>
        /// </ul>  
        /// </remarks>                   
        /// <response code="200">Book Value will be return </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("bookvalues")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<BookValueResponse>> GetBookValues([FromBody] BookValueRequest bookValueRequest)
        {
            var res = await _valuationService.GetBookValues(bookValueRequest);
            return Ok(res);
        }

    }
}
