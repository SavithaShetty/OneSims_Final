﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using InventoryServiceReference;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.Helpers;
using Sonic.CDK.Api.Security;
using Sonic.CDK.Api.Services.Interfaces;

namespace Sonic.CDK.Api.Controllers
{

    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    public class VehicleInventoryController : ControllerBase
    {
        private readonly IVehicleInvService _vehicleInvService;
        public VehicleInventoryController(IVehicleInvService vehicleInvService)
        {
            _vehicleInvService = vehicleInvService;
        }

        /// <summary>
        /// Get generic values 
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>        
        /// <li> Region - region ID of dealer </li> 
        /// <li> Source - identifier value of service consumer client</li> 
        /// </ul>
        /// </remarks>   
        /// <param name="source">The identifier value of service consumer client</param>
        /// <param name="regionid">The region ID of dealer</param>
        /// <param name="newvehicle">Boolean value to for newvehicle Ex:- true for newvehicle</param>
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains generic values list and error list will be empty or contains the warnings</li>
        /// <li> For invalid payload request the response will have generic values list and contains the error list returns from CDK service</li>  
        /// </ul>
        /// </remarks>  
        /// </response>   
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("listvalues/{source}/{regionid}/{newvehicle}/")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<ListValuesResponse>> GetListvalues([FromRoute][Required] string source, [FromRoute][Required] decimal regionid, [FromRoute][Required] Boolean newvehicle)
        {

            var res = await _vehicleInvService.GetListValues(regionid, newvehicle);
            return Ok(res);
        }

        /// <summary>
        /// Get vehicle RO PO values from vehicle service history.
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>        
        /// <li> dealerId - dealer ID of dealer </li> 
        /// <li> regionId - region ID of dealer</li> 
        /// <li> adpVehicleId - adp vehicle ID</li> 
        /// </ul>
        /// </remarks>
        /// <param name="dealerId">dealer ID of dealer</param>
        /// <param name="regionId">region ID of dealer</param>
        /// <param name="adpVehicleId">adp vehicle ID</param>
        /// <response code="200">Success</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpGet("GetDVCValues/{dealerId}/{regionId}/{adpVehicleId}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<List<ROPO>>> GetDVCValues([FromRoute][Required] string dealerId, [FromRoute][Required] decimal regionId, [FromRoute][Required] decimal adpVehicleId)
        {
            var res = await _vehicleInvService.GetDVCValues(dealerId, regionId, adpVehicleId);
            return Ok(res);
        }
    }
}
