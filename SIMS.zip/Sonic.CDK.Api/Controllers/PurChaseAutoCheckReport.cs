﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.Helpers;
using Sonic.CDK.Api.Security;
using Sonic.CDK.Api.Services;
using Sonic.CDK.Api.Services.Interfaces;

namespace Sonic.CDK.Api.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/VehcileValuation")]
    [ApiController]
    [ApiConventionType(typeof(SIMSConventions))]
    [Authorize(AuthenticationSchemes = BasicAuthenticationHandler.SchemeName)]
    [Produces("application/json")]
    public class PurChaseAutoCheckReport : ControllerBase
    {
        private readonly IAutoCheckService _autocheckService;

        public PurChaseAutoCheckReport(IAutoCheckService autocheckService)
        {
            _autocheckService = autocheckService;
        }


        /// <summary>
        ///This end point is used to get Purchase AutoCheck Report, For every hit to this service is Chargeable..
        /// </summary>
        /// <remarks>This end point is used to  get Purchase AutoCheck Report, For every hit to this service is Chargeable.</remarks>
        /// <param name="UserID">This UserID is provided by AutoCheck Vendor</param>
        /// <param name="Password">This Password is  provided by AutoCheck Vendor</param>
        ///  <param name="VIN">This VIN length should be 17</param>
        ///  <param name="DealerId">This DealerId is provided by AutoCheck Vendor</param>
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains Autocheck Reports and error list will be empty</li>
        /// <li> For invalid payload request the response will have empty Report and contains the error list returns from CarFax service</li>
        /// </ul>
        /// </remarks>  
        /// </response>     
        /// <response code="404">Purchange of Autocheck Not Found</response>   
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>          
        [HttpGet("GetAutoCheckReport/{UserID}/{Password}/{VIN}/{DealerId}")]
        [MapToApiVersion("1")]
        public async Task<ActionResult<AutoCheckReport>> GetAutoCheckReport(string UserID, string Password, string VIN, string DealerId)
        {
            AutockeckRequest _autocheckRequest = new AutockeckRequest();
            _autocheckRequest.DealerID = DealerId;
            _autocheckRequest.VIN = VIN;
            _autocheckRequest.Password = Password;
            _autocheckRequest.UserID = UserID;
            var res = await _autocheckService.GetAutoCheckReport(_autocheckRequest);
            return Ok(res);
        }
    }
}
