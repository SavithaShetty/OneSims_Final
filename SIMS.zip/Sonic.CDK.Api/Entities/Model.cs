﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    /// <summary>
    /// Model
    /// </summary>
    public class Model
    {
        /// <summary>
        /// The Id of the Model
        /// </summary>
        /// <example>1</example>
        public string Code { get; set; }

        /// <summary>
        /// The value of Make
        /// </summary>
        public string Value { get; set; }
    }
}
