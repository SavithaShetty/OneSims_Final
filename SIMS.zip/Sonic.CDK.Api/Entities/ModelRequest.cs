﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class ModelRequest : ContractDetails
    {
        /// <summary>
        /// Year 
        /// </summary>
        public int Year { get; set; }
        /// <summary>
        /// Make 
        /// </summary>
        public string Make { get; set; }
    }

    
    public class ModelRequestValidator : AbstractValidator<ModelRequest>
    {
        public ModelRequestValidator()
        {
            RuleFor(m => m.DealerId).NotNull().NotEmpty();            
            RuleFor(m => m.PorviderId).NotEmpty();
            RuleFor(m => m.Region).NotNull().NotEmpty();
            RuleFor(m => m.Source).NotNull().NotEmpty();
            RuleFor(m => m.Year).NotEmpty().InclusiveBetween(1950, 3000);
            RuleFor(m => m.Make).NotNull().NotEmpty();

        }
    }
}
