﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class BookValueRequest:ContractDetails
    {
        /// <summary>
        /// VIN - Optional Parameter
        /// </summary>
        public string VIN { get; set; }

        /// <summary>
        /// Year -Optional Parameter
        /// </summary>
        public int? Year { get; set; } = null;

        /// <summary>
        /// Make - Optional Parameter
        /// </summary>
        public string Make { get; set; }

        /// <summary>
        /// Model -Optional Parameter
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// Trim -Optional Parameter
        /// </summary>
        public string Trim { get; set; }

        /// <summary>
        /// BodyStyle -Optional Parameter
        /// </summary>
        public string BodyStyle { get; set; }

        /// <summary>
        /// Odometer -Optional Parameter
        /// </summary>
        public int? Odometer { get; set; } = null;

        /// <summary>
        /// Condition -Optional Parameter
        /// </summary>
        public string Condition { get; set; }

        /// <summary>
        /// ProviderDefCode - is body style ID and it is Manadatory field 
        /// </summary>
        public string ProviderDefCode { get; set; }

        /// <summary>
        /// Options selected
        /// </summary>
        public List<OptionValues> Options { get; set; }
    }
}
