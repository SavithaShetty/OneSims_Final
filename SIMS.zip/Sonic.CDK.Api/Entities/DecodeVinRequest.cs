﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class DecodeVinRequest:ContractDetails
    {
        public string VIN { get; set; }
    }

    public class DecodeVinRequestValidator: AbstractValidator<DecodeVinRequest>
    {
        public DecodeVinRequestValidator()
        {
            RuleFor(m => m.DealerId).NotNull().NotEmpty();
            RuleFor(m => m.PorviderId).NotEmpty();
            RuleFor(m => m.Region).NotNull().NotEmpty();
            RuleFor(m => m.Source).NotNull().NotEmpty();
            RuleFor(m => m.VIN).NotNull().NotEmpty().MinimumLength(17).MaximumLength(17);
            
        }
    }


}
