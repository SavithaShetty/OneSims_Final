﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class DecodeVinResponse
    {
        /// <summary>
        /// Will contains the error list
        /// </summary>
        public List<Error> Errors { get; set; }

        /// <summary>
        /// Clarify value is true if vehicle partially decoded
        /// </summary>
        public bool? Clarify { get; set; }

        public List<VinDecodeValue> VinDecodeValues { get; set; }
        
    }
}
