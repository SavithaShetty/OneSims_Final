﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class OptionsRequest:ContractDetails
    {
        /// <summary>
        /// VIN - Optional Parameter
        /// </summary>
        public string VIN { get; set; }

        /// <summary>
        /// Year -Optional Parameter
        /// </summary>
        public int? Year { get; set; } = null;

        /// <summary>
        /// Make - Optional Parameter
        /// </summary>
        public string Make { get; set; }

        /// <summary>
        /// Model -Optional Parameter
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// Trim -Optional Parameter
        /// </summary>
        public string Trim { get; set; }

        /// <summary>
        /// BodyStyle -Optional Parameter
        /// </summary>
        public string BodyStyle { get; set; }

        /// <summary>
        /// Odometer -Optional Parameter
        /// </summary>
        public int? Odometer { get; set; } = null;

        /// <summary>
        /// Condition -Optional Parameter
        /// </summary>
        public string Condition { get; set; }

        /// <summary>
        /// ProviderDefCode -  is body style ID and it is Manadatory field 
        /// </summary>
        public string ProviderDefCode { get; set; }

        /// <summary>
        /// LowVolume - optional parameter
        /// </summary>
        public bool? LowVolume { get; set; } = null;

    }

    public class OptionsRequestValidator : AbstractValidator<OptionsRequest>
    {
        public OptionsRequestValidator()
        {
            RuleFor(m => m.DealerId).NotNull().NotEmpty();
            RuleFor(m => m.PorviderId).NotEmpty();
            RuleFor(m => m.Region).NotNull().NotEmpty();
            RuleFor(m => m.Source).NotNull().NotEmpty();
            RuleFor(m => m.Year).InclusiveBetween(1950, 3000).When(m=>m.Year.HasValue);
            RuleFor(m => m.ProviderDefCode).NotNull().NotEmpty();
            //RuleFor(m => m.Make).NotNull().NotEmpty();
            //RuleFor(m => m.Model).NotNull().NotEmpty();
            //RuleFor(m => m.Trim).NotNull().NotEmpty();
        }
    }
}
