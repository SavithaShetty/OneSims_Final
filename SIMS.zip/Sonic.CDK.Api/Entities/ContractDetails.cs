﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{

    public class ContractDetails
    {
        /// <summary>
        /// Dealer ID provided from CDK
        /// </summary>
        public string DealerId { get; set; }

        /// <summary>
        /// Provider ID - for specific book value provider
        /// </summary>
        public int PorviderId { get; set; }

        /// <summary>
        /// Region - value for specific book value provider
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// Source - identifier value of service consumer client
        /// </summary>
        public string Source { get; set; }
    }

    
}
