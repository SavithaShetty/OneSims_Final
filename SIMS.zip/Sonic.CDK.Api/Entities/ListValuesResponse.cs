﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class ListValuesResponse
    {
        public decimal location { get; set; }
        public List<IDValues> lot { get; set; }
        public List<IDValues> generic_transmissions { get; set; }
        public List<IDValues> generic_xcolors { get; set; }
        public List<IDValues> generic_icolors { get; set; }
        public List<IDValues> generic_itexture { get; set; }
        public List<IDValues> invstatus { get; set; }
        public List<IDValues> dmvnewused { get; set; }
        public List<IDValues> acquiredtype { get; set; }
        public List<IDValues> acquiredsource { get; set; }
        public List<IDValues> fuel { get; set; }
        public List<IDValues> dmvbody { get; set; }
        public List<IDValues> invtype { get; set; }
        public List<IDValues> @class { get; set; }
        public List<IDValues> dmvclass { get; set; }
        public List<IDValues> authenticity_of_mileage { get; set; }
        public List<IDValues> unit_of_measure { get; set; }
        public List<IDValues> registration_class { get; set; }
        public List<IDValues> licensestates { get; set; }
        public List<Error> Errors { get; set; }
    }

    public class IDValues
    {
        public string ID { get; set; }
        public string Value { get; set; }
    }
}
