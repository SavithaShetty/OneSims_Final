﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class AutoCheckReport
    {

        public string dealerID
        { 
            get; 
            set; 
        }
        public string vinNmbr
        {
            get;
            set;

        }

        public string vinPass
        {
            get;
            set;
        }
        ///// <summary>
        ///// 100 - For green button 
        ///// 90 - For red button
        ///// 80 - For exception button
        ///// </summary>
        //public byte ReportIconId
        //{
        //    get;
        //    set;

        //}

        public string vinReportUrl
        {
            get;
            set;

        }

        public string ErrorMsg
        {
            get;
            set;

        }

    }
}
