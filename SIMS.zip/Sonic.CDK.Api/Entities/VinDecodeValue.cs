﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class VinDecodeValue
    {
        public string vin { get; set; }

        public string year { get; set; }

        public string Make { get; set; }

        public string Model { get; set; }

        public string Trim { get; set; }

        public string BodyStyle { get; set; }

        public string Region { get; set; }

        public decimal Odometer { get; set; }

        public string PoviderDefCode { get; set; }

        public decimal Location { get; set; }

        public decimal ProviderId { get; set; }

        public List<Make> Makes { get; set; }

        public List<Model> Models { get; set; }

        public List<Trim> Trims { get; set; }

        public List<BodyStyle> BodyStyles { get; set; }

        public List<OptionValues> Options { get; set; }
        
    }
}
