﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class BodyStyleResponse
    {
        public List<BodyStyle> BodyStyles { get; set; }
        public List<Error> Errors { get; set; }
    }
}
