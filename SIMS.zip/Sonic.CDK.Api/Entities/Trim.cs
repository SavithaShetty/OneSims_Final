﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    /// <summary>
    ///  Trim
    /// </summary>
    public class Trim
    {
        /// <summary>
        /// The Code value of Trim
        /// </summary>
        /// <example>1</example>
        public string Code { get; set; }

        /// <summary>
        /// The value of Trim
        /// </summary>
        public string Value { get; set; }
    }
}
