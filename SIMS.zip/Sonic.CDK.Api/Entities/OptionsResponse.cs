﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class OptionsResponse
    {
        public List<Error> Errors { get; set; }

        public List<OptionValues> optionValues  { get; set; }

        public string PoviderDefCode { get; set; }
    }
}
