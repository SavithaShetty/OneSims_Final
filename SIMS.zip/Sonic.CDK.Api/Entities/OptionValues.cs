﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class OptionValues
    {
        /// <summary>
        /// Mapped to CDK  field 's'
        /// </summary>
        public Boolean? Selected { get; set; }

        /// <summary>
        /// Mapped to CDK field 'o'
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// Mapped to CDK field 'd'
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_a' and nullable
        /// </summary>
        public decimal? Cur_a { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_a1' and nullable
        /// </summary>
        public decimal? Cur_a1 { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_a2' and nullable
        /// </summary>        
        public decimal? Cur_a2 { get; set; }

        /// <summary>
        /// Mapped to CDK field 'std'
        /// </summary>   
        public string Std { get; set; }

        /// <summary>
        /// Mapped to CDK field 'oa'
        /// </summary> 
        public string Oa { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_fair' and nullable
        /// </summary>        
        public decimal? Cur_option_trade_in_fair { get; set; }


        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_good' and nullable
        /// </summary>        
        public decimal? Cur_option_trade_in_good { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_excellent' and nullable
        /// </summary>        
        public decimal? Cur_option_trade_in_excellent { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_good' and nullable
        /// </summary>        
        public decimal? Cur_option_retail { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_wholesale' and nullable
        /// </summary>        
        public decimal? Cur_option_wholesale { get; set; }


    }
}
