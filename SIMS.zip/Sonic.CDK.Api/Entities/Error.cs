﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class Error
    {
       

        public decimal err_id { get; set; }
        public string severity_descField { get; set; }
        public string err_desc { get; set; }
        public string err_type_desc { get; set; }
        public string error_detail { get; set; }
        public string error_data { get; set; }
    }
}
