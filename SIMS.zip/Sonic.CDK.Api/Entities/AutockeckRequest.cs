﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class AutockeckRequest
    {
        public string DealerID { get; set; }
        public string VIN {get;set;}
        public string UserID { get; set; }
        public string Password { get; set; }
        public string AutocheckAppId { get; set; }
    }
    public class AutochekRequestValidator : AbstractValidator<AutockeckRequest>
    {
        public AutochekRequestValidator()
        {
            RuleFor(m => m.DealerID).NotNull().NotEmpty()
           .WithMessage("Dealer ID is requred");
            RuleFor(m => m.VIN).NotEmpty();
            RuleFor(m => m.UserID).NotNull().NotEmpty();
            RuleFor(m => m.Password).NotNull().NotEmpty();
        }
    }
}
