﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class BookValueReport
    {
        public OptionValues[] option { get; set; }
        public decimal uint_provider_id { get; set; }         

        public string str_state_region { get; set; }

        public decimal lng_valuation_result_id{ get; set; }

        public string str_condition{ get; set; }

        public string cd_condition{ get; set; }

        public decimal cur_wholesale{ get; set; }

        public decimal cur_retail{ get; set; }

        public decimal cur_tradein{ get; set; }

        public decimal cur_loan{ get; set; }

        public decimal cur_msrp{ get; set; }

        public string str_book_dt{ get; set; }

        public decimal uint_location_id{ get; set; }

        public string str_provider_defn_code{ get; set; }

        public decimal cur_base_wholesale{ get; set; }

        public decimal cur_base_retail{ get; set; }

        public decimal cur_base_tradein{ get; set; }

        public decimal cur_mileage_wholesale{ get; set; }

        public decimal cur_mileage_retail{ get; set; }

        public decimal cur_mileage_tradein{ get; set; }

        public decimal cur_options_total{ get; set; }

        public decimal cur_av_loan{ get; set; }

        public string xml{ get; set; }

        public decimal cur_av_retail{ get; set; }

        public decimal cur_av_tradein{ get; set; }

        public decimal cur_bv_loan{ get; set; }

        public decimal cur_bv_retail{ get; set; }

        public decimal cur_bv_tradein{ get; set; }

        public decimal lngTotalOptionsRetail{ get; set; }

        public decimal lngTotalOptionsTradeInExcellent{ get; set; }

        public decimal lngTotalOptionsTradeInFair{ get; set; }

        public decimal lngTotalOptionsTradeInGood{ get; set; }

        public decimal lngTotalOptionsWholesale{ get; set; }

        public decimal cur_engine_wholesale{ get; set; }

        public decimal cur_engine_retail{ get; set; }

        public decimal cur_transmission_wholesale{ get; set; }

        public decimal cur_transmission_retail{ get; set; }

        public decimal cur_drive_train_wholesale{ get; set; }

        public decimal cur_drive_train_retail{ get; set; }
    }

    public class BookValueReportOption
    {
        /// <summary>
        /// Mapped to CDK  field 's'
        /// </summary>
        public Boolean? Selected { get; set; }

        /// <summary>
        /// Mapped to CDK field 'o'
        /// </summary>
        public string ID{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'd'
        /// </summary>
        public string Value{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_a' and nullable
        /// </summary>
        public decimal? Cost{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_a1' and nullable
        /// </summary>
        public decimal? TradeInCost { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_a2' and nullable
        /// </summary>        
        public decimal? RetailCost { get; set; }

        /// <summary>
        /// Mapped to CDK field 'std'
        /// </summary>   
        public string Std{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'oa'
        /// </summary> 
        public string Oa{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_fair' and nullable
        /// </summary>        
        public decimal? TradeInFair{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_good' and nullable
        /// </summary>        
        public decimal? TradeInGood { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_trade_in_excellent' and nullable
        /// </summary> 
        public decimal TradeInExcellent { get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_retail' and nullable
        /// </summary> 
        public decimal Retail{ get; set; }

        /// <summary>
        /// Mapped to CDK field 'cur_option_wholesale' and nullable
        /// </summary> 
        public decimal Wholesale{ get; set; }
    }
}
