﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class ROPO
    {
        public string Number { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public decimal Cost { get; set; }
        public string DealerShipID { get; set; }
        public string ROPOType { get; set; }
        public DateTime DateClosed { get; set; }
    }
}
