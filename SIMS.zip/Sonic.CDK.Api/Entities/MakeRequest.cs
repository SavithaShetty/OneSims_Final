﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Entities
{
    public class MakeRequest:ContractDetails
    {
        /// <summary>
        /// Year 
        /// </summary>
        public int Year { get; set; }
    }

    public class MakeRequestValidator : AbstractValidator<MakeRequest>
    {
        public MakeRequestValidator()
        {
            RuleFor(m => m.DealerId).NotNull().NotEmpty()
            .WithMessage("Dealer ID is requred");
            RuleFor(m => m.PorviderId).NotEmpty();
            RuleFor(m => m.Region).NotNull().NotEmpty();
            RuleFor(m => m.Source).NotNull().NotEmpty();
            RuleFor(m => m.Year).NotEmpty().InclusiveBetween(1950, 3000);

        }
    }
}
