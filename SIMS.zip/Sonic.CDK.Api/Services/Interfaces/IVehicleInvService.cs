﻿using InventoryServiceReference;
using Sonic.CDK.Api.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Services.Interfaces
{
    public interface IVehicleInvService
    {
        Task<ListValuesResponse> GetListValues(decimal regionId, bool newVehicle);

        Task<List<ROPO>> GetDVCValues(string dealerId, decimal regionId, decimal adpVehicleId);
    }
}
