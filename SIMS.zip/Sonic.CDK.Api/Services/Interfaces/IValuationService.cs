﻿using Sonic.CDK.Api.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Services.Interfaces
{
    public interface IValuationService
    {
        Task<DecodeVinResponse> GetDecodeValues(DecodeVinRequest request);
        Task<MakeResponse> GetMakes(MakeRequest request);
        Task<ModelResponse> GetModels(ModelRequest request);
        Task<TrimResponse> GetTrims(TrimRequest request);
        Task<BodyStyleResponse> GetBodyStyles(BodyStyleRequest request);
        Task<OptionsResponse> GetOptions(OptionsRequest request);
        Task<BookValueResponse> GetBookValues(BookValueRequest request);

        //Other methods of CDK service not using currently


    }
}
