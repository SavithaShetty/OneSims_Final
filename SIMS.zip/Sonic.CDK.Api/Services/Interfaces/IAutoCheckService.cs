﻿using Sonic.CDK.Api.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Services.Interfaces
{
    public interface IAutoCheckService
    {
       Task<AutoCheckReport> GetAutoCheckReport(AutockeckRequest autockeckRequest);
    }
}
