﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;
using CDKAutoCheckRefreneces;
using CDKReference;
using Microsoft.Extensions.Options;
using Sonic.CDK.Api.Configuration;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.Exceptions;
using Sonic.CDK.Api.Services.Interfaces;

namespace Sonic.CDK.Api.Services
{
    public class AutocheckService: IAutoCheckService
    {
        private AutoCheckSettings _autocheckSettigs;
        private readonly VinDetailsEndPointClient autoCheckClient;
          
        public AutocheckService(IOptions<Settings> settings)
        {
            _autocheckSettigs = settings.Value.autoCheckSettings;

            BasicHttpBinding binding = new BasicHttpBinding
            {
                //SendTimeout = TimeSpan.FromSeconds('00:10:00'),
                MaxBufferSize = int.MaxValue,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = false
                //ReaderQuotas = XmlDictionaryReaderQuotas.Max

            };
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            EndpointAddress address = new EndpointAddress(_autocheckSettigs.Endpoint);
            autoCheckClient = new VinDetailsEndPointClient(binding, address);
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
        }
    public async Task<AutoCheckReport> GetAutoCheckReport(AutockeckRequest autockeckRequest)
        {
            AutoCheckReport autoCheckReports = new AutoCheckReport();
            try
            {
                
                string autoCheckAppId = _autocheckSettigs.AutoCheckAppID;
                System.Net.ServicePointManager.ServerCertificateValidationCallback = ((secureSender, certificate, chain, sslPolicyErrors) => true);
                autoCheckClient.ClientCredentials.UserName.UserName = autockeckRequest.UserID;
                autoCheckClient.ClientCredentials.UserName.Password = autockeckRequest.Password;

                getVinReportDetailsResponse response = await autoCheckClient.getVinReportDetailsAsync(autockeckRequest.DealerID, autoCheckAppId, autockeckRequest.VIN);
               
                if (string.IsNullOrEmpty(response.@return.vinReportUrl.Trim()))
                {
                    // autoCheckReports.ReportIconId = 80; // For exception button
                    autoCheckReports.ErrorMsg = "Report Not Available";
                }
                else
                {
                    autoCheckReports.ErrorMsg = "Call was Successful";
                    autoCheckReports.vinReportUrl = response.@return.vinReportUrl;
                    autoCheckReports.vinNmbr = response.@return.vinNmbr;
                    autoCheckReports.dealerID = response.@return.dealerID;
                    autoCheckReports.vinPass = response.@return.vinPass;
                }

            }
            catch(Exception ex)
            { autoCheckReports.ErrorMsg = "Call was UnSuccessful Ex:" +ex; }
            return autoCheckReports;
        }
    }
}
