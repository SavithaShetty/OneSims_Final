﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using CDKReference;
using Microsoft.Extensions.Options;
using Sonic.CDK.Api.Configuration;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.Exceptions;
using Sonic.CDK.Api.Services.Interfaces;

namespace Sonic.CDK.Api.Services
{
    public class ValuationService: IValuationService
    {

        private CDKSettings _cdkSettigs;
        private readonly ADPVehicleValuationSvcSoapClient cdkClient;
        public ValuationService(IOptions<Settings> settings)
        {
            _cdkSettigs = settings.Value.cdkSettings;

            BasicHttpBinding binding = new BasicHttpBinding
            {
                OpenTimeout = new TimeSpan(0, 1, 0),
                ReceiveTimeout=new TimeSpan(0,10,0),
                SendTimeout = new TimeSpan(0, 1, 0),
                CloseTimeout = new TimeSpan(0, 1, 0),
                MaxBufferSize = int.MaxValue,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = false,
                //ReaderQuotas = XmlDictionaryReaderQuotas.Max

            };
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            EndpointAddress address = new EndpointAddress(_cdkSettigs.ValuationEndpoint);
            cdkClient = new ADPVehicleValuationSvcSoapClient(binding, address);
        }

        public async Task<MakeResponse> GetMakes(MakeRequest request )
        {
            try
            {
                //ADPVehicleValuationSvcSoapClient cdkClient = new ADPVehicleValuationSvcSoapClient(binding,address);            
                /*Construct SOAP request*/
                getValMakesRequest makeRequest = new getValMakesRequest();
                makeRequest.dealerId = request.DealerId;
                makeRequest.locale = "en";
                makeRequest.valMakesReq = new valMakesReq[]{
                new valMakesReq()
                {
                    Provider = request.PorviderId,
                    region = request.Region,
                    year = request.Year.ToString(),
                }
            };

                GetValMakesResponse1 data = await cdkClient.GetValMakesAsync(makeRequest);
                getValMakesResponse getValMakesResponse = data.@return;

                if (getValMakesResponse != null)
                {
                    MakeResponse makeResponse = new MakeResponse();
                    if (getValMakesResponse.valMakesResp.Length > 0)
                    {
                        valMakes resp = getValMakesResponse.valMakesResp[0];
                        ValMakesProvider valMakesProvider = resp.provider;
                        //ValMakesProviderOption[] optionField = valMakesProvider.option;
                        List<Entities.Make> listMakes = new List<Entities.Make>();
                        if (valMakesProvider.option != null && valMakesProvider.option.Length > 0)
                        {
                            foreach (ValMakesProviderOption item in valMakesProvider.option)
                            {
                                listMakes.Add(new Make() { Code = item.Code, Value = item.Value });
                            }
                        }
                        makeResponse.Makes = listMakes;
                    }
                    if (getValMakesResponse.errors != null && getValMakesResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in getValMakesResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        makeResponse.Errors = listError;
                    }
                    return makeResponse;
                }
                else
                {
                    throw new ApiException("CDK GetValMakes Service Not responding");
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        public async Task<ModelResponse> GetModels(ModelRequest request)
        {
            try
            {
                /*Construct SOAP request*/
                getValModelsRequest modelRequest = new getValModelsRequest();
                modelRequest.dealerId = request.DealerId;
                modelRequest.locale = "en";
                modelRequest.valModelsReq = new valModelsReq[]{
                new valModelsReq()
                {
                   provider=new valModelsReqProvider()
                   {
                       provider_id=request.PorviderId,
                       region=request.Region,
                       year=request.Year.ToString(),
                       make=request.Make,
                   }
                }
            };

                GetValModelsResponse1 data = await cdkClient.GetValModelsAsync(modelRequest);
                getValModelsResponse getValModelsResponse = data.@return;

                if (getValModelsResponse != null)
                {
                    ModelResponse modelResponse = new ModelResponse();
                    if (getValModelsResponse.valModelsResp.Length > 0)
                    {
                        valModels resp = getValModelsResponse.valModelsResp[0];
                        valModelsProvider valModelsProvider = resp.provider;
                        //ValMakesProviderOption[] optionField = valMakesProvider.option;
                        List<Entities.Model> listModels = new List<Entities.Model>();
                        if (valModelsProvider.option != null && valModelsProvider.option.Length > 0)
                        {
                            foreach (valModelsProviderOption item in valModelsProvider.option)
                            {
                                listModels.Add(new Model() { Code = item.code, Value = item.Value });
                            }
                        }
                        modelResponse.Models = listModels;
                    }
                    if (getValModelsResponse.errors != null && getValModelsResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in getValModelsResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        modelResponse.Errors = listError;
                    }
                    return modelResponse;
                }
                else
                {
                    throw new ApiException("CDK GetValModels Service Not responding");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }

        public async Task<TrimResponse> GetTrims(TrimRequest request)
        {
            try
            {
                /*Construct SOAP request*/
                getValTrimsRequest trimsRequest = new getValTrimsRequest();
                trimsRequest.dealerId = request.DealerId;
                trimsRequest.locale = "en";
                trimsRequest.valTrimsReq = new valTrimsReq[1];
                trimsRequest.valTrimsReq[0] = new valTrimsReq();
                trimsRequest.valTrimsReq[0].provider = new valTrimsReqProvider();
                trimsRequest.valTrimsReq[0].provider.provider_id = request.PorviderId;
                trimsRequest.valTrimsReq[0].provider.region = request.Region;
                trimsRequest.valTrimsReq[0].provider.year = request.Year.ToString();
                trimsRequest.valTrimsReq[0].provider.make = request.Make;

                if (string.IsNullOrWhiteSpace(request.Model))
                    request.Model = "";
                trimsRequest.valTrimsReq[0].provider.model = request.Model;
                   

                GetValTrimsResponse1 data = await cdkClient.GetValTrimsAsync(trimsRequest);
                getValTrimsResponse getValTrimsResponse = data.@return;

                if (getValTrimsResponse != null)
                {
                    TrimResponse trimResponse = new TrimResponse();
                    if (getValTrimsResponse.valTrimsResp.Length > 0)
                    {
                        valTrims resp = getValTrimsResponse.valTrimsResp[0];
                        valTrimsProvider valTrimsProvider = resp.provider;
                        //ValMakesProviderOption[] optionField = valMakesProvider.option;
                        List<Entities.Trim> listTrims = new List<Entities.Trim>();
                        if (valTrimsProvider.option != null && valTrimsProvider.option.Length > 0)
                        {
                            foreach (valTrimsProviderOption item in valTrimsProvider.option)
                            {
                                listTrims.Add(new Trim() { Code = item.code, Value = item.Value });
                            }
                        }
                        trimResponse.Trims = listTrims;
                    }
                    if (getValTrimsResponse.errors != null && getValTrimsResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in getValTrimsResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        trimResponse.Errors = listError;
                    }
                    return trimResponse;
                }
                else
                {
                    throw new ApiException("CDK GetValTrims Service Not responding");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<BodyStyleResponse> GetBodyStyles(BodyStyleRequest request)
        {
            try
            {
                /*Construct SOAP request*/
                getValBodyRequest bodyRequest = new getValBodyRequest();
                bodyRequest.dealerId = request.DealerId;
                bodyRequest.locale = "en";
                bodyRequest.valBodyReq = new valBodyReq[1];
                bodyRequest.valBodyReq[0] = new valBodyReq();
                bodyRequest.valBodyReq[0].provider = new valBodyReqProvider();
                bodyRequest.valBodyReq[0].provider.provider_id = request.PorviderId;
                bodyRequest.valBodyReq[0].provider.region = request.Region;
                bodyRequest.valBodyReq[0].provider.year = request.Year.ToString();
                bodyRequest.valBodyReq[0].provider.make = request.Make;

                if (String.IsNullOrWhiteSpace(request.Model))
                    request.Model = "";
                bodyRequest.valBodyReq[0].provider.model = request.Model;
                bodyRequest.valBodyReq[0].provider.trim = request.Trim;
               

                GetValBodyResponse1 data = await cdkClient.GetValBodyAsync(bodyRequest);
                getValBodyResponse getValBodyResponse = data.@return;

                if (getValBodyResponse != null)
                {
                    BodyStyleResponse bodyResponse = new BodyStyleResponse();
                    if (getValBodyResponse.valBodyResp.Length > 0)
                    {
                        valBody resp = getValBodyResponse.valBodyResp[0];
                        valBodyProvider valBodyProvider = resp.provider;
                        //ValMakesProviderOption[] optionField = valMakesProvider.option;
                        List<Entities.BodyStyle> listBodyStyle = new List<Entities.BodyStyle>();
                        if (valBodyProvider.option != null && valBodyProvider.option.Length > 0)
                        {
                            foreach (valBodyProviderOption item in valBodyProvider.option)
                            {
                                listBodyStyle.Add(new BodyStyle() { Code = item.code, Value = item.Value });
                            }
                        }
                        bodyResponse.BodyStyles = listBodyStyle;
                    }
                    if (getValBodyResponse.errors != null && getValBodyResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in getValBodyResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        bodyResponse.Errors = listError;
                    }
                    return bodyResponse;
                }
                else
                {
                    throw new ApiException("CDK GetValBody Service Not responding");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<DecodeVinResponse> GetDecodeValues(DecodeVinRequest request)
        {
            try
            {
                /*Construct SOAP request*/
                vinDecodeValRequest decodeRequest = new vinDecodeValRequest();
                decodeRequest.dealerId = request.DealerId;
                decodeRequest.locale = "en";
                decodeRequest.vinDecodeValReq = new vinDecodeValReq[1];
                decodeRequest.vinDecodeValReq[0] = new vinDecodeValReq();
                decodeRequest.vinDecodeValReq[0].provider = new vinDecodeValReqProvider();
                decodeRequest.vinDecodeValReq[0].provider.provider_id = request.PorviderId;
                decodeRequest.vinDecodeValReq[0].provider.region = request.Region;
                decodeRequest.vinDecodeValReq[0].provider.vin = request.VIN;

                ValDecodeVinResponse data = await cdkClient.ValDecodeVinAsync(decodeRequest);
                vinDecodeValResponse vinDecodeValResponse = data.@return;
                

                if (vinDecodeValResponse != null)
                {
                    DecodeVinResponse decodeResponse = new DecodeVinResponse();
                    if (vinDecodeValResponse.valDecodeResp != null && vinDecodeValResponse.valDecodeResp.Count() > 0 )
                    {
                        vinDecodeValResp vinDecodeValResp = vinDecodeValResponse.valDecodeResp[0];
                        decodeResponse.Clarify = vinDecodeValResp.clarify;
                        //if (!decodeResponse.Clarify.Value)
                        //{
                        //    if (vinDecodeValResp.providerVinDef[0].str_vin == null)
                        //        break;
                        //}
                        decodeResponse.VinDecodeValues = new List<VinDecodeValue>();
                        foreach (vinDecodeValRespProviderVinDef resp in vinDecodeValResp.providerVinDef)
                        {
                            VinDecodeValue vinDecodeValue = new VinDecodeValue();
                            vinDecodeValue.Region = resp.cd_state_region;
                            vinDecodeValue.PoviderDefCode = resp.str_provider_defn_code;
                            vinDecodeValue.Location = resp.uint_location_id;
                            vinDecodeValue.ProviderId = resp.uint_provider_id;
                            vinDecodeValue.vin = resp.str_vin;
                            vinDecodeValue.year = resp.uint_year;
                            vinDecodeValue.Make = resp.cd_make;
                            vinDecodeValue.Model = resp.cd_model;
                            vinDecodeValue.BodyStyle = resp.cd_body_style;
                            vinDecodeValue.Odometer = resp.lng_odometer;
                            vinDecodeValue.Trim = resp.cd_trim;

                            if (resp.makes != null)
                            {
                                vinDecodeValue.Makes = new List<Make>();                                
                                foreach(ValMakesProviderOption make in resp.makes)
                                {
                                    vinDecodeValue.Makes.Add(new Make() { Code = make.Code, Value = make.Value });
                                }
                            }

                            if (resp.models != null)
                            {
                                vinDecodeValue.Models = new List<Model>();
                                foreach (valModelsProviderOption model in resp.models)
                                {
                                    vinDecodeValue.Models.Add(new Model() { Code = model.code, Value = model.Value });
                                }
                            }

                            if (resp.trims != null)
                            {
                                vinDecodeValue.Trims = new List<Trim>();
                                foreach (valTrimsProviderOption trim in resp.trims)
                                {
                                    vinDecodeValue.Trims.Add(new Trim() { Code = trim.code, Value = trim.Value });
                                }
                            }

                            if(resp.body_styles!=null)
                            {
                                vinDecodeValue.BodyStyles = new List<BodyStyle>();
                                foreach (valBodyProviderOption body in resp.body_styles)
                                {
                                    vinDecodeValue.BodyStyles.Add(new BodyStyle() { Code = body.code, Value = body.Value });      
                                }

                            }

                            if(resp.options!=null)
                            {
                                List<Entities.OptionValues> listOptions = new List<Entities.OptionValues>();
                                foreach (valOptionsProviderOption option in resp.options)
                                {
                                    OptionValues optionValue = new OptionValues
                                    {
                                        ID = option.o,
                                        Value = option.d,
                                        Cur_a = option.cur_a,
                                        Selected = option.s == -1 ? true : false,
                                        Oa = option.oa,
                                        Std = option.std,
                                        Cur_a1 = option.cur_a1,
                                        Cur_a2 = option.cur_a2
                                    };
                                    listOptions.Add(optionValue);
                                }
                                vinDecodeValue.Options = listOptions;
                            }

                            decodeResponse.VinDecodeValues.Add(vinDecodeValue);
                        }
                        
                    }
                    if (vinDecodeValResponse.errors != null && vinDecodeValResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in vinDecodeValResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        decodeResponse.Errors = listError;
                    }
                    return decodeResponse;
                }
                else
                {
                    throw new ApiException("CDK ValDecodeVin Service Not responding");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<OptionsResponse> GetOptions(OptionsRequest request)
        {
            try
            {
                /*Construct SOAP request*/
                getValOptionsRequest optionsRequest = new getValOptionsRequest();
                optionsRequest.dealerId = request.DealerId;
                optionsRequest.locale = "en";
                optionsRequest.getValOptionsReq = new getValOptionsReq[1];
                optionsRequest.getValOptionsReq[0] = new getValOptionsReq();
                optionsRequest.getValOptionsReq[0].provider = new getValOptionsReqProvider();
                optionsRequest.getValOptionsReq[0].provider.provider_id = request.PorviderId;
                optionsRequest.getValOptionsReq[0].provider.state_region = request.Region;

                //Mandatory Field
                optionsRequest.getValOptionsReq[0].provider.str_provider_defn_code = request.ProviderDefCode;

                if (!String.IsNullOrWhiteSpace(request.VIN))
                    optionsRequest.getValOptionsReq[0].provider.vin = request.VIN;

                if (request.Year.HasValue)
                    optionsRequest.getValOptionsReq[0].provider.year = request.Year.ToString();

                if (!String.IsNullOrWhiteSpace(request.Make))
                    optionsRequest.getValOptionsReq[0].provider.make = request.Make;

                if (!String.IsNullOrWhiteSpace(request.Model))
                    optionsRequest.getValOptionsReq[0].provider.model = request.Model;

                if (!String.IsNullOrWhiteSpace(request.Trim))
                    optionsRequest.getValOptionsReq[0].provider.series = request.Trim;

                if (!String.IsNullOrWhiteSpace(request.BodyStyle))
                    optionsRequest.getValOptionsReq[0].provider.body_style= request.BodyStyle;

                if (!String.IsNullOrWhiteSpace(request.Condition))
                    optionsRequest.getValOptionsReq[0].provider.condition = request.Condition;

                if (request.Odometer.HasValue)
                    optionsRequest.getValOptionsReq[0].provider.odometer = request.Odometer.Value;

                if (request.LowVolume.HasValue)
                    optionsRequest.getValOptionsReq[0].provider.low_volume = request.LowVolume.Value;


                GetValOptionsResponse1 data = await cdkClient.GetValOptionsAsync(optionsRequest);
                getValOptionsResponse getValOptionsResponse = data.@return;

                if (getValOptionsResponse != null)
                {
                    OptionsResponse optionResponse = new OptionsResponse();
                    if (getValOptionsResponse.getValOptionsResp!=null && getValOptionsResponse.getValOptionsResp.Length > 0)
                    {

                        getValOptionsResp resp = getValOptionsResponse.getValOptionsResp[0];
                        valOptionsProvider valOptionsProvider = resp.provider;

                        if (valOptionsProvider != null && !string.IsNullOrWhiteSpace(valOptionsProvider.str_provider_defn_code))
                            optionResponse.PoviderDefCode = valOptionsProvider.str_provider_defn_code;

                        List<Entities.OptionValues> listOptions = new List<Entities.OptionValues>();
                        if (valOptionsProvider.option != null && valOptionsProvider.option.Length > 0)
                        {
                            foreach (valOptionsProviderOption option in valOptionsProvider.option)
                            {
                                OptionValues optionValue = new OptionValues { 
                                    ID = option.o, 
                                    Value = option.d, 
                                    Cur_a = option.cur_a, 
                                    Selected = option.s == -1 ? true : false, 
                                    Oa = option.oa, 
                                    Std = option.std, 
                                    Cur_a1 = option.cur_a1, 
                                    Cur_a2 = option.cur_a2 
                                };
                                listOptions.Add(optionValue);                                
                            }
                        }
                        optionResponse.optionValues = listOptions;
                    }
                    if (getValOptionsResponse.errors != null && getValOptionsResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in getValOptionsResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        optionResponse.Errors = listError;
                    }
                    return optionResponse;
                }
                else
                {
                    throw new ApiException("CDK GetValOptions Service Not responding");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }

        public async Task<BookValueResponse> GetBookValues(BookValueRequest request)
        {
            try
            {
                /*Construct SOAP request*/
                getBookValueRequest bookRequest = new getBookValueRequest();
                bookRequest.dealerId = request.DealerId;
                bookRequest.locale = "en";
                bookRequest.bookValueReq = new getBookValueReq[1];
                bookRequest.bookValueReq[0] = new getBookValueReq();
                bookRequest.bookValueReq[0].provider = new getBookValueReqProvider();
                bookRequest.bookValueReq[0].provider.uint_provider_id = request.PorviderId;
                bookRequest.bookValueReq[0].provider.cd_state_region = request.Region;
                bookRequest.bookValueReq[0].provider.lng_odometer = request.Odometer.HasValue?request.Odometer.Value:0;

                if(!String.IsNullOrWhiteSpace(request.VIN))
                bookRequest.bookValueReq[0].provider.str_vin = request.VIN;


                if (request.Year.HasValue && request.Year.Value>0)
                    bookRequest.bookValueReq[0].provider.uint_year = request.Year.Value.ToString();

                if (!String.IsNullOrWhiteSpace(request.Make))
                    bookRequest.bookValueReq[0].provider.cd_make = request.Make;

                if (!String.IsNullOrWhiteSpace(request.Model))
                    bookRequest.bookValueReq[0].provider.cd_model = request.Model;

                if (!String.IsNullOrEmpty(request.Trim))
                    bookRequest.bookValueReq[0].provider.cd_series = request.Trim;

                if (!String.IsNullOrEmpty(request.BodyStyle))
                    bookRequest.bookValueReq[0].provider.cd_body_style = request.BodyStyle;

   
                bookRequest.bookValueReq[0].provider.str_provider_defn_code = request.ProviderDefCode;

                if (String.IsNullOrWhiteSpace(request.Condition))
                    request.Condition = "0";

                bookRequest.bookValueReq[0].provider.cd_condition = request.Condition;

                int index = 0;

                if (request.Options != null && request.Options.Count > 0)
                {
                    bookRequest.bookValueReq[0].provider.option = new getBookValueReqProviderOption[request.Options.Count];

                    foreach (OptionValues optionValue in request.Options)
                    {
                        bookRequest.bookValueReq[0].provider.option[index] = new getBookValueReqProviderOption();
                        bookRequest.bookValueReq[0].provider.option[index].o = optionValue.ID;
                        bookRequest.bookValueReq[0].provider.option[index].s = (optionValue.Selected.HasValue && optionValue.Selected.Value==true) ? -1 : 0;
                        bookRequest.bookValueReq[0].provider.option[index].d = optionValue.Value.Replace("\'","");

                        //if (providerId == "5")
                        //{
                        //    bookRequest.bookValueReq[0].provider.option[index].oa = optionValue.Oa;
                        //    bookRequest.bookValueReq[0].provider.option[index].std = optionValue.Std;
                        //}
                        //else
                        //{
                            bookRequest.bookValueReq[0].provider.option[index].cur_a = optionValue.Cur_a.Value;
                            if (request.PorviderId == 6)
                            {
                                bookRequest.bookValueReq[0].provider.option[index].cur_a1 = optionValue.Cur_a1.Value;
                                bookRequest.bookValueReq[0].provider.option[index].cur_a2 = optionValue.Cur_a2.Value;
                            }
                        //}
                        index++;
                    }
                }

                GetBookValueResponse1 data = await cdkClient.GetBookValueAsync(bookRequest);
                getBookValueResponse getBookValueResponse = data.@return;

                if (getBookValueResponse != null)
                {
                    BookValueResponse bookValueResponse = new BookValueResponse();
                    if (getBookValueResponse.getBookValueResp != null && getBookValueResponse.getBookValueResp.Length > 0)
                    {
                        getBookValueResp resp = getBookValueResponse.getBookValueResp[0];                        
                        if(resp.report!=null && resp.report.Length>0)
                        {
                            bookValueResponse.bookValueReports = new BookValueReport[resp.report.Length];
                            index = 0;
                            foreach(getBookValueRespReport report in resp.report)
                            {
                                bookValueResponse.bookValueReports[index] = new BookValueReport();
                                bookValueResponse.bookValueReports[index].uint_provider_id = report.uint_provider_id;
                                bookValueResponse.bookValueReports[index].str_state_region = report.str_state_region;
                                bookValueResponse.bookValueReports[index].lng_valuation_result_id = report.lng_valuation_result_id;
                                bookValueResponse.bookValueReports[index].str_condition = report.str_condition;
                                bookValueResponse.bookValueReports[index].cd_condition = report.cd_condition;
                                bookValueResponse.bookValueReports[index].cur_wholesale = report.cur_wholesale;
                                bookValueResponse.bookValueReports[index].cur_retail = report.cur_retail;
                                bookValueResponse.bookValueReports[index].cur_tradein = report.cur_tradein;
                                bookValueResponse.bookValueReports[index].cur_loan = report.cur_loan;
                                bookValueResponse.bookValueReports[index].cur_msrp = report.cur_msrp;
                                bookValueResponse.bookValueReports[index].str_book_dt = report.str_book_dt;
                                bookValueResponse.bookValueReports[index].uint_location_id = report.uint_location_id;
                                bookValueResponse.bookValueReports[index].str_provider_defn_code = report.str_provider_defn_code;
                                bookValueResponse.bookValueReports[index].cur_base_wholesale = report.cur_base_wholesale;
                                bookValueResponse.bookValueReports[index].cur_base_retail = report.cur_base_retail;
                                bookValueResponse.bookValueReports[index].cur_base_tradein = report.cur_base_tradein;
                                bookValueResponse.bookValueReports[index].cur_mileage_wholesale = report.cur_mileage_wholesale;
                                bookValueResponse.bookValueReports[index].cur_mileage_retail = report.cur_mileage_retail;
                                bookValueResponse.bookValueReports[index].cur_mileage_tradein = report.cur_mileage_tradein;
                                bookValueResponse.bookValueReports[index].cur_options_total = report.cur_options_total;
                                bookValueResponse.bookValueReports[index].cur_av_loan = report.cur_av_loan;
                                bookValueResponse.bookValueReports[index].xml = report.xml;
                                bookValueResponse.bookValueReports[index].cur_av_retail = report.cur_av_retail;
                                bookValueResponse.bookValueReports[index].cur_av_tradein = report.cur_av_tradein;
                                bookValueResponse.bookValueReports[index].cur_bv_loan = report.cur_bv_loan;
                                bookValueResponse.bookValueReports[index].cur_bv_retail = report.cur_bv_retail;
                                bookValueResponse.bookValueReports[index].cur_bv_tradein = report.cur_bv_tradein;
                                bookValueResponse.bookValueReports[index].lngTotalOptionsRetail = report.lngTotalOptionsRetail;
                                bookValueResponse.bookValueReports[index].lngTotalOptionsTradeInExcellent = report.lngTotalOptionsTradeInExcellent;
                                bookValueResponse.bookValueReports[index].lngTotalOptionsTradeInFair = report.lngTotalOptionsTradeInFair;
                                bookValueResponse.bookValueReports[index].lngTotalOptionsTradeInGood = report.lngTotalOptionsTradeInGood;
                                bookValueResponse.bookValueReports[index].lngTotalOptionsWholesale = report.lngTotalOptionsWholesale;
                                bookValueResponse.bookValueReports[index].cur_engine_wholesale = report.cur_engine_wholesale;
                                bookValueResponse.bookValueReports[index].cur_engine_retail = report.cur_engine_retail;
                                bookValueResponse.bookValueReports[index].cur_transmission_wholesale = report.cur_transmission_wholesale;
                                bookValueResponse.bookValueReports[index].cur_transmission_retail = report.cur_transmission_retail;
                                bookValueResponse.bookValueReports[index].cur_drive_train_wholesale = report.cur_drive_train_wholesale;
                                bookValueResponse.bookValueReports[index].cur_drive_train_retail = report.cur_drive_train_retail;

                                if(report.option!=null && report.option.Length>0)
                                {
                                    int optionIndex = 0;
                                    bookValueResponse.bookValueReports[index].option = new OptionValues[report.option.Length];
                                    foreach(getBookValueRespReportOption opt in report.option)
                                    {
                                        bookValueResponse.bookValueReports[index].option[optionIndex] = new OptionValues();
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Selected = (opt.s == -1) ? true : false;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].ID = opt.o;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Value = opt.d;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Oa = opt.oa;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Std = opt.std;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_a = opt.cur_a;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_a1 = opt.cur_a1;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_a2 = opt.cur_a2;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_option_retail = opt.cur_option_retail;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_option_trade_in_good = opt.cur_option_trade_in_good;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_option_trade_in_fair = opt.cur_option_trade_in_fair;
                                        bookValueResponse.bookValueReports[index].option[optionIndex].Cur_option_trade_in_excellent = opt.cur_option_trade_in_excellent;
                                        optionIndex++;
                                    }

                                }
                                index++;

                            }
                        }                       
                    }
                    if (getBookValueResponse.errors != null && getBookValueResponse.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in getBookValueResponse.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        bookValueResponse.Errors = listError;
                    }
                    return bookValueResponse;
                }
                else
                {
                    throw new ApiException("CDK GetBookValue Service Not responding");
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
