﻿using InventoryServiceReference;
using Microsoft.Extensions.Options;
using Sonic.CDK.Api.Configuration;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.Exceptions;
using Sonic.CDK.Api.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Services
{
    public class VehicleInvService : IVehicleInvService
    {
        private CDKSettings _cdkSettigs;
        private readonly AdpVehicleInventorySvcSoapClient _cdkInvClient;
        public VehicleInvService(IOptions<Settings> settings)
        {
            _cdkSettigs = settings.Value.cdkSettings;
            BasicHttpBinding binding = new BasicHttpBinding
            {
                //SendTimeout = TimeSpan.FromSeconds('00:10:00'),
                MaxBufferSize = int.MaxValue,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = false
                //ReaderQuotas = XmlDictionaryReaderQuotas.Max

            };
            binding.Security.Mode = BasicHttpSecurityMode.Transport;
            EndpointAddress address = new EndpointAddress(_cdkSettigs.InventoryEndpoint);
            _cdkInvClient = new AdpVehicleInventorySvcSoapClient(binding, address);
        }

        public async Task<ListValuesResponse> GetListValues(decimal regionId, bool newVehicle)
        {
            try
            {
                /*Construct SOAP request*/

                getListValuesReq valueReq = new getListValuesReq();
                valueReq.int_location = regionId;
                valueReq.isnew = newVehicle;
                getListValuesReq[] valueReqList = new getListValuesReq[] { valueReq };

                getListValuesRequest requestObj = new getListValuesRequest();
                requestObj.locale = "EN";
                requestObj.getListValuesReq = valueReqList;

                GetListValuesResponse1 response = await _cdkInvClient.GetListValuesAsync(requestObj);

                if (response.@return != null)
                {
                    ListValuesResponse listValuesResponse = new ListValuesResponse();
                    if (response.@return.getListValuesResp != null && response.@return.getListValuesResp.Length > 0)
                    {
                        getListValuesResp getListValuesResp = response.@return.getListValuesResp[0];
                        listValuesResponse.location = getListValuesResp.int_location;
                        listValuesResponse.lot = getListValuesResp.lot.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.generic_transmissions = getListValuesResp.generic_transmissions.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.generic_xcolors = getListValuesResp.generic_xcolors.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.generic_icolors = getListValuesResp.generic_icolors.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.generic_itexture = getListValuesResp.generic_itexture.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.invstatus = getListValuesResp.invstatus.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.dmvnewused = getListValuesResp.dmvnewused.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.acquiredtype = getListValuesResp.acquiredtype.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.acquiredsource = getListValuesResp.acquiredsource.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.fuel = getListValuesResp.fuel.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.dmvbody = getListValuesResp.dmvbody.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.invtype = getListValuesResp.invtype.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.@class = getListValuesResp.@class.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.dmvclass = getListValuesResp.dmvclass.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.authenticity_of_mileage = getListValuesResp.authenticity_of_mileage.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.unit_of_measure = getListValuesResp.unit_of_measure.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.registration_class = getListValuesResp.registration_class.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                        listValuesResponse.licensestates = getListValuesResp.licensestates.Select(x => new IDValues()
                        {
                            ID = x.value,
                            Value = x.Value
                        }).ToList<IDValues>();

                    }
                    if (response.@return.errors != null && response.@return.errors.Length > 0)
                    {
                        List<Error> listError = new List<Error>();
                        foreach (errorCodes error in response.@return.errors)
                        {
                            listError.Add(new Error()
                            {
                                err_id = error.err_id,
                                error_data = error.error_data,
                                err_desc = error.err_desc,
                                error_detail = error.error_detail,
                                err_type_desc = error.err_type_desc
                            });

                        }
                        listValuesResponse.Errors = listError;
                    }
                    return listValuesResponse;
                }
                else
                {
                    throw new ApiException("CDK GetListValues Service Not responding");
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        public async Task<List<ROPO>> GetDVCValues(string dealerId, decimal regionId, decimal adpVehicleId)
        {
            try
            {
                getVehicleServiceHistoryReq getVehicleServiceHistoryReq = new getVehicleServiceHistoryReq
                {
                    location_id = regionId,
                    veh_id = adpVehicleId
                };
                getVehicleServiceHistoryRequest getVehicleServiceHistoryRequest = new getVehicleServiceHistoryRequest
                {
                    dealerId = dealerId,
                    locale = "en",
                    getVehicleServiceHistoryReq = new getVehicleServiceHistoryReq[] { getVehicleServiceHistoryReq }

                };
                GetVehicleServiceHistoryResponse1 response = await _cdkInvClient.GetVehicleServiceHistoryAsync(getVehicleServiceHistoryRequest);
                if (response.@return != null)
                {
                    List<ROPO> ropo = new List<ROPO>();
                    if (response.@return.veh_service_history != null && response.@return.veh_service_history.Count() > 0
                        && response.@return.veh_service_history[0].service_items != null && response.@return.veh_service_history[0].service_items.Count() > 0)
                    {
                        foreach (var item in response.@return.veh_service_history[0].service_items)
                        {
                            ROPO val = new ROPO();
                            val.Description = item.str_descr;
                            val.Cost = item.cur_cost;
                            val.Number = item.str_number;
                            val.Status = item.str_status;
                            val.ROPOType = item.str_type.ToUpper();
                            DateTime parsedDate;
                            DateTime.TryParseExact(item.dt_closed, "MM/dd/yyyy", null,
                               DateTimeStyles.None, out parsedDate);
                            val.DateClosed = parsedDate;
                            ropo.Add(val);                            
                        }
                    }
                    return ropo;
                }
                else
                {
                    throw new ApiException("CDK GetDVCValues Service Not responding");
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
    }
}
