﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Configuration
{
    public class Settings
    {        

        public List<User> users { get; set; }

        public CDKSettings cdkSettings { get; set; }

        public AutoCheckSettings autoCheckSettings { get; set; }
    }
}
