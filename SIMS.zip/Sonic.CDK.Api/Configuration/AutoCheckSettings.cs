﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Configuration
{
    public class AutoCheckSettings
    {
       public string Endpoint { get; set; }
        public string AutoCheckAppID { get; set; }
    }
}
