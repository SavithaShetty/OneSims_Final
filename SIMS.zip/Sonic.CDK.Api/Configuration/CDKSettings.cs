﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.CDK.Api.Configuration
{
    public class CDKSettings
    {
        public string ValuationEndpoint { get; set; }
        public string InventoryEndpoint { get; set; }
    }
}
