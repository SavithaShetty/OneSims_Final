﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Pricing;
using Sonic.OneSIMS.BusinessLogic.Pricing;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomailModels.Pricing;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Pricing
{
    public class PricingLogicTest
    {
        private Mock<IPricingRepository> pricingRepositoryMock;
        private List<BumpHistoryData> bumpHistoryDatas;
        private List<Appraisalloglist> previousAppraisalData;
        long VID;
        short SID;
        short IID;
        public PricingLogicTest()
        {
            pricingRepositoryMock = new Mock<IPricingRepository>();
            VID = 4310980; SID = 101; IID = 1;
            bumpHistoryDatas = new List<BumpHistoryData>
            {
                new BumpHistoryData { BumpDate = DateTime.Now, Appraiser = "Raju.Mahesh", BumpReason = null, Variance = 1 , OldAppraisalValue = 8000, NewAppraisalValue = 8001, AppraisalID = 2787555, RTCAppraiser = null, StoreName = "Acura of Serramonte"   },
                new BumpHistoryData { BumpDate = DateTime.Now, Appraiser = "Raju.Mahesh", BumpReason = null, Variance = 1 , OldAppraisalValue = 8001, NewAppraisalValue = 8002, AppraisalID = 2787556, RTCAppraiser = null, StoreName = "Audi Brinhimgham"   }
            };
            previousAppraisalData = new List<Appraisalloglist>
            {
                new Appraisalloglist{ VID = 4310980, SID = 101, IID = 1}
            };
        }
        [Fact]
        public void GetBumpHistory_Returns_vehicleData()
        {
            pricingRepositoryMock.Setup(p => p.GetBumpHistory(1,1,1)).Returns(bumpHistoryDatas);
            IPricingLogic bumphistoryLogic = new PricingLogic(pricingRepositoryMock.Object);
            var result = bumphistoryLogic.GetBumpHistory(1, 1, 1);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetBumpHistory_Returns_Empty_vehicleData()
        {
            pricingRepositoryMock.Setup(p => p.GetBumpHistory(1,1,1)).Returns(new List<BumpHistoryData>());
            IPricingLogic bumphistoryLogic = new PricingLogic(pricingRepositoryMock.Object);
            var result = bumphistoryLogic.GetBumpHistory(1, 1, 1);
            Assert.True(result.Count == 0);
        }
        [Fact]
        public void GetPreviousAppraisal_Returns_vehicleData()
        {
            pricingRepositoryMock.Setup(p => p.GetPreviousApprasisal(VID, SID, IID)).Returns(previousAppraisalData);
            IPricingLogic previousAppraisalLogic = new PricingLogic(pricingRepositoryMock.Object);
            var result = previousAppraisalLogic.GetPreviousApprasisal(VID, SID, IID);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetPreviousApprasisal_Returns_Empty_vehicleData()
        {
            pricingRepositoryMock.Setup(p => p.GetPreviousApprasisal(VID, SID, IID)).Returns(new List<Appraisalloglist>());
            IPricingLogic previousAppraisalLogic = new PricingLogic(pricingRepositoryMock.Object);
            var result = previousAppraisalLogic.GetPreviousApprasisal(VID, SID, IID);
            Assert.True(result.Count == 0);
        }
        [Fact]
        public void GetRTCBumpHistory_Returns_vehicleData()
        {
            pricingRepositoryMock.Setup(p => p.GetRTCBumpHistory(VID, SID, IID)).Returns(bumpHistoryDatas);
            IPricingLogic previousAppraisalLogic = new PricingLogic(pricingRepositoryMock.Object);
            var result = previousAppraisalLogic.GetRTCBumpHistory(VID, SID, IID);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetRTCBumpHistory_Returns_Empty_vehicleData()
        {
            pricingRepositoryMock.Setup(p => p.GetRTCBumpHistory(VID, SID, IID)).Returns(new List<BumpHistoryData>());
            IPricingLogic previousAppraisalLogic = new PricingLogic(pricingRepositoryMock.Object);
            var result = previousAppraisalLogic.GetRTCBumpHistory(VID, SID, IID);
            Assert.True(result.Count == 0);
        }
    }

}
