﻿using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Pricing;
using Sonic.OneSIMS.BusinessLogic.Pricing;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal.PricingRepository;
using Sonic.OneSIMS.DomailModels.Common;
using Sonic.OneSIMS.DomainModels.Pricing;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Pricing
{
    public class CostInformationLogicTest
    {
        private Mock<ICostInformationRepository> costInformationRepositoryMock;
        private short resonType;
        private List<ReasonCode> reasonCode;
        private CostInfoSave costInfoSave;
        private bool saveResult = true;
        private VehicleIdentity vehicleIdentity;
        private CostInfoEdit costInfoEdit;
        private CostInfoEdit costInfoEdit1;
        private CostInfoEdit costInfoEdit2;
        private CostInfoEdit costInfoEdit3;

        public CostInformationLogicTest()
        {
            costInformationRepositoryMock = new Mock<ICostInformationRepository>();
            resonType = 2;
            reasonCode = new List<ReasonCode>
            {
                new ReasonCode{PriceChangeReasonId = 1, PriceChangeReasonCode = "AB"},
                new ReasonCode{PriceChangeReasonId = 2, PriceChangeReasonCode = "CD"}
            };
            costInfoSave = new CostInfoSave
            {
                vid = 1,
                sid = 1,
                iid = 1,
                cid = 10,
                appraisalid = 1232,
                bumpusername = "test",
                newappraisalvalue = 123,
                purchasevalue = 100,
                reasoncode = 2,
                username = "test"
            };
            vehicleIdentity = new VehicleIdentity
            {
                VID = 1,
                SID = 1,
                IID = 1,
                CID = DomailModels.Enums.Company.SU
            };
            costInfoEdit = new CostInfoEdit
            {
                VID = vehicleIdentity.VID,
                SID = (short)vehicleIdentity.SID,
                IID = (short)vehicleIdentity.IID,
                isSightUnseen = false,
                SalesPersonAppraised = false,
                Step5Exist = true,
                Vehicle_Src = 80,
                Onchange = true,
                appraisalValue = new AppraisalValueEntity
                {
                    EstCondition = 100,
                    AppraisalValue = 300,
                },
                MarketValue = 400
            };

            costInfoEdit1 = new CostInfoEdit
            {
                VID = vehicleIdentity.VID,
                SID = (short)vehicleIdentity.SID,
                IID = (short)vehicleIdentity.IID,
                isSightUnseen = true,
                SalesPersonAppraised = false,
                Step5Exist = true,
                Vehicle_Src = 80,
                Onchange = false,
                appraisalValue = new AppraisalValueEntity
                {
                    EstCondition = 200,
                    AppraisalValue = 300,
                    PurchasePrice = 500
                },
                MarketValue = 500
            };

            costInfoEdit2 = new CostInfoEdit
            {
                VID = vehicleIdentity.VID,
                SID = (short)vehicleIdentity.SID,
                IID = (short)vehicleIdentity.IID,
                isSightUnseen = true,
                SalesPersonAppraised = false,
                Step5Exist = true,
                Vehicle_Src = 90,
                Onchange = false,
                appraisalValue = new AppraisalValueEntity
                {
                    EstCondition = 200,
                    UnseenValue = 100,
                    AppraisalValue = 300,
                    PurchasePrice = 500
                },
                MarketValue = 300
            };

            costInfoEdit3 = new CostInfoEdit
            {
                VID = vehicleIdentity.VID,
                SID = (short)vehicleIdentity.SID,
                IID = (short)vehicleIdentity.IID,
                isSightUnseen = true,
                SalesPersonAppraised = false,
                Step5Exist = false,
                Vehicle_Src = 110,
                SACStatus = 402,
                Onchange = false,
                appraisalValue = new AppraisalValueEntity
                {
                    EstCondition = 200,
                    UnseenValue = 100,
                    AppraisalValue = 300,
                    PurchasePrice = 500
                },
                MarketValue = 500
            };
        }

        [Fact]
        public void GetReasonCodeDetails_Returns_RegionCodes()
        {
            costInformationRepositoryMock.Setup(p => p.GetReasonCodeDetails(resonType)).Returns(reasonCode);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetReasonCodeDetails(resonType);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void SaveCostInforamtion_Returns_True()
        {
            costInformationRepositoryMock.Setup(p => p.SaveCostInforamtion(costInfoSave)).Returns(saveResult);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.SaveCostInforamtion(costInfoSave);
            Assert.True(result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightSeen_Returns_CostInfoEditDetails()
        {
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightUnSeen_Returns_CostInfoEditDetails()
        {
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit1);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit1, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightUnSeenOtherThanVehicleSrc80_Returns_CostInfoEditDetails()
        {
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit2);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit2, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightUnSeenVehicleSrc110AndSACStatus402_Returns_CostInfoEditDetails()
        {
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit3);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit3, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightUnSeenVehicleSrc110AndSACStatusGreaterThan403_Returns_CostInfoEditDetails()
        {
            costInfoEdit3.SACStatus = 403;
            costInfoEdit3.Onchange = true;
            costInfoEdit3.MarketValue = 300;
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit3);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit3, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightSeenVehicleSrc110AndSACStatusGreaterThan403_Returns_CostInfoEditDetails()
        {
            costInfoEdit3.SACStatus = 403;
            costInfoEdit3.Onchange = true;
            costInfoEdit3.isSightUnseen = false;
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit3);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit3, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightUnSeenVehicleSrc120_Returns_CostInfoEditDetails()
        {
            costInfoEdit3.Onchange = false;
            costInfoEdit3.Vehicle_Src = 120;
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit3);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit3, result);
        }

        [Fact]
        public void GetAppraisalEditInforamtion_ForSightUnSeenVehicleSrc80_Returns_CostInfoEditDetails()
        {
            costInfoEdit3.Onchange = false;
            costInfoEdit3.Vehicle_Src = 80;
            costInformationRepositoryMock.Setup(p => p.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString())).Returns(costInfoEdit3);
            ICostInformationLogic costInformationLogic = new CostInformationLogic(costInformationRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalEditInforamtion(vehicleIdentity.VID, (short)vehicleIdentity.SID, (short)vehicleIdentity.IID, vehicleIdentity.CID.ToString());
            Assert.Equal(costInfoEdit3, result);
        }
    }
}
