﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Pricing;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomainModels.Pricing;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Pricing
{
    public class PriceReviewLogicTest
    {
        private Mock<IPriceReviewRepository> pricingRepositoryMock;
        private PriceReviewLogParams priceReviewLogParams;
        private List<PriceReviewLogData> priceReviewLogData;
        private PriceReviewLockedDetails priceReviewLockDetails;
        private List<PriceReviewHistory> priceReviewHistories;
        private string username;
        private int pricereviewlogid;

        public PriceReviewLogicTest()
        {
            pricingRepositoryMock = new Mock<IPriceReviewRepository>();
            priceReviewLogParams = new PriceReviewLogParams()
            {
                CID = 10,
                RegionID = 73,
                StartRow = 1,
                EndRow = 9000,
                VINOrStock = "",
                AppraisalType = "",
                IsLease = false,
                Fromdate = "1/1/2021",
                Todate = "5/5/2021",
                IsPurchase = false,
                RegionName = "",
                SortByField = "StockNo",
                SortDirection = "DESC",
                StatusList = "801,802,803,804",
                StoreLocationID = 101
            };

            priceReviewLogData = new List<PriceReviewLogData>()
            {
                new PriceReviewLogData
                {
                    VID=12345,
                    SID=101,
                    IID=1,
                    Year=2021,
                    VIN="JF1GV7F68BG521147",
                    Dealership="Acura of Serramonte",
                    DealershipValue=0,
                    Difference=100,
                   StockNumber="654789",
                    ExtColor="black",
                    Make="Jeep",
                   Mileage=666,
                   Model="Altima",
                   PriceRvwLogID=123321,
                   PriceRvwStatus="802",
                   PriceStatusID=32123,
                   RecommendedValue=100,
                   RequestedDateTime=new DateTime().ToString(),
                   SACID=46312,
                   SeriesTrim="Sport (4WD 4dr Sport)",
                   StockNo="654789",
                   VehicleStatusID=102
                }
            };
            pricereviewlogid = 123;
            username = "testUser";
            priceReviewLockDetails = new PriceReviewLockedDetails()
            {
                PRVW_ID = 732145,
                Islock = true,
                UserName = "testUser"
            };
            priceReviewHistories = new List<PriceReviewHistory>
            {
                new PriceReviewHistory{vehicleIdentity = new DomailModels.Common.VehicleIdentity{ VID=1,SID=1,IID=1,CID= DomailModels.Enums.Company.SU},Year=2008, Make="BMW", Model="X4", SeriesTrim="M40D"  },
                new PriceReviewHistory{vehicleIdentity = new DomailModels.Common.VehicleIdentity{ VID=2,SID=1,IID=1,CID= DomailModels.Enums.Company.SU},Year=2009, Make="Audi", Model="A4", SeriesTrim="Premium Plus"  }
            };
        }

        [Fact]
        public void GetPriceReviewLogDetails_Returns_Result()
        {
            pricingRepositoryMock.Setup(p => p.GetPriceReviewLogDetails(priceReviewLogParams)).Returns(priceReviewLogData);
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.GetPriceReviewLogDetails(priceReviewLogParams);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetPriceReviewLogDetails_Returns_EmptyList()
        {
            pricingRepositoryMock.Setup(p => p.GetPriceReviewLogDetails(new PriceReviewLogParams())).Returns(new List<PriceReviewLogData>());
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.GetPriceReviewLogDetails(new PriceReviewLogParams());
            Assert.True(result == null);
        }

        [Fact]
        public void LockUnlockSACRecord_Returns_True()
        {
            pricingRepositoryMock.Setup(p => p.LockUnlockPriceReviewRecord(priceReviewLockDetails)).Returns(true);
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.LockUnlockPriceReviewRecord(priceReviewLockDetails);
            Assert.True(result == true);
        }
        [Fact]
        public void LockUnlockSACRecord_Returns_False()
        {
            pricingRepositoryMock.Setup(p => p.LockUnlockPriceReviewRecord(priceReviewLockDetails)).Returns(false);
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.LockUnlockPriceReviewRecord(priceReviewLockDetails);
            Assert.True(result == false);
        }


        [Fact]
        public void GetLockedBy_Returns_Username()
        {
            pricingRepositoryMock.Setup(p => p.GetLockedBy(pricereviewlogid)).Returns(username);
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.GetLockedBy(pricereviewlogid);
            Assert.True(result.Length > 0);
        }
        [Fact]
        public void GetLockedBy_Returns_Empty()
        {
            pricingRepositoryMock.Setup(p => p.GetLockedBy(pricereviewlogid)).Returns("");
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.GetLockedBy(pricereviewlogid);
            Assert.True(result.Length == 0);
        }

        [Fact]
        public void GetPriceReviewHistory_Returns_Result()
        {
            pricingRepositoryMock.Setup(p => p.GetPriceReviewHistory(1, "RequestedDateTime", "desc")).Returns(priceReviewHistories);
            IPriceReviewLogic pricingLogic = new PriceReviewLogic(pricingRepositoryMock.Object);
            var result = pricingLogic.GetPriceReviewHistory(1, "RequestedDateTime", "desc");
            Assert.True(result.Count > 0);
        }
    }
}
