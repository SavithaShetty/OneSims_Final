﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Options;
using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces.SAC;
using Sonic.OneSIMS.DataAccess.Interfaces.SAC;
using Sonic.OneSIMS.DomainModels.Enums;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Sac;
using Sonic.OneSIMS.DomainModels.SAC;
using Sonic.OneSIMS.Framework.Configuration;
using Sonic.OneSIMS.Infrastructure;
using Sonic.OneSIMS.Infrastructure.ZipCode;
using Sonic.OneSIMS.Infrastructure.ZipCode.Entities;
using Xunit;
using System.Linq;
using Sonic.OneSIMS.BusinessLogic.SAC;
using Sonic.OneSIMS.DomainModels.Common;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.SAC
{
    public class SacLogLogicTest
    {
        private Mock<ISACRepository> SACRepositoryMock;
        private Mock<IZipCodeService> zipcodeServiceMock;
        private Mock<IOptions<Framework.Configuration.ZipCodeSettings>> zipcodesettingsMock;
        private Mock<IOptions<Framework.Configuration.Settings>> settingsMock;
        private List<SacLoglist> sacLogData;
        private LockedDetail sacLockDetails;
        private LockedDetail sacLockDetails_Empty;
        private List<TradeStoreDetails> tradeStoreDetails;
        private SACNextAppraisal sacNextAppraisal;
        private SACNextAppraisal sacNextAppraisal_Empty;
        private SACVehicle sacVehicle;
        private SACVehicle sacVehicle_empty;
        long VID = 149513;
        string VIN;
        short SID = 101; short IID = 1; short CID = 10;
        int Region_ID = 0;
        string AppraisalType = "Display All";
        string SAC_Status = "402,404";
        bool IsLease = true;
        string VINOrStock = "2B3KA73W27H653144";
        int sacid = 2465456;
        string username = "Arati.K";
        private bool LockedDetail = true;
        decimal suggestedPrice;
        decimal suggestedPrice_Empty;
        short RegionId;
        long SACID = 2465456;

        private List<IDValues> SACRecommendation;
        private List<IDValues> InventorySegment;
        private SaveSacRecommendationDetails saveSacRecmmDetails;
        private SaveSacRecommendationDetails saveSacRecmmDetails_empty;

        public SacLogLogicTest()
        {
            SACRepositoryMock = new Mock<ISACRepository>();
            zipcodeServiceMock = new Mock<IZipCodeService>();
            zipcodesettingsMock = new Mock<IOptions<Framework.Configuration.ZipCodeSettings>>();
            settingsMock = new Mock<IOptions<Framework.Configuration.Settings>>();
            suggestedPrice = 1;
            RegionId = 0;

            sacLogData = new List<SacLoglist>
            {
                new SacLoglist
                {
                    VIN = "2B3KA73W27H653144",
                    VID = 149513,
                    SID = 101,
                    CID = 0,
                    CSID = 101,
                    IID = 1,
                    SACStatusID = "402",
                    SACID = 2465456,
                    Year = 2007,
                    Make = "Dodge",
                    Model = "Charger",
                    SeriesTrim = "SRT8 (4dr Sdn 5-Spd Auto SRT8 RWD)",
                    ExteriorColor = "Black",
                    Mileage = 2333,
                    CreatedDate = "11/23/2021  6:38PM",
                    Appraisedby = "Raju Mahesh",
                    SACAppValue = null,
                    Dealership = "Acura of Serramonte",
                    SACStatus = "Pending",
                    Photos = null,
                    CReportIconID = null,
                    CReportURL = null,
                    AReportIconID = 90,
                    AReportURL = "http://autocheck.dealersuite.com/autocheck/viewFullReport?APPID=TtNmcg8mwm1D6eK7%2FOUdKg%3D%3D&DEALERID=sITgdjgM7m84weoUpnrwVA%3D%3D&VIN=ufbChKHoVU3Jacy4dPxlLveAl3s%2FKpv5aObnVZ%2Fupsw%3D",
                    AppraisalType = 30,
                    TimerColor = "1",
                    Indicator = null
                }

            };

            sacLockDetails = new LockedDetail()
            {
                SAC_ID = 2465456,
                UserName = "Arati.k",
                Islock = true
            };
            sacLockDetails_Empty = new LockedDetail()
            {
                SAC_ID = 2465456,
                UserName = "test",
                Islock = false
            };

            tradeStoreDetails = new List<TradeStoreDetails>
            {
                new TradeStoreDetails
                {
                 DealershipId = 100,
                 Dealership = "Acura 101 West",
                 Need = 0,
                 AverageGross = 0,
                 Distance = 0,
                 Certifiable = "0",
                 ZipCode = "91302",
                 SourceZipcode = "94014"
                },
                new TradeStoreDetails
                {
                 DealershipId = 245,
                 Dealership = "Audi Birmingham",
                 Need = 0,
                 AverageGross = 0,
                 Distance = 0,
                 Certifiable = "0",
                 ZipCode = "35210",
                 SourceZipcode = "94014"
                }

            };

            sacNextAppraisal = new SACNextAppraisal()
            {
                SAC_ID = 166,
                VID = 984811,
                SID = 103,
                IID = 1,
                CID = 10,
                VIN = "2FMDK39C89BA67401"
            };

            sacNextAppraisal_Empty = new SACNextAppraisal()
            {
                
            };

            sacVehicle = new SACVehicle()
            {
                VehicleIdentity = {
                VID = 149513,
                SID = 101,
                IID = 1,
                CID = (DomailModels.Enums.Company)this.CID
              },
                SACID = 2465456,
                VehicleSource = (VehicleSource?)30,
                SACRecommendation = new List<IDValues> {
                   new IDValues
                   {
                    ID = "10",
                    Value = "Keep",
                    Selected = false,
                    Code = null
                   },
                  new IDValues
                   {
                    ID = "20",
                    Value = "Match",
                    Selected = false,
                   Code = null
                   },
                  new IDValues
                   {
                    ID = "30",
                    Value = "More Info",
                    Selected = true,
                    Code = null
                   }
                },
                StopSale = false,
                InventorySegment = new List<IDValues> {
                    new IDValues
                {
                     ID = "A",
                     Value = "A",
                     Selected = true,
                     Code = null
                },
                    new IDValues
                {
                    ID = "B",
                    Value = "B",
                    Selected = false,
                    Code = null
                },
                    new IDValues
                {
                    ID= "C",
                    Value = "C",
                    Selected = false,
                    Code = null
                },
                    new IDValues
                {
                    ID = "WS",
                    Value = "WS",
                    Selected = false,
                    Code = null
                }
            },
                PushPrice = 20000,
                SuggestedPrice = 0,
                RecommendationAppraisalPrice = null,
                RecommendationRetailPrice = null,
                NoteForDealership = "Please upload clear photos",
                NoteForSAC = "",
                VehicleTradeToStore = 0,
                VehicleTradeToCompany = 0,
                TradePrice = null,
                TransportNeeded = false,
                PendingWholesale = false,
                EstimatedTransportationCost = null,
                EstimatedReconAmount = 823,
                PackAmout = 0,
                DealerFeeAmtUSED = 0,
                UserName = null,
                LastModifiedTime = DateTime.Now,
                vehicleTradeToStoreName = null,
                isInterCompany = false
            };

            sacVehicle_empty = new SACVehicle()
            {
            };

            saveSacRecmmDetails = new SaveSacRecommendationDetails()
            {
               
                VID = 149513,
                SID = 101,
                IID = 1,
                CID = 10,
                SACID = 2465456,
                VehicleSource = (VehicleSource?)30,
                SACRecommendation = new IDValues {
                    ID = "10",
                    Value = "Keep",
                    Selected = false,
                    Code = null
                },
                StopSale = false,
                PushPrice = 20000,
                SuggestedPrice = 0,
                RecommendationAppraisalPrice = null,
                RecommendationRetailPrice = null,
                NoteForDealership = "Please upload clear photos",
                NoteForSAC = "",
                VehicleTradeToStore = 0,
                VehicleTradeToCompany = 0,
                TradePrice = null,
                TransportNeeded = false,
                PendingWholesale = false,
                EstimatedTransportationCost = null,
                UserName = null,
                vehicleTradeToStoreName = null,
            };

            saveSacRecmmDetails_empty = new SaveSacRecommendationDetails()
            {
            };

        }

        //SAC Log data
        [Fact]
        public void GetSacLog_Returnd_result()
        {
            SACRepositoryMock.Setup(p => p.GetSacLog(CID, Region_ID, AppraisalType, SAC_Status, IsLease, VINOrStock)).Returns(sacLogData);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetSacLog(CID, Region_ID, AppraisalType, SAC_Status, IsLease, VINOrStock);
            Assert.True(result.Count > 0);
        }
        [Fact]
        public void GetSacLog_Returnd_Empty()
        {
            SACRepositoryMock.Setup(p => p.GetSacLog(CID, Region_ID, AppraisalType, SAC_Status, IsLease, VINOrStock)).Returns(new List<SacLoglist>());
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetSacLog(CID, Region_ID, AppraisalType, SAC_Status, IsLease, VINOrStock);
            Assert.True(result.Count == 0);
        }

        //Get SAC locked data

        [Fact]
        public void GetLockedBy_Returns_Username()
        {
            SACRepositoryMock.Setup(p => p.GetLockedBy(sacid)).Returns(username);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetLockedBy(sacid);
            Assert.True(result.Length > 0);
        }
        [Fact]
        public void GetLockedBy_Returns_Empty()
        {
            SACRepositoryMock.Setup(p => p.GetLockedBy(sacid)).Returns("");
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetLockedBy(sacid);
            Assert.True(result.Length == 0);
        }

        // Get Lock or Unlock SAC record

        [Fact]
        public void LockUnlockSACRecord_Returns_True()
        {
            bool expected = true;
            SACRepositoryMock.Setup(p => p.LockUnlockSACRecord(sacLockDetails)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            bool result = sacLogic.LockUnlockSACRecord(sacLockDetails);
            Assert.Equal(expected, result);

        }
        [Fact]
        public void LockUnlockSACRecord_Returns_False()
        {
            bool expected = false;
            SACRepositoryMock.Setup(p => p.LockUnlockSACRecord(sacLockDetails_Empty)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            bool result = sacLogic.LockUnlockSACRecord(sacLockDetails_Empty);
            Assert.Equal(expected, result);
        }

        // Get Trade store List
        [Fact]
        public void GetTradeStoreList_Returnd_result()
        {
            SACRepositoryMock.Setup(p => p.GetTradeStoreList(VID, SID, IID, CID)).Returns(tradeStoreDetails);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetTradeStoreList(VID, SID, IID, CID);
            Assert.True(result.Count > 0);
        }
        [Fact]
        public void GetTradeStoreList_Returnd_Empty()
        {
            SACRepositoryMock.Setup(p => p.GetTradeStoreList(VID, SID, IID, CID)).Returns(new List<TradeStoreDetails>());
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetTradeStoreList(VID, SID, IID, CID);
            Assert.True(result.Count == 0);
        }

        //Get Suggested Price

        [Fact]
        public void GetSuggestedPrice_Returns_True()
        {
            SACRepositoryMock.Setup(p => p.GetSuggestedPrice(VID, SID, IID, CID)).Returns(suggestedPrice);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetSuggestedPrice(VID, SID, IID, CID);
            Assert.True(result > 0);
        }
        [Fact]
        public void GetSuggestedPrice_Returns_Empty()
        {
            decimal expected = 0;
            SACRepositoryMock.Setup(p => p.GetSuggestedPrice(VID, SID, IID, CID)).Returns(suggestedPrice_Empty);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetSuggestedPrice(VID, SID, IID, CID);
            Assert.Equal(expected, result);
        }

        // Get NextPending Appraisal
        [Fact]
        public void GetNextPendingAppraisal_Returnd_result()
        {
            
            SACRepositoryMock.Setup(p => p.GetNextPendingAppraisal(CID, RegionId)).Returns(sacNextAppraisal);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetNextPendingAppraisal(CID, RegionId);
<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<AUTO GENERATED BY CONFLICT EXTENSION<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< OneSIMS_Development
            Assert.True(result.VIN != string.Empty);
====================================AUTO GENERATED BY CONFLICT EXTENSION====================================
            Assert.Equal(this.sacNextAppraisal, result);
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>AUTO GENERATED BY CONFLICT EXTENSION>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Arati/SAC_Unittestcases
        }
        [Fact]
        public void GetNextPendingAppraisal_Returnd_Empty()
        {
            SACRepositoryMock.Setup(p => p.GetNextPendingAppraisal(CID, RegionId)).Returns(sacNextAppraisal_Empty);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetNextPendingAppraisal(CID, RegionId);
<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<AUTO GENERATED BY CONFLICT EXTENSION<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< OneSIMS_Development
            Assert.True(result.VIN == string.Empty);
====================================AUTO GENERATED BY CONFLICT EXTENSION====================================
            Assert.Equal(this.sacNextAppraisal_Empty, result);
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>AUTO GENERATED BY CONFLICT EXTENSION>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Arati/SAC_Unittestcases
        }

        // Get SAC Vehicle Recommendation
        [Fact]
        public void GetSACVehicleRecommendation_Returns_True()
        {
            SACRepositoryMock.Setup(p => p.GetSACVehicleRecommendation(VID, SID, IID, CID, SACID)).Returns(sacVehicle);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetSACVehicleRecommendation(VID, SID, IID, CID, SACID);
            Assert.Equal(this.sacVehicle, result);
        }
        [Fact]
        public void GetSACVehicleRecommendation_Returns_Empty()
        {
            
            SACRepositoryMock.Setup(p => p.GetSACVehicleRecommendation(VID, SID, IID, CID, SACID)).Returns(sacVehicle_empty);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.GetSACVehicleRecommendation(VID, SID, IID, CID, SACID);
            Assert.Equal(this.sacVehicle_empty, result);
        }

        // Save SAC Vehicle Recommendation
        [Fact]
        public void SaveReconAmountDetails_Returns_true()
        {
            bool expected = true;
            SACRecommendation recommendation = (SACRecommendation)Convert.ToInt32(sacVehicle.SACRecommendation.Count);
            bool isSuccess = false;
            if (recommendation == SACRecommendation)
            {
                sacVehicle.TransportNeeded = false;
                //Code for keep or need More info
                isSuccess = UpdateKeepRecommendation(sacVehicle);
            }
            else if (recommendation == SACRecommendation.NeedMoreInfo)
            {
                sacVehicle.TransportNeeded = false;
                //Code for keep or need More info
                isSuccess = UpdateMoreInfoRecommendation(sacVehicle);
            }
            else if (recommendation == SACRecommendation.Match)
            {
                //Code for match
                isSuccess = UpdateMatchRecommendation(sacVehicle);
            }
            SACRepositoryMock.Setup(p => p.SaveSACVehicleRecommendation(saveSacRecmmDetails)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.SaveSACVehicleRecommendation(saveSacRecmmDetails);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void SaveReconAmountDetails_Returns_false()
        {
            bool expected = false;
            SACRepositoryMock.Setup(p => p.SaveSACVehicleRecommendation(saveSacRecmmDetails_empty)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.SaveSACVehicleRecommendation(saveSacRecmmDetails_empty);
            Assert.Equal(expected, result);
        }

        // Update SAC Recommendation Keep
        [Fact]
        public void UpdateSACRecommendationKeep_Returns_True()
        {
            bool expected = true;
            SACRepositoryMock.Setup(p => p.UpdateSACRecommendationKeep(saveSacRecmmDetails)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.UpdateSACRecommendationKeep(saveSacRecmmDetails);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdateSACRecommendationKeep_Returnss_False()
        {
            bool expected = false;
            SACRepositoryMock.Setup(p => p.UpdateSACRecommendationKeep(saveSacRecmmDetails_empty)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.UpdateKeepRecommendation(saveSacRecmmDetails_empty);
            Assert.Equal(expected, result);
        }

        // Update SAC Recommendation Keep
        [Fact]
        public void UpdateMatchRecommendation_Returns_True()
        {
            bool expected = true;
            SACRepositoryMock.Setup(p => p.UpdateSACRecommendationKeep(saveSacRecmmDetails)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.UpdateSACRecommendationKeep(saveSacRecmmDetails);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdateMatchRecommendation_Returnss_False()
        {
            bool expected = false;
            SACRepositoryMock.Setup(p => p.UpdateMatchRecommendation(saveSacRecmmDetails_empty)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.UpdateMatchRecommendation(saveSacRecmmDetails_empty);
            Assert.Equal(expected, result);
        }

        // Update SAC Recommendation Keep
        [Fact]
        public void UpdateMoreInfoRecommendation_Returns_True()
        {
            bool expected = true;
            SACRepositoryMock.Setup(p => p.UpdateMoreInfoRecommendation(saveSacRecmmDetails)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.UpdateMoreInfoRecommendation(saveSacRecmmDetails);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdateMoreInfoRecommendation_Returnss_False()
        {
            bool expected = false;
            SACRepositoryMock.Setup(p => p.UpdateMoreInfoRecommendation(saveSacRecmmDetails_empty)).Returns(expected);
            ISACLogic sacLogic = new SACLogic(SACRepositoryMock.Object, zipcodeServiceMock.Object);
            var result = sacLogic.UpdateMoreInfoRecommendation(saveSacRecmmDetails_empty);
            Assert.Equal(expected, result);
        }
    }
}
