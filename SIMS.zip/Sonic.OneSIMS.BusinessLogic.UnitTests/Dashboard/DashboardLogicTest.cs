﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Settings;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomainModels.Dashboard;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Dashboard
{
    public class DashboardLogicTest
    {
        private Mock<IDashboardRepository> dashboardRespositoryMock;
        private BadgeCount count;

        public DashboardLogicTest()
        {
            dashboardRespositoryMock = new Mock<IDashboardRepository>();

            count = new BadgeCount()
            {
                appCount = 5,
                sacCount = 10
            };
        }
        [Fact]
        public void getMenuBadgeCount_Returns_Result()
        {
            dashboardRespositoryMock.Setup(p => p.GetBadgeCount(101,10)).Returns(count);
            IDashboardLogic dashboardLogic = new DashboardLogic(dashboardRespositoryMock.Object);
            var result = dashboardLogic.GetBadgeCount(101,10);
            Assert.True(result.appCount>0 && result.sacCount>0);
        }

        [Fact]
        public void getMenuBadgeCount_Returns_zero()
        {
            dashboardRespositoryMock.Setup(p => p.GetBadgeCount(101, 10)).Returns(new BadgeCount());
            IDashboardLogic dashboardLogic = new DashboardLogic(dashboardRespositoryMock.Object);
            var result = dashboardLogic.GetBadgeCount(101, 10);
            Assert.True(result.appCount==0 && result.sacCount==0);
        }
    }
}
