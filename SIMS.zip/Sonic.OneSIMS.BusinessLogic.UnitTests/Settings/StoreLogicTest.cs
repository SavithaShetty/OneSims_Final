﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Settings;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomailModels.Settings;
using Sonic.OneSIMS.DomainModels.Settings;
using Sonic.OneSIMS.DomainModels.Settings.Regions;
using Sonic.OneSIMS.DomainModels.Settings.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Settings
{
    public class StoreLogicTest
    {
        private Mock<IStoreRepository> storeRepositoryMock;
        private Store store;
        private List<Store> stores;
        private List<Brand> brands;
        private StoreDetails storeDetails;
        private StoreOtherInfo storeOtherInfo;
        private List<Configurations> configurations;
        private DealershipConfiguration dealershipConfiguration;
        private DealershipInformation dealershipInformation;
        private List<RegionNames> regionNames;

        public StoreLogicTest()
        {
            storeRepositoryMock = new Mock<IStoreRepository>();
            store = new Store
            {
                StoreId = 101,
                StoreName = "Accura Of Serramonte",
                RegionId = 40,
                RegionName = "ABC",
                City = "XYZ",
                Address = "LMN",
                PhoneNumber = "32233",
                ZipCode = "34444"
            };
            stores = new List<Store>
            {
                new Store{ StoreId=101,StoreName="Accura Of Serramonte", RegionId=40},
                new Store{ StoreId=102,StoreName="BMW of Nashville", RegionId=40}
            };

            brands = new List<Brand>
            {
                new Brand{ BrandId=1,BrandName="BMW"},
                new Brand{ BrandId=2,BrandName="Audi"},
            };

            storeDetails = new StoreDetails
            {
                Store_id = 101,
                StoreName = "Accura Of Serramonte"
            };

            storeOtherInfo = new StoreOtherInfo
            {
                InspectionAmount = 500,
                StoreCDKDetails = new List<StoreCDKDetails> { new StoreCDKDetails { Dealership_Name = "Accura Of Serramonte" } }
            };

            configurations = new List<Configurations>
            {
                new Configurations{ CurrStoreID=101,StoreId=101,StoreName="Accura Of Serramonte",IsADPSyncReqd=true}
            };

            dealershipConfiguration = new DealershipConfiguration
            {
                storeID = 101,
                sonicConfiguration = new SonicConfiguraion { storeID = 101, isActive = true, isCDKSyncRequired = true }
            };

            dealershipInformation = new DealershipInformation
            {
                Store_id = 101,
                IsUsedStore = true,
                IsNewStore = false,
                StoreName = "Accura Of Serramonte",
                Is_Act = true
            };

            regionNames = new List<RegionNames>
            {
                new RegionNames{ RegionID=10,RegionName="AB"},
                new RegionNames{ RegionID=20,RegionName="CD"},
                new RegionNames{ RegionID=30,RegionName="EF"},
            };
        }

        [Fact]
        public void AddStore_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.AddStore(store)).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.AddStore(store);
            Assert.True(result);
        }

        [Fact]
        public void AddStore_Returns_False()
        {
            storeRepositoryMock.Setup(p => p.AddStore(store)).Returns(false);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.AddStore(store);
            Assert.False(result);
        }

        [Fact]
        public void UpdateStore_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.UpdateStore(store)).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.UpdateStore(store);
            Assert.True(result);
        }

        [Fact]
        public void UpdateStore_Returns_False()
        {
            storeRepositoryMock.Setup(p => p.UpdateStore(store)).Returns(false);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.UpdateStore(store);
            Assert.False(result);
        }

        [Fact]
        public void GetAllStores_Returns_StoreList()
        {
            storeRepositoryMock.Setup(p => p.GetAllStores()).Returns(stores);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetAllStores();
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetAllStores_Returns_EmptyList()
        {
            storeRepositoryMock.Setup(p => p.GetAllStores()).Returns(new List<Store>());
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetAllStores();
            Assert.False(result.Count() > 0);
        }

        [Fact]
        public void GetStoreById_Returns_MatchingStore()
        {
            storeRepositoryMock.Setup(p => p.GetStoreById(101)).Returns(stores[0]);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetStoreById(101);
            Assert.True(result.StoreName == stores[0].StoreName);
        }

        [Fact]
        public void GetStoreByRegionId_Returns_StoreList()
        {
            storeRepositoryMock.Setup(p => p.GetStoreByRegionId(40)).Returns(stores);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetStoreByRegionId(40);
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetRegionsAndStores_Returns_RegionStoreList()
        {
            storeRepositoryMock.Setup(p => p.GetRegionsAndStores(10)).Returns(stores);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetRegionsAndStores(10);
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetBrands_Returns_BrandList()
        {
            storeRepositoryMock.Setup(p => p.GetBrands()).Returns(brands);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetBrands();
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetBrands_Returns_EmptyList()
        {
            storeRepositoryMock.Setup(p => p.GetBrands()).Returns(new List<Brand>());
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetBrands();
            Assert.False(result.Count() > 0);
        }

        [Fact]
        public void DeleteStoreById_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.DeleteStoreById(101)).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.DeleteStoreById(101);
            Assert.True(result);
        }

        [Fact]
        public void SearchStores_Returns_Store()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.SearchStores(stores, 101);
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void SearchStores_Returns_Empty()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.SearchStores(stores, 105);
            Assert.False(result.Count() > 0);
        }

        [Fact]
        public void IsValidpassword_Returns_True()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.IsValidpassword("Welcome@123");
            Assert.True(result);
        }

        [Fact]
        public void IsValidpassword_Returns_False()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.IsValidpassword("Welcome123");
            Assert.False(result);
        }

        [Fact]
        public void ValidateVIN_Returns_True()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.ValidateVIN("2G1WH52K439149593");
            Assert.True(result);
        }

        [Fact]
        public void ValidateVIN_Returns_False()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.ValidateVIN("Welcome123");
            Assert.False(result);
        }

        [Fact]
        public void ValidMileage_Returns_True()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.ValidMileage(1000);
            Assert.True(result);
        }

        [Fact]
        public void ValidMileage_Returns_False()
        {
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.ValidMileage(6000);
            Assert.False(result);
        }

        [Fact]
        public void GetStoresCount_Returns_Count()
        {
            storeRepositoryMock.Setup(p => p.GetStoresCount(true)).Returns(2);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetStoresCount(true);
            Assert.True((int)result > 0);
        }

        [Fact]
        public void GetStoresCount_Returns_Zero()
        {
            storeRepositoryMock.Setup(p => p.GetStoresCount(false)).Returns(0);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetStoresCount(false);
            Assert.False((int)result > 0);
        }

        [Fact]
        public void GetStoresList_Returns_StoreList()
        {
            storeRepositoryMock.Setup(p => p.GetStoresList()).Returns(stores);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetStoresList();
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetStoresList_Returns_EmptyList()
        {
            storeRepositoryMock.Setup(p => p.GetStoresList()).Returns(new List<Store>());
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetStoresList();
            Assert.False(result.Count() > 0);
        }

        [Fact]
        public void AddDealershipInfo_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.AddDealershipInfo(storeDetails)).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.AddDealershipInfo(storeDetails);
            Assert.True(result);
        }

        [Fact]
        public void GetDealershipInfo_Returns_Store()
        {
            storeRepositoryMock.Setup(p => p.GetDealershipInfo(101)).Returns(storeDetails);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetDealershipInfo(101);
            Assert.True(result.StoreName == "Accura Of Serramonte");
        }

        [Fact]
        public void AddOtherConfig_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.AddOtherConfig(storeOtherInfo)).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.AddOtherConfig(storeOtherInfo);
            Assert.True(result);
        }

        [Fact]
        public void GetOtherConfig_Returns_StoreInfo()
        {
            storeRepositoryMock.Setup(p => p.GetOtherConfig(101)).Returns(storeOtherInfo);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetOtherConfig(101);
            Assert.True(result.InspectionAmount == 500);
        }

        [Fact]
        public void GetConfigurations_Returns_ConfigurationList()
        {
            storeRepositoryMock.Setup(p => p.GetConfigurations()).Returns(configurations);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetConfigurations();
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void AddConfiguration_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.AddConfiguration(configurations[0])).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.AddConfiguration(configurations[0]);
            Assert.True(result);
        }

        [Fact]
        public void GetAllStoresList_Returns_StoreList()
        {
            storeRepositoryMock.Setup(p => p.GetAllStoresList(10, true)).Returns(stores);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetAllStoresList(10, true);
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetDealershipConfigurations_Returns_Configuration()
        {
            storeRepositoryMock.Setup(p => p.GetDealershipConfigurations(101)).Returns(dealershipConfiguration);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetDealershipConfigurations(101);
            Assert.True(result.storeID == 101);
        }

        [Fact]
        public void GetDealershipInformation_Returns_DealerShipInfo()
        {
            storeRepositoryMock.Setup(p => p.GetDealershipInformation(101)).Returns(dealershipInformation);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetDealershipInformation(101);
            Assert.True(result.Store_id == 101);
        }

        [Fact]
        public void CheckForNameDuplicate_Returns_False()
        {
            storeRepositoryMock.Setup(p => p.CheckForNameDuplicate("Accura Of Serramonte", 101)).Returns(false);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.CheckForNameDuplicate("Accura Of Serramonte", 101);
            Assert.False(result);
        }

        [Fact]
        public void GetRegions_Returns_Regions()
        {
            storeRepositoryMock.Setup(p => p.GetRegions(10)).Returns(regionNames);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.GetRegions(10);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void AddNewStoreDetails_Returns_StoreId()
        {
            storeRepositoryMock.Setup(p => p.AddNewStoreDetails("BMW Of Nashville")).Returns(110);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.AddNewStoreDetails("BMW Of Nashville");
            Assert.True(result == 110);
        }

        [Fact]
        public void DeleteNonOprDateClosedEndpoints_Returns_True()
        {
            storeRepositoryMock.Setup(p => p.DeleteNonOprDateClosedEndpoint(10, 101)).Returns(true);
            IStoreLogic storeLogic = new StoreLogic(storeRepositoryMock.Object);
            var result = storeLogic.DeleteNonOprDateClosedEndpoint(10, 101);
            Assert.True(result);
        }
    }
}
