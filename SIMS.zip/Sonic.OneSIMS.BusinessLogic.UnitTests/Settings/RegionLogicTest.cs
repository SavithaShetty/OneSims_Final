﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Settings;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomailModels.Settings;
using Sonic.OneSIMS.DomainModels.Settings.Regions;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Settings
{
    public class RegionLogicTest
    {
        private Mock<IRegionRepository> regiontRepositoryMock;
        private Region regionId;
        private Region regionEmpty;
        private RegionConfiguration regionConfiguration;
        private RegionConfiguration regionConfigurationEmpty;
        private List<Region> regionList;
        private List<RegionStore> regionStores;
        private List<Store> storeList;
        private Store Store;
        private Store StoreEmpty;

        public RegionLogicTest()
        {
            regiontRepositoryMock = new Mock<IRegionRepository>();
            regionList = new List<Region>
            {
                new Region { RegionId = 69, RegionName = "AL-FL-Nc", Visible = "False"}
            };
            regionStores = new List<RegionStore>
            {
                new RegionStore { RegionStoreName= "Land Rover Birmingham", RegionStoreID= 213 }
            };
            regionId = new Region { RegionId = 69, RegionName = "AL-FL-Nc", Visible = "False" };
            regionEmpty = new Region { };
            regionConfigurationEmpty = new RegionConfiguration { };
            regionConfiguration = new RegionConfiguration
            {
                Region = regionId,
                RegionStores = new List<RegionStore> 
                { 
                    new RegionStore
                    {
                        RegionStoreID=1,
                        RegionStoreName ="Central United States"
                    }
                },
                IsRegionActive = true,
                IsEnableSAC = true,
                UserName = null,
                CID = 10

            };
            StoreEmpty = new Store { };
            storeList = new List<Store>
            {
                new Store {
                     StoreId = 245,
                     StoreName = "Audi Birmingham",
                     Address = null,
                     City = null,
                     PhoneNumber = null,
                     ZipCode = null,
                     RegionId = 0,
                     RegionName = null
             }
            };
        }
        [Fact]
        public void GetRegion_Returns_Data()
        {
            regiontRepositoryMock.Setup(p => p.GetAllRegions(1)).Returns(regionList);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.GetAllRegions(1);
            Assert.True(result.Count() > 0);
        }

        [Fact]
        public void GetRegion_Returns_Empty_Data()
        {
            regiontRepositoryMock.Setup(p => p.GetAllRegions(1)).Returns(new List<Region>());
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.GetAllRegions(1);
            Assert.True(result.Count() == 0);
        }
        [Fact]
        public void AddRegion_Returns_True()
        {
            bool expected = true;
            regiontRepositoryMock.Setup(p => p.AddRegions(regionId)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.AddRegions(regionId);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void AddRegion_Returnss_False()
        {
            bool expected = false;
            regiontRepositoryMock.Setup(p => p.AddRegions(regionEmpty)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.AddRegions(regionEmpty);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void DeleteRegion_true()
        {
            bool expected = true;
            const int Id = 69;
            regiontRepositoryMock.Setup(p => p.DeleteRegionById(Id)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.DeleteRegionById(Id);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void DeleteRegion_Returns_false()
        {
            bool expected = false;
            const int Id = 0;
            regiontRepositoryMock.Setup(p => p.DeleteRegionById(Id)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.DeleteRegionById(Id);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void SaveRegionConfigSettings_Returns_true()
        {
            bool expected = true;
            regiontRepositoryMock.Setup(p => p.SaveRegionConfigSettings(regionConfiguration)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.SaveRegionConfigSettings(regionConfiguration);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void SaveRegionConfigSettings_Returns_false()
        {
            bool expected = false;
            regiontRepositoryMock.Setup(p => p.SaveRegionConfigSettings(regionConfigurationEmpty)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.SaveRegionConfigSettings(regionConfigurationEmpty);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void AddPod_Returns_true()
        {
            bool expected = true;
            regiontRepositoryMock.Setup(p => p.AddPod(regionConfiguration)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.AddPod(regionConfiguration);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void AddPod_Returns_false()
        {
            bool expected = false;
            regiontRepositoryMock.Setup(p => p.AddPod(regionConfigurationEmpty)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.AddPod(regionConfigurationEmpty);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void GetRegionConfigurations_Returns_true()
        {
            regiontRepositoryMock.Setup(p => p.GetRegionConfigurations(1)).Returns(regionConfiguration);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.GetRegionConfigurations(1);
            Assert.True(result.RegionStores.Count > 0);
        }

        [Fact]
        public void GetRegionConfigurations_Returns_Null()
        {
            regiontRepositoryMock.Setup(p => p.GetRegionConfigurations(1)).Returns(regionConfigurationEmpty);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.GetRegionConfigurations(1);
            Assert.True(result.Region == null);
        }
        [Fact]
        public void DeletePodAssociation_true()
        {
            bool expected = true;
            const int regionId = 69;
            const int storeId = 101;
            regiontRepositoryMock.Setup(p => p.DeletePodAssociation(regionId, storeId)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.DeletePodAssociation(regionId, storeId);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void DeletePodAssociation_false()
        {
            bool expected = false;
            const int regionId = 0;
            const int storeId = 0;
            regiontRepositoryMock.Setup(p => p.DeletePodAssociation(regionId, storeId)).Returns(expected);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.DeletePodAssociation(regionId, storeId);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void GetRegionAssociatedStores_Returns_true()
        {
            regiontRepositoryMock.Setup(p => p.GetRegionAssociatedStores(1)).Returns(storeList);
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.GetRegionAssociatedStores(1);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetRegionAssociatedStores_Returns_false()
        {
            regiontRepositoryMock.Setup(p => p.GetRegionAssociatedStores(1)).Returns(new List<Store>());
            IRegionLogic regionLogic = new RegionLogic(regiontRepositoryMock.Object);
            var result = regionLogic.GetRegionAssociatedStores(1);
            Assert.True(result.Count == 0);
        }


    }
}
