﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Settings;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomailModels.Common;
using Sonic.OneSIMS.DomainModels.Settings.Corporate;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Settings
{
    public class CorporateConfigurationLogicTests
    {
        private Mock<ICorporateRepository> corporateConfigRepositoryMock;
        private CorpGeneralOption options;
        private AgeBucket ageBucket;
        private List<AgeBucket> listageBucket;
        private List<CorpGeneralOption> corporateOptions;
        public CorporateConfigurationLogicTests()
        {
            corporateConfigRepositoryMock = new Mock<ICorporateRepository>();
            corporateOptions = new List<CorpGeneralOption>
            {
                new CorpGeneralOption {
                Corp_ID = 0,
                STCPhone = "88-888-888-8889",
                SAC_Mileage_Limit_for_Rec_Match = 50000,
                SAC_Green_to_Yellow_time_frame = 3,
                SAC_Yellow_to_Red_time_frame = 4,
                TradePrice = 500,
                SAC_Disable_Rvw_Comp_Recom = true,
                IsFactoryOptionsRequired = true,
                Apprsl_Green_to_Yellow_time_frame = 60,
                Apprsl_Yellow_to_Red_time_frame = 1200,
                Dashboard_Exp_Time = 999,
                Target_Apprsl_Close_Percentage = 65,
                Expire_Trial_List_Vehicles = 75,
                Store_Frcst_Deviation_Max = 100,
                Pend_to_Pri_Apprsl_time = 21,
                Old_Rec_in_Pend_Apprsl = 5,
                Old_Rec_in_Pend_Aquisition = 10,
                eLeads_Comp_Apprsl_Date_Limiter = 15,
                Print_Apprsl_Exp_Days = 3,
                Print_Apprsl_Exp_Mileage = 150,
                Print_Apprsl_Exp_Days_osoe = 14,
                Print_Apprsl_Exp_Mileage_osoe = 500,
                Pri_Apprsl_Date_Limiter = 30,
                Old_SAC_Rec_in_Incoming_status = 14,
                Target_Acceptance = 90,
                Price_Performance_Target = 80,
                Price_To_Sale_Gap_Target = 500,
                Price_Recom_Tlrnc_Prcnt_Variance = 1,
                Price_Recom_Tlrnc_Max_Variance = 500,
                Recom_Flag_Decay = 3,
                Trade_Walk_Decay = 3,
                Buy_List_Priority_Thrs = 120,
                PendingServiceAppraisalTime = 10,
                ServiceAppraisalSalesHistory = 10,
                PriorAppraisalToRemoved = 10,
                userName = "Test",
                cid = 10
            }
            };

            options = new CorpGeneralOption
            {
                Corp_ID = 0,
                STCPhone = "88-888-888-8889",
                SAC_Mileage_Limit_for_Rec_Match = 50000,
                SAC_Green_to_Yellow_time_frame = 3,
                SAC_Yellow_to_Red_time_frame = 4,
                TradePrice = 500,
                SAC_Disable_Rvw_Comp_Recom = true,
                IsFactoryOptionsRequired = true,
                Apprsl_Green_to_Yellow_time_frame = 60,
                Apprsl_Yellow_to_Red_time_frame = 1200,
                Dashboard_Exp_Time = 999,
                Target_Apprsl_Close_Percentage = 65,
                Expire_Trial_List_Vehicles = 75,
                Store_Frcst_Deviation_Max = 100,
                Pend_to_Pri_Apprsl_time = 21,
                Old_Rec_in_Pend_Apprsl = 5,
                Old_Rec_in_Pend_Aquisition = 10,
                eLeads_Comp_Apprsl_Date_Limiter = 15,
                Print_Apprsl_Exp_Days = 3,
                Print_Apprsl_Exp_Mileage = 150,
                Print_Apprsl_Exp_Days_osoe = 14,
                Print_Apprsl_Exp_Mileage_osoe = 500,
                Pri_Apprsl_Date_Limiter = 30,
                Old_SAC_Rec_in_Incoming_status = 14,
                Target_Acceptance = 90,
                Price_Performance_Target = 80,
                Price_To_Sale_Gap_Target = 500,
                Price_Recom_Tlrnc_Prcnt_Variance = 1,
                Price_Recom_Tlrnc_Max_Variance = 500,
                Recom_Flag_Decay = 3,
                Trade_Walk_Decay = 3,
                Buy_List_Priority_Thrs = 120,
                PendingServiceAppraisalTime = 10,
                ServiceAppraisalSalesHistory = 10,
                PriorAppraisalToRemoved = 10,
                userName = "Test",
                cid = 10
            };


        }

        [Fact]
        public void AddCorporateGeneralOptions_Returns_True()
        {
            bool expected = true;
            corporateConfigRepositoryMock.Setup(p => p.AddCorporateConfigInfo(options)).Returns(expected);
            ICorporateLogic corporateLogic = new CorporateLogic(corporateConfigRepositoryMock.Object);
            var result = corporateLogic.AddCorporateConfigInfo(options);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void GetCorporateGeneralOptions_Returns_result()
        {
            corporateConfigRepositoryMock.Setup(p => p.GetCorporateConfigInfo(10)).Returns(options);
            ICorporateLogic afterMarketLogic = new CorporateLogic(corporateConfigRepositoryMock.Object);
            var result = afterMarketLogic.GetCorporateConfigInfo(10);
            Assert.True(result.Corp_ID == 0);
        }

        [Fact]
        public void GetCorporateGeneralOptions_Returns_Empty_Questions()
        {
            corporateConfigRepositoryMock.Setup(p => p.GetCorporateConfigInfo(20)).Returns(options);
            ICorporateLogic afterMarketLogic = new CorporateLogic(corporateConfigRepositoryMock.Object);
            var result = afterMarketLogic.GetCorporateConfigInfo(10);
            Assert.True(result == null);
        }
    }
}
