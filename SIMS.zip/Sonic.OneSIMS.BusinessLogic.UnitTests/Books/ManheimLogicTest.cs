using Moq;
using Sonic.OneSIMS.BusinessLogic.Books;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomainModels.Books.Manheim;
using Sonic.OneSIMS.Infrastructure.Manheim;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.DecodeVin;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.MakeModelTrim;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.Transaction;
using System;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Books
{
    public class ManheimLogicTest
    {
        private Mock<IManheimService> manheimServiceMock;
        private Mock<IBooksCommonLogic> booksCommonLogicMock;

        private List<ManheimTransactionData> manheimTransactionDatas;
        private Transaction transaction;
        private Makes makes;
        private Models models;
        private Trims trims;
        private ManheimBookValuationRequest bookValuationRequest;
        private DomainModels.Books.Common.BookValuation bookValuation;
        private VinVehicleDetail vinVehicleDetail;

        private string manheim_Id = "201906957630040";
        private string region = "WC";

        public ManheimLogicTest()
        {
            manheimServiceMock = new Mock<IManheimService>();
            booksCommonLogicMock = new Mock<IBooksCommonLogic>();
            manheimTransactionDatas = new List<ManheimTransactionData>
            {
               new ManheimTransactionData
               {
                   AuctionName = "Manheim California",
                   BookCondition="Avg",
                   Engine="4GT",
                   ExteriorColor="White",
                   InSampleFlag = "Yes",
                   Odometer=36081,
                   PurchaseDate = DateTime.Now.AddYears(-3),
                   PurchasePrice = 36250,
                   SaleType = "Regular",
                   Transmission = "Automatic"
               },
               new ManheimTransactionData
               {
                   AuctionName = "Manheim Southern California",
                   BookCondition="Avg",
                   Engine="4GT",
                   ExteriorColor="White",
                   InSampleFlag = "Yes",
                   Odometer=48479,
                   PurchaseDate = DateTime.Now.AddYears(-3).AddDays(-5),
                   PurchasePrice = 36000,
                   SaleType = "Regular",
                   Transmission = "Automatic"
               }
            };
            transaction = new Transaction
            {
                href = "https://api.manheim.com/valuation-samples/id/201906957630040?country=US&region=WC&orderBy=purchasedate+desc&limit=25&start=1",
                count = 1,
                currency = "USD",
                odometerUnits = "Miles",
                items = new List<Item>
                {
                    new Item
                    {
                        location= new Location{ href="https://api.manheim.com/locations/id/CADE"},
                        region = new Region{href="https://api.manheim.com/valuations/regions/id/WC?country=US"},
                        purchaseDate = "2021-10-20",
                        purchasePrice=36250,
                        vehicleDetails= new VehicleDetails{engine="4GT", transmission="Automatic", color="White", odometer=36081, grade="36", condition="Avg" },
                        saleType="Regular",
                        inSample="Yes"
                    }
                }

            };

            makes = new Makes
            {
                count = 2,
                href = "https://api.manheim.com/valuations/years/2005/makes?country=US&orderBy=make+asc",
                items = new List<Make> {
                            new Make{
                             href = "https://api.manheim.com/valuations/years/2005/makes/ACURA?country=US",
                             make = "ACURA",
                             models = null
                            },
                            new Make{
                             href = "https://api.manheim.com/valuations/years/2005/makes/ASTON%20MARTIN?country=US",
                             make = "ASTON MARTIN",
                             models = null
                            }
                },

            };

            models = new Models
            {
                count = 2,
                href = "https://api.manheim.com/valuations/years/2005/makes/ACURA/models?country=US&orderBy=model+asc",
                items = new List<Model>
                {
                    new Model
                    {
                        href="https://api.manheim.com/valuations/years/2005/makes/ACURA/models/MDX?country=US",
                        model="MDX",
                        trims= null
                    },
                    new Model
                    {
                        href="https://api.manheim.com/valuations/years/2005/makes/ACURA/models/NSX?country=US",
                        model="NSX",
                        trims= null
                    }
                }

            };

            trims = new Trims
            {
                count = 2,
                href = "https://api.manheim.com/valuations/years/2005/makes/ACURA/models/MDX/trims?country=US&orderBy=trim+asc",
                items = new List<Trim>
                {
                    new Trim
                    {
                        href="https://api.manheim.com/valuations/years/2005/makes/ACURA/models/MDX/trims/4D%20SUV?country=US",
                        trim="4D SUV"
                    },
                    new Trim
                    {
                        href="https://api.manheim.com/valuations/years/2005/makes/ACURA/models/MDX/trims/4D%20SUV%20TOURING?country=US",
                        trim="4D SUV TOURING"
                    }
                }
            };

            bookValuationRequest = new ManheimBookValuationRequest
            {
                vehicleIdentity = new DomailModels.Common.VehicleIdentity
                {
                    VID = 4311075,
                    SID = 101,
                    IID = 1,
                    CID = DomailModels.Enums.Company.SU
                },
                Mileage = 10000,
                color = "White",
                Region = "WC",
                VIN = "WP0CA299X3S627000"
            };

            vinVehicleDetail = new VinVehicleDetail
            {
                count = 2,
                href = "https://api.manheim.com/valuations/vin/WP0CA299X3S627000?country=US&odometer=0&region=WC",
                items = new List<VinVehicle>
                {
                    new VinVehicle
                    {
                        description = new Description
                        {
                            make = "PORSCHE",
                            model = "911 CARRERA AWD",
                            subSeries="CARRERA 4",
                            trim="2D CONVERTIBLE",
                            year=2003
                        },
                        href ="https://api.manheim.com/valuations/id/200304458070406?country=US&odometer=10000&region=WC",
                        wholesale = new Wholesale
                        {
                            above=1000,
                            average=750,
                            below=500
                        },
                        adjustedPricing = new AdjustedPricing
                        {
                            wholesale = new Wholesale
                            {
                                above=1000,
                                below=500,
                                average=750
                            }
                        },
                        averageOdometer=8000,
                        averageGrade = 19
                    },
                    new VinVehicle
                    {
                        description = new Description
                        {
                            make = "PORSCHE",
                            model = "911 CARRERA 2WD",
                            subSeries="CARRERA 2",
                            trim="2D CONVERTIBLE",
                            year=2003
                        },
                        href="https://api.manheim.com/valuations/id/200304458080406?country=US&odometer=10000&region=WC",
                        wholesale = new Wholesale
                        {
                            above=1000,
                            average=750,
                            below=500
                        },
                        adjustedPricing = new AdjustedPricing
                        {
                            wholesale = new Wholesale
                            {
                                above=1000,
                                below=500,
                                average=750
                            }
                        },
                        averageOdometer=8000,
                        averageGrade = 19
                    }
                }
            };

            bookValuation = new DomainModels.Books.Common.BookValuation
            {
                BookId = 123,
                Year = new DomainModels.Common.IDValues { ID = "2003", Value = "2003" },
                Make = new DomainModels.Common.IDValues { ID = "PORSCHE", Value = "PORSCHE" },
                Model = new DomainModels.Common.IDValues { ID = "911 CARRERA 2WD", Value = "911 CARRERA 2WD" },
                BodyStyle = new DomainModels.Common.IDValues { ID = "2D CONVERTIBLE", Value = "2D CONVERTIBLE" },
                UVC = "2343"
            };
        }

        [Fact]
        public void GetTransactionData_Returns_Transactions()
        {
            manheimServiceMock.Setup(p => p.GetTransactionData(manheim_Id, region)).Returns(manheimTransactionDatas);
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var transactions = manheimLogic.GetTransactionData(manheim_Id, region);
            Assert.Equal(manheimTransactionDatas, transactions);
        }

        [Fact]
        public void GetFullTransactionData_Returns_Transactions()
        {
            manheimServiceMock.Setup(p => p.GetFullTransactionData(manheim_Id, region)).Returns(transaction);
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var fullTransactions = manheimLogic.GetFullTransactionData(manheim_Id, region);
            Assert.Equal(transaction, fullTransactions);
        }

        [Fact]
        public void GetLocationDetails_Returns_Location()
        {
            LocationDetails locationDetails = new LocationDetails
            {
                locationName = "abc",
                locationCode = "abc",
                locationType = "abc",
                locationActive = true,
                timeZone = "GMT"
            };
            manheimServiceMock.Setup(p => p.GetLocationDetails("23")).Returns(locationDetails);
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var locationDetail = manheimLogic.GetLocationDetails("23");
            Assert.Equal(locationDetails, locationDetail);
        }

        [Fact]
        public void GetMakes_Returns_Makes()
        {
            manheimServiceMock.Setup(p => p.GetMakes("2005")).Returns(makes);
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var make = manheimLogic.GetMakes("2005");
            Assert.True(make.Count == 2);
        }

        [Fact]
        public void GetMakes_Returns_Models()
        {
            manheimServiceMock.Setup(p => p.GetModels("2005", "ACURA")).Returns(models);
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var model = manheimLogic.GetModels("2005", "ACURA");
            Assert.True(model.Count == 2);
        }

        [Fact]
        public void GetTrims_Returns_Trims()
        {
            manheimServiceMock.Setup(p => p.GetTrims("2005", "ACURA", "MDX")).Returns(trims);
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var trim = manheimLogic.GetTrims("2005", "ACURA", "MDX");
            Assert.True(trim.Count == 2);
        }

        [Fact]
        public void GetBookValution_Returns_BookValuation()
        {
            manheimServiceMock.Setup(p => p.GetDecodedVin("WP0CA299X3S627000", "WC", 10000)).Returns(vinVehicleDetail);
            booksCommonLogicMock.Setup(p => p.GetManheimSavedBooks(4311075, 101, 1, "WC", "White", 10000)).Returns(new DomainModels.Books.Common.BookValuation());
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var manheimBookValuation = manheimLogic.GetBookValution(bookValuationRequest, false);
            Assert.True(manheimBookValuation.Year.Count > 0 && manheimBookValuation.Make.Count > 0 && manheimBookValuation.Model.Count > 0 && manheimBookValuation.Trim.Count > 0);
        }

        [Fact]
        public void GetBookValution_Returns_SavedBookValuation()
        {
            manheimServiceMock.Setup(p => p.GetDecodedVin("WP0CA299X3S627000", "WC", 10000)).Returns(vinVehicleDetail);
            manheimServiceMock.Setup(p => p.GetBookValue("2003", "PORSCHE", "911 CARRERA 2WD", 10000, "WC", "White")).Returns(vinVehicleDetail);
            booksCommonLogicMock.Setup(p => p.GetManheimSavedBooks(4311075, 101, 1, "WC", "White", 10000)).Returns(bookValuation);            
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var manheimBookValuation = manheimLogic.GetBookValution(bookValuationRequest, true);
            Assert.True(manheimBookValuation.Year.Count > 0 && manheimBookValuation.Make.Count > 0 && manheimBookValuation.Model.Count > 0 && manheimBookValuation.Trim.Count > 0);
        }

        [Fact]
        public void GetDecodedVin_Returns_VehicleDetails()
        {
            manheimServiceMock.Setup(p => p.GetDecodedVin("WP0CA299X3S627000", "WC", 10000)).Returns(vinVehicleDetail);
            booksCommonLogicMock.Setup(p => p.GetManheimSavedBooks(4311075, 101, 1, "WC", "White", 10000)).Returns(new DomainModels.Books.Common.BookValuation());
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var manheimDecode = manheimLogic.GetDecodedVin("WP0CA299X3S627000", "WC", 10000);
            Assert.True(manheimDecode.Year.Count > 0 && manheimDecode.Make.Count > 0 && manheimDecode.Model.Count > 0 && manheimDecode.Trim.Count > 0);
        }

        [Fact]
        public void GetBookValue_Returns_BookValue()
        {
            manheimServiceMock.Setup(p => p.GetBookValue("WP0CA299X3S627000", "WC", 10000, "White")).Returns(vinVehicleDetail);
            booksCommonLogicMock.Setup(p => p.GetManheimSavedBooks(4311075, 101, 1, "WC", "White", 10000)).Returns(new DomainModels.Books.Common.BookValuation());
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var vinVehicleDetails = manheimLogic.GetBookValue("WP0CA299X3S627000", "WC", 10000, "White");
            Assert.True(vinVehicleDetails.items.Count > 0);
        }

        [Fact]
        public void GetBookValue_Returns_BookValues()
        {
            manheimServiceMock.Setup(p => p.GetBookValue("2003", "PORSCHE", "911 CARRERA AWD", 10000, "WC", "White")).Returns(vinVehicleDetail);
            booksCommonLogicMock.Setup(p => p.GetManheimSavedBooks(4311075, 101, 1, "WC", "White", 10000)).Returns(new DomainModels.Books.Common.BookValuation());
            IManheimLogic manheimLogic = new ManheimLogic(manheimServiceMock.Object, booksCommonLogicMock.Object);
            var vinVehicleDetails = manheimLogic.GetBookValue("2003", "PORSCHE", "911 CARRERA AWD", "2D CONVERTIBLE", 10000, "WC", "White");
            Assert.True(vinVehicleDetails.WholeSaleAbove == 1000);
        }
    }
}
