﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Books;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomailModels.Common;
using Sonic.OneSIMS.DomainModels.Books;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Books
{
    public class ManagerNotesLogicTest
    {
        private Mock<IManagerNotesLogic> managerNotesLogicMock;
        private Mock<IManagerNotesRepository> managerNotesRepositoryMock;
        private VehicleIdentity vehicleIdentity;
        private ManagerNotes managerNotes;

        public ManagerNotesLogicTest()
        {
            managerNotesLogicMock = new Mock<IManagerNotesLogic>();
            managerNotesRepositoryMock = new Mock<IManagerNotesRepository>();
            vehicleIdentity = new VehicleIdentity
            { 
                VID = 1,
                SID = 1,
                IID = 1,
                CID = DomailModels.Enums.Company.SU
            };

            managerNotes = new ManagerNotes
            {
                vid = 1,
                sid = 1,
                iid = 1,
                CID = 10,
                Aditionalamount=100,
                Comments = "Test"                
            };
        }
        
        [Fact]
        public void GetManagerNotes_Returns_Comments()
        {
            managerNotesRepositoryMock.Setup(p => p.GetManagerNotes(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID))).Returns(managerNotes);
            IManagerNotesLogic managerNotesLogic = new ManagerNotesLogic(managerNotesRepositoryMock.Object);
            var result = managerNotesLogic.GetManagerNotes(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID));
            Assert.Equal(managerNotes.Comments, result.Comments);
        }

        [Fact]
        public void AddManagerNotes_Returns_Comments()
        {
            managerNotesRepositoryMock.Setup(p => p.AddManagerNotes(managerNotes)).Returns(managerNotes);
            IManagerNotesLogic managerNotesLogic = new ManagerNotesLogic(managerNotesRepositoryMock.Object);
            var result = managerNotesLogic.AddManagerNotes(managerNotes);
            Assert.Equal(managerNotes.Comments, result.Comments);
        }
    }
}
