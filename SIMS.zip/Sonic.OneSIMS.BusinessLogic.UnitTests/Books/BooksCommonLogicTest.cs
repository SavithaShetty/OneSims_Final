﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Books;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomailModels.Common;
using Sonic.OneSIMS.DomailModels.Settings;
using Sonic.OneSIMS.Infrastructure.Cdk;
using Sonic.OneSIMS.Infrastructure.Manheim;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.DecodeVin;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Books
{
    public class BooksCommonLogicTest
    {
        private Mock<IBooksCommonRepository> booksCommonRepositoryMock;
        private Mock<IManheimService> manheimServiceMock;
        private Mock<IBooksCommonLogic> booksCommonLogicMock;
        private Mock<IValuationService> valuationServiceMock;

        private BooksConfiguration booksConfiguration;
        private Dictionary<string, string> adpDealerRegionIds;
        private DomainModels.Books.Common.BookValuation bookValuation;
        private VehicleIdentity vehicleIdentity;
        private VinVehicleDetail vinVehicleDetail;

        public BooksCommonLogicTest()
        {
            booksCommonRepositoryMock = new Mock<IBooksCommonRepository>();
            manheimServiceMock = new Mock<IManheimService>();
            booksCommonLogicMock = new Mock<IBooksCommonLogic>();
            valuationServiceMock = new Mock<IValuationService>();

            bookValuation = new DomainModels.Books.Common.BookValuation
            {
                Year = new DomainModels.Common.IDValues { ID = "2008", Value = "2008" },
                Make = new DomainModels.Common.IDValues { ID = "BMW", Value = "32" },
                Model = new DomainModels.Common.IDValues { ID = "X3", Value = "15" },
                Trim = new DomainModels.Common.IDValues { ID = "Premium", Value = "3444" },
                BodyStyle = new DomainModels.Common.IDValues { ID = "Premium", Value = "3444" },
                BookValue = new DomainModels.Books.Common.BookValue
                {
                    WholeSaleAbove = 4950,
                    WholeSaleAverage = 3850,
                    WholeSaleBelow = 2775,
                    NationalAbove = 9000,
                    NationalAverage = 7875,
                    NationalBelow = 6725,
                    AverageOdometer = 144725,
                    AverageGrade = 24,
                    ManheimRegion = "RE"

                },
                UVC = "200806957591144"
            };

            vehicleIdentity = new VehicleIdentity();
            booksConfiguration = new BooksConfiguration
            {
                RequiredBookIds = new List<int> { 1, 2, 3, 4 },
                SetupBookIds = new List<int> { 1, 2, 3, 4 }
            };

            adpDealerRegionIds = new Dictionary<string, string>
            {
                { "ADPDealerID", "10" },
                { "ADPRegionID", "20" },
                { "BlackBookRegionID", "30" },
                { "NADARegionID", "40" },
                { "KBBRegionID", "50" }
            };

            vinVehicleDetail = new VinVehicleDetail
            {
                count = 1,
                href = "https://api.manheim.com/valuations/vin/JN1CA21A1WM807595?country=US&odometer=12345&color=Red",
                items = new List<VinVehicle>
                {
                    new VinVehicle{
                        description = new Description{year=2008,make="BMW",model="X3",subSeries="Premium",trim="Premium" },
                        wholesale = new Wholesale{above=4950,average=3850,below=2775 },
                        adjustedPricing = new AdjustedPricing
                        {
                            wholesale=new Wholesale{ above=9000,average=7875,below=6725}
                        },
                        averageOdometer=144725,
                        averageGrade=24,
                        href ="https://api.manheim.com/valuations/id/199805502960086?country=US&odometer=12345&color=Red"

                    }
                }
            };
        }

        [Fact]
        public void GetAllRequiredBooks_Returns_BookIds()
        {
            booksCommonRepositoryMock.Setup(p => p.GetAllRequiredBooks(101)).Returns(booksConfiguration);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetAllRequiredBooks(101);
            Assert.True(result.RequiredBookIds.Count > 0 && result.SetupBookIds.Count > 0);
        }

        [Fact]
        public void GetADPDealerAndRegionID_Returns_List()
        {
            booksCommonRepositoryMock.Setup(p => p.GetADPDealerAndRegionID(101, 0)).Returns(adpDealerRegionIds);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetADPDealerAndRegionID(101, 0);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetManheimRegionID_Returns_Id()
        {
            booksCommonRepositoryMock.Setup(p => p.GetManheimRegionID(101, 0)).Returns("60");
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetManheimRegionID(101, 0);
            Assert.Equal("60", result);
        }

        [Fact]
        public void SaveBBBooks_Returns_True()
        {
            booksCommonRepositoryMock.Setup(p => p.SaveBookValues(bookValuation, vehicleIdentity, "ABC", "test")).Returns(true);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.SaveBBBooks(bookValuation, vehicleIdentity, "ABC", "test");
            Assert.True(result);
        }

        [Fact]
        public void SaveNADABooks_Returns_True()
        {
            booksCommonRepositoryMock.Setup(p => p.SaveBookValues(bookValuation, vehicleIdentity, "ABC", "test")).Returns(true);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.SaveNADABooks(bookValuation, vehicleIdentity, "ABC", "test");
            Assert.True(result);
        }

        [Fact]
        public void SaveKBBBooks_Returns_True()
        {
            booksCommonRepositoryMock.Setup(p => p.SaveBookValues(bookValuation, vehicleIdentity, "ABC", "test")).Returns(true);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.SaveKBBBooks(bookValuation, vehicleIdentity, "ABC", "test");
            Assert.True(result);
        }

        [Fact]
        public void SaveManheimBooks_Returns_True()
        {
            booksCommonRepositoryMock.Setup(p => p.SaveBookValues(bookValuation, vehicleIdentity, "ABC", "test")).Returns(true);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.SaveManheimBooks(bookValuation, vehicleIdentity, "ABC", "test");
            Assert.True(result);
        }

        [Fact]
        public void GetBBSavedBooks_Returns_BookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 30)).Returns(bookValuation);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetBBSavedBooks(1, 1, 1);
            Assert.Equal(bookValuation, result);
        }

        [Fact]
        public void GetNADASavedBooks_Returns_BookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 10)).Returns(bookValuation);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetNADASavedBooks(1, 1, 1);
            Assert.Equal(bookValuation, result);
        }

        [Fact]
        public void GetKBBSavedBooks_Returns_BookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 20)).Returns(bookValuation);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetKBBSavedBooks(1, 1, 1);
            Assert.Equal(bookValuation, result);
        }

        [Fact]
        public void GetManheimSavedBooks_Returns_BookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 40)).Returns(bookValuation);
            manheimServiceMock.Setup(p => p.GetBookValue(bookValuation.Year.ID, bookValuation.Make.ID, bookValuation.Model.ID, 12345, "RE", "Red")).Returns(vinVehicleDetail);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetManheimSavedBooks(1, 1, 1, "RE", "Red", 12345);
            Assert.Equal(bookValuation, result);
        }

        [Fact]
        public void GetSavedBooks_Returns_NADABookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 10)).Returns(bookValuation);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetSavedBooks(1, 1, 1, "", "RE", "Red", 12345, 10);
            Assert.Equal(bookValuation, result.NADA);
        }

        [Fact]
        public void GetSavedBooks_Returns_BBBookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 30)).Returns(bookValuation);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetSavedBooks(1, 1, 1, "", "RE", "Red", 12345, 30);
            Assert.Equal(bookValuation, result.BlackBook);
        }

        [Fact]
        public void GetSavedBooks_Returns_KBBBookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 20)).Returns(bookValuation);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetSavedBooks(1, 1, 1, "", "RE", "Red", 12345, 20);
            Assert.Equal(bookValuation, result.KBB);
        }

        [Fact]
        public void GetSavedBooks_Returns_ManheimBookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 40)).Returns(bookValuation);
            manheimServiceMock.Setup(p => p.GetBookValue(bookValuation.Year.ID, bookValuation.Make.ID, bookValuation.Model.ID, 12345, "RE", "Red")).Returns(vinVehicleDetail);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetSavedBooks(1, 1, 1, "", "RE", "Red", 12345, 40);
            Assert.Equal(bookValuation, result.Manheim);
        }

        [Fact]
        public void GetSavedBooks_Returns_DefaultBookValue()
        {
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 10)).Returns(bookValuation);
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 20)).Returns(bookValuation);
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 30)).Returns(bookValuation);
            booksCommonRepositoryMock.Setup(p => p.GetSavedBookDetails(1, 1, 1, 40)).Returns(bookValuation);
            manheimServiceMock.Setup(p => p.GetBookValue(bookValuation.Year.ID, bookValuation.Make.ID, bookValuation.Model.ID, 12345, "RE", "Red")).Returns(vinVehicleDetail);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.GetSavedBooks(1, 1, 1, "", "RE", "Red", 12345, 0);
            Assert.True(result.Manheim != null && result.NADA != null && result.BlackBook != null && result.KBB != null);
        }

        [Fact]
        public void SaveBooks_Returns_True()
        {
            booksCommonRepositoryMock.Setup(p => p.SaveBookValues(bookValuation, vehicleIdentity, "ABC", "test")).Returns(true);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.SaveBooks(new DomainModels.Books.Common.Books { BlackBook = bookValuation, KBB = bookValuation, NADA = bookValuation, Manheim = bookValuation, UserName = "test", Vin = "ABC" });
            Assert.True(result);
        }

        [Fact]
        public void SaveBooks_Returns_False()
        {
            booksCommonRepositoryMock.Setup(p => p.SaveBookValues(bookValuation, vehicleIdentity, "ABC", "test")).Returns(true);
            IBooksCommonLogic booksCommonLogic = new BooksCommonLogic(booksCommonRepositoryMock.Object, manheimServiceMock.Object, valuationServiceMock.Object);
            var result = booksCommonLogic.SaveBooks(null);
            Assert.False(result);
        }

    }
}
