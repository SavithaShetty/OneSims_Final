﻿using Moq;
using Newtonsoft.Json;
using Sonic.OneSIMS.BusinessLogic.Books;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Books.KBB;
using Sonic.OneSIMS.Infrastructure.KBB;
using Sonic.OneSIMS.Infrastructure.KBB.Entities;
using System.Collections.Generic;
using System.Linq;
using Xunit;


namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Books
{
    public class KBBBooksLogicTest
    {
        private Mock<IKBBService> kbbServiceMock;
        private BookRequest bookRequest;
        private ConfigValues configValues;
        private BookResponse bookResponse;
        private List<Year> years;
        private string makesList;
        private VehicleConfigurationValues vehConfiguration;
        private VehicleValuationModel vehicleValuationModel;
        private ConfiguredOptionValuationModel[] configuredOptionValuationModels;

        public KBBBooksLogicTest()
        {
            kbbServiceMock = new Mock<IKBBService>();

            configuredOptionValuationModels = new ConfiguredOptionValuationModel[]
            {
                new ConfiguredOptionValuationModel{Id=1,DisplayName="test1",PriceType= PriceTypeValues.BaseWholesale,IsDefaultConfiguration=true,IsSelected=true,PriceAdjustment=23 },
                new ConfiguredOptionValuationModel{Id=2,DisplayName="test2",PriceType= PriceTypeValues.BaseRetail,IsDefaultConfiguration=true,IsSelected=false,PriceAdjustment=23 }
            };
            bookRequest = new BookRequest
            {
                dealerId = "",
                regionId = "",
                valuationData = new ValuationData
                {

                }
            };

            bookResponse = new BookResponse
            {

            };

            configValues = new ConfigValues
            {
                AuthPWD = "test",
                AuthUserName = "test",
                MediaType = "application/json",
                baseURL = "https://ase-v4-onesimsapiapp-02.azurewebsites.net/kbb/api/v1/KBB/"
            };

            years = new List<Year>
            {
                new Year{yearId = 2024},
                new Year{yearId = 2023},
                new Year{yearId = 2022},
                new Year{yearId = 2021}
            };

            makesList = JsonConvert.SerializeObject(
                new List<Make> {
                new Make
                {
                    makeId = 12,
                    makeName = "ACURA"
                },
                new Make
                {
                    makeId = 15,
                    makeName = "PORSCHE"
                }
                }
                );

            vehConfiguration = new VehicleConfigurationValues
            {
                Id = 1,
                Make = new IdStringPairValues { Id = 1, Value = "MakeTest" },
                Model = new IdStringPairValues { Id = 1, Value = "ModelTest" },
                Mileage = 1000,
                VIN = "ABC",
                Year = new IdStringPairValues { Id = 2008, Value = "2008" }
            };
            vehicleValuationModel = new VehicleValuationModel
            {
                IsInsufficientMarketData = false,
                IsLimitedProduction = true,
                MileageAdjustment = 300,
                MileageZeroPoint = 10,
                OptionAdjustment = 10,
                ValuationZipCode = "ZA333",
                ValuationPrices = new ValuationValues[] {
                    new ValuationValues {
                        Id=1,
                        Value=1333,
                        IsMaxDeductApplied=true,
                        KBB4PriceType= KBB4PriceType.BaseWholesale,
                        MileageAdjustment=300,
                        OptionAdjustment = 10,
                        optionPrices = new OptionPrices[]{ new OptionPrices { price=111,removalAdjustment=false,vehicleOptionId=22} },
                        PriceType = PriceTypeValues.BaseRetail,
                        PriceTypeId = 134
                    }
                }
            };
        }

        [Fact]
        public void GetYears_Returns_List()
        {
            kbbServiceMock.Setup(p => p.GetYearsList(configValues)).Returns(years);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var year = kbbBookLogic.GetYearsList(configValues);
            Assert.True(year.Count() > 0);
        }

        [Fact]
        public void GetMakes_Returns_List()
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = 2009;
            kbbServiceMock.Setup(p => p.GetKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Make)).Returns(makesList);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var make = kbbBookLogic.GetMakesKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Make);
            Assert.True(make.Count() > 0);
        }

        [Fact]
        public void GetModels_Returns_List()
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = 2009;
            inputParams.makeid = 123;
            kbbServiceMock.Setup(p => p.GetKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Model)).Returns(makesList);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var model = kbbBookLogic.GetModelsKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Model);
            Assert.True(model.Count() > 0);
        }

        [Fact]
        public void GetTrims_Returns_List()
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = 2009;
            inputParams.makeid = 123;
            inputParams.modelId = 456;
            kbbServiceMock.Setup(p => p.GetKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Trim)).Returns(makesList);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var trim = kbbBookLogic.GetTrimsKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Trim);
            Assert.True(trim.Count() > 0);
        }

        [Fact]
        public void GetBookValues_Returns_Books()
        {
            kbbServiceMock.Setup(p => p.GetBookValues(bookRequest, configValues)).Returns(bookResponse);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var bookResponses = kbbBookLogic.GetBookValues(bookRequest, configValues);
            Assert.Equal(bookResponses, bookResponse);
        }

        [Fact]
        public void GetBookValues_Returns_VehicleValuation()
        {
            kbbServiceMock.Setup(p => p.GetBookValues(bookRequest, configValues, vehConfiguration)).Returns(vehicleValuationModel);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var vehicleValuation = kbbBookLogic.GetBookValues(bookRequest, configValues, vehConfiguration);
            Assert.Equal(vehicleValuationModel, vehicleValuation);
        }

        [Fact]
        public void MergeBookValues_Returns_BookResponse()
        {
            kbbServiceMock.Setup(p => p.MergeBookValues(bookResponse, configuredOptionValuationModels, configuredOptionValuationModels, configuredOptionValuationModels, configuredOptionValuationModels, configuredOptionValuationModels)).Returns(bookResponse);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var vehicleValuation = kbbBookLogic.MergeBookValues(bookResponse, configuredOptionValuationModels, configuredOptionValuationModels, configuredOptionValuationModels, configuredOptionValuationModels, configuredOptionValuationModels);
            Assert.Equal(bookResponse, vehicleValuation);
        }

        [Fact]
        public void ParseBookValue_Returns_BookResponse()
        {
            kbbServiceMock.Setup(p => p.ParseBookValue(vehicleValuationModel)).Returns(bookResponse);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var vehicleValuation = kbbBookLogic.ParseBookValue(vehicleValuationModel);
            Assert.Equal(bookResponse, vehicleValuation);
        }

        [Fact]
        public void GetKBBEndpointResult_Returns_Object()
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = 2009;
            object obj = new object();
            kbbServiceMock.Setup(p => p.GetKBBEndpointResult(configValues, inputParams,KBBRestEndpoints.Year)).Returns(obj);
            IKBBBookLogic kbbBookLogic = new KBBBooksLogic(kbbServiceMock.Object);
            var vehicleValuation = kbbBookLogic.GetKBBEndpointResult(configValues, inputParams, KBBRestEndpoints.Year);
            Assert.Equal(obj, vehicleValuation);
        }
    }
}
