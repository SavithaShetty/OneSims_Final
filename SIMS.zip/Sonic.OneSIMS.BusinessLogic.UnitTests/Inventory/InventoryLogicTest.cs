﻿using Microsoft.Extensions.Options;
using Moq;
using Sonic.OneSIMS.Api.DTOs.Inventory;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Inventory;
using Sonic.OneSIMS.BusinessLogic.Inventory;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Inventory;
using Sonic.OneSIMS.DomailModels.Enums;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Enums;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.Infrastructure.Chrome;
using Sonic.OneSIMS.Infrastructure.Chrome.Entities;
using System;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Inventory
{
    public class InventoryLogicTest
    {
        private Mock<IInventoryRepository> InventorygRepositoryMock;
        private Mock<IVehicleInfoRepository> VehicleInfoRepositoryMock;
        private Mock<IChromeService> chromeServiceMock;
        private Mock<IOptions<Framework.Configuration.Settings>> settingsMock;


        private BasicInvAddVehicle basicInvAddVehicleinfo;
        private VinExistsDetails vinExistsDetailsCompletedInv, vinExistsDetailsPendingInv, vinExistsDetailsCompltedApsl, vinExistsDetailsPendingApsl, vinExistsDetails;
        private ChromeDecodeInfo  chromeDecodefail;
        long VID = 4310978;
        string decodefailMessage = "The VIN provided has failed to decode.  Do you want to proceed anyway?";
        string message = "Vehicle Added Successfully";
        short SID = 101;short IID = 1; short CID = 10;
        private List<StatusChangehistory> statusChangehistory;
        private List<MarketReadyHistory> marketReadyHistory;
        private List<PriceChangeHistory> priceChangehistory;

        public InventoryLogicTest()
        {
            InventorygRepositoryMock = new Mock<IInventoryRepository>();
            VehicleInfoRepositoryMock = new Mock<IVehicleInfoRepository>();
            chromeServiceMock = new Mock<IChromeService>();
            settingsMock = new Mock<IOptions<Framework.Configuration.Settings>>();

            chromeDecodefail = new ChromeDecodeInfo();

            basicInvAddVehicleinfo = new BasicInvAddVehicle
            {
                VIN = "19VDE1F53DE010359",
                CID = Company.SU,
                srcname = "Test",
                VehicleSrc = VehicleSource.ManualInventory,
                StoreID = 101,
                username = "test",
                IsDecodeSuccess = true
            };
            //---Completed Inventory
            vinExistsDetailsCompletedInv = new VinExistsDetails
            {
                VIN = "19VDE1F53DE010359",
                CID = 10,
                VID = 4310978,
                SID = 101,
                IID = 1,
                VehicleInStatus = "201",
                WizardPage = 5,
                StoreName = "Acura of Serramonte",
                isccaVehicle = false
            };
            //---Inventory pending
            vinExistsDetailsPendingInv = new VinExistsDetails
            {
                VIN = "19VDE1F53DE010359",
                CID = 10,
                VID = 4310978,
                SID = 101,
                IID = 1,
                VehicleInStatus = "201",
                WizardPage = 3,
                StoreName = "Acura of Serramonte",
                isccaVehicle = false
            };
            //---Completed Apparaisal
            vinExistsDetailsCompltedApsl = new VinExistsDetails
            {
                VIN = "19VDE1F53DE010359",
                CID = 10,
                VID = 4310978,
                SID = 101,
                IID = 1,
                VehicleInStatus = "102",
                WizardPage = 5,
                StoreName = "Acura of Serramonte",
                isccaVehicle = false
            };
            //---pending appraisal
            vinExistsDetailsPendingApsl = new VinExistsDetails
            {
                VIN = "19VDE1F53DE010359",
                CID = 10,
                VID = 4310978,
                SID = 101,
                IID = 1,
                VehicleInStatus = "101",
                WizardPage = 4,
                StoreName = "Acura of Serramonte",
                isccaVehicle = false
            };
            //Not exits
            vinExistsDetails = new VinExistsDetails
            {
                VIN = "19VDE1F53DE010359",
                CID = 0,
                VID = 0,
                SID = 0,
                IID = 0,
                VehicleInStatus = null,
                WizardPage = 0,
                StoreName = null,
                isccaVehicle = false
            };

          //status change history

            statusChangehistory = new List<StatusChangehistory>
            {
                new StatusChangehistory
                {
                user = "test",
                oldstatus = "IT",
                newstatus = "IS",
                datetime = DateTime.Now,
                remarks = "test test"
                },
                 new StatusChangehistory
                {
                user = "test",
                oldstatus = "IT",
                newstatus = "IS",
                datetime = DateTime.Now,
                remarks = "test test"
                }

            };
            //Market Ready history
            marketReadyHistory = new List<MarketReadyHistory>
            {
                new MarketReadyHistory
                {
                changedate = DateTime.Now,
                previousmrflag = "True",
                currentmrflag = "False",
                modifiedfrom = "ActionMenu",
                changedby = "Savitha.Ramanatha"
                },
                 new MarketReadyHistory
                {
                changedate = DateTime.Now,
                previousmrflag = "False",
                currentmrflag = "True",
                modifiedfrom = "ActionMenu",
                changedby = "Savitha.Ramanatha"
                }

            };

            //price change history

            priceChangehistory = new List<PriceChangeHistory>
            {
                new PriceChangeHistory
                {
                age = 10,
                groupage = 10,
                retailprice = 9000,
                suggestedprice = 0,
                changedby = "Ayman.Sana"
                },
                 new PriceChangeHistory
                {
                age = 10,
                groupage = 10,
                retailprice = 0,
                suggestedprice = 0,
                changedby = "Raju.Mahesh"
                }

            };

        }


        //----New ViN decode failure
        [Fact]
        public void InvAddVehicle_DecodeFail_Returnd_result()
        {
            VehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicInvAddVehicleinfo.VIN, basicInvAddVehicleinfo.StoreID, false)).Returns(vinExistsDetails);
            chromeServiceMock.Setup(p => p.GetDecodeVIN(basicInvAddVehicleinfo.VIN)).Returns(chromeDecodefail);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object,  chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.InvAddVehicle(basicInvAddVehicleinfo);
            Assert.True(result.CreationStatus == AppraisalCreationStatus.InventoryDecodeFailure && result.Message == decodefailMessage && result.VID == 0);
        }

        //----Vin exits as pending Apptaisal 
        [Fact]
        public void InvAddVehicle_ExistingApsl_Pending_Returnd_result()
        {
            VehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicInvAddVehicleinfo.VIN, basicInvAddVehicleinfo.StoreID, false)).Returns(vinExistsDetailsPendingApsl);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object,  chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.InvAddVehicle(basicInvAddVehicleinfo);
            Assert.True(result.CreationStatus == AppraisalCreationStatus.InvAppraisalPendingVehicleExists && result.VID == VID);
        }

        //----Vin exits as Completed Apptaisal 
        [Fact]
        public void InvAddVehicle_ExistingApsl_Completed_Returnd_result()
        {
            VehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicInvAddVehicleinfo.VIN, basicInvAddVehicleinfo.StoreID, false)).Returns(vinExistsDetailsCompltedApsl);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object,  chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.InvAddVehicle(basicInvAddVehicleinfo);
            Assert.True(result.CreationStatus == AppraisalCreationStatus.InvAppraisalCompletedVehicleExists && result.VID == VID);
        }

        //----Vin exits as Pending Inventory 
        [Fact]
        public void InvAddVehicle_ExistingInv_Pending_Returnd_result()
        {
            VehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicInvAddVehicleinfo.VIN, basicInvAddVehicleinfo.StoreID, false)).Returns(vinExistsDetailsPendingInv);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object,  chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.InvAddVehicle(basicInvAddVehicleinfo);
            Assert.True(result.CreationStatus == AppraisalCreationStatus.InventoryPendingVehicleExists && result.VID == VID);
        }


        //----Vin exits as Completed Inventory 
        [Fact]
        public void InvAddVehicle_ExistingInv_Complete_Returnd_result()
        {
            VehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicInvAddVehicleinfo.VIN, basicInvAddVehicleinfo.StoreID, false)).Returns(vinExistsDetailsCompletedInv);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.InvAddVehicle(basicInvAddVehicleinfo);
            Assert.True(result.CreationStatus == AppraisalCreationStatus.InventoryCompletedVehicleExists && result.VID == VID);
        }

        //Vehicle status change History
        [Fact]
        public void VehicleStatusChangeHistory_Returnd_result()
        {
            InventorygRepositoryMock.Setup(p => p.VehicleStatusChangeHistory(VID, SID, IID, CID)).Returns(statusChangehistory);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.VehicleStatusChangeHistory(VID,SID,IID,CID);
            Assert.True(result.Count>0);
        }
        [Fact]
        public void VehicleStatusChangeHistory_Returnd_Empty()
        {
            InventorygRepositoryMock.Setup(p => p.VehicleStatusChangeHistory(VID, SID, IID, CID)).Returns(new List<StatusChangehistory>());
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.VehicleStatusChangeHistory(VID, SID, IID, CID);
            Assert.True(result.Count==0);
        }

//Market Ready history
        [Fact]
        public void MarketReadyHistory_Returnd_result()
        {
            InventorygRepositoryMock.Setup(p => p.MarketReadyHistory(VID, SID, IID, CID)).Returns(marketReadyHistory);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.MarketReadyHistory(VID, SID, IID, CID);
            Assert.True(result.Count > 0);
        }
        [Fact]
        public void MarketReadyHistory_Returnd_Empty()
        {
            InventorygRepositoryMock.Setup(p => p.MarketReadyHistory(VID, SID, IID, CID)).Returns(new List<MarketReadyHistory>());
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.MarketReadyHistory(VID, SID, IID, CID);
            Assert.True(result.Count == 0);
        }

        //Price change History
        [Fact]
        public void PriceChangeHistory_Returnd_result()
        {
            InventorygRepositoryMock.Setup(p => p.PriceChangeHistory(VID, SID, IID, CID)).Returns(priceChangehistory);
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.PriceChangeHistory(VID, SID, IID, CID);
            Assert.True(result.Count > 0);
        }
        [Fact]
        public void PriceChangeHistory_Returnd_Empty()
        {
            InventorygRepositoryMock.Setup(p => p.PriceChangeHistory(VID, SID, IID, CID)).Returns(new List<PriceChangeHistory>());
            IInventoryLogic inventoryLogic = new InventoryLogic(InventorygRepositoryMock.Object, settingsMock
            .Object, chromeServiceMock.Object, VehicleInfoRepositoryMock.Object);
            var result = inventoryLogic.PriceChangeHistory(VID, SID, IID, CID);
            Assert.True(result.Count == 0);
        }

    }
}
