﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Inventory;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.DomainModels.Pricing;
using Sonic.OneSIMS.Infrastructure.Cdk;
using System;
using System.Collections.Generic;
using Xunit;
using ROPO = Sonic.OneSIMS.Infrastructure.Cdk.Entities.ROPO;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Inventory
{
    public class InventoryPricingLogicTest
    {
        private Mock<IInventoryPricingRepository> inventoryPricingRepositoryMock;
        private Mock<IVehicleInvService> vehicleInvServiceMock;
        private Mock<IInventoryPricingLogic> inventoryPricingLogicMock;
        private List<ROPO> rOPOs;
        private List<ROPO> rOPOs1;
        private ROPORequest rOPORequest;
        private PriceReviewLogParams priceReviewLogParams;
        private PriceReviewLockedDetails priceReviewLockDetails;
        private List<PriceReviewLogData> priceReviewLogData;
        private List<PriceReviewHistory> priceReviewHistories;
        private string username;
        private int pricereviewlogid;

        public InventoryPricingLogicTest()
        {
            inventoryPricingRepositoryMock = new Mock<IInventoryPricingRepository>();
            vehicleInvServiceMock = new Mock<IVehicleInvService>();
            inventoryPricingLogicMock = new Mock<IInventoryPricingLogic>();
            pricereviewlogid = 123;
            username = "testUser";
            priceReviewLockDetails = new PriceReviewLockedDetails()
            {
                PRVW_ID = 732145,
                Islock = true,
                UserName = "testUser"
            };
            priceReviewLogParams = new PriceReviewLogParams()
            {
                CID = 10,
                RegionID = 73,
                StartRow = 1,
                EndRow = 9000,
                VINOrStock = "",
                AppraisalType = "",
                IsLease = false,
                Fromdate = "1/1/2021",
                Todate = "5/5/2021",
                IsPurchase = false,
                RegionName = "",
                SortByField = "StockNo",
                SortDirection = "DESC",
                StatusList = "801,802,803,804",
                StoreLocationID = 101
            };
            priceReviewLogData = new List<PriceReviewLogData>()
            {
                new PriceReviewLogData
                {
                    VID=12345,
                    SID=101,
                    IID=1,
                    Year=2021,
                    VIN="JF1GV7F68BG521147",
                    Dealership="Acura of Serramonte",
                    DealershipValue=0,
                    Difference=100,
                   StockNumber="654789",
                    ExtColor="black",
                    Make="Jeep",
                   Mileage=666,
                   Model="Altima",
                   PriceRvwLogID=123321,
                   PriceRvwStatus="802",
                   PriceStatusID=32123,
                   RecommendedValue=100,
                   RequestedDateTime=new DateTime().ToString(),
                   SACID=46312,
                   SeriesTrim="Sport (4WD 4dr Sport)",
                   StockNo="654789",
                   VehicleStatusID=102
                }
            };
            rOPORequest = new ROPORequest
            {
                DealerId = "135",
                RegionId = 135,
                AcquiredDate = DateTime.Now.AddYears(-5),
                SoldDate = DateTime.Now.AddDays(-1),
                AdpVehicleId = 4449728
            };
            rOPOs = new List<ROPO>();
            rOPOs.Add(new ROPO { ROPOType = "RO", Number = "12323", Cost = 124, DateClosed = DateTime.Now.AddDays(-6), DealerShipID = "135", Description = "test", Status = "Closed" });
            rOPOs.Add(new ROPO { ROPOType = "RO", Number = "12321", Cost = 333, DateClosed = DateTime.Now.AddYears(-5), DealerShipID = "135", Description = "test", Status = "Open" });
            rOPOs.Add(new ROPO { ROPOType = "PO", Number = "12325", Cost = 777, DateClosed = DateTime.Now.AddYears(-4), DealerShipID = "135", Description = "test", Status = "Closed" });
            rOPOs.Add(new ROPO { ROPOType = "PO", Number = "12326", Cost = 432, DateClosed = DateTime.Now.AddYears(-3), DealerShipID = "135", Description = "test", Status = "Open" });

            rOPOs1 = new List<ROPO>();
            rOPOs1.Add(new ROPO { ROPOType = "RO", Number = "12323", Cost = 124, DateClosed = DateTime.Now.AddMinutes(-6), DealerShipID = "135", Description = "test", Status = "Closed" });
            rOPOs1.Add(new ROPO { ROPOType = "RO", Number = "12321", Cost = 333, DateClosed = DateTime.Now.AddMinutes(-5), DealerShipID = "135", Description = "test", Status = "Open" });
            rOPOs1.Add(new ROPO { ROPOType = "PO", Number = "12325", Cost = 777, DateClosed = DateTime.Now.AddMinutes(-4), DealerShipID = "135", Description = "test", Status = "Closed" });
            rOPOs1.Add(new ROPO { ROPOType = "PO", Number = "12326", Cost = 432, DateClosed = DateTime.Now.AddMinutes(-3), DealerShipID = "135", Description = "test", Status = "Open" });

            priceReviewHistories = new List<PriceReviewHistory>
            {
                new PriceReviewHistory{vehicleIdentity = new DomailModels.Common.VehicleIdentity{ VID=1,SID=1,IID=1,CID= DomailModels.Enums.Company.SU},Year=2008, Make="BMW", Model="X4", SeriesTrim="M40D"  },
                new PriceReviewHistory{vehicleIdentity = new DomailModels.Common.VehicleIdentity{ VID=2,SID=1,IID=1,CID= DomailModels.Enums.Company.SU},Year=2009, Make="Audi", Model="A4", SeriesTrim="Premium Plus"  }
            };
        }


        [Fact]
        public void GetActualReconValues_Returns_ActualReconROPOValues()
        {
            vehicleInvServiceMock.Setup(p => p.GetDVCValues(rOPORequest.DealerId, rOPORequest.RegionId, rOPORequest.AdpVehicleId)).Returns(rOPOs);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingRepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetActualReconValues(rOPORequest);
            Assert.True(result.TotalROPOCost > 0);
        }

        [Fact]
        public void GetDVCValues_Returns_DVCROPOValues()
        {
            vehicleInvServiceMock.Setup(p => p.GetDVCValues(rOPORequest.DealerId, rOPORequest.RegionId, rOPORequest.AdpVehicleId)).Returns(rOPOs);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingRepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetDVCValues(rOPORequest);
            Assert.True(result.TotalROPOCost > 0);
        }

        [Fact]
        public void GetActualReconValues_Returns_NULLROPOValues()
        {
            vehicleInvServiceMock.Setup(p => p.GetDVCValues(rOPORequest.DealerId, rOPORequest.RegionId, rOPORequest.AdpVehicleId)).Returns(rOPOs1);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingRepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetActualReconValues(rOPORequest);
            Assert.True(result.RO == null && result.PO == null);
        }

        [Fact]
        public void GetDVCValues_Returns_NULLROPOValues()
        {
            vehicleInvServiceMock.Setup(p => p.GetDVCValues(rOPORequest.DealerId, rOPORequest.RegionId, rOPORequest.AdpVehicleId)).Returns(rOPOs1);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingRepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetDVCValues(rOPORequest);
            Assert.True(result.RO == null && result.PO == null);
        }       

    }
}
