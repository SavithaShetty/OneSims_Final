﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Inventory;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.Infrastructure.Cdk;
using System;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Inventory
{
    public class InventoryPricingTestCases
    {
        private Mock<IInventoryPricingRepository> inventoryPricingrepositoryMock;
        private Mock<IVehicleInvService> vehicleInvServiceMock;
        private InventoryPricingDetails pricingDetails;
        private InventoryPricingDetails pricingDetailsEmpty;
        private InventorySavePricingDetails inventorySavePricingDetails;
        private InventorySavePricingDetails inventorySavePricingDetailsEmpty;
        private InventoryVDPPricingDetails inventoryVDPPricingDetails;
        private InventoryVDPPricingDetails inventoryVDPPricingDetailsemty;
        public InventoryPricingTestCases()
        {
            inventoryPricingrepositoryMock = new Mock<IInventoryPricingRepository>();
            pricingDetails = new InventoryPricingDetails
            {
                VIN = "1MEHM42177G602222",
                stockNo = null,
                UVC = "",
                Certifiable = false,
                Certified = false,
                Mileage = 345,
                RetailPrice = 0,
                MarketReady = false,
                StopSale = false,
                Status = 101,
                VehicleID = 4311038,
                StoreID = 101,
                InvtrID = 1,
                Acquired_Type = "",
                IsLeaseReturn = false,
                IsPendingWholesale = false,
                D_Rating = 0,
                SightUnseen = true,
                Suggested_RetailPrice = 0,
                Non_CPO_Sgst_Price = 0,
                Cpo_Sgst_Price = 0,
                Purchase_Price = 0,
                Region_ID = 71,
                IsUnitsMissing = true,
                WizardPage = 1,
                Rtc_Suggested_Price = 0,
                Show_RetailPrice = false,
                Is_Conditionvalue = false,
                Is_CPO_Suggested_Price = false,
                AppriasalValue=0,
                UnseenAppValue=0,
                ConditionValue=0

    };
            pricingDetailsEmpty = new InventoryPricingDetails
            {
                VIN = "",
                stockNo = null,
                UVC = "",
                Certifiable = false,
                Certified = false,
                Mileage = 0,
                RetailPrice = 0,
                MarketReady = false,
                StopSale = false,
                Status = 0,
                VehicleID = 0,
                StoreID = 0,
                InvtrID = 0,
                Acquired_Type = "",
                IsLeaseReturn = false,
                IsPendingWholesale = false,
                D_Rating = 0,
                SightUnseen = true,
                Suggested_RetailPrice = 0,
                Non_CPO_Sgst_Price = 0,
                Cpo_Sgst_Price = 0,
                Purchase_Price = 0,
                Region_ID = 0,
                IsUnitsMissing = true,
                WizardPage = 0,
                Rtc_Suggested_Price = 0,
                Show_RetailPrice = false,
                Is_Conditionvalue = false,
                Is_CPO_Suggested_Price = false,
                AppriasalValue = 0,
                UnseenAppValue = 0,
                ConditionValue = 0
            };
            inventorySavePricingDetails = new InventorySavePricingDetails
            {
                vid = 4311038,
                sid = 101,
                iid = 1,
                cid = 10,
                username = "raju.mahesh",
                appraisalID = 0,
                newAppraisalValue = 0,
                retailPrice = 200,
                suggestedPrice = 300,
                purchasePrice = 100,
                bumpUserName = "raju.mahesh",
                priceChangeFlag = 30,
                isPpendingWholesale = true,
                isMarketReady = true,
                isSalesPersonCreated = true,
                userRole = "salesPerson",
                statusID = 201,
                isConditionValueVisible = true,
                isAppConverted = false
            };
            inventorySavePricingDetailsEmpty = new InventorySavePricingDetails
            {
                vid = 0,
                sid = 0,
                iid = 0,
                cid = 0,
                username = "test",
                appraisalID = 0,
                newAppraisalValue = 0,
                retailPrice = 0,
                suggestedPrice = 0,
                purchasePrice = 0,
                bumpUserName = "test",
                priceChangeFlag = 0,
                isPpendingWholesale = true,
                isMarketReady = true,
                isSalesPersonCreated = true,
                userRole = "test",
                statusID = 0,
                isConditionValueVisible = true,
                isAppConverted = false
            };
            inventoryVDPPricingDetails = new InventoryVDPPricingDetails
            {
                age = new Age
                {
                    current_Age = 10,
                    group_Age = 10,
                    acquisition_Type = "",
                    acquisition_Date = null
                },
                retailPrice = new RetailPrice
                {
                    retail_Price = 8000,
                    wholeSale = false,
                    cpo_suggested_price = 0,
                    non_cpo_suggested_price = 0
                },
                apprisalPrice = new ApprisalPrice
                {
                    market_Value = 0,
                    condition = 0,
                    appraisal_Value = 0,
                    seenAppraisalValue = 8001,
                    unseenAppraisalValue = 0,
                    notesforDealership= "test"
                },
                pricing = new VDPPricing
                {
                    appraisal_Value = 0,
                    acquired_Value = 0,
                    retail_Selling_Price = 8000,
                    est_Recon = 0,
                    actual_Recon = 0,
                    gl_Balance = 0,
                    margin = 0,
                    dvcLink = null,
                    memo_Prior_Store_Recon = null,
                    sold_Price = 0
                },
                specialPricing = new SpecialPricing
                {
                    costco = 0,
                    truCar = 0,
                    usaa = 0,
                    wincentives = 0,
                    woIncentives = 0,
                    sellFor = 0
                },
                rtcRecommendation = new RTCRecommendation
                {
                    sac_Recommendation = "20",
                    dealership_Recommendation = 0,
                    recommended_Appraisal_Price = 0,
                    hold_Back_Appraisal_Price = 0,
                    inventory_Segment = "A",
                    trade_Price = 900,
                    notesforDealership = "test 800",
                    purchaser = " "
                },
                recordInformation = new RecordInformation
                {
                    sales_Person = "Ayman.Sana",
                    sourceName = "test,test",
                    date_Created = DateTime.Now.AddYears(-3),
                    last_Updated_By = "Savitha.Ramanatha",
                    last_Updated_Date = DateTime.Now.AddYears(-3),
                    purchased_By = "Raju.Mahesh",
                    purchased_Date = DateTime.Now.AddYears(-3)
                },
                isDataMissing = false,
                isCertiFied = false,
                isMarketReady = false,
                isSightSeen = true,
                isDRating = false
            };
            inventoryVDPPricingDetailsemty = new InventoryVDPPricingDetails
            {
                age = new Age
                {
                    current_Age = 0,
                    group_Age = 0,
                    acquisition_Type = "",
                    acquisition_Date = null
                },
                retailPrice = new RetailPrice
                {
                    retail_Price = 0,
                    wholeSale = false,
                    cpo_suggested_price = 0,
                    non_cpo_suggested_price = 0
                },
                apprisalPrice = new ApprisalPrice
                {
                    market_Value = 0,
                    condition = 0,
                    appraisal_Value = 0,
                    seenAppraisalValue = 0,
                    unseenAppraisalValue = 0,
                    notesforDealership= "test"
                },
                pricing = new VDPPricing
                {
                    appraisal_Value = 0,
                    acquired_Value = 0,
                    retail_Selling_Price = 0,
                    est_Recon = 0,
                    actual_Recon = 0,
                    gl_Balance = 0,
                    margin = 0,
                    dvcLink = null,
                    memo_Prior_Store_Recon = null,
                    sold_Price = 0
                },
                specialPricing = new SpecialPricing
                {
                    costco = 0,
                    truCar = 0,
                    usaa = 0,
                    wincentives = 0,
                    woIncentives = 0,
                    sellFor = 0
                },
                rtcRecommendation = new RTCRecommendation
                {
                    sac_Recommendation = "0",
                    dealership_Recommendation = 0,
                    recommended_Appraisal_Price = 0,
                    hold_Back_Appraisal_Price = 0,
                    inventory_Segment = "",
                    trade_Price = 900,
                    notesforDealership = "",
                    purchaser = " "
                },
                recordInformation = new RecordInformation
                {
                    sales_Person = "",
                    sourceName = "",
                    date_Created = DateTime.Now.AddYears(-3),
                    last_Updated_By = "",
                    last_Updated_Date = DateTime.Now.AddYears(-3),
                    purchased_By = "",
                    purchased_Date = DateTime.Now.AddYears(-3)
                },
                isDataMissing = false,
                isCertiFied = false,
                isMarketReady = false,
                isSightSeen = true,
                isDRating = false
            };
            vehicleInvServiceMock = new Mock<IVehicleInvService>();


        }

        [Fact]
        public void GetInventoryPricingDetails_Returns_True()
        {
            bool expected = true;
            inventoryPricingrepositoryMock.Setup(p => p.GetInventoryPricingDetails(10, 4311038, 101, 1)).Returns(pricingDetails);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingrepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetInventoryPricingDetails(10, 4311038, 101, 1);
            Assert.Equal(pricingDetails, result);
        }
        [Fact]
        public void GetInventoryPricingDetails_Returns_TrueEmpty()
        {
            bool expected = true;
            inventoryPricingrepositoryMock.Setup(p => p.GetInventoryPricingDetails(0, 0, 0, 0)).Returns(pricingDetailsEmpty);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingrepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetInventoryPricingDetails(0, 0, 0, 0);
            Assert.Equal(pricingDetailsEmpty, result);
        }
        [Fact]
        public void AddPricingPricingDetails_Returns_True()
        {
            bool expected = true;
            inventoryPricingrepositoryMock.Setup(p => p.SaveInventoryRetailPrice(inventorySavePricingDetails)).Returns(expected);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingrepositoryMock.Object, vehicleInvServiceMock.Object);
            bool result = pricingLogic.SaveInventoryRetailPrice(inventorySavePricingDetails);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void AddPricingPricingDetails_Returns_false()
        {
            bool expected = false;
            inventoryPricingrepositoryMock.Setup(p => p.SaveInventoryRetailPrice(inventorySavePricingDetailsEmpty)).Returns(expected);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingrepositoryMock.Object, vehicleInvServiceMock.Object);
            bool result = pricingLogic.SaveInventoryRetailPrice(inventorySavePricingDetailsEmpty);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void GetVDPPricingDetails_Returns_True()
        {
            inventoryPricingrepositoryMock.Setup(p => p.GetInventoryVDPPricingDetails(10, 4310968, 101, 1)).Returns(inventoryVDPPricingDetails);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingrepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetInventoryVDPPricingDetails(10, 4310968, 101, 1);
            Assert.Equal(inventoryVDPPricingDetails, result);
        }
        [Fact]
        public void GetVDPPricingDetails_Returns_empty_Result()
        {
            inventoryPricingrepositoryMock.Setup(p => p.GetInventoryVDPPricingDetails(10, 4310968, 101, 1)).Returns(inventoryVDPPricingDetailsemty);
            IInventoryPricingLogic pricingLogic = new InventoryPricingLogic(inventoryPricingrepositoryMock.Object, vehicleInvServiceMock.Object);
            var result = pricingLogic.GetInventoryVDPPricingDetails(10, 4310968, 101, 1);
            Assert.Equal(inventoryVDPPricingDetailsemty, result);
        }
    }
}
