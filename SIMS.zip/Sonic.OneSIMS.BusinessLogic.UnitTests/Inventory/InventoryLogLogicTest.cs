﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Inventory;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomailModels.Inventory;
using Sonic.OneSIMS.DomainModels.Enums;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.DomainModels.Settings.Store;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Inventory
{
    public class InventoryLogLogicTest
    {

        private Mock<IInventoryLogRepository> inventorylogRepositoryMock;
        private InventoryLogParam inventoryLogParam,ageFilter,statusFilter;
        private InventoryLogData inventoryLogData;
        private StoreProfile storeProfile;
        private AgeRanges ageRange;
        private List<InventoryLogData> inventoryLogDatas, reconageInventoryLogDatas;
        private List<AgeRanges> ageRanges;
        private VehicleHeaderInfo vehicleHeaderInfo;
        private VehicleHeaderInfo vehicleHeaderInfoEmpty;
        private RetailPriceChangeDetails RetailPriceChangeDetails;
        private VehiclePriceUpdates retailpricesave;
        private PriceReviewParams pricereview;
        public InventoryLogLogicTest()
        {
            inventorylogRepositoryMock = new Mock<IInventoryLogRepository>();
            inventoryLogParam = new InventoryLogParam()
            {
                CID = 10,
                SID = 101,
                Status = "201,203,202,204,205,301,215,232,219,214,209,234",
                Age_Bucket_Id = 0,
                SortByField = "String",
                SortDirection = "DESC",
                IncludeException = false,
                Recon = false,
                DataMissing = false,
                PhotosMissing = false,
                AdtextMissing = false,
                AcquiredType = "All",
                RetailPriceCheck = false,
                OpenDeals = false,
                BithdayList = false,
                UnitsNotOnline = false,
                InventorylogParam = "",
                CPO = false,
                Make = "All",
                PendingWholesale = false,
                BVA = false,
                BodyShop = false,
                MarketReady = false

            };
           
            // Excludes Recon vehicles i.e 215
            statusFilter = new InventoryLogParam()
            {
                CID = 10,
                SID = 101,
                Status = "201,203,202,204,205,301,232,219,214,209,234",
                Age_Bucket_Id = 0,
                SortByField = "String",
                SortDirection = "DESC",
                IncludeException = false,
                Recon = false,
                DataMissing = false,
                PhotosMissing = false,
                AdtextMissing = false,
                AcquiredType = "All",
                RetailPriceCheck = false,
                OpenDeals = false,
                BithdayList = false,
                UnitsNotOnline = false,
                InventorylogParam = "",
                CPO = false,
                Make = "All",
                PendingWholesale = false,
                BVA = false,
                BodyShop = false,
                MarketReady = false

            };

            // Excludes Recon vehicles i.e 215
            ageFilter = new InventoryLogParam()
            {
                CID = 10,
                SID = 101,
                Status = "201,203,202,204,205,301,215,232,219,214,209,234",
                Age_Bucket_Id = 10,
                SortByField = "String",
                SortDirection = "DESC",
                IncludeException = false,
                Recon = false,
                DataMissing = false,
                PhotosMissing = false,
                AdtextMissing = false,
                AcquiredType = "All",
                RetailPriceCheck = false,
                OpenDeals = false,
                BithdayList = false,
                UnitsNotOnline = false,
                InventorylogParam = "",
                CPO = false,
                Make = "All",
                PendingWholesale = false,
                BVA = false,
                BodyShop = false,
                MarketReady = false

            };

            inventoryLogDatas = new List<InventoryLogData>
            {
                new InventoryLogData
                {
                     StockNumber= "G521147 *#",
                     Year= 2011,
                     Invoice= null,
                     Write_Down= null,
                     Make= "Subaru",
                     Model= "Impreza Sedan WRX",
                     Series_Trim= "WRX Limited (4dr Man WRX Limited)",
                     ExteriorColor= "Black",
                     Mileage= 1250,
                     Wholesale_Average= null,
                     Status= "PA",
                     GLBalance= 0,
                     FEGross= 0,
                     AcquiredValue= 0,
                     CurrentAge= 5,
                     GroupAge= 5,
                     ATClickCount= 0,
                     CarsClickCount= 0,
                     DDCClickCount= 0,
                     RetailPrice= 0,
                     Photos= 0,
                     CarFax= null,
                     VehicleID= 4310948,
                     StatusID= 201,
                     Store_Name= "Acura of Serramonte",
                     InventoryID= 1,
                     WizardPage= 4,
                     CReportIconID= 90,
                     AReportIconID= 100,
                     CReportURL= "",
                     AReportURL= null,
                     Vin= "JF1GV7F68BG521147",
                     MSRP= 0,
                     InvoicePrice= null,
                    IsNew= false,
                     InteriorColor= "",
                     ReconAmount= 0,
                     VehicleInMarket= 0,
                     MarketPrice= 0,
                     AcquiredDate= null,
                     PriceChanges= 0,
                     CPO= "",
                     SightUnseen= false,
                     AppraisalValue= 0,
                     PrintAppButton= 0,
                     HasFactoryOptions= "0",
                     SuggestedPrice= null,
                     IsMissingData= null,
                     PriceStatusID= 0,
                     IsMarketReady= false,
                     EndingDoller= null,
                     CAN_REQST_LOANER= false,
                     DifferenceImage= null,
                     ReconType= "Text",
                     Is_Recon_Exists= false,
                     IsPublished= false,
                     IsPunched= false,
                     Punched= null,
                     AmtPunched= null,
                     PunchedValue= null,
                     VehicleSrc= 40,
                     IsKbbVehicle= null,
                     IsStep5Exists= true,
                     DaysInCurrentStatus= 0,
                     DaysInTransit= 0,
                     DaysInMarketReady= 0,
                     DaysInRecon= 0,
                     DaysOnLot= 0,
                     Discount= null,
                     AgeBucketID= 0,
                     Demo_Assigned_To= null,
                     Demo_Date= null,
                     Comments= null,
                     Is_Certifiable= false,
                     Is_Certified= false
                },
            };
            storeProfile = new StoreProfile()
            {
                StoreName = "Acura of Serramonte",
                SID = 101,
                ADP_REGION_ID = 35,
                InTransitUsed = true,
                InTransitNew = false,
                IsReconOnlineStore = true,
                MarketHomeNetPhotoStore = true,
                MissingDataCheckRequired = false,
                AutocheRequired = true,
                CarFaxRequired = true,
                AgeRanges = new List<AgeRanges>               {
                    {
                     new AgeRanges{AgeBcketId=0,AgeRange="Display All"}
                    },
                    {
                     new AgeRanges{AgeBcketId=10,AgeRange="0-20"}
                    },
                    {
                     new AgeRanges{AgeBcketId=11,AgeRange="21-35"}
                    }
                    ,
                    {
                     new AgeRanges{AgeBcketId=12,AgeRange="36-45"}
                    },
                    {
                     new AgeRanges{AgeBcketId=13,AgeRange="46-990"}
                    }
                },
            };

            reconageInventoryLogDatas = new List<InventoryLogData>
            {
                new InventoryLogData
                {
                    
                     StockNumber= "5117493 *#",
                     Year= 2007,
                     Invoice= null,
                     Write_Down= null,
                     Make= "Kia",
                     Model= "Optima",
                     Series_Trim= "4dr Sdn I4 Auto LX",
                     ExteriorColor= "White",
                     Mileage= 1234,
                     Wholesale_Average= null,
                     Status= "Recon",
                     GLBalance= 0,
                     FEGross= 0,
                     AcquiredValue= 0,
                     CurrentAge= 10,
                     GroupAge= 10,
                     ATClickCount= 0,
                     CarsClickCount= 0,
                     DDCClickCount= 0,
                     RetailPrice= 0,
                     Photos= 0,
                     CarFax= null,
                     VehicleID= 4310949,
                     StatusID= 215,
                     Store_Name= "Acura of Serramonte",
                     InventoryID= 1,
                     WizardPage= 4,
                     CReportIconID= 90,
                     AReportIconID= 100,
                     CReportURL= "",
                     AReportURL= null,
                     Vin= "KNAGE123875117493",
                     MSRP= 0,
                     InvoicePrice= null,
                     IsNew= false,
                     InteriorColor= "",
                     ReconAmount= 0,
                     VehicleInMarket= 0,
                     MarketPrice= 0,
                     AcquiredDate= null,
                     PriceChanges= 0,
                     CPO= "",
                     SightUnseen= false,
                     AppraisalValue= 0,
                     PrintAppButton= 0,
                     HasFactoryOptions= "0",
                     SuggestedPrice= null,
                     IsMissingData= null,
                     PriceStatusID= 0,
                     IsMarketReady= false,
                     EndingDoller= null,
                     CAN_REQST_LOANER= false,
                     DifferenceImage= null,
                     ReconType= "Text",
                     Is_Recon_Exists= false,
                     IsPublished= false,
                     IsPunched= false,
                     Punched= null,
                     AmtPunched= null,
                     PunchedValue= null,
                     VehicleSrc= 40,
                     IsKbbVehicle= null,
                     IsStep5Exists= true,
                     DaysInCurrentStatus= 0,
                     DaysInTransit= 0,
                     DaysInMarketReady= 0,
                     DaysInRecon= 0,
                     DaysOnLot= 0,
                     Discount= null,
                     AgeBucketID= 0,
                     Demo_Assigned_To= null,
                     Demo_Date= null,
                     Comments= null,
                     Is_Certifiable= false,
                     Is_Certified= false,
                },
            };
            vehicleHeaderInfo = new VehicleHeaderInfo()
            {
                vin = "WDBNG76J95A438204",
                years = "2005",
                make = "Mercedes-Benz",
                model = "S-Class",
                vehicleType = "Trade",
                mileage = 789,
                isSalesPerson = false,
                vehicleSource = VehicleSource.ManualAppraisalTrade,
                statusName = "Pending Appraisal",
                statusId = 101,
                isCertified = false,
                isCertifiable=false,
                stockNo = "",
                isMarketReady = false,
                onlineUrl = "",
                isAutoIUsedVIPAvailable = true,
                autoIUseURLVIPURL = "https://www.ipacket.info/WDBNG76J95A438204",
                dmvURL = "",
                isAutoCheckReq = "True",
                isCarfaxReq = "True",
                seriesTrim = "5.5L (4dr Sdn 5.5L)"
            };
            vehicleHeaderInfoEmpty = new VehicleHeaderInfo()
            {
                vin = "",
                years = "",
                make = "",
                model = "",
                vehicleType = "",
                mileage = 0,
                isSalesPerson = false,
                vehicleSource = VehicleSource.ManualAppraisalTrade,
                statusName = "Pending Appraisal",
                statusId = 101,
                isCertified = false,
                isCertifiable=false,
                stockNo = "",
                isMarketReady = false,
                onlineUrl = "",
                isAutoIUsedVIPAvailable = true,
                autoIUseURLVIPURL = "",
                dmvURL = "",
                isAutoCheckReq = "",
                isCarfaxReq = "",
                seriesTrim = ""
            };
            RetailPriceChangeDetails = new RetailPriceChangeDetails()
            {
                StockNumber = "D23451",
                SugestedPrice = 1212,
                MarketReady = true,
                RetailPrice = 1234,
                DRating = 1,
                CPO = "Y",
                IsCertifiable = false,
                StatusID = 203,
                PricingStatusID = 801,
                Modification_Date = null,
                Rvw_Requested_Date = null,
                DateDifference = null,
                PriceRvwEnforcement = "Y",
                Is_RetailPrice_Editable = true,
                IsAutoPrice = false,
                ManheimInfo = true,
                isexceptliststore = true,
                isenddollarvalidstore = false,
                EndingDoller = 9
            };
            retailpricesave = new VehiclePriceUpdates()
            {
                VID = 1234,
                SID = 101,
                IID = 1,
                MarketReady = true,
                CPO = true,
                NewRetailPrice = 1234,
                PerformanceMeasure = 0,
                StopSale = false,
                UserName = "test"
            };
            pricereview = new PriceReviewParams()
            {
                VID = 1234,
                SID = 101,
                IID = 1,
                CID = DomailModels.Enums.Company.SU,
                PriceMismatchReasonID = 10,
                Notes = "test test",
                UserName = "test"
            };
        }



        [Fact]
        public void GetInventoryLog_Returns_Result()
        {
            inventorylogRepositoryMock.Setup(p => p.GetInventoryLogDetails(inventoryLogParam)).Returns(inventoryLogDatas);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetInventoryLogDetails(inventoryLogParam);
            Assert.True(result.Count > 0);
        }


        [Fact]
        public void GetStoreProfile_Resturns_Result()
        {
            inventorylogRepositoryMock.Setup(p => p.GetStoreProfile(10,101)).Returns(storeProfile);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetStoreProfile(10,101);
            Assert.True(result.SID==101);
        }
        [Fact]
        public void GetInventoryLog_Returns_AgeFilter_Result()
        {
            inventorylogRepositoryMock.Setup(p => p.GetInventoryLogDetails(ageFilter)).Returns(reconageInventoryLogDatas);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetInventoryLogDetails(ageFilter);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetInventoryLog_Returns_Status_Filter_Result()
        {
            inventorylogRepositoryMock.Setup(p => p.GetInventoryLogDetails(statusFilter)).Returns(reconageInventoryLogDatas);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetInventoryLogDetails(statusFilter);
            Assert.True(result.Count > 0);
        }
        [Fact]
        public void GetInventoryHeaderInfo_Return_result()
        {
            inventorylogRepositoryMock.Setup(p => p.GetVehicleHeaderInfo(984734, 101, 3, 10)).Returns(vehicleHeaderInfo);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetVehicleHeaderInfo(984734, 101, 3, 10);
            Assert.True(vehicleHeaderInfo.Equals(result));
        }
        [Fact]
        public void GetInventoryHeaderInfo_Return_false()
        {
            inventorylogRepositoryMock.Setup(p => p.GetVehicleHeaderInfo(984734, 101, 3, 10)).Returns(vehicleHeaderInfo);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetVehicleHeaderInfo(0, 0, 0, 0);
            Assert.False(vehicleHeaderInfoEmpty.Equals(result));
        }

        [Fact]
        public void GetRetailPriceChangeDetails_Return_result()
        {
            inventorylogRepositoryMock.Setup(p => p.GetRetailPriceChangeDetails(984734, 101, 3, 10)).Returns(RetailPriceChangeDetails);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetRetailPriceChangeDetails(984734, 101, 3, 10);
            Assert.True(RetailPriceChangeDetails.Equals(result));
        }
        [Fact]
        public void GetRetailPriceChangeDetails_Return_null()
        {
            inventorylogRepositoryMock.Setup(p => p.GetRetailPriceChangeDetails(984734, 101, 3, 10)).Returns(new RetailPriceChangeDetails());
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.GetRetailPriceChangeDetails(0, 0, 0, 0);
            Assert.True(result==null);
        }
        [Fact]
        public void RetailPriceActiveSave_Return_true()
        {
            var expected= true;
            inventorylogRepositoryMock.Setup(p => p.RetailPriceActiveSave(retailpricesave)).Returns(expected);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.RetailPriceActiveSave(retailpricesave);
            Assert.True(result== expected);
        }
        [Fact]
        public void RetailPriceActiveSave_Return_false()
        {
            var expected = false;
            inventorylogRepositoryMock.Setup(p => p.RetailPriceActiveSave(retailpricesave)).Returns(expected);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.RetailPriceActiveSave(retailpricesave);
            Assert.True(result == expected);
        }
        [Fact]
        public void RequestRetailPriceReview_Return_true()
        {
            var expected = true;
            inventorylogRepositoryMock.Setup(p => p.RequestRetailPriceReview(pricereview)).Returns(expected);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.RequestRetailPriceReview(pricereview);
            Assert.True(result == expected);
        }
        [Fact]
        public void RequestRetailPriceReview_Return_false()
        {
            var expected = false;
            inventorylogRepositoryMock.Setup(p => p.RequestRetailPriceReview(pricereview)).Returns(expected);
            IInventoryLogLogic inventoryLogLogic = new InventoryLogLogic(inventorylogRepositoryMock.Object);
            var result = inventoryLogLogic.RequestRetailPriceReview(pricereview);
            Assert.True(result == expected);
        }
    }

}
