﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomailModels.Common;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.Infrastructure.Cdk;
using Sonic.OneSIMS.Infrastructure.Chrome;
using Sonic.OneSIMS.Infrastructure.Chrome.Entities;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{
    public class VehicleInfoLogicTest
    {
        private Mock<IVehicleInfoRepository> vehicleInfoRepositoryMock;
        private Mock<IChromeService> chromeServiceMock;
        private Mock<IVehicleInvService> vehicleInvServiceMock;
        private Mock<IAutoCheckCarFaxLogic> autoCheckCarFaxLogicMock;

        private VehicleIdentity vehicleIdentity;
        private AppraisalProfile appraisalProfile;
        private List<IDSavedValues> savedVehicleInfo;
        private List<Year> Years;
        List<Make> Makes;
        List<Model> Models;
        List<Trim> Trims;
        private VehicleInformation vehicleInformation;
        private VehicleDecodeDetails vehicleDecodeDetails;
        private MasterOptions masterOptions;
        private Infrastructure.Cdk.Entities.ListValuesResponse listValuesResponse;
        private ChromeDecodeInfo chromeDecodeInfo;
        private VinExistsDetails vinExistsDetails;
        private BasicAppraisalInfo basicAppraisalInfo;
        private CreateAppraisalResponse createAppraisalResponse;


        public VehicleInfoLogicTest()
        {
            vehicleInfoRepositoryMock = new Mock<IVehicleInfoRepository>();
            chromeServiceMock = new Mock<IChromeService>();
            vehicleInvServiceMock = new Mock<IVehicleInvService>();
            autoCheckCarFaxLogicMock = new Mock<IAutoCheckCarFaxLogic>();
            createAppraisalResponse = new CreateAppraisalResponse
            {
                VID = 1,
                SID = 1,
                IID = 1,
                CID = 10,
                CreationStatus = DomainModels.Enums.AppraisalCreationStatus.AppraisalPendingInSameStore,
                Message = "test",
                StoreName = "Accura of Serammonte"
            };
            basicAppraisalInfo = new BasicAppraisalInfo
            {
                IsDecodeSuccess = true,
                VIN = "2C3LA43R87H869600",
                username = "test",
                StoreID = 101,
                VehicleSrc = DomainModels.Enums.VehicleSource.ManualAppraisalTrade
            };
            vinExistsDetails = new VinExistsDetails
            {
                VIN = "2C3LA43R87H869600",
                VID = 1,
                SID = 101,
                IID = 1,
                CID = 10,
                SourceVID = 2,
                SourceSID = 2,
                SourceIID = 1,
                SourceCID = 20,
                VehicleInStatus = "102"
            };
            chromeDecodeInfo = new ChromeDecodeInfo
            {
                vin = "2C3LA43R87H869600",
                IsDecodeSuccess = true,
                year = 2008,
                make = new List<Make> { new Make { ID = "Make", Value = "Make" } },
                model = new List<Model> { new Model { ID = "Model", Value = "Model" } },
                series = new List<Infrastructure.Chrome.Entities.IDValues> { new Infrastructure.Chrome.Entities.IDValues { ID = "Series", Value = "Series" } },
                Engine = new List<Infrastructure.Chrome.Entities.IDValues> { new Infrastructure.Chrome.Entities.IDValues { ID = "Engine", Value = "Engine" } }
            };
            vehicleInformation = new VehicleInformation
            {
                VIN = "2C3LA43R87H869600",
                VID = 1,
                SID = 1,
                IID = 1,
                Year = new DomainModels.Common.IDValues { ID = "", Value = "" },
                vehicleSource = DomainModels.Enums.VehicleSource.ManualAppraisalTrade,
                IsDecodeSuccess = false,
                VehicleType = new DomainModels.Common.IDValues { ID = "Car", Value = "Car" },
                Transmission = new DomainModels.Common.IDValues { ID = "Transmission", Value = "Transmission" },
                Series = new DomainModels.Common.IDValues { ID = "Series", Value = "Series" },
                OdometerOptions = new DomainModels.Common.IDValues { ID = "Odometer", Value = "Odometer" },
                Model = new DomainModels.Common.IDValues { ID = "Model", Value = "Model" },
                InteriorType = new DomainModels.Common.IDValues { ID = "Leather", Value = "Leather" },
                InteriorColor = new DomainModels.Common.IDValues { ID = "Red", Value = "Red" },
                Fuel = new DomainModels.Common.IDValues { ID = "Diesel", Value = "Diesel" },
                ExteriorColor = new DomainModels.Common.IDValues { ID = "Black", Value = "Black" },
                Engine = new DomainModels.Common.IDValues { ID = "Engine", Value = "Engine" },
                DriveTrain = new DomainModels.Common.IDValues { ID = "DriveTrain", Value = "DriveTrain" },
                BodyStyle = new DomainModels.Common.IDValues { ID = "BodyStyle", Value = "BodyStyle" },
                AcquisitionType = new DomainModels.Common.IDValues { ID = "AcquisitionType", Value = "AcquisitionType" }
            };
            masterOptions = new MasterOptions
            {
                BodyStyle = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "BodyStyle1" } },
                DriveTrain = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "DriveTrain1" } },
                OdometerOptions = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "OdometerOptions1" } },
                ExteriorColor = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "ExteriorColor1" } },
                Transmission = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "Transmission1" } },
                Fuel = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "Fuel1" } },
                InteriorColor = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "InteriorColor1" } },
                InteriorType = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "InteriorType1" } },
                VehicleType = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "VehicleType1" } },
                AcquisitionType = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "1", Value = "AcquisitionType1" } }
            };
            vehicleDecodeDetails = new VehicleDecodeDetails
            {
                VIN = "2C3LA43R87H869600",
                VehicleType = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Car", Value = "Car" } },
                Transmission = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Transmission", Value = "Transmission" } },
                Series = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Series", Value = "Series" } },
                OdometerOptions = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Odometer", Value = "Odometer" } },
                Model = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Model", Value = "Model" } },
                InteriorType = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Leather", Value = "Leather" } },
                InteriorColor = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Red", Value = "Red" } },
                Fuel = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Diesel", Value = "Diesel" } },
                ExteriorColor = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Black", Value = "Black" } },
                Engine = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "Engine", Value = "Engine" } },
                DriveTrain = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "DriveTrain", Value = "DriveTrain" } },
                BodyStyle = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "BodyStyle", Value = "BodyStyle" } },
                AcquisitionType = new List<DomainModels.Common.IDValues> { new DomainModels.Common.IDValues { ID = "AcquisitionType", Value = "AcquisitionType" } }
            };

            vehicleIdentity = new VehicleIdentity
            {
                CID = DomailModels.Enums.Company.SU,
                VID = 1,
                SID = 1,
                IID = 1
            };

            appraisalProfile = new AppraisalProfile
            {
                VID = 1,
                SID = 1,
                IID = 1,
                CID = DomailModels.Enums.Company.SU,
                VIN = "2C3LA43R87H869600",
                vehicleSource = DomainModels.Enums.VehicleSource.ManualServiceAppraisal
            };

            Years = new List<Year>
            {
                new Year{ID="2018",Value="2018"},
                new Year{ID="2019",Value="2019"},
                new Year{ID="2020",Value="2020"},
                new Year{ID="2021",Value="2021"}

            };

            Makes = new List<Make>
            {
                new Make{ID="1",Value="Acura"},
                new Make{ID="43",Value="Alfa Romeo"},
                new Make{ID="44",Value="Aston Martin"},
                new Make{ID="4",Value="Audi"}

            };

            Models = new List<Model>
            {
                new Model{ID="34033",Value="ILX"},
                new Model{ID="34229",Value="NSX"},
                new Model{ID="33571",Value="RDX"},
                new Model{ID="33973",Value="TLX"}

            };

            Trims = new List<Trim>
            {
                new Trim{ID="418425",Value="Sedan"},
                new Trim{ID="418426",Value="Sedan w/Premium Package"},
                new Trim{ID="418427",Value="Sedan w/Technology Package *Ltd Avail*"},
                new Trim{ID="418428",Value="Sedan w/Premium/A-Spec Package"}

            };


        }

        [Fact]
        public void GetAppraisalProfile_Returns_Appraisal()
        {
            vehicleInfoRepositoryMock.Setup(p => p.GetVehicleProfile(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID))).Returns(appraisalProfile);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.GetVehicleProfile(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID));
            Assert.Equal(appraisalProfile, result);
        }

        [Fact]
        public void SaveVehicleInformation_Returns_True()
        {
            vehicleInfoRepositoryMock.Setup(p => p.SaveVehicleInformation(vehicleInformation)).Returns(true);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.SaveVehicleInformation(vehicleInformation);
            Assert.True(result);
        }

        [Fact]
        public void GetVehicleInfo_Returns_VehicleDecodeDetails()
        {
            vehicleInformation.IsDecodeSuccess = true;
            vehicleInfoRepositoryMock.Setup(p => p.GetVehicleInformation(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, (short)vehicleIdentity.CID)).Returns(vehicleInformation);
            vehicleInfoRepositoryMock.Setup(p => p.GetMasterOptions()).Returns(masterOptions);
            vehicleInvServiceMock.Setup(p => p.GetListValues(45, false)).Returns(listValuesResponse);
            chromeServiceMock.Setup(p => p.GetDecodeVIN(vehicleInformation.VIN)).Returns(chromeDecodeInfo);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            VehicleInformation info;
            var result = vehicleInfoLogic.GetVehicleInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, (short)vehicleIdentity.CID, out info);
            Assert.True(result != null);
        }

        [Fact]
        public void GetVehicleInfo_DecodeFailure_Returns_VehicleDecodeDetails()
        {
            vehicleInformation.IsDecodeSuccess = false;
            vehicleInformation.Year = new DomainModels.Common.IDValues { ID = "2003", Value = "2003" };
            vehicleInformation.Make = new DomainModels.Common.IDValues { ID = "Make", Value = "Make" };
            vehicleInformation.Model = new DomainModels.Common.IDValues { ID = "Model", Value = "Model" };
            vehicleInformation.BodyStyle = new DomainModels.Common.IDValues { ID = "Trim", Value = "Trim" };
            vehicleInfoRepositoryMock.Setup(p => p.GetVehicleInformation(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, (short)vehicleIdentity.CID)).Returns(vehicleInformation);
            vehicleInfoRepositoryMock.Setup(p => p.GetMasterOptions()).Returns(masterOptions);
            vehicleInvServiceMock.Setup(p => p.GetListValues(45, false)).Returns(listValuesResponse);
            chromeServiceMock.Setup(p => p.GetDecodeVIN(vehicleInformation.VIN)).Returns(chromeDecodeInfo);
            chromeServiceMock.Setup(p => p.GetChromeYears()).Returns(new List<Year> { new Year { ID = "2003", Value = "2003" } });
            chromeServiceMock.Setup(p => p.GetChromeMakes(2003)).Returns(new List<Make> { new Make { ID = "Make", Value = "Make" } });
            chromeServiceMock.Setup(p => p.GetChromeModels(2003,"Make")).Returns(new List<Model> { new Model { ID = "Model", Value = "Model" } });
            chromeServiceMock.Setup(p => p.GetChromeStyles("Model")).Returns(new List<Trim> { new Trim { ID = "Trim", Value = "Trim" } });
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            VehicleInformation info;
            var result = vehicleInfoLogic.GetVehicleInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, (short)vehicleIdentity.CID, out info);
            Assert.True(result != null);
        }

        [Fact]
        public void GetVehicleInfo_Returns_VehicleBadVinDetails()
        {
            vehicleInfoRepositoryMock.Setup(p => p.GetVehicleInformation(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, (short)vehicleIdentity.CID)).Returns(vehicleInformation);
            vehicleInfoRepositoryMock.Setup(p => p.GetMasterOptions()).Returns(masterOptions);
            vehicleInvServiceMock.Setup(p => p.GetListValues(45, false)).Returns(listValuesResponse);
            chromeServiceMock.Setup(p => p.GetChromeYears()).Returns(Years);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            VehicleInformation info;
            var result = vehicleInfoLogic.GetVehicleInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, (short)vehicleIdentity.CID, out info);
            Assert.True(result != null);
        }

        [Fact]
        public void GetYears_Returns_List()
        {
            chromeServiceMock.Setup(p => p.GetChromeYears()).Returns(Years);
            VehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var year = vehicleInfoLogic.GetYears();
            Assert.True(year.Count > 0);
        }

        [Fact]
        public void GetMakes_Returns_List()
        {
            int year = 2021;
            chromeServiceMock.Setup(p => p.GetChromeMakes(year)).Returns(Makes);
            VehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            List<DomainModels.Common.IDValues> makelist = vehicleInfoLogic.GetMakes(year);
            Assert.True(makelist.Count > 0);
        }

        [Fact]
        public void GetModels_Returns_List()
        {
            int year = 2021;
            string makeId = "1";
            chromeServiceMock.Setup(p => p.GetChromeModels(year, makeId)).Returns(Models);
            VehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            List<DomainModels.Common.IDValues> modellist = vehicleInfoLogic.GetModels(year, makeId);
            Assert.True(modellist.Count > 0);
        }

        [Fact]
        public void GetTrims_Returns_List()
        {
            string modelId = "34033";
            chromeServiceMock.Setup(p => p.GetChromeStyles(modelId)).Returns(Trims);
            VehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            List<DomainModels.Common.IDValues> trimlist = vehicleInfoLogic.GetTrims(modelId);
            Assert.True(trimlist.Count > 0);
        }

        [Fact]
        public void GetSavedVehicleInfo_Returns_VehicleDetails()
        {

            this.savedVehicleInfo = new List<IDSavedValues>();
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Series/Trim", Value = "Sport (AWD 4dr Sport)", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Sight Unseen", Value = "True", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "DMV Type", Value = "Car", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Engine", Value = "3.6 Liter V6 Cylinder Engine, 264 HP", visible = true });

            vehicleInfoRepositoryMock.Setup(p => p.GetSavedVehicleInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID))).Returns(this.savedVehicleInfo);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.GetSavedVehicleInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID));
            Assert.Equal(this.savedVehicleInfo, result);
        }

        [Fact]
        public void GetVehicleHeaderInfo_Returns_VehicleHeaderDetails()
        {

            this.savedVehicleInfo = new List<IDSavedValues>();
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "VIN", Value = "2CNDL037786296621", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Year", Value = "2008", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Series/Trim", Value = "Sport (AWD 4dr Sport)", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Sight Unseen", Value = "True", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "DMV Type", Value = "Car", visible = true });
            this.savedVehicleInfo.Add(new IDSavedValues() { name = "Engine", Value = "3.6 Liter V6 Cylinder Engine, 264 HP", visible = true });

            vehicleInfoRepositoryMock.Setup(p => p.GetVehicleHeaderInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID))).Returns(this.savedVehicleInfo);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.GetVehicleHeaderInfo(vehicleIdentity.VID, vehicleIdentity.SID, vehicleIdentity.IID, ((short)vehicleIdentity.CID));
            Assert.Equal(this.savedVehicleInfo, result);
        }

        [Fact]
        public void CreateCCAVehicleDetails_Returns_Response()
        {
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 30)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateCCAVehicleDetails(vinExistsDetails, basicAppraisalInfo, 30);
            Assert.True(result != null);
        }

        [Fact]
        public void CreateAppraisal_Returns_AppraisalCompletedInSameSameStore()
        {
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.AppraisalCompletedInSameSameStore);
        }

        [Fact]
        public void CreateAppraisal_Returns_AppraisalExistsInOtherStoreLessThan15days()
        {
            vinExistsDetails.VehicleInStatus = "101";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-5);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 5)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.AppraisalExistsInOtherStoreLessThan15days);
        }

        [Fact]
        public void CreateAppraisal_Returns_AppraisalExistsInOtherStoreLessThan90days()
        {
            vinExistsDetails.VehicleInStatus = "101";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-30);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 30)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.AppraisalExistsInOtherStoreLessThan90days);
        }

        [Fact]
        public void CreateAppraisal_Returns_AppraisalPendingInSameStore()
        {
            vinExistsDetails.VehicleInStatus = "101";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-100);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 100)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.AppraisalPendingInSameStore);
        }

        [Fact]
        public void CreateAppraisal_Returns_OnHandInSameStore()
        {
            vinExistsDetails.VehicleInStatus = "201";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-100);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 100)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.OnHandInSameStore);
        }

        [Fact]
        public void CreateAppraisal_Returns_OnHandInDiffStore()
        {
            vinExistsDetails.SID = 102;
            vinExistsDetails.VehicleInStatus = "201";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-100);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 100)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.OnHandInDiffStore);
        }

        [Fact]
        public void CreateAppraisal_Returns_OnHandInDiffCompany()
        {
            vinExistsDetails.CID = 20;
            vinExistsDetails.SID = 2001;
            vinExistsDetails.VehicleInStatus = "201";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-100);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 100)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            //Need to change code and test case
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.OnHandInDiffStore);
        }

        [Fact]
        public void CreateAppraisal_With_Status_102_Returns_AppraisalExistsInOtherStoreLessThan15days()
        {
            vinExistsDetails.CID = 20;
            vinExistsDetails.SID = 2001;
            vinExistsDetails.VehicleInStatus = "102";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-5);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 5)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.AppraisalExistsInOtherStoreLessThan15days);
        }

        [Fact]
        public void CreateAppraisal_With_Status_102_Returns_AppraisalExistsInOtherStoreLessThan90days()
        {
            vinExistsDetails.CID = 20;
            vinExistsDetails.SID = 2001;
            vinExistsDetails.VehicleInStatus = "102";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-30);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 30)).Returns(createAppraisalResponse);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.AppraisalExistsInOtherStoreLessThan90days);
        }

        [Fact]
        public void CreateAppraisal_Returns_NewAppraisalDecodeFailure()
        {
            chromeDecodeInfo.IsDecodeSuccess = false;
            vinExistsDetails.CID = 20;
            vinExistsDetails.SID = 2001;
            vinExistsDetails.VehicleInStatus = "102";
            vinExistsDetails.isccaVehicle = true;
            vinExistsDetails.AppraisedDate = System.DateTime.Now.AddDays(-100);
            vehicleInfoRepositoryMock.Setup(p => p.GetVinExistsCheckDetails(basicAppraisalInfo.VIN, basicAppraisalInfo.StoreID, true)).Returns(vinExistsDetails);
            vehicleInfoRepositoryMock.Setup(p => p.CopVehicleDetailsFromSourceToDestination(vinExistsDetails, basicAppraisalInfo, 100)).Returns(createAppraisalResponse);
            chromeServiceMock.Setup(p => p.GetDecodeVIN(vehicleInformation.VIN)).Returns(chromeDecodeInfo);
            IVehicleInfoLogic vehicleInfoLogic = new VehicleInfoLogic(vehicleInfoRepositoryMock.Object, chromeServiceMock.Object, autoCheckCarFaxLogicMock.Object, vehicleInvServiceMock.Object);
            var result = vehicleInfoLogic.CreateAppraisal(basicAppraisalInfo);
            Assert.True(result.CreationStatus == DomainModels.Enums.AppraisalCreationStatus.NewAppraisalDecodeFailure);
        }
    }
}
