﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{
    public class AppraisalLogLogicTest
    {
        private Mock<IAppraisallogRepository> appraisallogRepositoryMock;
        private List<Appraisalloglist> appraisalloglists;

        public AppraisalLogLogicTest()
        {
            appraisallogRepositoryMock = new Mock<IAppraisallogRepository>();
            appraisalloglists = new List<Appraisalloglist>
            {
                new Appraisalloglist{VID=1,SID=1,IID=1,CID=10,AppraisalValue=2000,AppraisedDate=DateTime.Now.AddDays(-100).ToString()},
                new Appraisalloglist{VID=2,SID=1,IID=2,CID=10,AppraisalValue=4000,AppraisedDate=DateTime.Now.AddDays(-150).ToString()}
            };
        }

        [Fact]
        public void GetAppraisalLog_Returns_AppraisalLogList()
        {
            appraisallogRepositoryMock.Setup(p => p.GetAppraisalLog(10, 1, 1)).Returns(appraisalloglists);
            IAppraisallogLogic costInformationLogic = new AppraisalLogLogic(appraisallogRepositoryMock.Object);
            var result = costInformationLogic.GetAppraisalLog(10, 1, 1);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void DeleteAppraisal_Returns_True()
        {
            appraisallogRepositoryMock.Setup(p => p.DeleteAppraisal(10, 1, 1, 10)).Returns(true);
            IAppraisallogLogic costInformationLogic = new AppraisalLogLogic(appraisallogRepositoryMock.Object);
            var result = costInformationLogic.DeleteAppraisal(10, 1, 1, 10);
            Assert.True(result);
        }
    }
}
