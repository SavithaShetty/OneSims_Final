﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomailModels.Enums;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.Infrastructure.PhotoUpload;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{

    public class PhotoLogicTest
    {
        private Mock<IPhotoUploadRepository> photoRepositoryMock;
        private Mock<IPhotoUploadService> photoUploadMock;
        private AnswerWrapper amountdetails;
        private AnswerWrapper amountvalueEmpty;
        VehiclePhotoDetails photoDetails;
        VehiclePhotoDetails marketingphotoDetails;
        private readonly IPhotoUploadService _photouploadservice;
        List<VehiclePhotoDetails> photoDetailslist;
        PhotoPublishParams photoPublishParams;
        MrktCommentParams marktcommentparam;
        long VID;
        short SID;
        short IID;
        int PhotoCat;
        Company CID;
        decimal amount;
        decimal amountEmpty;
        PhotoSourceRequest request;
        public PhotoLogicTest()
        {
            photoRepositoryMock = new Mock<IPhotoUploadRepository>();
            photoUploadMock = new Mock<IPhotoUploadService>();
            VID = 4310980; SID = 101; IID = 1; CID = Company.SU;
            amountdetails = new AnswerWrapper { VID = 14310993, SID = 101, IID = 1, UserName = "test", ReconAmt = 100 };
            amountvalueEmpty = new AnswerWrapper { };
            amount = 1;
            photoDetails = new VehiclePhotoDetails
            {
                VID = 4310980,
                SID = 101,
                IID = 1,
                Created_By = "raju.mahesh",
                CurrStatusId = 101,
                MediaPhotoURL = "",
                MediaThumbnailURL = "",
                PhotoCat = 10,
                PhotoGuide = "odometer",
                PhotoUrl = "",
                Photo_ID = 1234,
                AppraisalPhotos = new List<VehiclePhotoDetails>(),
            };
            marketingphotoDetails = new VehiclePhotoDetails
            {
                Photo_ID = 0,
                AppraisalPhotos = null,
                MarketingPhotoUrl = new List<MarketingPhotoUrl>
  {
       new MarketingPhotoUrl{ PhotoIdentifier ="163aa702-c56e-44de-b733-a2b8fe41fe95",MediaPhotoURL="https=//content.homenetiol.com/~resize-fit.300x225/62ef9995715c4d71a01b661c274ac7cf.jpg",MediaThumbnailURL="https=//content.homenetiol.com/~resize-fit.300x225/62ef9995715c4d71a01b661c274ac7cf.jpg"},
       new MarketingPhotoUrl{ PhotoIdentifier ="163aa702-c56e-44de-b733-a2b8fe41fe95",MediaPhotoURL="https=//content.homenetiol.com/~resize-fit.300x225/62ef9995715c4d71a01b661c274ac7cf.jpg",MediaThumbnailURL="https=//content.homenetiol.com/~resize-fit.300x225/62ef9995715c4d71a01b661c274ac7cf.jpg"}
  },
                MediaPhotoURL = null,
                PhotoType = null,
                ThumbType = null,
                Media_Overlay_URL = null,
                MediaThumbnailURL = null,
                CurrStatusId = 203,
                VID = 0,
                SID = 0,
                IID = 0,
                PhotoCat = null,
                Photo = null,
                ThumbnailPhoto = null,
                Created_By = null,
                PhotoUrl = null,
                PhotoGuide = null,
                IsCloudStorage = false,
                NoOfPhotos = 38,
                NoOfClicks = 0,
                IsMarketReady = true,
                ATClickCount = 0,
                DDCClickCount = 0,
                MarketingComments = "test"
            };

            photoDetailslist = new List<VehiclePhotoDetails>
            {
                new VehiclePhotoDetails
                {
                    VID = 4310980,
                    SID = 101,
                    IID = 1,
                    Created_By = "raju.mahesh",
                    CurrStatusId = 101,
                    MediaPhotoURL = "",
                    MediaThumbnailURL = "",
                    PhotoCat = 10,
                    PhotoGuide = "odometer",
                    PhotoUrl = "",
                    Photo_ID = 1234,
                    AppraisalPhotos = new List<VehiclePhotoDetails>(),
                },
                 new VehiclePhotoDetails
                {
                    VID = 4310980,
                    SID = 101,
                    IID = 1,
                    Created_By = "raju.mahesh",
                    CurrStatusId = 101,
                    MediaPhotoURL = "",
                    MediaThumbnailURL = "",
                    PhotoCat = 10,
                    PhotoGuide = "odometer",
                    PhotoUrl = "",
                    Photo_ID = 1234,
                    AppraisalPhotos = new List<VehiclePhotoDetails>(),
                }

            };
            photoPublishParams = new PhotoPublishParams
            {
                VID = 4310980,
                SID = 101,
                IID = 1,
                CID = Company.SU,
                PublishPhotoIds = "1234,1234"
            };
            marktcommentparam = new MrktCommentParams
            {
                VID = 4310980,
                SID = 101,
                IID = 1,
                CID = Company.SU,
                MrktCommnet = "test"
            };
        }

        [Fact]
        public void GetReconAdditionalAmount_Returns_Amount()
        {
            photoRepositoryMock.Setup(p => p.GetReconAdditionalAmount(VID, SID, IID)).Returns(amount);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.GetReconConditionAdditionalAmount(VID, SID, IID);
            Assert.True(result > 0);
        }
        [Fact]
        public void GetReconAdditionalAmount_Returns_Zero_Amount()
        {
            decimal expected = 0;
            photoRepositoryMock.Setup(p => p.GetReconAdditionalAmount(VID, SID, IID)).Returns(amountEmpty);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.GetReconConditionAdditionalAmount(VID, SID, IID);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void GetAllPhotoData_Returns_photos()
        {
            photoRepositoryMock.Setup(p => p.GetAllPhotoData(VID, SID, IID, CID)).Returns(photoDetails);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.GetAllPhotoData(VID, SID, IID, CID);
            Assert.True(result.DriverSide.Count == 0);
        }

        [Fact]
        public void GetAllPhotoData_Returns_Default_nophotos()
        {
            photoRepositoryMock.Setup(p => p.GetAllPhotoData(VID, SID, IID, CID)).Returns(new VehiclePhotoDetails());
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.GetAllPhotoData(VID, SID, IID, CID);
            Assert.True(result.DriverSide == null);
        }

        [Fact]
        public void SaveReconAmountDetails_Returns_true()
        {
            bool expected = true;
            photoRepositoryMock.Setup(p => p.SaveReconAmountDetails(amountdetails)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.SaveReconAmountDetails(amountdetails);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void SaveReconAmountDetails_Returns_false()
        {
            bool expected = false;
            photoRepositoryMock.Setup(p => p.SaveReconAmountDetails(amountvalueEmpty)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.SaveReconAmountDetails(amountvalueEmpty);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void DeleteApprasialPhoto_Returns_true()
        {
            bool expected = true;
            photoRepositoryMock.Setup(p => p.DeleteSelectedPhoto(VID, SID, IID, DomailModels.Enums.Company.SU, "")).Returns(photoDetails);
            photoUploadMock.Setup(p => p.DeletePhoto(photoDetails)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.DeleteApprasialPhoto(VID, SID, IID, DomailModels.Enums.Company.SU, "");
            Assert.Equal(expected, result);
        }

        [Fact]
        public void DeleteApprasialPhoto_Returns_false()
        {
            bool expected = false;
            photoRepositoryMock.Setup(p => p.DeleteSelectedPhoto(VID, SID, IID, DomailModels.Enums.Company.SU, "")).Returns(new VehiclePhotoDetails());
            photoUploadMock.Setup(p => p.DeletePhoto(photoDetails)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.DeleteApprasialPhoto(VID, SID, IID, DomailModels.Enums.Company.SU, "");
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UploadPhoto_Returns_true()
        {

            bool expected = true;
            photoUploadMock.Setup(p => p.UploadPhoto(request)).Returns(photoDetails);
            photoRepositoryMock.Setup(p => p.UploadPhotoDetails(photoDetails)).Returns(expected);
            photoRepositoryMock.Setup(p => p.SyncPhotoDetails(photoDetails)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.UploadPhoto(request);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void UploadPhoto_Returns_false()
        {
            bool expected = false;
            photoUploadMock.Setup(p => p.UploadPhoto(request)).Returns(photoDetails);
            photoRepositoryMock.Setup(p => p.UploadPhotoDetails(photoDetails)).Returns(expected);
            photoRepositoryMock.Setup(p => p.SyncPhotoDetails(photoDetails)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.UploadPhoto(request);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void GetMarketingPhotosData_Returns_photos()
        {
            photoRepositoryMock.Setup(p => p.GetMarketingPhotosData(VID, SID, IID, CID, PhotoCat)).Returns(marketingphotoDetails);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.GetMarketingPhotos(VID, SID, IID, CID, PhotoCat);
            Assert.True(result.MarketingPhotoUrl.Count >= 0);
        }

        [Fact]
        public void GetMarketingPhotosData_Returns_Default_nophotos()
        {
            photoRepositoryMock.Setup(p => p.GetMarketingPhotosData(VID, SID, IID, CID, PhotoCat)).Returns(new VehiclePhotoDetails());
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.GetMarketingPhotos(VID, SID, IID, CID, PhotoCat);
            Assert.True(result.MarketingPhotoUrl==null);
        }

        [Fact]
        public void DeletePhotos_Returns_true()
        {
            bool expected = true;
            photoRepositoryMock.Setup(p => p.DeletePhotos(VID, SID, IID, DomailModels.Enums.Company.SU, "")).Returns(photoDetailslist);
            photoUploadMock.Setup(p => p.DeleteselectedPhoto(photoDetailslist)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.DeletePhotos(VID, SID, IID, DomailModels.Enums.Company.SU, "");
            Assert.Equal(expected, result);
        }

        [Fact]
        public void DeletePhotos_Returns_false()
        {
            bool expected = false;
            photoRepositoryMock.Setup(p => p.DeletePhotos(VID, SID, IID, DomailModels.Enums.Company.SU, "")).Returns(new List<VehiclePhotoDetails>());
            photoUploadMock.Setup(p => p.DeleteselectedPhoto(photoDetailslist)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.DeletePhotos(VID, SID, IID, DomailModels.Enums.Company.SU, "");
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdatePhotostoPublish_Returns_true()
        {
            bool expected = true;
            photoRepositoryMock.Setup(p => p.UpdatePhotostoPublish(photoPublishParams)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.UpdatePhotostoPublish(photoPublishParams);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdatePhotostoPublish_Returns_false()
        {
            bool expected = false;
            photoRepositoryMock.Setup(p => p.UpdatePhotostoPublish(photoPublishParams)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.UpdatePhotostoPublish(photoPublishParams);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdateMarketText_Returns_true()
        {
            bool expected = true;
            photoRepositoryMock.Setup(p => p.UpdateMarketText(marktcommentparam)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.UpdateMarketText(marktcommentparam);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void UpdateMarketText_Returns_false()
        {
            bool expected = false;
            photoRepositoryMock.Setup(p => p.UpdateMarketText(marktcommentparam)).Returns(expected);
            IReconPhotoLogic photoLogic = new ReconPhotoLogic(photoRepositoryMock.Object, photoUploadMock.Object);
            var result = photoLogic.UpdateMarketText(marktcommentparam);
            Assert.Equal(expected, result);
        }
    }
}
