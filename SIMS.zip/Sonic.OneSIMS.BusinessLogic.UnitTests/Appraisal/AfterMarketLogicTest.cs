﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{
    public class AfterMarketLogicTest
    {
        private Mock<IAfterMarketRepository> afterMarketRepositoryMock;
        private AMFO amfo;
        private AMFO amfoEmpty;
        private List<AfterMarketQuestions> afterMarketQuestions;
        public AfterMarketLogicTest()
        {
            afterMarketRepositoryMock = new Mock<IAfterMarketRepository>();
            afterMarketQuestions = new List<AfterMarketQuestions>
            {
                new AfterMarketQuestions { Id = 1, Description = "Comments", Selected = true, Comments = "test" },
                new AfterMarketQuestions { Id = 2, Description = "Bumpers and/or Winch", Selected = true, Comments = "test" },
                new AfterMarketQuestions { Id = 3, Description = "Vehicle Lifted or Lowered", Selected = true, Comments = "test" },
                new AfterMarketQuestions { Id = 4, Description = "Wheels and/or Tires SIMS", Selected = true, Comments = "test" }
            };

            amfo = new AMFO
            {
                VehicleIdentity = new DomailModels.Common.VehicleIdentity { VID = 14310993, SID = 101, IID = 1, CID = DomailModels.Enums.Company.SU },
                AfterMarketQuestions = afterMarketQuestions,
                UserName = "Test"
            };
            amfoEmpty = new AMFO { };
            amfoEmpty = new AMFO
            {
                VehicleIdentity = new DomailModels.Common.VehicleIdentity { VID = 0, SID = 0, IID = 0, CID = DomailModels.Enums.Company.SU },
                AfterMarketQuestions = afterMarketQuestions,
                UserName = "Test"
            };

        }

        [Fact]
        public void AddAfterMarketAnswers_Returns_True()
        {
            bool expected = true;
            afterMarketRepositoryMock.Setup(p => p.AddAfterMarketAnswers(amfo)).Returns(expected);
            IAfterMarketLogic afterMarketLogic = new AfterMarketLogic(afterMarketRepositoryMock.Object);
            var result = afterMarketLogic.AddAfterMarketAnswers(amfo);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void AddHistory_Returnss_False()
        {
            bool expected = false;
            afterMarketRepositoryMock.Setup(p => p.AddAfterMarketAnswers(amfoEmpty)).Returns(expected);
            IAfterMarketLogic afterMarketLogic = new AfterMarketLogic(afterMarketRepositoryMock.Object);
            var result = afterMarketLogic.AddAfterMarketAnswers(amfoEmpty);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void GetAfterMarketQuestions_Returns_Questions()
        {
            afterMarketRepositoryMock.Setup(p => p.GetAfterMarketQuestions(1, 1, 1)).Returns(afterMarketQuestions);
            IAfterMarketLogic afterMarketLogic = new AfterMarketLogic(afterMarketRepositoryMock.Object);
            var result = afterMarketLogic.GetAfterMarketQuestions(1, 1, 1);
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetAfterMarketQuestions_Returns_Empty_Questions()
        {
            afterMarketRepositoryMock.Setup(p => p.GetAfterMarketQuestions(1, 1, 1)).Returns(new List<AfterMarketQuestions>());
            IAfterMarketLogic afterMarketLogic = new AfterMarketLogic(afterMarketRepositoryMock.Object);
            var result = afterMarketLogic.GetAfterMarketQuestions(1, 1, 1);
            Assert.True(result.Count == 0);
        }
    }
}
