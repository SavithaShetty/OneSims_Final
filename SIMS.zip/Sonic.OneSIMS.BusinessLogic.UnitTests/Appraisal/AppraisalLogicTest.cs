﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{
    public class AppraisalLogicTest
    {
        private Mock<IAppraisalRepository> appraisalRepositoryMock;
        private SyncVehicleDetails syncVehicleDetails;
        private SyncVehicleDetails syncVehicleDetails1;

        public AppraisalLogicTest()
        {
            appraisalRepositoryMock = new Mock<IAppraisalRepository>();
            syncVehicleDetails = new DomainModels.Appraisal.SyncVehicleDetails
            {
                VID = 1,
                SID = 1,
                CID = 10,
                IID = 1,
                username = "Test",
                sectionIdentifier = DomainModels.Enums.CCASyncIdentifier.ALL
            };

            syncVehicleDetails1 = new DomainModels.Appraisal.SyncVehicleDetails
            {
                VID = 1,
                SID = 1,
                CID = 10,
                IID = 1,
                username = "Test",
                sectionIdentifier = DomainModels.Enums.CCASyncIdentifier.BOOKS
            };

            
        }

        public static IEnumerable<object[]> resubmitVehicleData =>
       new List<object[]>
       {
            new object[] { new ResubmitVehicleDetails
            {
                VID = 1,
                SID = 1,
                CID = 10,
                IID = 1,
                username = "Test",
            }, true },
            new object[] { new ResubmitVehicleDetails
            {
                VID = 1,
                SID = 1,
                CID = 10,
                IID = 1,
                username = "Test",
            }, false }
       };

        public static IEnumerable<object[]> UpdateVehicleStatusReqData =>
       new List<object[]>
       {
            new object[] { new UpdateVehicleStatusReq
            {
                VID = 1,
                SID = 1,
                CID = 10,
                IID = 1,
                username = "Test",
                ExperienceGuide = true,
                VehicleSrc = 10
            }, true },
            new object[] { new UpdateVehicleStatusReq
            {
                VID = 1,
                SID = 1,
                CID = 10,
                IID = 1,
                username = "Test",
                ExperienceGuide = false,
                VehicleSrc = 10
            }, false }
       };

        [Fact]
        public void SyncVehicleDetails_Returns_True_ForAllSections()
        {
            bool expected = true;
            appraisalRepositoryMock.Setup(p => p.SyncAllVehicleDetails(syncVehicleDetails.VID, syncVehicleDetails.SID, syncVehicleDetails.IID, syncVehicleDetails.CID, syncVehicleDetails.username)).Returns(expected);
            IAppraisalLogic manheimLogic = new AppraisalLogic(appraisalRepositoryMock.Object);
            var result = manheimLogic.SyncVehicleDetails(syncVehicleDetails);
            Assert.Equal(expected, result);

        }

        [Fact]
        public void SyncVehicleDetails_Returns_True_ForBooksSections()
        {
            bool expected = true;
            appraisalRepositoryMock.Setup(p => p.SyncAllVehicleDetails(syncVehicleDetails1.VID, syncVehicleDetails1.SID, syncVehicleDetails1.IID, syncVehicleDetails1.CID, syncVehicleDetails1.username)).Returns(expected);
            IAppraisalLogic manheimLogic = new AppraisalLogic(appraisalRepositoryMock.Object);
            var result = manheimLogic.SyncVehicleDetails(syncVehicleDetails);
            Assert.Equal(expected, result);

        }

        [Theory, MemberData(nameof(resubmitVehicleData))]
        public void ResubmitVehicleDetails_Returns_TrueOrFalse(ResubmitVehicleDetails resubmitVehicleDetail, bool expected)
        {
            appraisalRepositoryMock.Setup(p => p.ResubmitVehicleDetails(resubmitVehicleDetail)).Returns(expected);
            IAppraisalLogic manheimLogic = new AppraisalLogic(appraisalRepositoryMock.Object);
            var result = manheimLogic.ResubmitVehicleDetails(resubmitVehicleDetail);
            Assert.Equal(expected, result);
        }

        [Theory, MemberData(nameof(UpdateVehicleStatusReqData))]
        public void UpdateVehicleStatus_Returns_TrueOrFalse(UpdateVehicleStatusReq updateVehicleStatus, bool expected)
        {
            appraisalRepositoryMock.Setup(p => p.UpdateVehicleStatus(updateVehicleStatus)).Returns(expected);
            IAppraisalLogic manheimLogic = new AppraisalLogic(appraisalRepositoryMock.Object);
            var result = manheimLogic.UpdateVehicleStatus(updateVehicleStatus);
            Assert.Equal(expected, result);
        }
    }
}
