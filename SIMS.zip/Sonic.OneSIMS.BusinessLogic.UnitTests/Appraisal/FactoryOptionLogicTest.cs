﻿using Microsoft.Extensions.Options;
using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.Infrastructure.Chrome;
using Sonic.OneSIMS.Infrastructure.Chrome.Entities;
using System.Collections.Generic;
using System.Data;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{
    public class FactoryOptionLogicTest
    {
        private Mock<IFactoryOptionsRepository> factoryOptionsRepositoryMock;
        private Mock<IChromeService> chromeServiceMock;
        private Mock<IOptions<Framework.Configuration.Settings>> settingsMock;

        long VID;
        short SID;
        short IID;
        short CID;
        string InServiceDate;
        int TrimId;
        decimal MSRP;
        string VIN;
        VehicleFactoryOptions vehicleFactoryOptions;
        List<DomainModels.Appraisal.FactoryOptions> lstFactoryOptions;
        List<FactoryOptionsVDP> factoryOptionsVDPs;
        ChromeDecodeInfo chromeDecode;
        DataTable dt;

        public FactoryOptionLogicTest()
        {
            factoryOptionsRepositoryMock = new Mock<IFactoryOptionsRepository>();
            chromeServiceMock = new Mock<IChromeService>();
            settingsMock = new Mock<IOptions<Framework.Configuration.Settings>>();

            VID = 4310980; SID = 101; IID = 1; CID = 10; InServiceDate = "2014-09-24 00:00:00.000";
            TrimId = 349799; MSRP = 0; VIN = "5XYKT3A69DG353356";
            chromeDecode = new ChromeDecodeInfo();
            chromeDecode.FactoryOptions = new List<Infrastructure.Chrome.Entities.FactoryOptions>
            {
             new Infrastructure.Chrome.Entities.FactoryOptions
             {
             Description="CONVENIENCE PKG",
             InstalledCause="OptionCodeBuild",
             OemCode="CPK",
             OptionKindId="2",
             Price=2000,
             StyleId = new int[] {349799 },
             Utf="M",
             Vehicle_src=0,
             optionid="359845"
             }
            };

            lstFactoryOptions = new List<DomainModels.Appraisal.FactoryOptions>();

            factoryOptionsVDPs = new List<FactoryOptionsVDP>
            {
                new FactoryOptionsVDP
                {
                    OptionKindId="27",
                    name="CHARCOAL, LEATHER-APPOINTED SEAT TRIM",
                    value=0
                }
            };

            vehicleFactoryOptions = new VehicleFactoryOptions
            {
                VID = 4310980,
                SID = 101,
                IID = 1,
                InServiceDate = "2014-09-24 00:00:00.000",
                UserName = "raju.mahesh",
                Options = new List<GroupedFactoryOptionList>
                {
                    new GroupedFactoryOptionList
                    {
                        factoryOptions = lstFactoryOptions,
                        Header = "test"
                    }
                }
            };

            dt = new DataTable("Obj_Factory_Options");
            dt.Columns.Add("OptionKindID", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("MSRP", typeof(decimal));
            dt.Columns.Add("OEMCode", typeof(string));
            dt.Columns.Add("StyleID", typeof(int));
            dt.Columns.Add("OptionID", typeof(string));

        }

        [Fact]
        public void GetFactoryOptions_WhenChromeDecode_Is_True()
        {
            factoryOptionsRepositoryMock.Setup(p => p.GetFactoryOptions(VID, SID, IID, CID, ref InServiceDate, ref TrimId, ref MSRP)).Returns(lstFactoryOptions);
            chromeServiceMock.Setup(p => p.GetDecodeVIN(VIN)).Returns(chromeDecode);
            IFactoryOptionLogic factoryOptionLogic = new FactoryOptionLogic(factoryOptionsRepositoryMock.Object, settingsMock.Object, chromeServiceMock.Object);
            var result = factoryOptionLogic.GetFactoryOptions(VIN, VID, SID, IID, CID, true);
            Assert.True(result.Options.Count > 0);
        }

        [Fact]
        public void GetFactoryOptions_WhenChromeDecode_Is_False()
        {
            var serviceDate = It.IsAny<string>();
            var trim = It.IsAny<int>();
            var msrp = It.IsAny<decimal>();
            factoryOptionsRepositoryMock.Setup(p => p.GetFactoryOptions(VID, SID, IID, CID, ref serviceDate, ref trim, ref msrp)).Returns(lstFactoryOptions);
            chromeServiceMock.Setup(p => p.GetDecodeBadVIN(trim.ToString())).Returns(chromeDecode);
            IFactoryOptionLogic factoryOptionLogic = new FactoryOptionLogic(factoryOptionsRepositoryMock.Object, settingsMock.Object, chromeServiceMock.Object);
            var result = factoryOptionLogic.GetFactoryOptions(VIN, VID, SID, IID, CID, false);
            Assert.True(result.Options.Count > 0);
        }

        [Fact]
        public void GetSavedFactoryOptions_Returns_Options()
        {
            var serviceDate = It.IsAny<string>();
            serviceDate = "";
            var trim = It.IsAny<int>();
            var msrp = It.IsAny<decimal>();
            factoryOptionsRepositoryMock.Setup(p => p.GetSavedFactoryOptions(VID, SID, IID, CID, ref serviceDate, ref trim, ref msrp)).Returns(factoryOptionsVDPs);
            IFactoryOptionLogic factoryOptionLogic = new FactoryOptionLogic(factoryOptionsRepositoryMock.Object, settingsMock.Object, chromeServiceMock.Object);
            var result = factoryOptionLogic.GetSavedFactoryOptions(VID, SID, IID, CID);
            Assert.True(result.Options.Count > 1);
        }

        [Fact]
        public void GetSavedFactoryOptions_Returns_Default_Option()
        {
            var serviceDate = It.IsAny<string>();
            serviceDate = "";
            var trim = It.IsAny<int>();
            var msrp = It.IsAny<decimal>();
            factoryOptionsRepositoryMock.Setup(p => p.GetSavedFactoryOptions(VID, SID, IID, CID, ref serviceDate, ref trim, ref msrp)).Returns(new List<FactoryOptionsVDP>());
            IFactoryOptionLogic factoryOptionLogic = new FactoryOptionLogic(factoryOptionsRepositoryMock.Object, settingsMock.Object, chromeServiceMock.Object);
            var result = factoryOptionLogic.GetSavedFactoryOptions(VID, SID, IID, CID);
            Assert.True(result.Options.Count == 1);
        }

        [Fact]
        public void SaveFactoryOptions_Returns_False()
        {
            bool expected = false;
            factoryOptionsRepositoryMock.Setup(p => p.SaveFactoryOptions(vehicleFactoryOptions, dt)).Returns(expected);
            IFactoryOptionLogic factoryOptionLogic = new FactoryOptionLogic(factoryOptionsRepositoryMock.Object, settingsMock.Object, chromeServiceMock.Object);
            var result = factoryOptionLogic.SaveFactoryOptions(vehicleFactoryOptions);
            Assert.Equal(expected, result);
        }
    }
}
