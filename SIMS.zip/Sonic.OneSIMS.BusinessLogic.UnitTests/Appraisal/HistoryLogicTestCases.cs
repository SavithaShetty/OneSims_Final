﻿using Moq;
using Sonic.OneSIMS.BusinessLogic.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DataAccess.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System;
using System.Collections.Generic;
using Xunit;

namespace Sonic.OneSIMS.BusinessLogic.UnitTests.Appraisal
{
    public class HistoryLogicTestCases
    {
        private Mock<IHistoryRepository> historyRepositoryMock;
        private HistoryAnswers hisoryAnswers;
        private HistoryAnswers hisoryAnswersEmpty;
        List<HistoryQuestions> historyQuestions;
        List<HistoryQuestions> historyQuestionsEmpty;
        public HistoryLogicTestCases()
        {
            historyRepositoryMock = new Mock<IHistoryRepository>();
            historyQuestions = new List<HistoryQuestions>
            {
                new HistoryQuestions{ QuestionId ="qp/82", QuestionType="boolean" , Description=  "Do you have a free and clear title? Select “No” if your vehicle is leased or financed." ,Answer ="No" },
                new HistoryQuestions{ QuestionId ="qp/79", QuestionType="Boolean" , Description=  "Are 2 sets of keys and alarm pad (if applicable) available?" ,Answer ="No" },
                new HistoryQuestions{ QuestionId ="qp/76/amount", QuestionType="Integer" , Description=  "How much were the total claims?" ,Answer ="" },
                new HistoryQuestions{ QuestionId ="qp/76", QuestionType="Boolean" , Description=  "Has an insurance claim ever been filed on this vehicle?" ,Answer ="No" }
    };
            historyQuestionsEmpty = new List<HistoryQuestions>
            {
                
    };
            hisoryAnswers = new HistoryAnswers
            {
                VehicleIdentity = new DomailModels.Common.VehicleIdentity { VID = 4310993, SID = 101, IID = 1, CID = DomailModels.Enums.Company.SU },
                HistoryQuestions = historyQuestions,
                UserName = "Test"
            };

            hisoryAnswersEmpty = new HistoryAnswers
            {
                VehicleIdentity = new DomailModels.Common.VehicleIdentity { VID = 0, SID = 0, IID = 0, CID = DomailModels.Enums.Company.SU },
                HistoryQuestions = historyQuestions,
                UserName = "Test"
            };

        }

        [Fact]
        public void AddHistory_Returns_True()
        {
            bool expected = true;
            historyRepositoryMock.Setup(p => p.AddHistoryAnswers(hisoryAnswers)).Returns(expected);
            IHistoryLogic historyLogic = new HistoryLogic(historyRepositoryMock.Object);
            var result = historyLogic.AddHistoryAnswers(hisoryAnswers);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void AddHistory_Returnss_False()
        {
            bool expected = false;
            historyRepositoryMock.Setup(p => p.AddHistoryAnswers(hisoryAnswersEmpty)).Returns(expected);
            IHistoryLogic historyLogic = new HistoryLogic(historyRepositoryMock.Object);
            var result = historyLogic.AddHistoryAnswers(hisoryAnswersEmpty);
            Assert.Equal(expected, result);
        }
        [Fact]
        public void GetHistoryQuestions_Returns_Questions()
        {
            historyRepositoryMock.Setup(p => p.GetVehicleHistoryQuestions(hisoryAnswers.VehicleIdentity.VID, Convert.ToInt16(hisoryAnswers.VehicleIdentity.SID), Convert.ToInt16(hisoryAnswers.VehicleIdentity.IID))).Returns(historyQuestions);
            IHistoryLogic historyLogic = new HistoryLogic(historyRepositoryMock.Object);
            var result = historyLogic.GetVehicleHistoryQuestions(hisoryAnswers.VehicleIdentity.VID, Convert.ToInt16(hisoryAnswers.VehicleIdentity.SID), Convert.ToInt16(hisoryAnswers.VehicleIdentity.IID));
            Assert.True(result.Count > 0);
        }

        [Fact]
        public void GetAfterMarketQuestions_Returns_Empty_Questions()
        {
            historyRepositoryMock.Setup(p => p.GetVehicleHistoryQuestions(0, 0, 0)).Returns(historyQuestionsEmpty);
            IHistoryLogic historyLogic = new HistoryLogic(historyRepositoryMock.Object);
            var result = historyLogic.GetVehicleHistoryQuestions(0,0,0);
            Assert.True(result.Count == 0);
        }
    }
}
