using Newtonsoft.Json;
using Sonic.KBB.Api.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.KBB.Api.IntegrationTests
{
    public class KBBTest : IClassFixture<CustomWebApplicationFactory<Startup>>
    {
        private readonly HttpClient _client;
        public KBBTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
            var byteArray = Encoding.ASCII.GetBytes("Test1:Test1");
            _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

        }

        [Trait("Category", "YearList")]
        [Fact(DisplayName = "Successful")]
        public async Task YearsList_Successful()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/years?RequestSource=SIMS");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<YearResponse> yearsList = JsonConvert.DeserializeObject<List<YearResponse>>(stringResponse);
            Assert.Contains(yearsList, x => x.yearId == 2020);
        }

        [Trait("Category", "Make")]
        [Fact(DisplayName = "Successful")] 
        public async Task GetMakes_Returns_ListOfMakes()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/makes?RequestSource=SIMS&YearId=2020");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
             
            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();           
            List<MakeResponse> makeRes = JsonConvert.DeserializeObject<List<MakeResponse>>(stringResponse);
            Assert.Contains(makeRes, x=>x.makeId == 2);
        }

        [Trait("Category", "Make")]
        [Fact(DisplayName = "No data returned")]
        public async Task GetMakes_ReturnsNo_ListOfMakes()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/makes?RequestSource=SIMS&YearId=25252");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode(); 

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<MakeResponse> makeRes = JsonConvert.DeserializeObject<List<MakeResponse>>(stringResponse);
            Assert.Empty(makeRes);
        }

        [Trait("Category", "Model")]
        [Fact(DisplayName = "Successful")]
        public async Task GetModel_Returns_ListOfMakes()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/models?RequestSource=SIMS&YearId=2020&MakeId=2");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<ModelResponse> modelRes = JsonConvert.DeserializeObject<List<ModelResponse>>(stringResponse);
            Assert.Contains(modelRes, x => x.modelId == 30207);
        }

        [Trait("Category", "Model")]
        [Fact(DisplayName = "No data returned")]
        public async Task GetModel_ReturnsNo_ListOfMakes()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/models?RequestSource=SIMS&YearId=2020&MakeId=2202");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<ModelResponse> modelRes = JsonConvert.DeserializeObject<List<ModelResponse>>(stringResponse);
            Assert.Empty(modelRes);
        }
        [Trait("Category", "ModelYear")]
        [Fact(DisplayName = "Successful")]
        public async Task GetModelYear_Returns_ModelYear()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/modelyears?RequestSource=SIMS&YearId=2020&MakeId=2&ModelId=30207");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<ModelYearResponse> modelRes = JsonConvert.DeserializeObject<List<ModelYearResponse>>(stringResponse);
            Assert.Contains(modelRes, x => x.modelYearId == 113223);
        }

        [Trait("Category", "ModelYear")]
        [Fact(DisplayName = "No data returned")]
        public async Task GetModelYear_ReturnsNo_ModelYear()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/modelyears?RequestSource=SIMS&YearId=2020&MakeId=2&ModelId=30207231");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<ModelYearResponse> modelRes = JsonConvert.DeserializeObject<List<ModelYearResponse>>(stringResponse);
            Assert.Empty(modelRes);
        }

        [Trait("Category", "Trim")]
        [Fact(DisplayName = "Successful")]
        public async Task GetTrim_Returns_ListOfTrim()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetTrim?RequestSource=SIMS&YearId=2020&MakeId=2&ModelId=30207&ModelYearID=113223");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<TrimResponse> trimRes = JsonConvert.DeserializeObject<List<TrimResponse>>(stringResponse);
            Assert.Contains(trimRes, x => x.trimId == 355807);
        }

        [Trait("Category", "Trim")]
        [Fact(DisplayName = "No data returned")]
        public async Task GetTrim_ReturnsNo_ListOfTrim()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetTrim?RequestSource=SIMS&YearId=2020&MakeId=2&ModelId=30207&ModelYearID=113223542");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<TrimResponse> trimRes = JsonConvert.DeserializeObject<List<TrimResponse>>(stringResponse);
            Assert.Empty(trimRes);
        }

        [Trait("Category", "DecodeVIN")]
        [Fact(DisplayName = "Successful")]
        public async Task DecodeVIN_Successful_Decode()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/DecodeVIN?RequestSource=SIMS&VIN=SALVR2BG9EH935410");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            DecodeResponse decodeRes = JsonConvert.DeserializeObject<DecodeResponse>(stringResponse);
            Assert.Contains(decodeRes.vinResults, x=>x.makeId == 26);
        }

        [Trait("Category", "DecodeVIN")]
        [Fact(DisplayName = "Failure")]
        public async Task DecodeVIN_Failure_Decode()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/DecodeVIN?RequestSource=SIMS&VIN=SA88R2BG999936410");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            DecodeResponse decodeRes = JsonConvert.DeserializeObject<DecodeResponse>(stringResponse);
            Assert.Empty(decodeRes.vinResults);
        }
        [Trait("Category", "Options")]
        [Fact(DisplayName ="Factory Options - Successful")]
        public async Task Options_Successful_Options()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetEquipmentOptionsByVehicleId?RequestSource=SIMS&VehicleId=6743&AppCategory=0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<VehOptionsResponse> optionRes = JsonConvert.DeserializeObject<List<VehOptionsResponse>>(stringResponse);
            Assert.Contains(optionRes, x => x.optionType == "Option");
        }

        [Trait("Category", "Options")]
        [Fact(DisplayName = "Factory Options - Failure")]
        public async Task Options_Failure_Options()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetEquipmentOptionsByVehicleId?RequestSource=SIMS&VehicleId=6742423&AppCategory=0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<VehOptionsResponse> optionRes = JsonConvert.DeserializeObject<List<VehOptionsResponse>>(stringResponse);
            Assert.Empty(optionRes);
        }

        [Trait("Category", "Options")]
        [Fact(DisplayName = "Engines - Successful")]
        public async Task Engines_Successful_Engines()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetEquipmentOptionsByVehicleId?RequestSource=SIMS&VehicleId=6743&AppCategory=0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<VehOptionsResponse> optionRes = JsonConvert.DeserializeObject<List<VehOptionsResponse>>(stringResponse);
            Assert.Contains(optionRes, x => x.optionType == "Equipment" && x.categoryName=="Engine");
        }


        [Trait("Category", "Options")]
        [Fact(DisplayName = "Transmission - Successful")]
        public async Task Transmission_Successful_Options()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetEquipmentOptionsByVehicleId?RequestSource=SIMS&VehicleId=6743&AppCategory=0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<VehOptionsResponse> optionRes = JsonConvert.DeserializeObject<List<VehOptionsResponse>>(stringResponse);
            Assert.Contains(optionRes, x => x.optionType == "Equipment" && x.categoryName == "Transmission");
        }

        [Trait("Category", "Options")]
        [Fact(DisplayName = "DriveTrain - Successful")]
        public async Task DriveTrain_Successful_Options()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB        
            var httpResponse = await _client.GetAsync("/api/v1/KBB/GetEquipmentOptionsByVehicleId?RequestSource=SIMS&VehicleId=6743&AppCategory=0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<VehOptionsResponse> optionRes = JsonConvert.DeserializeObject<List<VehOptionsResponse>>(stringResponse);
            Assert.Contains(optionRes, x => x.optionType == "Equipment" && x.categoryName == "Drivetrain");
        }


        [Trait("Category", "Books")]
        [Fact(DisplayName = "1. ApplyConfiguration -- Consuming for the first time - Successful")]
        public async Task ApplyConfiguration_Successful_Books()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB  
            ApplyConfigRequet applyConfig = new ApplyConfigRequet();
            applyConfig.StartingConfiguration.VehicleId = 434436;

            string applyConfigBody = JsonConvert.SerializeObject(applyConfig);
            _client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            System.Net.Http.HttpContent content = new StringContent(applyConfigBody.ToString(), Encoding.UTF8, "application/json");
            var httpResponse = await _client.PostAsync("/api/v1/KBB/Applyconfiguration", content);

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            ApplyConfigResponse applyConfigRes = JsonConvert.DeserializeObject<ApplyConfigResponse>(stringResponse);
            Assert.Contains(applyConfigRes.finalConfiguration.vehicleOptionIds, x => x == 8284342);
        }

        [Trait("Category", "Books")]
        [Fact(DisplayName = "2. ApplyConfiguration -- Subsequent consuming - Successful")]
        public async Task ApplyConfiguration_SecondTime_Successful_Books()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB  
            ApplyConfigRequet applyConfig = new ApplyConfigRequet();
            applyConfig.StartingConfiguration.VehicleId = 434436;
            List<int> vehOptIds = new List<int>() {  8284342,8284343,8284345,8284347,8284348,
            8284349,8284350,8284353,8284354,8284355,8284358,8284359,8284360,8284361,8284362,
            8284364,8284365,8284366,8284367,8284368,8284369,8284370,8284371,8284372,8284373,
            8284374,8284375,8284376,8284377,8284382,8284384,8284386,8284389,8284392};
            applyConfig.StartingConfiguration.vehicleOptionIds = vehOptIds.ToArray();
            applyConfig.ConfigurationChanges.Add(new ConfigurationChange() { VehicleOptionId = 8284343, Sequence = 1, Action = "deselected" });
            string applyConfigBody = JsonConvert.SerializeObject(applyConfig);
            _client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            System.Net.Http.HttpContent content = new StringContent(applyConfigBody.ToString(), Encoding.UTF8, "application/json");
            var httpResponse = await _client.PostAsync("/api/v1/KBB/Applyconfiguration", content);

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            ApplyConfigResponse applyConfigRes = JsonConvert.DeserializeObject<ApplyConfigResponse>(stringResponse);
            Assert.Contains(applyConfigRes.finalConfiguration.vehicleOptionIds, x => x == 8284342);
        }

        [Trait("Category", "Books")]
        [Fact(DisplayName = "BookValues -- Successful")]
        public async Task BookValues_Successful_Books()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB  
            BookValuesRequest bookReq = new BookValuesRequest();
            bookReq.Mileage= 24025;
            bookReq.zipcode = 75243;
            bookReq.ValuationDate = DateTime.Today.AddDays(-1);
            bookReq.Configuration.VehicleId = 433871;
            List<int> vehOptIds = new List<int>() {   8284342,
            8284343,8284345,8284347,8284348,8284349,8284350,8284353,8284354,
            8284355,8284358,8284359,8284360,8284361,8284362,8284364,8284365,8284366,8284367,
            8284368,8284369,8284370,8284371,8284372,8284373,8284374,8284375,8284376,8284377,
            8284382,8284384,8284386,8284389,8284392};
            bookReq.Configuration.VehicleOptionIds = vehOptIds.ToArray();

            string bookReqBody = JsonConvert.SerializeObject(bookReq);
            _client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            System.Net.Http.HttpContent content = new StringContent(bookReqBody.ToString(), Encoding.UTF8, "application/json");
            var httpResponse = await _client.PostAsync("/api/v1/KBB/bookvalues", content);

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            BookResponse applyConfigRes = JsonConvert.DeserializeObject<BookResponse>(stringResponse);
            Assert.Contains(applyConfigRes.prices, x => x.priceTypeId == 2);
        }

        [Trait("Category", "Books")]
        [Fact(DisplayName = "BookValues -- Failure")]
        public async Task BookValues_Failure_Books()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/KBB  
            BookValuesRequest bookReq = new BookValuesRequest();
            bookReq.Mileage = 24025;
            bookReq.zipcode = 75243;
            bookReq.ValuationDate = DateTime.Today.AddDays(-1);
            bookReq.Configuration.VehicleId = 433871345;
            List<int> vehOptIds = new List<int>() {   8284342,
            8284343,8284345,8284347,8284348,8284349,8284350,8284353,8284354,
            8284355,8284358,8284359,8284360,8284361,8284362,8284364,8284365,8284366,8284367,
            8284368,8284369,8284370,8284371,8284372,8284373,8284374,8284375,8284376,8284377,
            8284382,8284384,8284386,8284389,8284392};
            bookReq.Configuration.VehicleOptionIds = vehOptIds.ToArray();

            string bookReqBody = JsonConvert.SerializeObject(bookReq);
            _client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            System.Net.Http.HttpContent content = new StringContent(bookReqBody.ToString(), Encoding.UTF8, "application/json");
            var httpResponse = await _client.PostAsync("/api/v1/KBB/bookvalues", content);

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            BookResponse applyConfigRes = JsonConvert.DeserializeObject<BookResponse>(stringResponse);
            Assert.Empty(applyConfigRes.prices);
        }

        public void Dispose()
        {
            _client.Dispose();
        }
    }
}
