﻿using Moq;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.DomailModels.Settings;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sonic.OneSIMS.Api.IntegrationTests.MockRepository
{
    public class  MockStoreRepository: Mock<IStoreRepository>
    {
        public MockStoreRepository MockGetByID(Store results)
        {
            Setup(x => x.GetStoreById(It.IsAny<int>()))
                .Returns(results);

            return this;
        }
    }
}
