﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.OneSIMS.Api.IntegrationTests.Appraisal
{
    public  class HistoryTest : IClassFixture<CustomWebApplicationFactory<Startup>>
    {
        private readonly HttpClient _client;
        public HistoryTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
        }

        [Fact]
        public async Task GetHistoryQuestion()
        {
            // The endpoint or route of the controller action.
            
            var httpResponse = await _client.GetAsync("/api/History/GetHistoryQuestions/1/101/1/JTHBE1KS0A0050265/Naveen");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            //var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            //var stores = JsonConvert.DeserializeObject<IEnumerable<AppraisalProfile>>(stringResponse);
            //Assert.Contains(stores, s => s.VehicleID == 1);
            //Assert.Contains(stores, s => s.StoreName == "Acura of Serramonte");
        }
    }
}
