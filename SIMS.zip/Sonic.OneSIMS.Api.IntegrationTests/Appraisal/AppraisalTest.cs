﻿using Newtonsoft.Json;
using Sonic.OneSIMS.Api.IntegrationTests.Helper;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Common;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.OneSIMS.Api.IntegrationTests.Appraisal
{
    public class AppraisalTest : IClassFixture<CustomWebApplicationFactory<Startup>>
    {
        private readonly HttpClient _client;
        public AppraisalTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
        }
        [Fact]
        public async Task GetAppraisalProfile()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/GetAppraisalProfile?VehicleID=1&SotreID=101&InvtrID=1");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            //var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            //var stores = JsonConvert.DeserializeObject<IEnumerable<AppraisalProfile>>(stringResponse);
            //Assert.Contains(stores, s => s.VehicleID == 1);
            //Assert.Contains(stores, s => s.StoreName == "Acura of Serramonte");
        }
        [Fact]
        public async Task SaveVehicleInfo()
        {
            // Arrange
            var request = new
            {
                Url = "/api/VehicleInfo/CreateAppaisal",
                Body = new
                {
                    vin = "1GCWGGFA5E1186070",
                    customerFirstName = "test",
                    customerLastName = "test1",
                    vehicleSrc = 10,
                    isSalesPerson = false,
                    storeID = 101,
                    laneID = 0,
                    kioskReq = false,
                    serviceAppraisalDate = "2021-05-16T19:24:02.633Z"
                }
            };

            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();

            // Assert
            response.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task SaveVehicleDetails()
        {
            // Arrange
            var request = new
            {
                Url = "/api/VehicleInfo/SaveVehicleInformation",
                Body = new
                {
                    VIN = "1GCWGGFA5E1186070",
                    VehicleID = 11,
                    StoreID = 101,
                    InvtrID = 1,
                    Mileage = 4000,
                    Year=new IDValues {ID="2009",Value="2009" },
                    Make=new IDValues {ID="16",Value= "Honda" },
                    Engine=new IDValues {Value= "2.4 Liter 4 Cylinder Engine, 166 HP" },
                    Model=new IDValues { ID= "15919", Value= "Accord Cpe" },
                    BodyStyle = new IDValues {ID= "2dr Car",Value= "2dr Car" },
                    Series = new IDValues {ID= "280135",Value= "EX (EX AT)" },
                    Transmission=new IDValues{ID="11",Value="Test" }
                }
            };

            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();

            // Assert
            response.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task GetVehicleInformation()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/GetVehicleInfo?VehicleID=11&StoreID=101&InvtrID=1");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            //var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            //var stores = JsonConvert.DeserializeObject<IEnumerable<VehicleInformation>>(stringResponse);
            //Assert.Contains(stores, s => s.VehicleID == 11);
            //Assert.Contains(stores, s => s.StoreID == 101);
        }
        [Fact]
        public async Task GetYear()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/years");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task GetMake()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/GetMakes/2014");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task GetModel()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/GetModels/2014/44");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task GetDecodeVIN()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/GetDecodeVIN?VIN=1GCWGGFA5E1186070");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
        }
        [Fact]
        public async Task GetTrims()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/VehicleInfo/GetTrims/26542");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
        }
    }
}
