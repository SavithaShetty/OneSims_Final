﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.OneSIMS.Api.IntegrationTests.Appraisal
{
    public class AppraisalLogTest : IClassFixture<CustomWebApplicationFactory<Startup>>
    {

        private readonly HttpClient _client;
        public AppraisalLogTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
        }
        [Fact]
        public async Task GetAppraisalLog()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/api/Appraisal/GetAppraisalLog/10/101/'101,102,103'/0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

        }

        [Fact]
        public async Task DeleteAppraisal()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.DeleteAsync("/api/Appraisal/DeleteAppraisal/62/101/1/10");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

        }
    }
}
