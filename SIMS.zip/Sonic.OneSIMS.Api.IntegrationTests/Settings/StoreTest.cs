﻿using Newtonsoft.Json;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.IntegrationTests.Helper;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.OneSIMS.Api.IntegrationTests.Settings
{
    public class StoreTest : IClassFixture<CustomWebApplicationFactory<Startup>>
    {
        private readonly HttpClient _client;

        public StoreTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
        }

        [Fact]
        public async Task GetStores_ReturnsStoresList()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/v1/SonicStore");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var stores = JsonConvert.DeserializeObject<IEnumerable<Store>>(stringResponse);
            Assert.Contains(stores, s => s.StoreName == "Acura 101 West");
            Assert.Contains(stores, s => s.StoreName == "Acura of Serramonte");
        }


        [Fact]
        public async Task GetStore_ReturnsStoreDetailsById()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/v1/SonicStore/101");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var store = JsonConvert.DeserializeObject<Store>(stringResponse);
            Assert.Equal("Acura of Serramonte", store.StoreName);
        }

        [Fact]
        public async Task GetStore_ReturnsNoStore()
        {
            // The endpoint or route of the controller action.
            var httpResponse = await _client.GetAsync("/v1/SonicStore/50");

            Assert.True(httpResponse.StatusCode == System.Net.HttpStatusCode.NotFound);

        }

        [Fact]
        public async Task AddStore_ReturnsSuccess()
        {
            Random random = new Random();
            int storeId = random.Next(3000, 5000);
            // Arrange
            var request = new
            {
                Url = "v1/SonicStore",
                Body = new
                {
                    StoreId = storeId,
                    StoreName = "TestStore" + storeId
                }
            };

            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            var value = await response.Content.ReadAsStringAsync();

            // Assert
            response.EnsureSuccessStatusCode();

        }
    }
}
