using Newtonsoft.Json;
using Sonic.Chrome.Api.Entities;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.Chrome.Api.IntegrationTests
{
    public class ChromeTest : IClassFixture<CustomWebApplicationFactory<Startup>>
    {
        private readonly HttpClient _client;
        private readonly IDisposable disposable;

        public ChromeTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
            var byteArray = Encoding.ASCII.GetBytes("Test1:Test1");
            _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

        }

        [Fact]
        public async Task GetTransactionData_ReturnsYearListSuccess()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome       
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/years/ChromeAPI");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var chromeYearsData = JsonConvert.DeserializeObject<List<IDValues>>(stringResponse);
            Assert.Contains(chromeYearsData, item => item.ID == "2016");
            List<IDValues> list = new List<IDValues>();
             list = chromeYearsData;

        }

        [Fact]
        public async Task GetTransactionData_ReturnsMakeList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/makes?RequestSource=OneSIMS&YearId=2020");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();
             
            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var chromeTransactionData = JsonConvert.DeserializeObject<IEnumerable<IDValues>>(stringResponse);
            Assert.Contains(chromeTransactionData, item => item.ID == "1" &&  item.Value == "Acura");
        }
        [Fact]
        public async Task GetTransactionData_ReturnsModelList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        ?RequestSource=SIMS&YearId=25252
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/models?RequestSource=SIMS&YearId=2016&MakeId=46");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var chromeTransactionData = JsonConvert.DeserializeObject<IEnumerable<IDValues>>(stringResponse);
            Assert.Contains(chromeTransactionData, item => item.ID == "29804" && item.Value == "488 GTB");
        }
        [Fact]
        public async Task GetTransactionData_ReturnsTrimList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/trims?RequestSource=SIMS&ModelId=29308");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var chromeTransactionData = JsonConvert.DeserializeObject<IEnumerable<IDValues>>(stringResponse);
            Assert.Contains(chromeTransactionData, item => item.ID == "389309" && item.Value == "2016.5 4dr Sdn AWD 60D");
        }
        [Fact]
        public async Task GetTransactionData_ReturnsDecodeVIN()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/DecodeVin?RequestSource=SIMS&VIN=5YJXCAE46GF000944");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var chromeTransactionData = JsonConvert.DeserializeObject<VinVehicleDetail>(stringResponse);
            /*Assert.Contains(chromeTransactionData)*/
            Assert.True(chromeTransactionData != null);
        }

        [Fact]
        public async Task GetTransactionData_ReturnsMakeListFailure()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/makes?RequestSource=SIMS&YearId=25252");

            // Must be Failure.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<IDValues> chromeMakesList = JsonConvert.DeserializeObject<List<IDValues>>(stringResponse);
            Assert.True((chromeMakesList).Count == 0);
            
        }

        [Fact]
        public async Task GetTransactionData_ReturnsModelListFailure()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/models?RequestSource=SIMS&YearId=2016&MakeId=0");

            // Must be Failure.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<Model> chromeModelList=JsonConvert.DeserializeObject<List<Model>>(stringResponse);
            Assert.True((chromeModelList).Count == 0);

        }
        [Fact]
        public async Task GetTransactionData_ReturnsTrimListFailure()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/trims?RequestSource=SIMS&ModelId=0");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            List<Model> chromeTrimList = JsonConvert.DeserializeObject<List<Model>>(stringResponse);
            Assert.True((chromeTrimList).Count == 0);
        }
        [Fact]
        public async Task GetTransactionData_ReturnsDecodeVINFailure()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Chrome        
            var httpResponse = await _client.GetAsync("/api/v1/Chrome/DecodeVIN?RequestSource=SIMS&VIN=SA88R2BG999936410");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var chromeTransactionData = JsonConvert.DeserializeObject<VinVehicleDetail>(stringResponse);
            /*Assert.Contains(chromeTransactionData)*/
            Assert.True(!chromeTransactionData.IsDecodeSuccess);
        }
        public void Dispose(ChromeTest chromeTest)
        {
            Dispose(chromeTest);
            GC.SuppressFinalize(this);
        }
    }
}
