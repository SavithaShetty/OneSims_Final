﻿using System;

namespace OneSIMS.Pricing.DomainModels
{
    public class Class1
    {
    }
}
