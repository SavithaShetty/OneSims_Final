﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OneSIMS.Pricing.DomainModels.AppraisalPricing
{
    public class AppraisalPricingResponse
    {
        public Int64 vehicle_id { get; set; }
        public short invtr_id { get; set; }
        public int store_id { get; set; }
        public Decimal? price { get; set; }
        public string confidence { get; set; }
        public long request_id { get; set; }
        public string request_type { get; set; }
        public string price_type { get; set; }

    }
}
