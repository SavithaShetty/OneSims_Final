﻿using Newtonsoft.Json;
using Sonic.CDK.Api;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.IntegrationTests;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.CDK.Api.IntegrationTests
{
   public class CDKAutocheckTestCases : IClassFixture<CustomWebApplicationFactory<Startup>>
    {
        private readonly HttpClient _client;

        public CDKAutocheckTestCases(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
            var byteArray = Encoding.ASCII.GetBytes("Test1:Test1");
            _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
        }
        [Fact]
        public async Task GetAutoCheckData_ReturnsAutoCheckDetails()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/AutoCheck        
            var httpResponse = await _client.GetAsync("/api/v1/VehcileValuation/GetAutoCheckReport/srvc_Sonic/Ser$739ie/1B3CB3HA2BD204527/52274CA");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var autocheckreport = JsonConvert.DeserializeObject<AutoCheckReport>(stringResponse);
            Assert.Contains(autocheckreport.vinNmbr, "1B3CB3HA2BD204527");
        }
        [Fact]
        public async Task GetAutocheckData_ReturnEmptyResult()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/AutoCheck        
            var httpResponse = await _client.GetAsync("/api/v1/VehcileValuation/GetAutoCheckReport/test/test/1B3CB3HA2BD204527/test");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var autocheckreport = JsonConvert.DeserializeObject<AutoCheckReport>(stringResponse);
            Assert.Null(autocheckreport.vinNmbr);
        }
    }
}
