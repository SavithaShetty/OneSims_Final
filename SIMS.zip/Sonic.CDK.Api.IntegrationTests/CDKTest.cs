﻿using Newtonsoft.Json;
using Sonic.CDK.Api;
using Sonic.CDK.Api.Entities;
using Sonic.CDK.Api.IntegrationTests;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.CDK.Api.IntegrationTests
{
    public class CDKTest : IClassFixture<CustomWebApplicationFactory<Startup>>, IDisposable
    {
        private readonly HttpClient _client;

        public CDKTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
            var byteArray = Encoding.ASCII.GetBytes("Test1:Test1");
            _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
        }

        [Trait("Category", "Make")]
        [Fact(DisplayName = "Make endpoint successful")]
        public async Task GetMakes_ReturnsMakesList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/makes";

            MakeRequest request = new MakeRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            MakeResponse makeResponse = JsonConvert.DeserializeObject<MakeResponse>(stringResponse);
            Assert.True(makeResponse.Makes.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Make")]
        [Fact(DisplayName = "Make endpoint error list returned")]
        public async Task GetMakes_ReturnsErrorList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/makes";

            MakeRequest request = new MakeRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 1952;
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            MakeResponse makeResponse = JsonConvert.DeserializeObject<MakeResponse>(stringResponse);
            Assert.True(makeResponse.Makes.Count == 0  && makeResponse.Errors.Count>0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Model")]
        [Fact(DisplayName = "Model endpoint successful")]
        public async Task GetModels_ReturnsModelList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/models";
            ModelRequest request = new ModelRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            request.Make = "Dodge";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            ModelResponse modelResponse  = JsonConvert.DeserializeObject<ModelResponse>(stringResponse);
            Assert.True(modelResponse.Models.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Model")]
        [Fact(DisplayName = "Model endpoint error list returned")]
        public async Task GetModels_ReturnsErrorList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/models";
            ModelRequest request = new ModelRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            request.Make = "ABC";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            ModelResponse modelResponse = JsonConvert.DeserializeObject<ModelResponse>(stringResponse);
            Assert.True(modelResponse.Models.Count == 0 && modelResponse.Errors.Count > 0);            
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Trim")]
        [Fact(DisplayName = "Trim endpoint successful")]
        public async Task GetTrims_ReturnsTrimList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/trims";
            TrimRequest request = new TrimRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            request.Make = "Dodge";
            request.Model = "Challenger";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            TrimResponse trimResponse = JsonConvert.DeserializeObject<TrimResponse>(stringResponse);
            Assert.True(trimResponse.Trims.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Trim")]
        [Fact(DisplayName = "Trim endpoint error list returned")]
        public async Task GetTrims_ReturnsErrorList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/trims";
            TrimRequest request = new TrimRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            request.Make = "ABC";
            request.Model = "XYZ";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            TrimResponse trimResponse = JsonConvert.DeserializeObject<TrimResponse>(stringResponse);            
            Assert.True(trimResponse.Trims.Count == 0 && trimResponse.Errors.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "BodyStyle")]
        [Fact(DisplayName = "BodyStyle endpoint successful")]
        public async Task GetBodyStyle_ReturnsBodyStyleList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/bodystyles";
            BodyStyleRequest request = new BodyStyleRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            request.Make = "Dodge";
            request.Model = "Challenger";
            request.Trim = "GT";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            BodyStyleResponse bodyResponse = JsonConvert.DeserializeObject<BodyStyleResponse>(stringResponse);
            Assert.True(bodyResponse.BodyStyles.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "BodyStyle")]
        [Fact(DisplayName = "BodyStyle endpoint error list returned")]
        public async Task GetBodyStyle_ReturnsErrorList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/bodystyles";
            BodyStyleRequest request = new BodyStyleRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.Year = 2020;
            request.Make = "xyz";
            request.Model = "Challenger";
            request.Trim = "GT";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            BodyStyleResponse bodyResponse = JsonConvert.DeserializeObject<BodyStyleResponse>(stringResponse);
            Assert.True(bodyResponse.BodyStyles.Count == 0 && bodyResponse.Errors.Count>0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Options")]
        [Fact(DisplayName = "Options endpoint successful")]
        public async Task GetOptions_ReturnsOptions()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/options";
            OptionsRequest request = new OptionsRequest();
            request.DealerId = "1";
            request.PorviderId = 6;
            request.Region = "10";
            request.Source = "SIMSPortal";
            request.Year = 2015;
            request.Make = "Ford";
            //request.Model = "Challenger";
            request.Trim = "C-Max";
            request.ProviderDefCode = "201534849";
            request.BodyStyle = "Hatchback 5D Energi 2.0L I4 Electric/Hybrid";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            OptionsResponse optionResponse = JsonConvert.DeserializeObject<OptionsResponse>(stringResponse);
            Assert.True(optionResponse.optionValues.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "Options")]
        [Fact(DisplayName = "Options endpoint error list returned")]
        public async Task GetOptions_ReturnsErrorList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/options";
            OptionsRequest request = new OptionsRequest();
            request.DealerId = "1";
            request.PorviderId = 6;
            request.Region = "10";
            request.Source = "SIMSPortal";
            request.Year = 2015;
            request.Make = "Ford";
            //request.Model = "Challenger";
            request.Trim = "C-Max";
            request.ProviderDefCode = "123"; // invalid body value
            request.BodyStyle = "Hatchback 5D Energi 2.0L I4 Electric/Hybrid";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            OptionsResponse optionResponse = JsonConvert.DeserializeObject<OptionsResponse>(stringResponse);
            Assert.True(optionResponse.optionValues.Count == 0 && optionResponse.Errors.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "decodevin")]
        [Fact(DisplayName = "decodevin endpoint successful")]
        public async Task GetDecodeVin_Success()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/decodevin";
            DecodeVinRequest request = new DecodeVinRequest();
            request.DealerId = "1";
            request.PorviderId = 6;
            request.Region = "10";
            request.Source = "SIMSPortal";
            request.VIN = "1FTEW1CF9FFB14367";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            DecodeVinResponse decodeResponse = JsonConvert.DeserializeObject<DecodeVinResponse>(stringResponse);
            Assert.True(decodeResponse.VinDecodeValues.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "decodevin")]
        [Fact(DisplayName = "decodevin endpoint error list returned")]
        public async Task GetDecodeVin_Failure()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/decodevin";
            DecodeVinRequest request = new DecodeVinRequest();
            request.DealerId = "1";
            request.PorviderId = 6;
            request.Region = "10";
            request.Source = "SIMSPortal";
            request.VIN = "AAAAAAAAAAAAAAAAA"; //invalid vin
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert            
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            DecodeVinResponse decodeResponse = JsonConvert.DeserializeObject<DecodeVinResponse>(stringResponse);
            Assert.True(decodeResponse.Errors.Count > 0);
            //Assert.Contains(makeResponse);
        }

        [Trait("Category", "bookvalues")]
        [Fact(DisplayName = "bookvalues endpoint successful")]
        public async Task GetBookValues_ReturnsBookValues()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/bookvalues";
            BookValueRequest request = new BookValueRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.VIN = "1N4AL21E09N469791";
            request.Year = 2009;
            request.Make = "Nissan";        
            request.Model = "Altima";
            request.Trim = "Base";
            request.ProviderDefCode = "2009640219";
            request.BodyStyle = "4D Sedan";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            BookValueResponse bookResponse = JsonConvert.DeserializeObject<BookValueResponse>(stringResponse);
            Assert.True(bookResponse.bookValueReports.Length > 0);
            
        }

        [Trait("Category", "bookvalues")]
        [Fact(DisplayName = "bookvalues endpoint error list returned")]
        public async Task GetBookValues_ReturnsErrorList()
        {
            //Arrange
            string endpoint = "/api/v1/VehcileValuation/bookvalues";
            BookValueRequest request = new BookValueRequest();
            request.DealerId = "1";
            request.PorviderId = 4;
            request.Region = "CA";
            request.Source = "SIMSPortal";
            request.VIN = "1N4AL21E09N469791";
            request.Year = 2009;
            request.Make = "Nissan";
            request.Model = "Altima";
            request.Trim = "Base";
            request.ProviderDefCode = "1234"; // invalid id
            request.BodyStyle = "4D Sedan";
            string json = JsonConvert.SerializeObject(request);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

            // Act                  
            var httpResponse = await _client.PostAsync(endpoint, httpContent);


            // Assert
            httpResponse.EnsureSuccessStatusCode();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            BookValueResponse bookResponse = JsonConvert.DeserializeObject<BookValueResponse>(stringResponse);
            Assert.True(bookResponse.Errors.Count > 0);
        }

        public void Dispose()
        {
            _client.Dispose();
        }
    }
}
