﻿using Microsoft.Extensions.Options;
using OneSIMS.Pricing.DataAccess.Helpers;
using OneSIMS.Pricing.DataAccess.Interfaces;
using OneSIMS.Pricing.DomainModels.AppraisalPricing;
using Sonic.OneSIMS.Infrastructure.Persistence;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace OneSIMS.Pricing.DataAccess.Settings
{
    public class AppraisalPricingRepository : BaseRespository, IAppraisalPricingRepository
    {
        public AppraisalPricingRepository(IOptions<DataConnection> dataConnection) : base(dataConnection) { }
    
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing)
        {
            bool _priceResponse = false;
            try
            {

                SqlCommand query = _database.GetStoredProcSqlCommand("PRC_Update_SuggestionPriceFromRetailPricing");
                _database.AddInSqlParameter(query, "@Vehicle_Id", SqlDbType.BigInt, appraisalPricing.vehicle_id);
                _database.AddInSqlParameter(query, "@Store_Id", SqlDbType.SmallInt, appraisalPricing.store_id);
                _database.AddInSqlParameter(query, "@Invtr_Id", SqlDbType.SmallInt, appraisalPricing.invtr_id);
                _database.AddInSqlParameter(query, "@Price", SqlDbType.Decimal, appraisalPricing.price);
                _database.AddInSqlParameter(query, "@Confidence", SqlDbType.VarChar, appraisalPricing.confidence);
                _database.AddInSqlParameter(query, "@request_type", SqlDbType.VarChar, appraisalPricing.request_type);
                _database.AddInSqlParameter(query, "@price_type", SqlDbType.VarChar, appraisalPricing.price_type);
                var res = _database.ExecuteReader(query);
                while (res.Read())
                {
                    _priceResponse = Convert.ToBoolean(res["SUCCESS"]);
                }

                return _priceResponse;
            }
            catch (Exception ex)
            {

            }
            return _priceResponse;
        }
    }
}
