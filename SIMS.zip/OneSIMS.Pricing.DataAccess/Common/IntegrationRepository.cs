﻿using Microsoft.Extensions.Options;
using Sonic.OneSIMS.DataAccess.Interfaces;
using Sonic.OneSIMS.Infrastructure.Persistence;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;

namespace OneSIMS.Pricing.DataAccess
{
    public class IntegrationRepository //: BaseRespository, IIntegrationRepository
    {
        //public IntegrationRepository(IOptions<DataConnection> dataConnection) : base(dataConnection) { }

        //public IntegrationParameter GetIntegrationParameter(short StoreId, byte IntegrationType, string Vin = null)
        //{
        //    IntegrationParameter integrationParameter = new IntegrationParameter();
        //    try
        //    {
        //        DbCommand loadDataCommand = this._database.GetStoredProcCommand("PRC_Get_Integration_Parameter");
        //        _database.AddInParameter(loadDataCommand, "@StoreID", DbType.Int16, StoreId);
        //        _database.AddInParameter(loadDataCommand, "@Intg_type", DbType.Byte, IntegrationType);
        //        if (Vin != null)
        //            _database.AddInParameter(loadDataCommand, "@vin", DbType.String, Vin);

        //        var reader = this._database.ExecuteReader(loadDataCommand);

        //        while (reader.Read())
        //        {
        //            integrationParameter.UserName = reader["User_Name"].ToString();
        //            integrationParameter.Password = reader["Passwd"].ToString();
        //            integrationParameter.AutoCheckDealerId = reader["AutoCheck_Dealer_ID"].ToString();
        //        }
        //        reader.NextResult();
        //        while (reader.Read())
        //        {
        //            integrationParameter.IsOnHandVehicle = Convert.ToBoolean(reader["IsOnHand"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return integrationParameter;
        //    }
        //    return integrationParameter;
        //}

        //public bool AddExternalVehicleData(ExternalVehicleData externalVehicleData)
        //{
        //    IntegrationParameter integrationParameter = new IntegrationParameter();
        //    try
        //    {
        //        DbCommand loadDataCommand = this._database.GetStoredProcCommand("PRC_Save_External_Vehicle_Data");
        //        _database.AddInParameter(loadDataCommand, "@vehicleId", DbType.Int64, externalVehicleData.vehicleIdentity.VehicleID);
        //        _database.AddInParameter(loadDataCommand, "@storeId", DbType.Int16, externalVehicleData.vehicleIdentity.StoreId);
        //        _database.AddInParameter(loadDataCommand, "@invtrId", DbType.Int16, externalVehicleData.vehicleIdentity.InventoryId);
        //        _database.AddInParameter(loadDataCommand, "@rptIconId", DbType.Byte, externalVehicleData.ReportIconId);
        //        _database.AddInParameter(loadDataCommand, "@rptURL", DbType.String, externalVehicleData.ReportURL);
        //        _database.AddInParameter(loadDataCommand, "@createdBy", DbType.String, externalVehicleData.CreatedBy);
        //        _database.AddInParameter(loadDataCommand, "@rptprovname", DbType.String, Enum.GetName(typeof(IntegrationType), externalVehicleData.integrationType));
        //        var reader = this._database.ExecuteNonQuery(loadDataCommand);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }
        //}
    }
}
