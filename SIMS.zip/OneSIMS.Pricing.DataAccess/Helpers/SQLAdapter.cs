﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace OneSIMS.Pricing.DataAccess.Helpers
{
    /// <summary>
    /// SQLAdapter is a helper class to read data.
    /// </summary>
    public class SQLAdapter
    {
        /// <summary>
        /// This method will check to make sure that the provided DataSet is not null,
        /// and that the first table has a row count greater than 0 in length.
        /// </summary>
        /// <param name="dataSet">DataSet.</param>
        /// <returns>It returns boolean.</returns>
        public static bool CheckDataSetDataValidity(DataSet dataSet)
        {
            // make sure that the results are valid for the request above
            if (dataSet != null && dataSet.Tables != null && dataSet.Tables.Count > 0 &&
                dataSet.Tables[0] != null && dataSet.Tables[0].Rows != null && dataSet.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This method will convert a .NET boolean into the db representation of it, i.e. Y or N.
        /// </summary>
        /// <param name="value">boolean value.</param>
        /// <returns>It returns Y or N.</returns>
        public static string SetSQLBoolean(bool value)
        {
            return value ? "Y" : "N";
        }

        /// <summary>
        /// This method will convert a .NET boolean into the db representation of it, i.e. 1 or 0.
        /// </summary>
        /// <param name="value">boolean value.</param>
        /// <returns>It returns 1 or 0.</returns>
        public static int GetBitBoolean(bool value)
        {
            return value ? 1 : 0;
        }

        /// <summary>
        /// These below methods will get a short/int/long/byte back from a sql number field by using the 
        /// GetDecimal(i) method and converting the result to short/int/long/byte..
        /// </summary>
        /// <param name="dataReader">The data reader to get the data from</param>
        /// <param name="column">Target coloumn name</param>
        /// <returns>The short/int/long/byte from the DB</returns>
        public static short GetInt16(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                return 0;
            }
            else
            {
                return dataReader.GetInt16(index);
            }
        }
        public static short? GetNullableshort(SqlDataReader dataReader, string column)
        {
            short? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetInt16(index);
            }
            return returnValue;
        }
        public static int GetInt32(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                return 0;
            }
            else
            {
                return dataReader.GetInt32(index);
            }
        }
        public static int? GetNullableInt32(SqlDataReader dataReader, string column)
        {
            int? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetInt32(index);
            }
            return returnValue;
        }
        public static byte GetByte(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                return 0;
            }
            else
            {
                return dataReader.GetByte(index);
            }
        }
        public static byte? GetNullableByte(SqlDataReader dataReader, string column)
        {
            byte? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetByte(index);
            }
            return returnValue;
        }
        public static long GetLong(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                return 0;
            }
            else
            {
                return dataReader.GetInt64(index);
            }
        }
        public static long? GetNullableLong(SqlDataReader dataReader, string column)
        {
            long? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetInt64(index);
            }
            return returnValue;
        }
        public static decimal GetDecimal(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                return 0.0M;
            }
            else
            {
                return dataReader.GetDecimal(index);
            }
        }

        public static decimal? GetNullableDecimal(SqlDataReader dataReader, string column)
        {
            decimal? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetDecimal(index);
            }

            return returnValue;
        }

        public static double GetDouble(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                return 0.00;
            }
            else
            {
                return dataReader.GetDouble(index);
            }
        }

        public static double? GetNullableDouble(SqlDataReader dataReader, string column)
        {
            double? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetDouble(index);
            }

            return returnValue;
        }

        /// <summary>
        /// This method mirrors the SQLDataReader.GetString(i) method.
        /// It does not do an isnull check - it is to encapsulate the use of 
        /// unsigned indexes, and to keep the code symmetrical.
        /// </summary>
        /// <param name="index">Target coloumn index</param>
        /// <returns>the string from the DB</returns>
        public static string GetString(SqlDataReader dataReader, int index)
        {
            string returnValue = string.Empty;
            if (!dataReader.IsDBNull(index))
            {
                returnValue = dataReader.GetString(index);
            }

            return returnValue;
        }

        /// <summary>
        /// Get the string.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a string.</returns>
        public static string GetString(SqlDataReader dataReader, string column)
        {
            string returnValue = string.Empty;
            int index = dataReader.GetOrdinal(column);
            if (!dataReader.IsDBNull(index))
            {
                returnValue = dataReader.GetString(index);
            }

            return returnValue;
        }

        /// <summary>
        /// Get the datetime.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="index">Column index.</param>
        /// <returns>It returns a datetime.</returns>
        public static DateTime GetDateTime(SqlDataReader dataReader, int index)
        {
            return dataReader.GetDateTime(index);
        }

        /// <summary>
        /// Get the datetime.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a datetime.</returns>
        public static DateTime GetDateTime(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            return GetDateTime(dataReader, index);
        }

        /// <summary>
        /// Get the Nullable datetime.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="index">Column index.</param>
        /// <returns>It returns a Nullable datetime.</returns>
        public static DateTime? GetNullableDateTime(SqlDataReader dataReader, int index)
        {
            DateTime? returnValue = null;
            if (!dataReader.IsDBNull(index))
            {
                returnValue = dataReader.GetDateTime(index);
            }

            return returnValue;
        }

        /// <summary>
        /// Get the Nullable datetime.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a Nullable datetime.</returns>
        public static DateTime? GetNullableDateTime(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            return GetNullableDateTime(dataReader, index);
        }

        /// <summary>
        /// Get the boolean.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a boolean.</returns>
        public static bool GetBoolean(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            return dataReader.GetBoolean(index);
        }

        /// <summary>
        /// Get the Nullable boolean.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a Nullable boolean.</returns>
        public static bool? GetNullableBoolean(SqlDataReader dataReader, string column)
        {
            bool? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                returnValue = dataReader.GetBoolean(index);
            }

            return returnValue;
        }

        /// <summary>
        /// Get the boolean bit.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a boolean bit.</returns>
        public static int GetBitBoolean(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);
            bool bitBool = Convert.ToBoolean(dataReader.GetValue(index));
            return GetBitBoolean(bitBool);
        }

        /// <summary>
        /// Get the Nullable boolean bit.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a Nullable boolean bit.</returns>
        public static int? GetNullableBitBoolean(SqlDataReader dataReader, string column)
        {
            int? returnValue;
            int index = dataReader.GetOrdinal(column);
            if (dataReader.IsDBNull(index))
            {
                returnValue = null;
            }
            else
            {
                bool bitBool = Convert.ToBoolean(dataReader.GetValue(index));
                returnValue = GetBitBoolean(bitBool);
            }

            return returnValue;
        }

        /// <summary>
        /// Get the byte[].
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="index">Column index.</param>
        /// <returns>It returns a byte[].</returns>
        public static byte[] GetBinary(SqlDataReader dataReader, int index)
        {
            byte[] returnValue;
            if (!dataReader.IsDBNull(index))
            {
                returnValue = dataReader.GetSqlBinary(index).Value;
            }
            else
            {
                returnValue = new byte[0];
            }

            return returnValue;
        }

        /// <summary>
        /// Get the byte[].
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a byte[].</returns>
        public static byte[] GetBinary(SqlDataReader dataReader, string column)
        {
            int index = dataReader.GetOrdinal(column);

            return GetBinary(dataReader, index);
        }

        /// <summary>
        /// Get the GUID.
        /// </summary>
        /// <param name="dataReader">Data reader.</param>
        /// <param name="column">Column name.</param>
        /// <returns>It returns a guid.</returns>
        public static Guid GetGuid(SqlDataReader dataReader, string column)
        {
            if (!dataReader.IsDBNull(dataReader.GetOrdinal(column)))
            {
                return new Guid(dataReader.GetString(dataReader.GetOrdinal(column)));
            }
            else
            {
                return Guid.Empty;
            }
        }
    }
}
