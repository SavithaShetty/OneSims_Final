﻿using OneSIMS.Pricing.DomainModels.AppraisalPricing;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneSIMS.Pricing.DataAccess.Interfaces
{
    public interface IAppraisalPricingRepository
    {
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing);
    }
}
