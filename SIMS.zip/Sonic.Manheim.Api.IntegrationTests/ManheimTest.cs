﻿using Newtonsoft.Json;
using Sonic.Manheim.Api.Entities;
using Sonic.Manheim.Api.Entities.DecodeVin;
using Sonic.Manheim.Api.Entities.MakeModelTrim;
using Sonic.Manheim.Api.Entities.Transaction;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sonic.Manheim.Api.IntegrationTests
{
    public class ManheimTest : IClassFixture<CustomWebApplicationFactory<Startup>>, IDisposable
    {
        private readonly HttpClient _client;

        public ManheimTest(CustomWebApplicationFactory<Startup> factory)
        {
            _client = factory.CreateClient();
            var byteArray = Encoding.ASCII.GetBytes("Test1:Test1");
            _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

        }

        [Fact]
        public async Task GetTransactionData_ReturnsTransactionDataList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetTransactionData/201301766060786/RE/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var manheimTransactionData = JsonConvert.DeserializeObject<IEnumerable<ManheimTransactionData>>(stringResponse);
            Assert.Contains(manheimTransactionData, item => item.AuctionName == "Manheim Ohio");
        }

        [Fact]
        public async Task GetTransactionData_ReturnsNoTransactionDataList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetTransactionData/101301766060786/RE/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var manheimTransactionData = JsonConvert.DeserializeObject<IEnumerable<ManheimTransactionData>>(stringResponse);
            Assert.Empty(manheimTransactionData);
        }

        [Fact]
        public async Task GetFullTransactionData_ReturnsTransactionDataList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetFullTransactionData/201301766060786/RE/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var manheimTransactionData = JsonConvert.DeserializeObject<Transaction>(stringResponse);
            Assert.True(manheimTransactionData.items.Count > 0);
        }

        [Fact]
        public async Task GetFullTransactionData_ReturnsNoTransactionDataList()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetFullTransactionData/101301766060786/RE/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var manheimTransactionData = JsonConvert.DeserializeObject<Transaction>(stringResponse);
            Assert.True(manheimTransactionData.items.Count == 0);
        }

        [Fact]
        public async Task GetLocationDetails_ReturnsLocationDetails()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetLocationDetails/OAA/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var locationDetails = JsonConvert.DeserializeObject<LocationDetails>(stringResponse);
            Assert.Equal("Manheim Ohio", locationDetails.locationName);
        }

        [Fact]
        public async Task GetLocationDetails_ReturnsInternalServerError()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetLocationDetails/BBB/internal");

            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        [Fact]
        public async Task GetMakes_ReturnsMakes()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetMakes/2015/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var makes = JsonConvert.DeserializeObject<Makes>(stringResponse);
            Assert.True(makes.count > 0);
        }

        [Fact]
        public async Task GetMakes_ReturnsInternalServerError()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetMakes/2025/internal");
            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        [Fact]
        public async Task GetModels_ReturnsModels()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim                    
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetModels/2015/ACURA/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var models = JsonConvert.DeserializeObject<Models>(stringResponse);
            Assert.True(models.count > 0);
        }

        [Fact]
        public async Task GetModels_ReturnsInternalServerError()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim                    
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetModels/2015/XYZ/internal");

            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        [Fact]
        public async Task GetTrims_ReturnsTrims()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim      
            //GetTrims/{year}/{make}/{model}/{source}
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetTrims/2015/ACURA/ILX/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var trims = JsonConvert.DeserializeObject<Trims>(stringResponse);
            Assert.True(trims.count > 0);
        }

        [Fact]
        public async Task GetTrims_ReturnsInternalServerError()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim      
            //GetTrims/{year}/{make}/{model}/{source}
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetTrims/2015/ACURA/AAA/internal");

            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        [Fact]
        public async Task GetDecodedVin_Success()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim      
            //GetTrims/{year}/{make}/{model}/{source}
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetDecodedVin/2G2WS542841256074/RE/255000/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var decodedVin = JsonConvert.DeserializeObject<VinVehicleDetail>(stringResponse);
            Assert.True(decodedVin.count > 0);
        }

        [Fact]
        public async Task GetDecodedVin_Failure()
        {
            // The endpoint or route of the controller action.
            //api/v{version:apiVersion}/Manheim      
            //GetTrims/{year}/{make}/{model}/{source}
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetDecodedVin/2Q2WS542841256074/RE/255000/internal");

            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        [Fact]
        public async Task GetBookValueByVin_Success()
        {
            // The endpoint or route of the controller action.                        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetBookValue/2G2WS542841256074/201301766060786/RE/255000/RED/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var bookValue = JsonConvert.DeserializeObject<VinVehicleDetail>(stringResponse);
            Assert.True(bookValue.count > 0);
        }

        [Fact]
        public async Task GetBookValueByVin_Failure()
        {
            // The endpoint or route of the controller action.            
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetBookValue/1QWS542841256074/101301766060786/RE/255000/RED/internal");

            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        [Fact]
        public async Task GetBookValueByYearMakeModel_Success()
        {
            // The endpoint or route of the controller action.                        
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetBookValue/2015/ACURA/ILX/255000/RE/RED/internal");

            // Must be successful.
            httpResponse.EnsureSuccessStatusCode();

            //throw new Exception();

            // Deserialize and examine results.
            var stringResponse = await httpResponse.Content.ReadAsStringAsync();
            var bookValue = JsonConvert.DeserializeObject<VinVehicleDetail>(stringResponse);
            Assert.True(bookValue.count > 0);
        }

        [Fact]
        public async Task GetBookValueByYearMakeModel_Failure()
        {
            // The endpoint or route of the controller action.            
            var httpResponse = await _client.GetAsync("/api/v1/Manheim/GetBookValue/2010/ACU/ILX/255000/RE/RED/internal");

            Assert.Equal(System.Net.HttpStatusCode.InternalServerError, httpResponse.StatusCode);
        }

        public void Dispose()
        {
            _client.Dispose();
        }
    }
}
