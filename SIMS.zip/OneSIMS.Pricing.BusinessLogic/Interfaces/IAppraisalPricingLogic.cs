﻿using System;
using System.Collections.Generic;
using System.Text;
using OneSIMS.Pricing;
using OneSIMS.Pricing.DomainModels.AppraisalPricing;

namespace OneSIMS.Pricing.BusinessLogic.Interfaces
{
  public  interface IAppraisalPricingLogic
    {
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing);

        public String PushPriceToPricingModel(PushPriceRequest pushPriceRequest);
    }

   
}
