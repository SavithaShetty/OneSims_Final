﻿using OneSIMS.Pricing.BusinessLogic.Interfaces;
using OneSIMS.Pricing.DataAccess.Interfaces;
using OneSIMS.Pricing.DomainModels.AppraisalPricing;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace OneSIMS.Pricing.BusinessLogic.Settings
{
    public class AppraisalPricingLogic : IAppraisalPricingLogic
    {
        private readonly IAppraisalPricingRepository _appraisalPricingRepository;
        public AppraisalPricingLogic(IAppraisalPricingRepository appraisalPricingRepository)
        {
            _appraisalPricingRepository = appraisalPricingRepository;
        }
        public bool AppraisalPriceResponse(AppraisalPricingResponse appraisalPricing)
        {
            bool _priceResponse=false;
            try
            {
                if (appraisalPricing.request_id != 0 && appraisalPricing.vehicle_id != 0
               && appraisalPricing.store_id != 0 && appraisalPricing.invtr_id != 0)
                {
                    _priceResponse = _appraisalPricingRepository.AppraisalPriceResponse(appraisalPricing);
                }
            }
            catch (Exception ex)
            {
                throw ex;
                // "Pushprice", "error on push price "+ Newtonsoft.Json.JsonConvert.SerializeObject(appraisalPricing).ToString()
            }
            return _priceResponse;
        }

        public string PushPriceToPricingModel(PushPriceRequest pushPriceRequest)
        {
            //DomainModels.AppraisalPricing.PushPriceRequest priceRequest = new DomainModels.AppraisalPricing.PushPriceRequest();
            //OneSIMS.Pricing.API.Entities.PushPriceRequest pushPriceRequest1 = new PushPriceRequest();

             String respResult = "";
            StringBuilder strbuilder = new StringBuilder();
            strbuilder.Append("vin=" + pushPriceRequest.vin);
            strbuilder.Append("&request_type=" + pushPriceRequest.request_type);
            strbuilder.Append("&uvc=" + pushPriceRequest.uvc);
            strbuilder.Append("&odometer=" + pushPriceRequest.odometer);
            strbuilder.Append("&autocheck=" + pushPriceRequest.autocheck);
            strbuilder.Append("&pricing_market_id=" + pushPriceRequest.Pricing_Market_Id);
            strbuilder.Append("&vehicle_id=" + pushPriceRequest.vehicle_id);
            strbuilder.Append("&invtr_id=" + pushPriceRequest.invtr_id);
            strbuilder.Append("&request_id=" + pushPriceRequest.request_id);
            strbuilder.Append("&kbb_id=" + pushPriceRequest.kbb_id);
            strbuilder.Append("&chrome_style_id=" + pushPriceRequest.chrome_style_id);

            try
            {

                //string URI = ConfigSettings.GetAppraisalPricingModelBaseURL();
                //string userName = ConfigSettings.GetAppraisalPricingModelUserName();
                //string password = ConfigSettings.GetAppraisalPricingModelPassword();
                string URI = "https://vpapi-uat.sonicautomotive.com/appraisals";
                string userName = "S!mscaller";
                string password = "Sonic123!";

                string myParameters = strbuilder.ToString();

                using (WebClient wc = new WebClient())
                {
                    // for SSL by pass
                    ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };

                    wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                    string strcredential = string.Format("{0}:{1}", userName, password);
                    wc.Headers[HttpRequestHeader.Authorization] = string.Format("Basic {0}",
                            Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(strcredential)));
                    //wc.Headers[HttpRequestHeader.Authorization] = "Basic UyFtc2NhbGxlcjpTb25pYzEyMyE =";
                    respResult = wc.UploadString(URI, myParameters);

                    //Logger.LogInfo("OnDemand_Push_Price", "Request:"+myParameters +" Response:"+HtmlResult);
                }

            }
            catch (Exception ex)
            {
               // Logger.LogError("OnDemand_Push_Price", "Request:" + strbuilder.ToString(), ex);
                respResult = ex.Message;
            }
            return respResult;
        }
    }
}
