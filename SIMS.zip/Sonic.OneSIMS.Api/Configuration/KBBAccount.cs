﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Configuration
{
    public class KBBExtService
    { 

        public string baseURL { get; set; }

        public string mediaType { get; set; }
    }
}
