﻿using Microsoft.Extensions.Configuration;
using System;
using System.Linq;

namespace Sonic.OneSIMS.Api.Configuration
{
    public class ConfigSettings
    {
        public IConfiguration _configuration { get; }

        public Settings settingObj;
        public ConfigSettings(IConfiguration configuration)
        {
            _configuration = configuration;
            settingObj = _configuration.GetSection("Settings").Get<Settings>();
        }
       
        public string GetMediaType()
        {
            return settingObj.KBBExtService.mediaType;
        }

        public string GetKBBAuthUserName()
        {
            return settingObj.users.Select(x=>x.Username).FirstOrDefault();
        }

        public string GetKBBAuthPassword()
        {
            return settingObj.users.Select(x => x.Password).FirstOrDefault();
        }

        internal string GetKBBBaseURL()
        {
            return settingObj.KBBExtService.baseURL;
        }
    }
}
