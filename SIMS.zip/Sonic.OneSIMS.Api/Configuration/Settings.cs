﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Configuration
{
    public class Settings
    {
        public Settings()
        {
            this.KBBExtService = new KBBExtService();
            this.users = new List<User>();
        }
        public KBBExtService KBBExtService { get; set; }
        public List<User> users { get; set; }
    }
}
