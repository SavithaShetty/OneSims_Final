﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Swashbuckle.AspNetCore.Swagger;

namespace Sonic.OneSIMS.Api.Extensions
{
    public static class SwaggerExtension
    {

        static List<string> lstSimsModules = new List<string>()
            {
                "Appraisal",
                "Settings",
                "User",
                "Inventory",
                "Dashboard",
                "Books",
                "SAC",
                "Pricing"
            };

        public static IServiceCollection AddSwaggerService(this IServiceCollection services)
        {

            // add JWT Authentication
            var securityScheme = new OpenApiSecurityScheme
            {
                Name = "JWT Authentication",
                Description = "Enter JWT Bearer token **_only_**",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.Http,
                Scheme = "bearer", // must be lower case
                BearerFormat = "JWT",
                Reference = new OpenApiReference
                {
                    Id = JwtBearerDefaults.AuthenticationScheme,
                    Type = ReferenceType.SecurityScheme
                }
            };

            services.AddSwaggerGen(setupAction =>
            {
                //your custom configuration goes here
                // UseFullTypeNameInSchemaIds replacement for .NET Core                
                setupAction.CustomSchemaIds(x => x.FullName);     
                foreach (string module in lstSimsModules)
                {
                    setupAction.SwaggerDoc(module, new OpenApiInfo()
                    {
                        Title = "SIMS Portal Services",
                        Version = $"{module}",
                        Description = "SIMS Portal related - API operations"
                    });
                }

                setupAction.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);
                setupAction.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        securityScheme, 
                        new string[] { }
                    }
                });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.XML";
                var xmlPath = System.IO.Path.Combine(AppContext.BaseDirectory, xmlFile);
                //... and tell Swagger to use those XML comments.
                setupAction.IncludeXmlComments(xmlPath);
                setupAction.AddFluentValidationRules();
            });
            return services;
        }

        public static IApplicationBuilder AddSwaggerMidleware(this IApplicationBuilder app)
        {
            //app.UseSwagger(c =>
            //{
            //    c.RouteTemplate = "/swagger/{documentName}/swagger.json";
            //});

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                foreach (string module in lstSimsModules)
                {
                    c.SwaggerEndpoint($"/swagger/{module}/swagger.json", module);
                }

                // deep linking
                c.DefaultModelExpandDepth(2);
                c.EnableDeepLinking();
                c.DisplayOperationId();
            });

            return app;
        }
    }
}
