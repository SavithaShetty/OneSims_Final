﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Common;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sonic.OneSIMS.Api.DTOs.Common.Enums;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class HistoryController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IHistoryLogic _historyLogic;
        private readonly IAutoCheckCarFaxLogic _autoCheckLogic;
        public readonly IConfiguration _configuration;

        public HistoryController(IHistoryLogic historyLogic, IAutoCheckCarFaxLogic autoCheckLogic, IMapper mapper, IConfiguration configuration)
        {
            _historyLogic = historyLogic;
            _autoCheckLogic = autoCheckLogic;
            _mapper = mapper;
            _configuration = configuration;
        }

        /// <summary>
        /// Returns history questions, answers, autocheck and Carfax
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <param name="VIN">VIN</param>
        /// <param name="UserName">User Name</param>
        /// <remarks>Get history questions and answers</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetHistoryQuestions/{VID}/{SID}/{IID}/{CID}/{VIN}/{UserName}")]
        public virtual ActionResult<HistoryDetails> GetVehicleHistoryQuestions([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Company CID, [FromRoute][Required] string VIN, [FromRoute][Required] string UserName)
        {
            var historyQuestionslist = _historyLogic.GetVehicleHistoryQuestions(VID, SID, IID);
            var autoCheckReport = _autoCheckLogic.GetAutoCheckReport(VID, SID, IID, VIN, UserName);
            var CarFaxReport = _autoCheckLogic.GetCarFaxReport(VID, SID, IID, VIN, UserName);
            IEnumerable<HistoryQuestions> historyQuestions = _mapper.Map<IEnumerable<HistoryQuestions>>(historyQuestionslist);
            ExternalVehicleData autoCheck = _mapper.Map<ExternalVehicleData>(autoCheckReport);
            ExternalVehicleData carFax = _mapper.Map<ExternalVehicleData>(CarFaxReport);
            HistoryDetails historyDetails = new HistoryDetails();
            historyDetails.HistoryQuestions = historyQuestions;
            historyDetails.AutoCheck = autoCheck;
            historyDetails.CarFax = carFax;
            return StatusCode(200, historyDetails);
        }


        /// <summary>
        /// Generate and returns autocheck report.
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <param name="VIN">VIN</param>
        /// <param name="UserName">User Name</param>
        /// <remarks>Generate autocheck report</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GenerateAutoCheckReport/{VID}/{SID}/{IID}/{CID}/{VIN}/{UserName}")]
        public virtual ActionResult<ExternalVehicleData> GenerateAutoCheckReport([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Company CID, [FromRoute][Required] string VIN, [FromRoute][Required] string UserName)
        {
            var autoCheckReport = _autoCheckLogic.GetAutoCheckReport(VID, SID, IID, VIN, UserName, true);
            return StatusCode(200, autoCheckReport);            
        }

        /// <summary>
        /// Generate and returns carfax report.
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <param name="VIN">VIN</param>
        /// <param name="UserName">User Name</param>
        /// <remarks>Generate carfax report</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GenerateCarFaxReport/{VID}/{SID}/{IID}/{CID}/{VIN}/{UserName}")]
        public virtual ActionResult<ExternalVehicleData> GenerateCarFaxReport([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Company CID, [FromRoute][Required] string VIN, [FromRoute][Required] string UserName)
        {
            var CarFaxReport = _autoCheckLogic.GetCarFaxReport(VID, SID, IID, VIN, UserName, true);
            return StatusCode(200, CarFaxReport);
        }

        /// <summary>
        /// Save history answers
        /// </summary>
        /// <param name="historyAnswers">hisory questions with answers object to add</param>
        /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("SaveHistoryAnswers")]
        public virtual ActionResult<bool> SaveHistoryAnswers([FromBody] HistoryAnswers historyAnswers)
        {
            if (historyAnswers != null)
            {
                var isSuccess = _historyLogic.AddHistoryAnswers(_mapper.Map<DomainModels.Appraisal.HistoryAnswers>(historyAnswers));
                return StatusCode(201, isSuccess);
            }
            return StatusCode(400, "Bad Request");
        }
    }
}
