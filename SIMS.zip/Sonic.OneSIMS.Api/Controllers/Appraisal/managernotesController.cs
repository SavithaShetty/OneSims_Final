﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.Api.DTOs.Common.Enums;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomainModels.Books;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class ManagerNotesController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IManagerNotesLogic _managernotesLogic;
        public readonly IConfiguration _configuration;

        public ManagerNotesController(IManagerNotesLogic managernotesLogic, IMapper mapper, IConfiguration configuration)
        {
            _managernotesLogic = managernotesLogic;
            _mapper = mapper;
            _configuration = configuration;
        }
        /// <summary>
        /// Get the appraisal manager notes details
        /// </summary>
        /// <remarks>
        /// Get appraisal manager notes details,like aditional amount, comments information       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 

        [HttpGet("GetManagerNotes")]
        public async Task<ActionResult<ManagerNotes>> GetManagerNotes([FromQuery][Required] int VID, [FromQuery][Required] int SID, [FromQuery][Required] int IID, [FromQuery][Required] short CID)
        {
            ManagerNotes info;
            info = _managernotesLogic.GetManagerNotes(VID, SID, IID, CID);
            ManagerNotes result = _mapper.Map<ManagerNotes>(info);
            return Ok(result);
        }
        /// <summary>
        /// Save manager notes
        /// </summary>
        /// <remarks>Save manager notes like aditional amount, comments.</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("SaveManagerNotes")]
        public virtual ActionResult<ManagerNotes> AddManagerNotes([FromBody] ManagerNotes managerNotes)
        {
            if (managerNotes != null)
            {
               var managerNotesData = _managernotesLogic.AddManagerNotes(managerNotes);
                ManagerNotes managerNoteDetails = _mapper.Map<ManagerNotes>(managerNotesData);
               return StatusCode(200, managerNoteDetails);
            }
            return StatusCode(400, "Bad Request");
        }

}
}
