﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.BusinessLogic.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Sonic.OneSIMS.Api.Controllers.Settings
{
    [Route("OneSIMS/[controller]")]
    [ApiController]
    public class StoreController : ControllerBase
    {
        private readonly IStoreLogic _storeLogic;
        private readonly IMapper _mapper;

        public StoreController(IStoreLogic storeLogic, IMapper mapper)
        {
            this._storeLogic = storeLogic;
            _mapper = mapper;
        }
        // GET: api/<StoreController>
        [HttpGet]
        public ActionResult GetAllStores()
        {
            return Ok(_storeLogic.GetAllStores());
        }

        // GET api/<StoreController>/5
        [HttpGet("{id}")]
        public ActionResult GetSotre(int id)
        {
            var storeItem = _storeLogic.GetStoreById(id);
            StoreReadDto storeReadDto = _mapper.Map<StoreReadDto>(storeItem);

            return Ok(storeReadDto);
        }

        // POST api/<StoreController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<StoreController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<StoreController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
