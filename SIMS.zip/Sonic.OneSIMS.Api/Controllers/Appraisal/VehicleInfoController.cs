﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.Api.DTOs.Chrome;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Common;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class VehicleInfoController : ControllerBase
    {
        private readonly IMapper _mapper;
        public readonly IConfiguration _configuration;
        public IVehicleInfoLogic _vehicleInfoLogic;
        public VehicleInfoController(IMapper mapper, IConfiguration configuration, IVehicleInfoLogic appraisalLogic)
        {
            _mapper = mapper;
            _configuration = configuration;
            _vehicleInfoLogic = appraisalLogic;

        }

        /// <summary>
        /// Create appraisal 
        /// </summary>
        /// <remarks>Create the new appraisal of vehicle by checking all required usecases</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>      
        [HttpPost("CreateAppaisal")]
        public virtual ActionResult<CreateAppraisalResponse> SaveBasicAppraisalInfoAndVinExistsCheck([FromBody] BasicAppraisalInfoCreateDto basicAppraisalInfo)
        {
            //_mapper.Map<BasicAppraisalInfo>(basicAppraisalInfo);
            var t = _vehicleInfoLogic.CreateAppraisal(_mapper.Map<BasicAppraisalInfo>(basicAppraisalInfo));
            return StatusCode(200, t);
        }

        /// <summary>
        /// Get the appraisal profile details
        /// </summary>
        /// <remarks>
        /// Get appraisal configuration details,like appraisal process should follow 4/5 steps, all book required or not and other configuration information       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetVehicleProfile")]
        public async Task<ActionResult<AppraisalProfile>> GetVehicleProfile([FromQuery][Required] Int64 VID, [FromQuery][Required] int SID, [FromQuery][Required] int IID, [FromQuery][Required] short CID)
        {
            return Ok(_vehicleInfoLogic.GetVehicleProfile(VID, SID, IID, CID));
            //return StatusCode(200, decodeVehicleDetails);
        }

        /// <summary>
        /// Save Vehicle Information.
        /// </summary>
        /// <remarks>Save vehicle informaion by passing all vehicle details.</remarks>
        /// <response code="200">successful operation</response>        
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("SaveVehicleInformation")]
        public virtual ActionResult<Boolean> SaveVehicleInformation([FromBody] DomainModels.Appraisal.VehicleInformation vehicleInformation)
        {
            //_mapper.Map<BasicAppraisalInfo>(basicAppraisalInfo);
            Boolean t = _vehicleInfoLogic.SaveVehicleInformation(vehicleInformation);
            return StatusCode(200, t);
        }

        /// <summary>
        /// Decode the VIN.
        /// </summary>
        /// <remarks>
        ///  ### Service decode the VIN and return the details from service as below
        /// <ul>
        /// <li> year, make, model, trim, and engine details are consumed from Chrome service </li>
        /// <li> drivetrain and bodystyle informatio are fetched from master tables in SIMS</li>
        /// <li> fuel,transmissions, interior color,interior type and vehcile type are consumed from CDK service, if CDK did not respond then values are taken from master table of SIMS</li>        
        /// </ul>
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 

        [HttpGet("GetDecodeVIN")]
        public async Task<ActionResult<VehicleDecodeDetails>> GetDecodeVIN([FromQuery][Required] string VIN)
        {
            return Ok(_vehicleInfoLogic.GetDecodeVIN(VIN));
            //return StatusCode(200, decodeVehicleDetails);
        }

        /// <summary>
        /// Get saved vehicle details.
        /// </summary>
        /// <remarks>vehicle decode and the saved values of vehicle properties set to true </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>         
        [HttpGet("GetVehicleInfo")]
        public async Task<ActionResult<VehicleInfoReadDto>> GetVehicleInfo([FromQuery][Required] long VID, [FromQuery][Required] int SID, [FromQuery][Required] int IID, [FromQuery][Required] short CID)
        {
            VehicleInformation info;
            VehicleDecodeDetails decodeResult = _vehicleInfoLogic.GetVehicleInfo(VID, SID, IID, CID, out info);
            VehicleInfoReadDto result = _mapper.Map<VehicleInfoReadDto>(decodeResult);
            // required to use mapper in feature
            result.Mileage = info.Mileage;
            result.iSKioskReq = info.iSKioskReq;
            result.SightUnseen = info.SightUnseen;
            result.BankPrice = info.BankPrice;
            return Ok(result);
            //return StatusCode(200, decodeVehicleDetails);
        }

        /// <summary>
        /// Get year list
        /// </summary>
        /// <remarks> Get year list  </remarks>        
        /// <response code="200">Returns the Year list </response>                    
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>   
        [HttpGet("years")]
        public ActionResult<List<IDValues>> GetYears()
        {
            var res = _vehicleInfoLogic.GetYears();
            return Ok(res);
        }

        /// <summary>
        /// Get makes for specific year 
        /// </summary>
        /// <remarks>Get makes for specific year value</remarks>       
        /// <param name="year">year Ex: 2016</param>       
        /// <response code="200">Returns Makes</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>   
        [HttpGet("GetMakes/{year}")]
        public ActionResult<List<IDValues>> GetMakes([FromRoute][Required] int year)
        {
            var res = _vehicleInfoLogic.GetMakes(year);
            return Ok(res);
        }

        /// <summary>
        /// Get models for specific year and make
        /// </summary>
        /// <remarks>Get models for specific year and make</remarks>        
        /// <param name="year">The Id of Year Ex:2016</param>
        /// <param name="makeid">The Id of Make Ex:43</param>
        /// <response code="200">Returns the models for specific year and make</response>
        /// <response code="404">Models not found for given year and make</response>
        /// <response code="400">Bad Request</response>                    
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetModels/{year}/{makeid}")]
        public ActionResult<List<IDValues>> GetModels([FromRoute][Required] int year, [FromRoute][Required] string makeid)
        {
            var res = _vehicleInfoLogic.GetModels(year, makeid);
            return Ok(res);
        }

        /// <summary>
        /// Get Trims for specific Model ID 
        /// </summary>
        /// <remarks>Get Trims for specific Model ID </remarks>        
        /// <param name="modelid">The Id of Model Ex:28132</param>
        /// <response code="200">Returns the trims for specific model</response>
        /// <response code="404">Trims not found for specific model</response>
        /// <response code="400">Bad Request</response>                    
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetTrims/{modelid}")]
        public ActionResult<List<IDValues>> GetTrims([FromRoute][Required] string modelid)
        {
            var res = _vehicleInfoLogic.GetTrims(modelid);
            return Ok(res);
        }
        /// <summary>
        /// Get vehicle info to display vehicle details.
        /// </summary>
        /// <remarks>Get Vehicle Info to display information in VDP  </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>         
        [HttpGet("GetSavedVehicleInfo")]
        public ActionResult<List<IDSavedValues>> GetSavedVehicleInfo([FromQuery][Required] long VID, [FromQuery][Required] int SID, [FromQuery][Required] int IID, [FromQuery][Required] short CID)
        {
            List<IDSavedValues> result = _vehicleInfoLogic.GetSavedVehicleInfo(VID, SID, IID, CID);
            return Ok(result);
            //return StatusCode(200, decodeVehicleDetails);
        }
        /// <summary>
        /// Get vehicle Header info to display vehicle details.
        /// </summary>
        /// <remarks>Get Vehicle Header Info to display information in VDP  </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>         
        [HttpGet("GetVehicleHeaderInfo")]
        public ActionResult<List<IDSavedValues>> GetVehicleHeaderInfo([FromQuery][Required] long VID, [FromQuery][Required] int SID, [FromQuery][Required] int IID, [FromQuery][Required] short CID)
        {
            List<IDSavedValues> result = _vehicleInfoLogic.GetVehicleHeaderInfo(VID, SID, IID, CID);
            return Ok(result);
            //return StatusCode(200, decodeVehicleDetails);
        }
    }
}
