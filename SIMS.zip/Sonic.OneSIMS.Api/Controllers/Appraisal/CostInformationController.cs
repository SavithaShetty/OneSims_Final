﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.Graph.Auth;
using Microsoft.Identity.Client;
using Sonic.OneSIMS.Api.DTOs.Pricing;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Pricing;
using Sonic.OneSIMS.Framework.Configuration;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]

    public class CostInformationController : ControllerBase
    {
        private readonly IMapper _mapper;

        public readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        public ICostInformationLogic _costInfoLogic;

        /// <summary>
        /// Initializes a new instance of the <see cref="ICostInformationLogic"/> class.
        /// </summary>
        /// <param name="_costInfoLogic"></param>
        /// <param name="mapper"></param>
        public CostInformationController(IMapper mapper, Microsoft.Extensions.Configuration.IConfiguration configuration, ICostInformationLogic costInfoLogic)
        {
            _mapper = mapper;
            _configuration = configuration;
            _costInfoLogic = costInfoLogic;

        }

        /// <summary>
        /// Returns Cost Information Edit parameters and SetUp .
        /// </summary>
        /// <remarks>Cost Information related Vehicle Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetAppraisalEditInforamtion/{VID}/{SID}/{IID}/{CID}")]

        public virtual ActionResult<DTOs.Pricing.CostInfoEdit> GetAppraisalEditInforamtion([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] string CID)
        {
            var price = _costInfoLogic.GetAppraisalEditInforamtion(VID, SID, IID, CID);
            //DTOs.Pricing.VDPCostInfoDetails costInfoDetails   = _mapper.Map<DTOs.Pricing.VDPCostInfoDetails>(price);
            return StatusCode(200, price);

        }

        /// <summary>
        /// Returns Saves Cost Information details i.e  Price which is edited in the cost section .
        /// </summary>
        /// <remarks>Saves and gets the results from DB realted Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpPost("SaveCostInforamtion")]
        public virtual ActionResult<Boolean> SaveCostInforamtion([FromBody] DTOs.Pricing.CostInfoSave costInfoSave)
        {
            Boolean isAddSuccess = _costInfoLogic.SaveCostInforamtion(_mapper.Map<DomainModels.Pricing.CostInfoSave>(costInfoSave));
            if (isAddSuccess)
            {
                return StatusCode(200, isAddSuccess);
            }
            else
            {
                return Ok("CostInfroamtion Values not saved");
            }

        }
        /// <summary>
        /// Returns Get Reason Details parameters.
        /// </summary>
        /// <remarks>Returns Get Reason Details parameters</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetReasonDetails/{REASONTYPE}")]
        public virtual ActionResult<List<ReasonCode>> GetReasonCodeDetails([FromRoute][Required] short REASONTYPE)
        {
            var price = _costInfoLogic.GetReasonCodeDetails(REASONTYPE);
            return StatusCode(200, price);
        }

        /// <summary>
        ///Check User is Valid to continue i.e. Authenticaion.
        /// </summary>
        /// <param>UserName for checking valid user or not</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("AuthenticateUser/{UserName}")]
        public virtual async Task<IActionResult> AuthenticateUser([FromRoute][Required] string UserName)
        {
            bool result = false;
            result = await DoesUserExistsAsync(UserName.Trim());
            if (result)
            {
                return StatusCode(201, result);
            }
            else
            {
                return StatusCode(200,result);
            }
        }
        private async Task<bool> DoesUserExistsAsync(string user)
        {

            try
            {
                AzureADSettings azureADSettings = _configuration.GetSection("Settings").Get<Settings>().azureADSettings;

                IConfidentialClientApplication confidentialClientApplication = ConfidentialClientApplicationBuilder
                    .Create(azureADSettings.ServiceAccountClientId)
                    .WithTenantId(azureADSettings.TenantId)
                    .WithClientSecret(azureADSettings.ServiceAccountSecretKey)
                    .Build();

                ClientCredentialProvider authProvider = new ClientCredentialProvider(confidentialClientApplication);

                GraphServiceClient graphClient = new GraphServiceClient(authProvider);

                var payload = await graphClient.Users[user.Trim() + "@sonicautomotive.com"]
                    .Request()
                    .GetAsync();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}
