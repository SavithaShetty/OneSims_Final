﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    public class AppraisalLogController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IAppraisallogLogic _appraisalLogic;
        public readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="AppraisallogController"/> class.
        /// </summary>
        /// <param name="appraisallogic"></param>
        /// <param name="configuration"></param>
        /// <param name="mapper"></param>
        public AppraisalLogController(IAppraisallogLogic appraisallogic, IMapper mapper, IConfiguration configuration)
        {
            _appraisalLogic = appraisallogic;
            _mapper = mapper;
            _configuration = configuration;
        }
    

        // DELETE api/<AppraisalController>/5
        /// <summary>
        /// Delete Appraisal
        /// </summary>
        /// <remarks>Delete Appraisal </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpDelete("DeleteAppraisal/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult DeleteAppraisal([FromRoute][Required] int VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            if (SID != 0)
            {
                bool isDeleteSuccess = _appraisalLogic.DeleteAppraisal(VID, SID,IID,CID);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, isDeleteSuccess);
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Return Appraisal Log.
        /// </summary>
        /// <remarks>Get Appraisal log data</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("getAppraisalLog/{CID}/{SID}/{CurrentLocationID}")]
        public virtual ActionResult<Appraisalloglist> GetAppraisalLog([FromRoute][Required] short CID, [FromRoute][Required] int SID, [FromRoute] short CurrentLocationID)
        {
            var Appdetails = _appraisalLogic.GetAppraisalLog(CID, SID, CurrentLocationID);
            //Appraisalloglist AppraisalLog = _mapper.Map<Appraisalloglist>(Appdetails);
            return StatusCode(200, Appdetails);
        }
       
    }
}
