﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Enums;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class AppraisalController : ControllerBase
    {
        private readonly IMapper _mapper;
        public IAppraisalLogic _vehicleInfosyncLogic;
        public AppraisalController(IMapper mapper, IAppraisalLogic appraisalLogic)
        {
            _mapper = mapper;
            _vehicleInfosyncLogic = appraisalLogic;

        }
        /// <summary>
        /// Sync CCA Vehicle Details 
        /// </summary>
        /// <remarks>Sync Vehicle Details based on conditions</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>      
        [HttpPost("SyncVehicleDetails")]
        public virtual ActionResult<Boolean> SyncVehicleDetails([FromBody] SyncVehicleDetails syncVehicleDetails)
        {
            Boolean t = _vehicleInfosyncLogic.SyncVehicleDetails(syncVehicleDetails);
            return StatusCode(200, t);
        }
        /// <summary>
        /// Resubmit CCA Vehicle to RTC Review
        /// </summary>
        /// <remarks>Resubmit vehicle to RTC Review</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>
        [HttpPost("ResubmitVehicleDetails")]
        public virtual ActionResult<Boolean> ResubmitVehicleDetails([FromBody] ResubmitVehicleDetails resubmitVehicleDetails)
        {
            Boolean t = _vehicleInfosyncLogic.ResubmitVehicleDetails(resubmitVehicleDetails);
            return StatusCode(200, t);
        }
        /// <summary>
        /// Update Vehicle Status
        /// </summary>
        /// <remarks>Finally need to update status</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpPost("UpdateVehicleStatus")]
        public virtual ActionResult<Boolean> UpdateVehicleStatus(DomainModels.Appraisal.UpdateVehicleStatusReq updateVehicleStatusReq)
        {
            Boolean Appdetails = _vehicleInfosyncLogic.UpdateVehicleStatus(updateVehicleStatusReq);
            return StatusCode(200, Appdetails);
        }

        /// <summary>
        /// GetUpdatedVehicleInfo
        /// </summary>
        /// <remarks>Get the  updated vehicle info</remarks>
        /// <param name="VID"></param>
        /// <param name="SID"></param>
        /// <param name="IID"></param>
        /// <param name="sectionIdentifier"></param>
        /// <returns></returns>
        [HttpGet("GetUpdatedVehicleInfo")]
        public ActionResult<UpdatedVehicleInfo> GetUpdatedVehicleInfo([FromQuery][Required] long VID, [FromQuery][Required] int SID, [FromQuery][Required] int IID, [FromQuery][Required] CCASyncIdentifier sectionIdentifier)
        {
            UpdatedVehicleInfo result = _vehicleInfosyncLogic.GetUpdatedVehicleInfo(VID, SID, IID, sectionIdentifier);
            return Ok(result);
            //return StatusCode(200, decodeVehicleDetails);
        }


        /// <summary>
        /// Get SAC/EG stored notes converstiond details
        /// </summary>
        /// <remarks>Get the updated converstion notes</remarks>
        /// <param name="VID">Vehicle Id</param>
        /// <param name="SID">Store ID</param>
        /// <param name="IID">Inventory ID</param>
        /// <param name="CID">Company ID</param>
        /// <returns></returns>
        [HttpGet("GetSACEGNotes/{VID}/{SID}/{IID}/{CID}")]
        public async Task<ActionResult<SACEGNotes>> GetSACEGNotes([FromRoute][Required] long VID, [FromRoute][Required] int SID, [FromRoute][Required] int IID, [FromRoute][Required] DomailModels.Enums.Company  CID)
        {
            return Ok(_vehicleInfosyncLogic.GetSACEGNotes(VID,SID,IID,CID));
        }

        /// <summary>
        /// Save the SAC / EG Chat converstion notes
        /// </summary>
        /// <param name="sACEGNotes">
        /// </param>
        /// <remarks>Get the  updated vehicle info</remarks>
        [HttpPost("SaveSACEGNote")]
        public async Task<ActionResult<bool>> SaveSACEGNote(SACEGNotes sACEGNotes)
        {
            return Ok(_vehicleInfosyncLogic.SaveSACEGNotes(sACEGNotes));            
        }

        /// <summary>
        /// Get Test message from App3
        /// </summary>
        [HttpGet("TestApp3")]
        public async Task<ActionResult<String>> GetTestMessage()
        {
            return Ok(_vehicleInfosyncLogic.GetTestMessage());
        }

    }
}
