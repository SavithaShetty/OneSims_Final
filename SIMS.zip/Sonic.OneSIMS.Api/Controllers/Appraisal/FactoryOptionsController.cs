﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.Api.DTOs.Chrome;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Sonic.OneSIMS.DomainModels.Appraisal;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class FactoryOptionsController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IFactoryOptionLogic _factoryoptionsLogic;
        public readonly IConfiguration _configuration;
        public FactoryOptionsController(IFactoryOptionLogic factoryOptionLogic, IMapper mapper, IConfiguration configuration)
        {
            _factoryoptionsLogic = factoryOptionLogic;
            _mapper = mapper;
            _configuration = configuration;
        }
        /// <summary>
        /// Get List of Factory Options from Service and Selected Values from Data Base
        /// </summary>
        /// <param name="VIN">VIN</param>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Inventory Id</param>
        /// <remarks>Get List of Factory Options from Service and Selected Values from Data Base </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetFactoryOptions")]
        public virtual ActionResult<DTOs.Appraisal.VehicleFactoryOptions> GetFactoryOptions([FromQuery][Required] string VIN, [FromQuery][Required] long VID, [FromQuery][Required] short SID, [FromQuery][Required] short IID, [FromQuery][Required] short CID, [FromQuery][Required] bool isdecodesuccess)
        {
            var lstfactoryOptions = _factoryoptionsLogic.GetFactoryOptions(VIN,VID, SID, IID, CID, isdecodesuccess);
            //IEnumerable<List<FactoryOptions>> factoryOptions = _mapper.Map<IEnumerable<List<FactoryOptions>>>(lstfactoryOptions);
            return StatusCode(200, lstfactoryOptions);
        }
        /// <summary>
        /// Save Factory Options
        /// </summary>
        /// <param name="FactoryOptions">Factory Options questions with answers object to add</param>
        /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("SaveFactoryOptions")]
        public virtual ActionResult<string> SaveFactoryOptions([FromBody] DTOs.Appraisal.VehicleFactoryOptions vehicleFactoryOptions)
        {
            if (vehicleFactoryOptions != null)
            {
                bool isAddSuccess = _factoryoptionsLogic.SaveFactoryOptions(_mapper.Map<DomainModels.Appraisal.VehicleFactoryOptions>(vehicleFactoryOptions));
                if (isAddSuccess)                
                    return StatusCode(200, isAddSuccess);
                
            }
            return StatusCode(400, "Bad Request");
        }
        /// <summary>
        /// Get List of Factory Options from  from Data Base to display
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Inventory Id</param>
        /// <remarks>Get List of Factory Options from Data Base to display </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetSavedFactoryOptions")]
        public virtual ActionResult<VehicleFactoryOptionsVDP> GetSavedFactoryOptions([FromQuery][Required] long VID, [FromQuery][Required] short SID, [FromQuery][Required] short IID, [FromQuery][Required] short CID)
        {
            var lstfactoryOptions = _factoryoptionsLogic.GetSavedFactoryOptions(VID, SID, IID, CID);
            //IEnumerable<List<FactoryOptions>> factoryOptions = _mapper.Map<IEnumerable<List<FactoryOptions>>>(lstfactoryOptions);
            return StatusCode(200, lstfactoryOptions);
        }
    }
}
