﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using AutoMapper.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.Configuration;
using Sonic.OneSIMS.Api.DTOs.Pricing;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Pricing;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Pricing;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Microsoft.Extensions.Configuration;
using System.ComponentModel.DataAnnotations;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]

    public class PricingController : ControllerBase
    {
        private readonly IMapper _mapper;

        public readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        public IPricingLogic _pricingLogic;

        /// <summary>
        /// Initializes a new instance of the <see cref="IPricingLogic"/> class.
        /// </summary>
        /// <param name="_pricingLogic"></param>
        /// <param name="mapper"></param>
        public PricingController(IMapper mapper, Microsoft.Extensions.Configuration.IConfiguration configuration, IPricingLogic pricingLogic)
        {
            _mapper = mapper;
            _configuration = configuration;
            _pricingLogic = pricingLogic;

        }
     
        /// <summary>
        /// Returns Pricing Steps Loading Parameters and SetUp .
        /// </summary>
        /// <remarks>Pricing related Vehicle Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetPricingDetailsOnLoad/{VehicleId}/{StoreId}/{InvtrId}/{CID}/{VehicleSource}")]
        public virtual ActionResult<DTOs.Pricing.PricingResponse> GetPricingDetailsOnLoad([FromRoute][Required] long VehicleId, [FromRoute][Required] short StoreId, [FromRoute][Required] short InvtrId, [FromRoute][Required] string CID, [FromRoute][Required] string VehicleSource)
        {
            var price = _pricingLogic.GetPricingDetailsOnLoad(VehicleId, StoreId, InvtrId, VehicleSource);
            DTOs.Pricing.PricingResponse pricingResp = _mapper.Map<DTOs.Pricing.PricingResponse>(price);
            return StatusCode(200, price);
        }

        /// <summary>
        /// Returns Saves Price details i.e  Price which we got from Pricing Module .
        /// </summary>
        /// <remarks>Saves and gets the results from DB realted Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpPost("SavePricingDetails")]
        public virtual ActionResult<Boolean> SavePricingDetails([FromBody] DTOs.Pricing.PricingRequest pricingRequest)
        {
            Boolean isAddSuccess = _pricingLogic.SavePricingDetails(_mapper.Map<DomainModels.Pricing.PricingRequest>(pricingRequest));
            if (isAddSuccess)
            {
                return StatusCode(200, isAddSuccess);
            }
            else
            {
                return Ok("Pricing Values not saved");
            }

        }

        /// <summary>
        /// Gets the price from saved values if price is not found means Requests the price from Pricing Module .
        /// </summary>
        /// <remarks>Vehicle Priceing realted Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpPost("PushPrice/{VehicleId}/{StoreId}/{InvtrId}")]
        public virtual ActionResult<string> PushPriceRequest([FromRoute] long VehicleId, [FromRoute] short StoreId, [FromRoute] short InvtrId)
        {
            string _priceRequest;
            _priceRequest = _pricingLogic.PushPriceRequest(VehicleId, StoreId, InvtrId);
            return StatusCode(200, _priceRequest);
        }

        /// <summary>
        /// Returns VDP Cost Information Parameters and SetUp .
        /// </summary>
        /// <remarks>Cost Information related Vehicle Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetCostInformationDetails/{VehicleId}/{StoreId}/{InvtrId}/{CID}")]

        public virtual ActionResult<DTOs.Pricing.VDPCostInfoDetails> GetCostInformationDetails([FromRoute][Required] long VehicleId, [FromRoute][Required] short StoreId, [FromRoute][Required] short InvtrId, [FromRoute][Required] string CID)
        {
            var price = _pricingLogic.GetCostInformationDetails(VehicleId,StoreId,InvtrId);
            //DTOs.Pricing.VDPCostInfoDetails costInfoDetails   = _mapper.Map<DTOs.Pricing.VDPCostInfoDetails>(price);
            return StatusCode(200, price);

        }
        /// <summary>
        /// GetRTCBumpHistory - To get the RTC Bump history data
        /// </summary>
        /// <param name="VID"></param>
        /// <param name="SID"></param>
        /// <param name="IID"></param>
        /// <returns></returns>
        [HttpGet("GetRTCBumpHistory/{VID}/{SID}/{IID}")]
        public virtual ActionResult<List<BumpHistoryData>> GetRTCBumpHistory([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            var rtcBumpHistory = _pricingLogic.GetRTCBumpHistory(VID, SID, IID);
            return StatusCode(200, rtcBumpHistory);
        }

        [HttpGet("GetBumpHistory/{VID}/{SID}/{IID}")]
        public virtual ActionResult<List<BumpHistoryData>> GetBumpHistory([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            var BumpHistory = _pricingLogic.GetBumpHistory(VID, SID, IID);
            return StatusCode(200, BumpHistory);
        }
        [HttpGet("GetPreviousApprasisal/{VID}/{SID}/{IID}")]
        public virtual ActionResult<List<Appraisalloglist>> GetPreviousApprasisal([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            var previousApprasialData = _pricingLogic.GetPreviousApprasisal(VID, SID, IID);
            return StatusCode(200, previousApprasialData);
        }

        [HttpGet("GetVehicleHistory/{VID}/{SID}/{IID}")]
        public virtual ActionResult<List<DomainModels.Pricing.VehicleHistoryData>> GetVehicleHistory([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            var vehicleHistoryData = _pricingLogic.GetVehicleHistory(VID, SID, IID);
            return StatusCode(200, vehicleHistoryData);
        }

        /// <summary>
        /// Returns Ending Doller for the Perticular vehicle .
        /// </summary>
        /// <remarks>Returns Ending Doller for the Perticular vehicle</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetEndingDoller/{VID}/{SID}/{IID}")]
        public virtual ActionResult<string> GetEndingDoller([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            string endingDoller = _pricingLogic.GetEndingDoller(VID, SID, IID);
            return StatusCode(200, endingDoller);
        }
        [HttpGet("GetAvgReconPricingValues/{VID}/{SID}/{IID}")]
        public virtual ActionResult<List<decimal>> GetAvgReconPricingValues([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            var previousApprasialData = _pricingLogic.GetAvgReconPricingValues(VID, SID, IID);
            return StatusCode(200, previousApprasialData);
        }
    }

}
