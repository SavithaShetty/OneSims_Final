﻿using AutoMapper;

using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sonic.OneSIMS.DomainModels.Appraisal;
using System.ComponentModel.DataAnnotations;
using Sonic.OneSIMS.Api.DTOs.Common.Enums;
using Sonic.OneSIMS.DomainModels.Inventory;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class ReconPhotoController : ControllerBase
    {
        private readonly IMapper _mapper;
        public readonly IConfiguration _configuration;
        public IReconPhotoLogic _photoLogic;
        public ReconPhotoController(IMapper mapper, IConfiguration configuration, IReconPhotoLogic photoLogic)
        {
            _mapper = mapper;
            _configuration = configuration;
            _photoLogic = photoLogic;

        }
        /// <summary>
        /// Save the Photo to Azure 
        /// </summary>
        /// <param name="photoUploadParams"></param>
        /// <returns></returns>
        ///  /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("AddVehiclePhoto")]
        public ActionResult<bool> AddVehiclePhoto([FromBody] DomainModels.Appraisal.PhotoSourceRequest photoUploadParams)
        {
            //Boolean t = _photoLogic.UploadPhoto(_mapper.Map<DomainModels.Appraisal.PhotoSourceRequest>(photoUploadParams));
            bool t = _photoLogic.UploadPhoto(photoUploadParams);
            return StatusCode(200, t);
        }

        /// <summary>
        /// To retrieve the Saved Photos
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <returns></returns>
        [HttpGet("GetAppraisalPhotos/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<VehiclePhotoWrapper> GetAppraisalPhotos([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Sonic.OneSIMS.DomailModels.Enums.Company CID)
        {
            VehiclePhotoWrapper photoData= _photoLogic.GetAllPhotoData(VID, SID, IID, CID);
            return StatusCode(200, photoData);
        }

        [HttpDelete("DeleteAppraisalPhoto/{VID}/{SID}/{IID}/{CID}/{PhotoGuide}")]
        public virtual ActionResult DeleteAppraisalPhotoSIMS([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Sonic.OneSIMS.DomailModels.Enums.Company CID, [FromRoute][Required] string PhotoGuide)
        {
           bool val= _photoLogic.DeleteApprasialPhoto(VID, SID, IID, CID, PhotoGuide);
            return StatusCode(200);
        }

        [HttpPost("SaveAmountDetails")]
        public virtual ActionResult SaveAmountDetailsSIMS([FromBody] AnswerWrapper Answer)
        {
           bool val= _photoLogic.SaveReconAmountDetails(Answer);
            return StatusCode(200);
        }
        [HttpGet("GetReconConditionAdditionalAmount/{VID}/{SID}/{IID}")]
        public virtual ActionResult<decimal> GetReconConditionAdditionalAmount([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID)
        {
            decimal AdditionalAmount = _photoLogic.GetReconConditionAdditionalAmount(VID, SID, IID);

            return StatusCode(200,AdditionalAmount);
        }


        /// <summary>
        /// To retrieve the Saved Photos
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <param name="photo_Cat">Photo category</param>
        /// <returns></returns>
        [HttpGet("GetAllPhotos/{VID}/{SID}/{IID}/{CID}/{photo_Cat}")]
        public virtual ActionResult<VehiclePhotoDetails> GetAllPhotos([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Sonic.OneSIMS.DomailModels.Enums.Company CID, [FromRoute][Required] int photo_Cat)
        {
            VehiclePhotoDetails photoData = _photoLogic.GetAllPhotos(VID, SID, IID, CID, photo_Cat);
            return StatusCode(200, photoData);
        }

        /// <summary>
        /// To Delete the Photos
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <param name="photoids">Photo_IDs</param>
        /// <returns></returns>
        [HttpDelete("DeletePhotos/{VID}/{SID}/{IID}/{CID}/{photoids}")]
        public virtual ActionResult DeletePhotos([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Sonic.OneSIMS.DomailModels.Enums.Company CID, [FromRoute][Required] string photoids)
        {
            bool val = _photoLogic.DeletePhotos(VID, SID, IID, CID, photoids);
            return StatusCode(200,val);
        }


        /// <summary>
        /// To Publish  Photos to Homenet
        /// </summary>
        /// <param name="photoPublishParams"></param>
        /// <returns></returns>
        ///  /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("UpdatePhotostoPublish")]
        public ActionResult<bool> UpdatePhotostoPublish([FromBody] PhotoPublishParams photoPublishParams)
        {
            bool t = _photoLogic.UpdatePhotostoPublish(photoPublishParams);
            return StatusCode(200, t);
        }
        /// <summary>
        /// To fetch the MarketingPhotos details
        /// </summary>
        /// <param name="VID"></param>
        /// <param name="SID"></param>
        /// <param name="IID"></param>
        /// <param name="CID"></param>
        /// <param name="PhotoCat"></param>
        /// <returns></returns>
        [HttpGet("GetMarketingPhotos/{VID}/{SID}/{IID}/{CID}/{PhotoCat}")]
        public virtual ActionResult GetMarketingPhotos([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Sonic.OneSIMS.DomailModels.Enums.Company CID, [FromRoute][Required] int PhotoCat)
        {
            VehiclePhotoDetails photoData = _photoLogic.GetMarketingPhotos(VID, SID, IID, CID, PhotoCat);
            return StatusCode(200, photoData);
        }


        /// <summary>
        /// Update Marketing comment
        /// </summary>
        /// <param name="marktcommentparam"></param>
        /// <returns></returns>
        ///  /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("UpdateMarketText")]
        public ActionResult<bool> UpdateMarketText([FromBody] MrktCommentParams marktcommentparam)
        {
            bool t = _photoLogic.UpdateMarketText(marktcommentparam);
            return StatusCode(200, t);
        }

    }
}
