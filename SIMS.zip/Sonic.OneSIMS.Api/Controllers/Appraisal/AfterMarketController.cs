﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Appraisal;
using Sonic.OneSIMS.Api.DTOs.Common.Enums;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal;

namespace Sonic.OneSIMS.Api.Controllers.Appraisal
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Appraisal")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class AfterMarketController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IAfterMarketLogic _afterMarketLogic;
        public readonly IConfiguration _configuration;

        public AfterMarketController(IAfterMarketLogic afterMarketLogic, IMapper mapper, IConfiguration configuration)
        {
            _afterMarketLogic = afterMarketLogic;
            _mapper = mapper;
            _configuration = configuration;
        }

        /// <summary>
        /// Returns After Market questions and answers
        /// </summary>
        /// <param name="VID">vehicle Id</param>
        /// <param name="SID">Store Id</param>
        /// <param name="IID">Inventory Id</param>
        /// <param name="CID">Company Id</param>
        /// <remarks>Get after market questions and answers</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetAfterMarketQuestions/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<IEnumerable<AfterMarketQuestions>> GetAfterMarketQuestions([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] Company CID)
        {
            var afterMarketQuestionslist = _afterMarketLogic.GetAfterMarketQuestions(VID, SID, IID);
            IEnumerable<AfterMarketQuestions> afterMarketQuestions = _mapper.Map<IEnumerable<AfterMarketQuestions>>(afterMarketQuestionslist);
            return StatusCode(200, afterMarketQuestions);
        }

        /// <summary>
        /// Save after market answers
        /// </summary>
        /// <param name="afterMarketQuestions">after market questions with answers object to add</param>
        /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("SaveAfterMarketAnswers")]
        public virtual ActionResult<bool> SaveAfterMarketAnswers([FromBody] AMFO afterMarketQuestions)
        {
            if (afterMarketQuestions != null)
            {
                var isSuccess = _afterMarketLogic.AddAfterMarketAnswers(_mapper.Map<DomainModels.Appraisal.AMFO>(afterMarketQuestions));                
                return StatusCode(201, isSuccess);
            }
            return StatusCode(400, "Bad Request");
        }
    }
}
