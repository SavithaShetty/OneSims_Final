﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Pricing;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.DomainModels.Pricing;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Controllers.Inventory
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Inventory")]
    public class InventoryPricingController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IInventoryPricingLogic _inventoryPricingLogic;
        public readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="InventoryLogController"/> class.
        /// </summary>
        /// <param name="appraisallogic"></param>
        /// <param name="configuration"></param>
        /// <param name="mapper"></param>
        public InventoryPricingController(IInventoryPricingLogic inventoryPricingLogic, IMapper mapper, IConfiguration configuration)
        {
            _inventoryPricingLogic = inventoryPricingLogic;
            _mapper = mapper;
            _configuration = configuration;
        }

        /// <summary>
        /// API to Get the Add Vehicle - Pricing details
        /// </summary>
        /// <remarks>
        /// Get Inventory Vehicle details like VehicleStatus, Certified, Wholesale, Retail Price and other details related to inventory       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetInventoryPricingDetails")]
        public async Task<ActionResult<InventoryPricingDetails>> InventoryPricingDetails([FromQuery][Required] short CID, [FromQuery][Required] long VID, [FromQuery][Required] short SID, [FromQuery][Required] short IID)
        {
            return Ok(_inventoryPricingLogic.GetInventoryPricingDetails(CID, VID, SID, IID));

        }
        /// <summary>
        /// API to Save- Pricing details
        /// </summary>
        /// <remarks>
        /// Save Inventory Vehicle Pricing details like VehicleStatus, Certified, Wholesale, Retail Price and other details related to inventory       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("SaveInventoryRetailPrice")]
        public async Task<ActionResult<Boolean>> SaveInventoryRetailPrice(InventorySavePricingDetails inventorySavePricingDetails)
        {
            return Ok(_inventoryPricingLogic.SaveInventoryRetailPrice(inventorySavePricingDetails));
        }

        /// <summary>
        /// API to get actual recon values from ADP vehicle inventory service where vehicle status is closed.
        /// </summary>
        /// <remarks>
        /// Get actual recon values(RO PO values) 
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("GetActualReconValues")]
        public async Task<ActionResult<DVC>> GetActualReconValues(ROPORequest rOPORequest)
        {
            //rOPORequest.AdpVehicleId = 4449728;
            //rOPORequest.RegionId = 135;
            //rOPORequest.DealerId = "135";
            return Ok(_inventoryPricingLogic.GetActualReconValues(rOPORequest));
        }

        /// <summary>
        /// API to get DVC values from ADP vehicle inventory service where vehicle status is open.
        /// </summary>
        /// <remarks>
        /// Get actual recon values(RO PO values) 
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("GetDVCValues")]
        public async Task<ActionResult<DVC>> GetDVCValues(ROPORequest rOPORequest)
        {
            return Ok(_inventoryPricingLogic.GetDVCValues(rOPORequest));
        }
        /// <summary>
        /// API to Get the Inventory Vehicle VDP- Pricing details
        /// </summary>
        /// <remarks>
        /// Get Inventory Vehicle details like age, retail price , recommendation, Retail Price and other details related to inventory       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetInventoryVDPPricingDetails/{VID}/{SID}/{IID}/{CID}")]
        public async Task<ActionResult<InventoryVDPPricingDetails>> GetInventoryVDPPricingDetails([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            return Ok(_inventoryPricingLogic.GetInventoryVDPPricingDetails(CID, VID, SID, IID));

        }

        #region inventory-costinformation

        /// <summary>
        /// API to Get the Cost Information Edit details
        /// </summary>
        /// <remarks>
        /// Get Inventory Vehicle details like VehicleStatus, Certified, Wholesale, Retail Price and other details related to inventory       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetInventoryCostEditDetails")]
        public async Task<ActionResult<InventoryCostInfoDetails>> InventoryCostEditDetails([FromQuery][Required] short CID, [FromQuery][Required] long VID, [FromQuery][Required] short SID, [FromQuery][Required] short IID)
        {
            return Ok(_inventoryPricingLogic.GetInventoryCostEditDetails(CID, VID, SID, IID));

        }

        /// <summary>
        /// Returns Saves Cost Information details i.e  Price which is edited in the cost section .
        /// </summary>
        /// <remarks>Saves and gets the results from DB realted Inforamtion</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpPost("SaveCostInforamtion")]
        public virtual ActionResult<Boolean> SaveCostInforamtion([FromBody] InventorySaveCostInfoDetails inventorySaveCostInfoDetails)
        {

            return Ok(_inventoryPricingLogic.SaveCostInfoDetails(inventorySaveCostInfoDetails));

        }

        /// <summary>
        /// Returns Inventory Source TYpes.
        /// </summary>
        /// <remarks>Get Inventory Source Type</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetInventorySourceType/{CID}/{SID}")]
        public virtual ActionResult<AcquisitionType> GetInventorySourceType([FromRoute][Required] int CID, [FromRoute][Required] int SID)
        {
            var Sourcelist = _inventoryPricingLogic.GetInventorySourceType(CID, SID);
            return StatusCode(200, Sourcelist);
        }

        #endregion inventory-costinformation

    }
}
