﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs.Inventory;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Inventory;
using Sonic.OneSIMS.DomainModels.Settings.Store;

namespace Sonic.OneSIMS.Api.Controllers.Inventory
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Inventory")]
    public class InventoryLogController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IInventoryLogLogic _inventoryLogic;
        public readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="InventoryLogController"/> class.
        /// </summary>
        /// <param name="appraisallogic"></param>
        /// <param name="configuration"></param>
        /// <param name="mapper"></param>
        public InventoryLogController(IInventoryLogLogic inventoryloglogic, IMapper mapper, IConfiguration configuration)
        {
            _inventoryLogic = inventoryloglogic;
            _mapper = mapper;
            _configuration = configuration;
        }

        /// <summary>
        /// Get the Store profile details
        /// </summary>
        /// <remarks>
        /// Get Inventory configuration details,like to get ADP_REGION_ID,AutoCheck and CarFax bit, store general/additional options like ReconOnlineStore,InTransitUsed configuration and other configurations related to store       
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetStoreProfile")]
        public async Task<ActionResult<StoreProfile>> GetStoreProfile([FromQuery][Required] short CID, [FromQuery][Required] int SID)
        {
            return Ok(_inventoryLogic.GetStoreProfile(CID, SID));

        }
        ///// <summary>
        ///// Get InventoryLog Details
        ///// </summary>
        ///// <remarks>
        ///// Get InventoryLog Details
        ///// </remarks>
        ///// <response code="200">successful operation</response>
        ///// <response code="401">Unauthorization</response>                    
        ///// <response code="400">Bad Request</response>                    
        ///// <response code="500">Internal Server Error</response> 
        [HttpPost("GetInventoryLogDetails")]
        public virtual ActionResult<List<DomailModels.Inventory.InventoryLogData>> GetInventoryLogDetails([FromBody] InventoryLogParam inventoryLogParam)
        {

            DomailModels.Inventory.InventoryLogParam inventoryLog = _mapper.Map<DomailModels.Inventory.InventoryLogParam>(inventoryLogParam);
            var inventoryDetails = _inventoryLogic.GetInventoryLogDetails(inventoryLog);
            return StatusCode(200, inventoryDetails);

        }

        /// <summary>
        /// Save Status Change.
        /// </summary>
        /// <remarks>
        /// Save Status Change.
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("SaveStatusChange")]
        public virtual ActionResult<bool> SaveStatusChange([FromBody] StatusChangeParam statusChangeParam)
        {
            bool saved = _inventoryLogic.SaveStatusChange(statusChangeParam);
            return StatusCode(200, saved);
        }

        /// <summary>
        /// Get Action Menu Status List.
        /// </summary>
        /// <remarks>
        /// Get Action Menu Status List based on storeid and inventory type.
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetActionMenuStatuslist")]
        public ActionResult<IDValues> GetActionMenuStatuslist([FromQuery][Required] short storeId, [FromQuery][Required] int inventoryType)
        {
            return StatusCode(200, _inventoryLogic.GetActionMenuStatuslist(storeId, inventoryType));
        }

        /// <summary>
        /// Get In-transit details.
        /// </summary>
        /// <remarks>
        /// Get In-transit details based on the store id.
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetITDetails")]
        public ActionResult<IDValues> GetITDetails([FromQuery][Required] short storeId)
        {
            return StatusCode(200, _inventoryLogic.GetITDetails(storeId));
        }

        /// <summary>
        /// Get Status of Market Ready Flag.
        /// </summary>
        /// <remarks>
        /// Get Status of Market Ready Flag.
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("CheckMarketReadyFlagStatus")]
        public ActionResult<IDValues> CheckMarketReadyFlagStatus([FromQuery][Required] int statusId, [FromQuery][Required] int storeId, [FromQuery][Required] int inventoryType)
        {
            return StatusCode(200, _inventoryLogic.CheckMarketReadyFlagStatus(statusId, storeId, inventoryType));
        }
        /// <summary>
        /// Get Header Details.
        /// </summary>
        /// <remarks>Get Header details for Inventory Vehicles </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>         
        [HttpGet("GetInventoryVehicleHeaderInfo")]
        public async Task<ActionResult<VehicleHeaderInfo>> GetInventoryVehicleHeaderInfo([FromQuery][Required] long VID, [FromQuery][Required] short SID, [FromQuery][Required] short IID, [FromQuery][Required] short CID)
        {
            VehicleHeaderInfo result = _inventoryLogic.GetVehicleHeaderInfo(VID, SID, IID, CID);
            return Ok(result);
        }

        /// <summary>
        /// Get Retail Price Change Details.
        /// </summary>
        /// <remarks>Get Retail price change details for Inventory Vehicles </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>        
        [HttpGet("GetRetailPriceChangeDetails/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<RetailPriceChangeDetails> GetRetailPriceChangeDetails([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            var vehiclestatushstry = _inventoryLogic.GetRetailPriceChangeDetails(VID, SID, IID, CID);
            return StatusCode(200, vehiclestatushstry);
        }

        /// <summary>
        /// Save Retail Price.
        /// </summary>
        /// <remarks>
        /// Save Retail Price.
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("RetailPriceActiveSave")]
        public virtual ActionResult<bool> RetailPriceActiveSave([FromBody] VehiclePriceUpdates retailpricesave)
        {
            bool saved = _inventoryLogic.RetailPriceActiveSave(retailpricesave);
            return StatusCode(200, saved);
        }
        /// <summary>
        /// Save Retail Price Review
        /// </summary>
        /// <remarks>
        /// Save Retail Price Review.
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("RequestRetailPriceReview")]
        public virtual ActionResult<bool> RequestRetailPriceReview([FromBody] PriceReviewParams pricereview)
        {
            bool saved = _inventoryLogic.RequestRetailPriceReview(pricereview);
            return StatusCode(200, saved);
        }
    }
}
