﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Sonic.OneSIMS.BusinessLogic.Interfaces.SAC;
using Microsoft.Extensions.Configuration;
using System.ComponentModel.DataAnnotations;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Inventory;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Appraisal;
using Sonic.OneSIMS.Api.DTOs.Inventory;
using Sonic.OneSIMS.DomainModels.Inventory;

namespace Sonic.OneSIMS.Api.Controllers.Inventory
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Inventory")]
    [ApiConventionType(typeof(SIMSConventions))]

    public class InventoryController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IInventoryLogic _InventoryLogic;
        public readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="InventoryController"/> class.
        /// </summary>
        /// <param name="inventorylogic"></param>
        /// <param name="configuration"></param>
        /// <param name="mapper"></param>
        public InventoryController(IInventoryLogic inventorylogic, IMapper mapper, IConfiguration configuration)
        {
            _InventoryLogic = inventorylogic;
            _mapper = mapper;
            _configuration = configuration;
        }

        /// <summary>
        /// Create appraisal 
        /// </summary>
        /// <remarks>Create the new appraisal of vehicle by checking all required usecases</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>      
        [HttpPost("AddVehicle")]
        public virtual ActionResult<CreateAppraisalResponse> AddVehicle([FromBody] BasicInvAddVehicle basicInvAddVehicleinfo)
        {
            var t = _InventoryLogic.InvAddVehicle(_mapper.Map<BasicInvAddVehicle>(basicInvAddVehicleinfo));
            return StatusCode(200, t);
        }
        /// <summary>
        /// Return Vehicle Status Change History.
        /// </summary>
        /// <remarks>Get Vehicle Status Change History</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("VehicleStatusChangeHistory/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<StatusChangehistory> VehicleStatusChangeHistory([FromRoute][Required] long VID,[FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            var vehiclestatushstry = _InventoryLogic.VehicleStatusChangeHistory(VID, SID,IID,CID);
            return StatusCode(200, vehiclestatushstry);
        }
        /// <summary>
        /// Return Market Ready History.
        /// </summary>
        /// <remarks>Get Market Ready History</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("MarketReadyHistory/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<MarketReadyHistory> MarketReadyHistory([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            var marketreadyhstry = _InventoryLogic.MarketReadyHistory(VID, SID, IID, CID);
            return StatusCode(200, marketreadyhstry);
        }
        /// <summary>
        /// Return Price Change History.
        /// </summary>
        /// <remarks>Get Price Change History</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("PriceChangeHistory/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<PriceChangeHistory> PriceChangeHistory([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            var pricechangehstry = _InventoryLogic.PriceChangeHistory(VID, SID, IID, CID);
            return StatusCode(200, pricechangehstry);
        }
    }
}
