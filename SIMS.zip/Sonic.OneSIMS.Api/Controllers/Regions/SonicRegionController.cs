﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.Api.DTOs.Regions;
using Sonic.OneSIMS.Api.DTOs.Store;

namespace Sonic.OneSIMS.Api.Controllers.Regions
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]

    public class SonicRegionController : ControllerBase
    {
        private readonly IRegionLogic _regionLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="SonicRegionController"/> class.
        /// </summary>
        /// <param name="regionLogic"></param>
        /// <param name="mapper"></param>
        public SonicRegionController(IRegionLogic regionLogic, IMapper mapper)
        {
            _mapper = mapper;
            _regionLogic = regionLogic;
        }


        /// <summary>
        /// Returns all active Regions of Sonic Used.
        /// </summary>
        /// <remarks>Get all active Regions</remarks>
        /// <response code="200">successful operation</response>
        [HttpGet("GetAllRegionList/{CID}")]
        public virtual ActionResult<Region> GetAllRegionList([FromRoute][Required] short CID)
        {
            var region = _regionLogic.GetAllRegions(CID);
            List<DomainModels.Settings.Regions.Region> regions = _mapper.Map<List<DomainModels.Settings.Regions.Region>>(region);
            return StatusCode(200, regions);
        }

        /// <summary>
        /// Add a New Region Details.
        /// </summary>
        /// <param name="newRegionDetails">Region Details </param>
        /// <response code="201">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddNewRegionDetails")]
        public virtual ActionResult<int> AddNewRegionDetails([FromBody] NewRegionDetails newRegionDetails)
        {
            if (!string.IsNullOrWhiteSpace(newRegionDetails.RegionName))
            {
                int errorNo = 0;
                DomainModels.Settings.Regions.NewRegionDetails regions = _mapper.Map<DomainModels.Settings.Regions.NewRegionDetails>(newRegionDetails);
                int regionId = _regionLogic.AddNewRegionDetails(regions, ref errorNo);
                //string message="RegionID="+regionId+"|ErrorNo="+errorNo+"";
                return StatusCode(201, regionId);
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }

        }

        /// <summary>
        /// Deletes Region Details
        /// </summary>
        /// <param name="RegionId">Region id to delete</param>
        /// <response code="200">Region Deletion Successfull</response>
        /// <response code="400">Invalid Region Id supplied</response>
        /// <response code="404">RegionAssociation not found</response>
        [HttpDelete("DeleteRegion/{RegionID}/{Is_Act}/{UserName}")]
        public virtual ActionResult<bool> DeleteRegion([FromRoute][Required] short RegionID, [FromRoute][Required] bool Is_Act, [FromRoute] string UserName)
        {
            if (RegionID != 0)
            {
                bool isDeleteSuccess = _regionLogic.DeleteRegionById(RegionID, Is_Act, UserName);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, isDeleteSuccess);
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Returns Details of Region Configurations.
        /// </summary>
        /// <remarks>Get all details of Region Configurations</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetRegionConfiguration/{RegionID}")]
        public virtual ActionResult<RegionConfiguration> GetRegionConfiguration([FromRoute][Required] short RegionID)
        {
            var regionDetails = _regionLogic.GetRegionConfigurations(RegionID);
            DomainModels.Settings.Regions.RegionConfiguration regions = _mapper.Map<DomainModels.Settings.Regions.RegionConfiguration>(regionDetails);
            return StatusCode(200, regions);
        }

        /// <summary>
        /// Returns List of Region Associated Stores.
        /// </summary>
        /// <remarks>Gets all stores associated to Region </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetRegionAssociatedStores/{RegionID}")]
        public virtual ActionResult<List<Store>> GetRegionAssociatedStores([FromRoute][Required] short RegionID)
        {
            var regionDetails = _regionLogic.GetRegionAssociatedStores(RegionID);
            List<DomailModels.Settings.Store> regions = _mapper.Map<List<DomailModels.Settings.Store>>(regionDetails);
            return StatusCode(200, regions);
        }

        /// <summary>
        /// Save the Region Details.
        /// </summary>
        /// <param name="regionConfiguration">Save Region Details </param>
        /// <response code="201">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="405">Invalid input</response>
        [HttpPost("SaveRegionConfigSettings")]
        public virtual ActionResult<bool> SaveRegionConfigSettings([FromBody] RegionConfiguration regionConfiguration)
        {
            DomainModels.Settings.Regions.RegionConfiguration regions = _mapper.Map<DomainModels.Settings.Regions.RegionConfiguration>(regionConfiguration);
            bool regionDetails = _regionLogic.SaveRegionConfigSettings(regions);

            if (regionDetails)
            {
                return StatusCode(200, regionDetails);
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }
        }

        /// <summary>
        /// Deletes the associated store from the  Region
        /// </summary>
        /// <param name="RegionId">Region id </param>
        /// <param name="StoreID">Store id </param>
        /// <response code="200">Store Association Deletion Successfull</response>
        /// <response code="400">Invalid Region Id supplied</response>
        /// <response code="404">RegionAssociation not found</response>
        [HttpDelete("DeleteStoreAssociation/{RegionID}/{StoreID}/{UserName}")]
        public virtual ActionResult<bool> DeleteStoreAssociation([FromRoute][Required] short RegionID, [FromRoute][Required] short StoreID, [FromRoute] string UserName)
        {
            if (RegionID != 0 && StoreID != 0)
            {
                bool isDeleteSuccess = _regionLogic.DeleteStoreAssociation(RegionID, StoreID, UserName);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, isDeleteSuccess);
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Add a New Stores to Region asoociation Details.
        /// </summary>
        /// <param name="newRegionDetails">Associate New stores to Region</param>
        /// <response code="201">successful operation</response>
        /// <response code="400">Invalid status value</response>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddStoreRegionAssociation")]
        public virtual ActionResult<int> AddStoreRegionAssociation([FromBody] NewRegionDetails newRegionDetails)
        {
            if (newRegionDetails.RegionID != 0 && newRegionDetails.StoreID != 0)
            {
                string errorNo = "";
                DomainModels.Settings.Regions.NewRegionDetails regions = _mapper.Map<DomainModels.Settings.Regions.NewRegionDetails>(newRegionDetails);
                int regionId = _regionLogic.AddStoreRegionAssociation(regions, ref errorNo);
                return StatusCode(201, regionId);
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }

        }

        /// <summary>
        /// Returns List of All UnAssociated Stores.
        /// </summary>
        /// <remarks>Gets of All UnAssociated Stores </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetAllRegionsStores")]
        public virtual ActionResult<List<RegionStore>> GetAllRegionsStores()
        {
            var regionStores = _regionLogic.GetAllRegionsStores();
            List<DomainModels.Settings.Regions.RegionStore> regionStore = _mapper.Map<List<DomainModels.Settings.Regions.RegionStore>>(regionStores);
            return StatusCode(200, regionStore);
        }


    }

}
