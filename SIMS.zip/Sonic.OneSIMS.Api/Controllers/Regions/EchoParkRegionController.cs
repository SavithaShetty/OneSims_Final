﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs.Regions;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;

namespace Sonic.OneSIMS.Api.Controllers.Stores
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class EchoParkRegionController : ControllerBase
    {


        private readonly IRegionLogic _regionLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="EchoParkRegionController"/> class.
        /// </summary>
        /// <param name="regionLogic"></param>
        /// <param name="mapper"></param>
        public EchoParkRegionController(IRegionLogic regionLogic, IMapper mapper)
        {
            _regionLogic = regionLogic;
            _mapper = mapper;
        }
        /// <summary>
        /// Return all active Regions of OneSIMS EchoPark.
        /// </summary>
        /// <remarks>Get all active Regions</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetRegion/{CID}")]
        public virtual ActionResult<Region> GetRegionList([FromRoute] short CID)
        {
            var regionItem = _regionLogic.GetAllRegions(CID);
            IEnumerable<Region> regions = (IEnumerable<Region>)_mapper.Map<IEnumerable<DomainModels.Settings.Regions.Region>>(regionItem);
            return StatusCode(200, regions);
        }

        /// <summary>
        /// Add a new Region.
        /// </summary>
        /// <param name="region">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddRegion")]
        public virtual ActionResult<string> AddRegion([FromBody] Region region)
        {
            if (region != null)
            {
                bool isAddSuccess = _regionLogic.AddRegions(_mapper.Map<DomainModels.Settings.Regions.Region>((object)region));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Region created");
                }
                else
                {
                    return Ok("Region was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes a Region.
        /// </summary>
        /// <param name="id">Store id to delete</param>
        /// <response code="400">Invalid Region ID supplied</response>
        /// <response code="404">Region not found</response>
        [HttpDelete("{id}")]
        public virtual ActionResult DeleteRegion([FromRoute] int? id)
        {
            if (id.HasValue)
            {
                bool isDeleteSuccess = _regionLogic.DeleteRegionById(id.Value);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        [HttpPost("AddPod")]
        public virtual ActionResult<string> AddPod([FromBody] RegionConfiguration regionConfiguration)
        {
            if (regionConfiguration != null)
            {
                bool isAddSuccess =_regionLogic.AddRegions(_mapper.Map<DomainModels.Settings.Regions.Region>((object)regionConfiguration));
               // bool isAddSuccess =_regionLogic.AddPod(_mapper.Map<DomailModels.Settings.Regions.Region>((object)regionConfiguration));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Region created");
                }
                else
                {
                    return Ok("Region was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        [HttpGet("Region/GetAllPod")]
        public virtual ActionResult<List<List<Pod>>> GetAllPods([FromBody] int regionId) 
        {
            // var storeItem = _regionLogic;
            var regionItem = regionId;// _regionLogic.GetAllPods(regionId);
            IEnumerable<DomainModels.Settings.Regions.Region> regions = (IEnumerable<DomainModels.Settings.Regions.Region>)_mapper.Map<DomainModels.Settings.Regions.Region>(regionItem);
            //IEnumerable<DomailModels.Settings.Store> stores = _mapper.Map<IEnumerable<DomailModels.Settings.Store>>(storeItem);
            return StatusCode(200, regionId);
        }

        [HttpDelete("{storeId,regionId}")]
        public virtual ActionResult DeletePodAssociation([FromBody] int? storeId, int? regionId)
        {
            if (storeId.HasValue && regionId.HasValue)
            {
                bool isDeleteSuccess = _regionLogic.DeletePodAssociation(storeId.Value,regionId.Value);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }
    }
        //public void DeletePodAssociation(int storeId, int regionId, string userName)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    configDataMngr.DeletePodAssociation(storeId, regionId, userName);
        //}

        #region Region Configuration

        //public List<Region> SearchRegion(string regionName, int startRow, int endRow, string sortDirection, string userName, ref int rowCount, string type)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return (configDataMngr.SearchRegion(regionName, startRow, endRow, sortDirection, userName, ref rowCount, type));
        //}

        //public RegionConfiguration GetRegionConfigSettings(int regionId)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return (configDataMngr.GetRegionConfigSettings(regionId));
        //}

        //public int SaveRegionConfigSettings(RegionConfiguration regionConfig, string userName)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return (configDataMngr.SaveRegionConfigSettings(regionConfig, userName));
        //}

        //public int AddRegion(string regionName, string userName, string type, ref int errorNo)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return (configDataMngr.AddRegion(regionName, userName, type, ref errorNo));
        //}

        //public int AddPod(RegionConfiguration regionConfig, int podId, string userName)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return (configDataMngr.AddPod(regionConfig, podId, userName));
        //}

        //public List<List<Pod>> GetRegionPods(int regionId, int startRow, int endRow, string sortDirection, ref int rowCount)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return (configDataMngr.GetRegionPods(regionId, startRow, endRow, sortDirection, ref rowCount));
        //}

        //public void DeletePodAssociation(int storeId, int regionId, string userName)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    configDataMngr.DeletePodAssociation(storeId, regionId, userName);
        //}

        //public int CheckRegionClassification(int RegionId, int ClassificationId)
        //{
        //    ConfigurationDataManager configDataMngr = new ConfigurationDataManager();
        //    return configDataMngr.CheckRegionClassification(RegionId, ClassificationId);
        //}

        #endregion
    }

