﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.Configuration;
using Sonic.OneSIMS.Api.DTOs.Books.KBB;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomainModels.Books.Common;
using Sonic.OneSIMS.DomainModels.Books.KBB;
using Sonic.OneSIMS.Infrastructure.KBB.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Sonic.OneSIMS.Api.Controllers.Books
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Books")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class KBBBookController
    {
        private readonly IKBBBookLogic _kbbBookLogic;
        private readonly IBooksCommonLogic _booksCommonLogic;
        private readonly IMapper _mapper;
        ConfigSettings _configSettings = null;
        ConfigValues _configValues = null;
        public KBBBookController(IKBBBookLogic kbbBookLogic, IMapper mapper, IConfiguration configuration, IBooksCommonLogic booksCommonLogic)
        {
            _kbbBookLogic = kbbBookLogic;
            _configSettings = new ConfigSettings(configuration);
            ReadConfigValues(ref _configValues);
            _mapper = mapper;
            _booksCommonLogic = booksCommonLogic;
        }

        private void ReadConfigValues(ref ConfigValues configValues)
        {
            configValues = new ConfigValues();
            configValues.AuthUserName = _configSettings.GetKBBAuthUserName();
            configValues.AuthPWD = _configSettings.GetKBBAuthPassword();
            configValues.MediaType = _configSettings.GetMediaType();
            configValues.baseURL = _configSettings.GetKBBBaseURL();
        }

        /// <summary>
        /// Get years list
        /// </summary>
        /// <remarks>Get the years list</remarks>
        /// <response code="200">Returns the years list </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetYears")]
        public IEnumerable<IDValues> GetYears()
        {
            return _kbbBookLogic.GetYearsList(_configValues);
        }

        /// <summary>
        /// Get the list of Makes for the provided YearId 
        /// </summary>         
        /// <remarks>Get list of Makes for the provided YearID.</remarks>
        /// <br />     
        /// <br />  
        /// <response code="200">Success: Returns list of Makes for the provided YearId successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>     
        [HttpGet("GetMakes")]
        public IEnumerable<IDValues> GetMakes([FromQuery][Required] int yearId)
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = yearId;
            return _kbbBookLogic.GetMakesKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.Make);
        }

        /// <summary>
        /// Get Model list by passing Make ID and Year ID
        /// </summary>
        /// <remarks>Get the list of Models</remarks>
        /// <response code="200">Success: Returns list of Model for the provided Make ID and Year ID successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetModels")]
        public IEnumerable<IDValues> GetModels([FromQuery][Required] int yearId, [FromQuery][Required] int makeId)
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = yearId;
            inputParams.makeid = makeId;
            return _kbbBookLogic.GetModelsKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.Model);
        }

        /// <summary>
        /// Get ModelYearID by passing Make ID, Model ID and Year ID
        /// </summary>
        /// <remarks>Get ModelYearID by passing Make ID, Model ID and Year ID</remarks>
        /// <response code="200">Success: Returns ModelYearID for the provided Make ID, Model ID and Year ID successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [HttpGet("GetModelYears")]
        public IEnumerable<ModelYear> GetModelYears([FromQuery][Required] int yearId, [FromQuery][Required] int makeId, [FromQuery][Required] int modelId)
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = yearId;
            inputParams.makeid = makeId;
            inputParams.modelId = modelId;
            var modelYearRes = _kbbBookLogic.GetKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.ModelYear);
            IEnumerable<DTOs.Books.KBB.ModelYear> modelYearList = _mapper.Map<IEnumerable<DTOs.Books.KBB.ModelYear>>(JsonConvert.DeserializeObject<List<ModelYear>>(modelYearRes.ToString()));
            return modelYearList;
        }

        /// <summary>
        /// Get list of TrimId by passing Make ID, Model ID, Year ID and ModelYearID
        /// </summary>
        /// <remarks>Get list of TrimId by passing Make ID, Model ID, Year ID and ModelYearID</remarks>
        /// <response code="200">Success: Returns list of TrimId for the provided  Make ID, Model ID, Year ID and ModelYearID successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [HttpGet("GetTrims")]
        public IEnumerable<IDValues> GetTrims([FromQuery][Required] int yearId, [FromQuery][Required] int makeId, [FromQuery][Required] int modelId)
        {
            InputParams inputParams = new InputParams();
            inputParams.yearId = yearId;
            inputParams.makeid = makeId;
            inputParams.modelId = modelId;
            var modelYearRes = _kbbBookLogic.GetKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.ModelYear);
            List<DTOs.Books.KBB.ModelYear> modelYearList = _mapper.Map<List<DTOs.Books.KBB.ModelYear>>(JsonConvert.DeserializeObject<List<ModelYear>>(modelYearRes.ToString()));
            if (modelYearList.Count() > 0)
            {
                inputParams.modelYearId = modelYearList[0].modelYearId;
                return _kbbBookLogic.GetTrimsKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.Trim);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Decode VIN
        /// </summary>
        /// <remarks>Decode the VIN Details</remarks>
        /// <response code="200">Success: Returns list of decoded details for the provided VIN successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [HttpPost("GetBookValuation")]
        public KBBBookValuation GetBookValuation([FromBody] KBBBookValuationRequest bookValuationRequest, [FromQuery] bool isEditMode)
        {
            InputParams inputParams = new InputParams();
            inputParams.VIN = bookValuationRequest.VIN;
            var decodeRes = _kbbBookLogic.GetKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.Decode);
            VINDecode decodeRespose = JsonConvert.DeserializeObject<VINDecode>(decodeRes.ToString());
            KBBBookValuation parsedDecodeResult = ConvertDecodeVin(decodeRespose.vinResults, bookValuationRequest, isEditMode);
            parsedDecodeResult.vin = bookValuationRequest.VIN;
            return parsedDecodeResult;
        }

        /// <summary>
        /// Get Vehicle options which includes Engine, DriveTrain, Transmission and Options based on different CategoryName and OptionType
        /// </summary>
        /// <remarks>Get Vehicle options which includes Engine, DriveTrain, Transmission and Options based on different CategoryName and OptionType Ex:
        /// <br />
        /// <br />
        /// For Engine -- "optionType": "Equipment" and "CategoryName": "Engine"
        /// <br />
        /// <br />
        /// For Transmission -- "optionType": "Equipment" and "CategoryName": "Transmission"
        /// <br />
        /// For DriveTrain -- "optionType": "Equipment" and "CategoryName": "Drivetrain"
        /// <br />
        /// <br />
        /// For Factory Options -- "optionType": "Option"
        /// <br />
        /// </remarks>
        /// <response code="200">Success: Returns list of vehicle Options for the provided VehicleId successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>
        [HttpGet("GetOptions")]
        public IEnumerable<KBBOption> GetOptions([FromQuery][Required] int vehicleId, [FromQuery] int appCategory)
        {
            InputParams inputParams = new InputParams();
            inputParams.VehicleId = vehicleId;
            inputParams.AppCategory = appCategory;
            List<KBBOption> kBBOptions = new List<KBBOption>();
            var optionList = _kbbBookLogic.GetKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.Options);
            IEnumerable<DTOs.Books.KBB.Options> optionsList = _mapper.Map<IEnumerable<DTOs.Books.KBB.Options>>(JsonConvert.DeserializeObject<List<Options>>(optionList.ToString()));
            List<KBBOption> kBBColorOption = new List<KBBOption>();
            foreach (var option in optionsList)
            {
                if (option.optionType.ToLower() == "option")
                {
                    KBBOption optionValue = new KBBOption
                    {
                        ID = option.VehicleOptionId.ToString(),
                        Value = option.optionName,
                        Cost = 0,
                        Selected = option.isTypical,
                        Oa = option.isConfigurable == true ? "S" : "A",
                        TradeInCost = 0,
                        RetailCost = 0
                    };
                    kBBOptions.Add(optionValue);
                }
                else if (option.optionType.ToLower() == "color")
                {
                    KBBOption optionValue = new KBBOption
                    {
                        ID = option.VehicleOptionId.ToString(),
                        Value = option.optionName,
                        Cost = 0,
                        Selected = option.isTypical,
                        Oa = option.isConfigurable == true ? "S" : "A",
                        TradeInCost = 0,
                        RetailCost = 0
                    };
                    kBBColorOption.Add(optionValue);
                }
            }
            kBBOptions.AddRange(kBBColorOption);
            return kBBOptions;
        }
        /// <summary>
        /// Get the Engine, DriveTrain and Transmission based on different CategoryName and OptionType
        /// </summary>
        /// <remarks>Get the Engine, DriveTrain and Transmission based on different CategoryName and OptionType       
        /// </remarks>
        /// <response code="200">Success: Returns list engines, transmissions and DriveTrain values for the provided VehicleId successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [HttpGet("GetEngineTransDriveTrain")]
        public DTOs.Books.KBB.TrimOptionValues GetEngineTransDriveTrain([FromQuery][Required] int vehicleId, [FromQuery] int appCategory)
        {
            InputParams inputParams = new InputParams();
            inputParams.VehicleId = vehicleId;
            inputParams.AppCategory = appCategory;
            var optionList = _kbbBookLogic.GetKBBEndpointResult(_configValues, inputParams, KBBRestEndpoints.Options);
            List<Options> optionsList = JsonConvert.DeserializeObject<List<Options>>(optionList.ToString());

            return GetEngTransDTFromOption(optionsList);
        }

        private DTOs.Books.KBB.TrimOptionValues GetEngTransDTFromOption(List<Options> optionsList)
        {
            DTOs.Books.KBB.TrimOptionValues optionList = new DTOs.Books.KBB.TrimOptionValues();
            optionList.Engine.AddRange(GetListOfIDValues(optionsList.FindAll(x => x.optionType.ToLower() == "equipment" && x.categoryGroup.ToLower() == "engine")));
            optionList.Transmission.AddRange(GetListOfIDValues(optionsList.FindAll(x => x.optionType.ToLower() == "equipment" && x.categoryGroup.ToLower() == "transmission")));
            optionList.DriveTrain.AddRange(GetListOfIDValues(optionsList.FindAll(x => x.optionType.ToLower() == "equipment" && x.categoryGroup.ToLower() == "drivetrain")));

            return optionList;
        }

        /// <summary>
        /// Post the book values along with configuration and returns with price values
        /// </summary>
        /// <remarks>Post the book values along with configuration to get price values for differnt price types and as per SIMS logic Retail and wholesale prices will be calculated
        /// <br />
        /// </remarks>
        /// <response code="200">Success: Returns list of price values for the provided configuration successfully from service.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         

        [HttpPost("GetBookValues")]
        public DTOs.Appraisal.BookResponse GetBookValues([FromBody] DTOs.BookRequest bookRequestValues)
        {
            Sonic.OneSIMS.Infrastructure.KBB.Entities.BookRequest bookReq = JsonConvert.DeserializeObject<Sonic.OneSIMS.Infrastructure.KBB.Entities.BookRequest>(JsonConvert.SerializeObject(bookRequestValues));
            var bookRes = _kbbBookLogic.GetBookValues(bookReq, _configValues);
            DTOs.Appraisal.BookResponse bookResponse = JsonConvert.DeserializeObject<DTOs.Appraisal.BookResponse>(JsonConvert.SerializeObject(bookRes));
            return bookResponse;
        }

        /// <summary>
        /// Save KBB book values into database
        /// </summary>
        /// <remarks>Save KBB book values into database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns true if book values saved successfully.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpPost("SaveKBBBooks")]
        public Boolean SaveKBBBooks([FromBody] DomainModels.Books.Common.Books books)
        {
            return _booksCommonLogic.SaveKBBBooks(books.KBB, books.VehicleIdentity, books.Vin, books.UserName);
        }

        /// <summary>
        /// Get saved KBB book values from database
        /// </summary>
        /// <remarks>Get Saved KBB book values from database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns saved books.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetSavedKBBBooks/{vehicleId}/{storeId}/{invtrId}")]
        public BookValuation GetSavedKBBBooks([FromRoute][Required] int vehicleId, [FromRoute][Required] int storeId, [FromRoute][Required] int invtrId)
        {
            return _booksCommonLogic.GetKBBSavedBooks(vehicleId, storeId, invtrId);
        }

        #region Decode parsing/extraction methods

        private KBBBookValuation ConvertDecodeVin(List<VinResult> valVinDecodeResp, KBBBookValuationRequest bookValuationRequest, bool isEditMode)
        {
            KBBBookValuation vinVehicleDetail = new KBBBookValuation();
            BookValuation savedBooks = null;
            if (isEditMode)//editmode true
            {
                savedBooks = _booksCommonLogic.GetKBBSavedBooks(bookValuationRequest.vehicleIdentity.VID, bookValuationRequest.vehicleIdentity.SID, bookValuationRequest.vehicleIdentity.IID);
            }

            if (valVinDecodeResp != null && valVinDecodeResp.Count > 0 && valVinDecodeResp[0].trimId > 0)
            {
                vinVehicleDetail.IsDecodeSuccess = true;

                #region No Clarify Needed
                if (valVinDecodeResp.Count == 1)
                {
                    vinVehicleDetail.vehicleId = valVinDecodeResp[0].vehicleId;
                    //VIN does not decode
                    if (valVinDecodeResp[0].yearId <= 0)
                    {
                        //Edit Mode
                        if (isEditMode && savedBooks != null)
                        {
                            AssignSavedValues(vinVehicleDetail, savedBooks, bookValuationRequest);
                        }
                        //Non-Edit Mode
                        else
                        {
                            vinVehicleDetail.years = GetYearsIDList();
                        }

                    }
                    //VIN decodes completely
                    else
                    {
                        //Edit Mode
                        if (isEditMode && savedBooks != null)
                        {
                            vinVehicleDetail.years = new List<IDValues>();
                            vinVehicleDetail.years.Add(new IDValues
                            {
                                ID = valVinDecodeResp[0].yearId.ToString(),
                                Value = valVinDecodeResp[0].yearId.ToString()
                            });

                            vinVehicleDetail.Uvc = "";// valVinDecodeResp.valDecodeResp[0].providerVinDef[0].str_provider_defn_code.Trim();

                            if (valVinDecodeResp[0].makeId > 0)
                            {
                                vinVehicleDetail.make = new List<IDValues>();
                                vinVehicleDetail.make.Add(new IDValues { ID = valVinDecodeResp[0].makeId.ToString(), Value = valVinDecodeResp[0].makeName });
                            }

                            if (valVinDecodeResp[0].modelId > 0)
                            {
                                vinVehicleDetail.model = new List<IDValues>();
                                vinVehicleDetail.model.Add(new IDValues { ID = valVinDecodeResp[0].modelId.ToString(), Value = valVinDecodeResp[0].modelName });
                            }

                            if (valVinDecodeResp[0].vehicleId > 0)
                            {
                                vinVehicleDetail.series = new List<IDValues>();
                                vinVehicleDetail.series.Add(new IDValues { ID = valVinDecodeResp[0].vehicleId.ToString(), Value = valVinDecodeResp[0].trimName });
                            }

                            if (valVinDecodeResp[0].vehicleOptions != null)
                            {
                                vinVehicleDetail.Options = new List<DTOs.Books.KBB.OptionValues>();
                                vinVehicleDetail.Engine = new List<IDValues>();
                                vinVehicleDetail.Transmission = new List<IDValues>();
                                vinVehicleDetail.DriveTrain = new List<IDValues>();

                                vinVehicleDetail.Engine.AddRange(GetListOfIDValues(valVinDecodeResp[0].vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "engine")));
                                vinVehicleDetail.DriveTrain.AddRange(GetListOfIDValues(valVinDecodeResp[0].vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "drivetrain")));
                                vinVehicleDetail.Transmission.AddRange(GetListOfIDValues(valVinDecodeResp[0].vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "transmission")));

                                vinVehicleDetail.Engine.ForEach(c => c.Selected = false);
                                vinVehicleDetail.DriveTrain.ForEach(c => c.Selected = false);
                                vinVehicleDetail.Transmission.ForEach(c => c.Selected = false);


                                foreach (var engine in vinVehicleDetail.Engine.Where(y => y.ID == savedBooks.Engine.ID))
                                {
                                    engine.Selected = true;
                                }
                                foreach (var driveTrain in vinVehicleDetail.DriveTrain.Where(y => y.ID == savedBooks.DriveTrain.ID))
                                {
                                    driveTrain.Selected = true;
                                }
                                foreach (var transmission in vinVehicleDetail.Transmission.Where(y => y.ID == savedBooks.Transmission.ID))
                                {
                                    transmission.Selected = true;
                                }
                                foreach (Options option in valVinDecodeResp[0].vehicleOptions.FindAll(x => x.optionType.ToLower() == "option"))
                                {
                                    DTOs.Books.KBB.OptionValues optionValue = new DTOs.Books.KBB.OptionValues { ID = option.VehicleOptionId.ToString(), Value = option.optionName, Cost = 0, Selected = option.isTypical, Oa = option.isConfigurable == true ? "S" : "A", TradeInCost = 0, RetailCost = 0 };

                                    if (savedBooks.Options.Any(x => x.ID == optionValue.ID && x.Selected == true))
                                        optionValue.Selected = true;
                                    else
                                        optionValue.Selected = false;
                                    vinVehicleDetail.Options.Add(optionValue);
                                }

                                foreach (Options option in valVinDecodeResp[0].vehicleOptions.FindAll(x => x.optionType.ToLower() == "color"))
                                {
                                    DTOs.Books.KBB.OptionValues optionValue = new DTOs.Books.KBB.OptionValues { ID = option.VehicleOptionId.ToString(), Value = option.optionName, Cost = 0, Selected = option.isTypical, Oa = option.isConfigurable == true ? "S" : "A", TradeInCost = 0, RetailCost = 0 };

                                    if (savedBooks.Options.Any(x => x.ID == optionValue.ID && x.Selected == true))
                                        optionValue.Selected = true;
                                    else
                                        optionValue.Selected = false;
                                    vinVehicleDetail.Options.Add(optionValue);
                                }
                            }
                            //To get bookValues
                            InternalGetBookValues(vinVehicleDetail, savedBooks, bookValuationRequest, vinVehicleDetail.Options);
                        }
                        //Non-Edit Mode
                        else
                        {
                            vinVehicleDetail.years = new List<IDValues>();
                            vinVehicleDetail.years.Add(new IDValues
                            {
                                ID = valVinDecodeResp[0].yearId.ToString(),
                                Value = valVinDecodeResp[0].yearId.ToString()
                            });

                            vinVehicleDetail.Uvc = "";// valVinDecodeResp.valDecodeResp[0].providerVinDef[0].str_provider_defn_code.Trim();

                            if (valVinDecodeResp[0].makeId > 0)
                            {
                                vinVehicleDetail.make = new List<IDValues>();
                                vinVehicleDetail.make.Add(new IDValues { ID = valVinDecodeResp[0].makeId.ToString(), Value = valVinDecodeResp[0].makeName });
                            }

                            if (valVinDecodeResp[0].modelId > 0)
                            {
                                vinVehicleDetail.model = new List<IDValues>();
                                vinVehicleDetail.model.Add(new IDValues { ID = valVinDecodeResp[0].modelId.ToString(), Value = valVinDecodeResp[0].modelName });
                            }

                            if (valVinDecodeResp[0].vehicleId > 0)
                            {
                                vinVehicleDetail.series = new List<IDValues>();
                                vinVehicleDetail.series.Add(new IDValues { ID = valVinDecodeResp[0].vehicleId.ToString(), Value = valVinDecodeResp[0].trimName });
                            }

                            if (valVinDecodeResp[0].vehicleOptions != null)
                            {
                                vinVehicleDetail.Options = new List<DTOs.Books.KBB.OptionValues>();
                                vinVehicleDetail.Engine = new List<IDValues>();
                                vinVehicleDetail.Transmission = new List<IDValues>();
                                vinVehicleDetail.DriveTrain = new List<IDValues>();

                                vinVehicleDetail.Engine.AddRange(GetListOfIDValues(valVinDecodeResp[0].vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "engine")));
                                vinVehicleDetail.DriveTrain.AddRange(GetListOfIDValues(valVinDecodeResp[0].vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "drivetrain")));
                                vinVehicleDetail.Transmission.AddRange(GetListOfIDValues(valVinDecodeResp[0].vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "transmission")));

                                vinVehicleDetail.Engine.ForEach(c => c.Selected = false);
                                vinVehicleDetail.DriveTrain.ForEach(c => c.Selected = false);
                                vinVehicleDetail.Transmission.ForEach(c => c.Selected = false);

                                foreach (Options option in valVinDecodeResp[0].vehicleOptions.FindAll(x => x.optionType.ToLower() == "option"))
                                {
                                    DTOs.Books.KBB.OptionValues optionValue = new DTOs.Books.KBB.OptionValues { ID = option.VehicleOptionId.ToString(), Value = option.optionName, Cost = 0, Selected = option.isTypical, Oa = option.isConfigurable == true ? "S" : "A", TradeInCost = 0, RetailCost = 0 };
                                    vinVehicleDetail.Options.Add(optionValue);
                                }

                                foreach (Options option in valVinDecodeResp[0].vehicleOptions.FindAll(x => x.optionType.ToLower() == "color"))
                                {
                                    DTOs.Books.KBB.OptionValues optionValue = new DTOs.Books.KBB.OptionValues { ID = option.VehicleOptionId.ToString(), Value = option.optionName, Cost = 0, Selected = option.isTypical, Oa = option.isConfigurable == true ? "S" : "A", TradeInCost = 0, RetailCost = 0 };
                                    vinVehicleDetail.Options.Add(optionValue);
                                }
                            }
                        }
                    }
                }
                #endregion
                #region Clarify Needed
                //  VIN decodes partially
                else
                {
                    vinVehicleDetail.years = new List<IDValues>();
                    vinVehicleDetail.make = new List<IDValues>();
                    vinVehicleDetail.model = new List<IDValues>();
                    vinVehicleDetail.series = new List<IDValues>();
                    vinVehicleDetail.bodyStyle = new List<IDValues>();
                    vinVehicleDetail.Engine = new List<IDValues>();
                    vinVehicleDetail.Transmission = new List<IDValues>();
                    vinVehicleDetail.DriveTrain = new List<IDValues>();
                    //Edit Mode
                    if (isEditMode && savedBooks != null)
                    {
                        AssignSavedValues(vinVehicleDetail, savedBooks, bookValuationRequest);
                    }
                    //Non-Edit Mode
                    else
                    {
                        foreach (VinResult vinDef in valVinDecodeResp)
                        {
                            if (vinDef.yearId > 0 && !String.IsNullOrEmpty(vinDef.yearId.ToString()))
                            {
                                IDValues yearValue = new IDValues { ID = vinDef.yearId.ToString(), Value = vinDef.yearId.ToString() };
                                if (vinVehicleDetail.years.Find(x => x.ID == vinDef.yearId.ToString()) == null)
                                {
                                    vinVehicleDetail.years.Add(yearValue);
                                }
                            }
                            if (vinDef.makeId > 0 && !String.IsNullOrEmpty(vinDef.makeId.ToString()))
                            {

                                IDValues makeValue = new IDValues { ID = vinDef.makeId.ToString(), Value = vinDef.makeName };
                                if (vinVehicleDetail.make.Find(x => x.ID == vinDef.makeId.ToString()) == null)
                                {
                                    vinVehicleDetail.make.Add(makeValue);
                                }
                            }
                            if (vinDef.modelId > 0 && !String.IsNullOrEmpty(vinDef.modelId.ToString()))
                            {
                                IDValues modelValue = new IDValues { ID = vinDef.modelId.ToString(), Value = vinDef.modelName };
                                if (vinVehicleDetail.model.Find(x => x.ID == vinDef.modelId.ToString()) == null)
                                {
                                    vinVehicleDetail.model.Add(modelValue);
                                }
                            }
                            if (vinDef.vehicleId > 0 && !String.IsNullOrEmpty(vinDef.vehicleId.ToString()))
                            {
                                //id = VehicleID which will be used to identify Trim.
                                IDValues seriesValue = new IDValues { ID = vinDef.vehicleId.ToString(), Value = vinDef.trimName };
                                if (vinVehicleDetail.series.Find(x => x.ID == vinDef.vehicleId.ToString()) == null)
                                {
                                    vinVehicleDetail.series.Add(seriesValue);
                                }
                            }

                            if (vinDef.vehicleOptions != null)
                            {
                                vinVehicleDetail.Options = new List<DTOs.Books.KBB.OptionValues>();
                                vinVehicleDetail.Engine.AddRange(GetListOfIDValues(vinDef.vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "engine")));
                                vinVehicleDetail.DriveTrain.AddRange(GetListOfIDValues(vinDef.vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "drivetrain")));
                                vinVehicleDetail.Transmission.AddRange(GetListOfIDValues(vinDef.vehicleOptions.FindAll(x => x.categoryGroup.ToLower() == "transmission")));
                            }

                        }
                        vinVehicleDetail.years.OrderByDescending(y => y.ID);
                        if (vinVehicleDetail.series.Count > 1)
                        {
                            vinVehicleDetail.Engine.Clear();
                            vinVehicleDetail.DriveTrain.Clear();
                            vinVehicleDetail.Transmission.Clear();
                        }
                    }
                }
                #endregion
            }
            else
            {
                //Edit Mode
                if (isEditMode == true && savedBooks != null)
                    AssignSavedValues(vinVehicleDetail, savedBooks, bookValuationRequest);
                //Non-Edit Mode
                else
                    vinVehicleDetail.years = GetYearsIDList();
            }

            if (vinVehicleDetail.years != null && vinVehicleDetail.years.Count > 1)
            {
                vinVehicleDetail.IsDecodeSuccess = false;
            }

            return vinVehicleDetail;
        }

        private void AssignSavedValues(KBBBookValuation vinVehicleDetail, BookValuation savedBooks, KBBBookValuationRequest bookValuationRequest)
        {
            vinVehicleDetail.years = GetYearsIDList();
            SelectSavedOption(vinVehicleDetail.years, savedBooks.Year);
            vinVehicleDetail.make = GetMakes(Convert.ToInt16(savedBooks.Year.ID)).ToList();
            SelectSavedOption(vinVehicleDetail.make, savedBooks.Make);
            vinVehicleDetail.model = GetModels(Convert.ToInt16(savedBooks.Year.ID), Convert.ToInt32(savedBooks.Make.ID)).ToList();
            SelectSavedOption(vinVehicleDetail.model, savedBooks.Model);
            vinVehicleDetail.series = GetTrims(Convert.ToInt16(savedBooks.Year.ID), Convert.ToInt32(savedBooks.Make.ID), Convert.ToInt32(savedBooks.Model.ID)).ToList();
            SelectSavedOption(vinVehicleDetail.series, savedBooks.Trim);
            DTOs.Books.KBB.TrimOptionValues trimOptionValues = GetEngineTransDriveTrain(Convert.ToInt32(savedBooks.Trim.ID), 1);
            vinVehicleDetail.Engine = trimOptionValues.Engine;
            vinVehicleDetail.Transmission = trimOptionValues.Transmission;
            vinVehicleDetail.DriveTrain = trimOptionValues.DriveTrain;
            foreach (var engine in vinVehicleDetail.Engine.Where(w => w.ID == savedBooks.Engine.ID))
            {
                engine.Selected = true;
            }
            foreach (var transmission in vinVehicleDetail.Transmission.Where(w => w.ID == savedBooks.Transmission.ID))
            {
                transmission.Selected = true;
            }
            foreach (var driveTrain in vinVehicleDetail.DriveTrain.Where(w => w.ID == savedBooks.DriveTrain.ID))
            {
                driveTrain.Selected = true;
            }
            InputParams optionInput = new InputParams();
            optionInput.VehicleId = Convert.ToInt32(savedBooks.Trim.ID);
            optionInput.AppCategory = 1;
            var optionList = _kbbBookLogic.GetKBBEndpointResult(_configValues, optionInput, KBBRestEndpoints.Options);
            List<Options> optionsList = JsonConvert.DeserializeObject<List<Options>>(optionList.ToString());
            List<DTOs.Books.KBB.OptionValues> optionValues = new List<DTOs.Books.KBB.OptionValues>();
            List<DTOs.Books.KBB.OptionValues> colorValues = new List<DTOs.Books.KBB.OptionValues>();
            foreach (var option in optionsList)
            {
                if (option.optionType.ToLower() == "option")
                {
                    DTOs.Books.KBB.OptionValues optionValue = new DTOs.Books.KBB.OptionValues();
                    optionValue.ID = option.VehicleOptionId.ToString();
                    optionValue.Value = option.optionName;
                    optionValue.Cost = 0;
                    foreach (var option1 in savedBooks.Options.Where(x => x.ID == option.VehicleOptionId.ToString()))
                    {
                        if (option1.Selected)
                            optionValue.Selected = true;
                        else
                            optionValue.Selected = false;
                    }
                    optionValue.Oa = option.isConfigurable == true ? "S" : "A";
                    optionValue.TradeInCost = 0;
                    optionValue.RetailCost = 0;
                    optionValues.Add(optionValue);
                }
                else if (option.optionType.ToLower() == "color")
                {
                    DTOs.Books.KBB.OptionValues optionValue = new DTOs.Books.KBB.OptionValues();
                    optionValue.ID = option.VehicleOptionId.ToString();
                    optionValue.Value = option.optionName;
                    optionValue.Cost = 0;
                    foreach (var option1 in savedBooks.Options.Where(x => x.ID == option.VehicleOptionId.ToString()))
                    {
                        if (option1.Selected)
                            optionValue.Selected = true;
                        else
                            optionValue.Selected = false;
                    }
                    optionValue.Selected = option.isTypical;
                    optionValue.Oa = option.isConfigurable == true ? "S" : "A";
                    optionValue.TradeInCost = 0;
                    optionValue.RetailCost = 0;
                    colorValues.Add(optionValue);
                }
            }
            optionValues.AddRange(colorValues);
            vinVehicleDetail.Options = optionValues;
            InternalGetBookValues(vinVehicleDetail, savedBooks, bookValuationRequest, optionValues);
        }

        private void InternalGetBookValues(KBBBookValuation vinVehicleDetail, BookValuation savedBooks, KBBBookValuationRequest bookValuationRequest, List<DTOs.Books.KBB.OptionValues> optionValues)
        {
            List<DomainModels.Common.OptionValue> opt = new List<DomainModels.Common.OptionValue>();
            foreach (var option in optionValues.Where(x => x.Selected == true))
            {
                opt.Add(new DomainModels.Common.OptionValue
                {
                    ID = option.ID,
                    Value = option.Value,
                    Selected = option.Selected,
                    Cost = option.Cost,
                    RetailCost = option.RetailCost,
                    TradeInCost = option.TradeInCost,
                    Oa = option.Oa
                });
            }

            //Fetch Book Values.
            DTOs.BookRequest bookRequest = new DTOs.BookRequest
            {
                dealerId = bookValuationRequest.contractDetails.DealerId,
                regionId = bookValuationRequest.contractDetails.Region,
                valuationData = new DomainModels.Common.ValuationData
                {
                    Year = savedBooks.Year,
                    Make = savedBooks.Make,
                    Model = savedBooks.Model,
                    Series = savedBooks.Trim,
                    Engine = savedBooks.Engine,
                    Transmission = savedBooks.Transmission,
                    DriveTrain = savedBooks.DriveTrain,
                    Mileage = bookValuationRequest.Mileage ?? 0,
                    Vin = bookValuationRequest.VIN,
                    Options = opt
                },
            };
            vinVehicleDetail.BookValue = GetBookValues(bookRequest);
        }

        private void SelectSavedOption(List<IDValues> listItems, DomainModels.Common.IDValues SelectedItem)
        {
            if (listItems != null && listItems.Count > 0)
            {
                if (SelectedItem != null && !string.IsNullOrWhiteSpace(SelectedItem.ID))
                {
                    IDValues items = listItems.Find(x => x.ID == SelectedItem.ID && x.Value == SelectedItem.Value);
                    items.Selected = true;
                }
            }
        }

        private List<IDValues> GetListOfIDValues(List<Options> vehicleOptions)
        {
            List<IDValues> idValList = new List<IDValues>();
            foreach (Options option in vehicleOptions)
            {
                idValList.Add(new IDValues { ID = option.VehicleOptionId.ToString(), Value = option.optionName, Selected = option.isTypical ? true : false });
            }
            return idValList;
        }

        private List<IDValues> GetYearsIDList()
        {
            return GetYears().ToList();
        }
        #endregion
    }
}
