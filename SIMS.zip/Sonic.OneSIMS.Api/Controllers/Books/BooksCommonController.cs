﻿using System;
using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.Helpers;
using AutoMapper.Configuration;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using System.ComponentModel.DataAnnotations;
using Sonic.OneSIMS.DomailModels.Settings;
using Sonic.OneSIMS.Api.DTOs.Books;
using Sonic.OneSIMS.Api.DTOs.Books.KBB;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.Configuration;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Books;
using Sonic.OneSIMS.DomainModels.Books.Common;

namespace Sonic.OneSIMS.Api.Controllers.Books
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Books")]
    [ApiConventionType(typeof(SIMSConventions))]


    public class BooksCommonController : ControllerBase
    {
        public IBooksCommonLogic _booksCommonLogic;
        private readonly IMapper _mapper;
        ConfigSettings _configSettings = null;
        ConfigValues _configValues = null;

        public BooksCommonController(IMapper mapper, IBooksCommonLogic booksCommonLogic, Microsoft.Extensions.Configuration.IConfiguration configuration)
        {

            _booksCommonLogic = booksCommonLogic;
            _configSettings = new ConfigSettings(configuration);
            ReadConfigValues(ref _configValues);
            _mapper = mapper;
        }

        private void ReadConfigValues(ref ConfigValues configValues)
        {
            configValues = new ConfigValues();
            configValues.AuthUserName = _configSettings.GetKBBAuthUserName();
            configValues.AuthPWD = _configSettings.GetKBBAuthPassword();
            configValues.MediaType = _configSettings.GetMediaType();
            configValues.baseURL = _configSettings.GetKBBBaseURL();
        }

        /// <summary>
        /// Get Required Books Configuration for a specific Store 
        /// </summary>
        /// <remarks>Get Configured Books details for a specific Store</remarks>       
        /// <param name="Store_Id">year Ex: 101,2001</param>       
        /// <response code="200">Returns BookId's configured for provided store</response>                
        /// <response code="400">Bad Request</response>        
        /// <response code="401">Unauthorized</response> 
        /// <response code="500">Internal Server Error</response>   
        [HttpGet("GetAllRequiredBooks/{Store_Id}")]
        public ActionResult<BooksConfiguration> GetAllRequiredBooks([FromRoute][Required] short Store_Id)
        {
            //MandatoryBooksResponse response = new MandatoryBooksResponse();
            //BooksConfiguration bookConfig = new BooksConfiguration();
            var res = _booksCommonLogic.GetAllRequiredBooks(Store_Id);
            return Ok(res);
            //response.BookIDs = bookConfig.RequiredBookIds;
            //response.SetupBookIds = bookConfig.SetupBookIds;
        }

        /// <summary>
        /// Get the existing book details saved in Database
        /// </summary>
        /// <remarks>Get the existing book details saved in Database
        /// <br /> 
        /// </remarks>
        /// <response code="200">Success: Returns book details from database.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetAllBooks/{VIN}/{vehicleId}/{storeId}/{inventoryId}/{CurrStoreID}/{mileage}")]
        public ActionResult<DTOs.Books.VinVehicleDetailBooks> GetAllBooks([FromRoute] string VIN, [FromRoute] long vehicleId, [FromRoute] short storeId, [FromRoute] short inventoryId, [FromRoute] short CurrStoreID, [FromRoute] int mileage)
        {
            var res = _booksCommonLogic.GetAllBooks(VIN, vehicleId, storeId, inventoryId, CurrStoreID, mileage);
            return Ok(res);
        }

        /// <summary>
        /// Save book values into database
        /// </summary>
        /// <remarks>Save book values into database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns true if book values saved successfully.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpPost("SaveBooks")]
        public Boolean SaveBooks([FromBody] DomainModels.Books.Common.Books books)
        {
            return _booksCommonLogic.SaveBooks(books);
        }

        /// <summary>
        /// Get saved book values from database
        /// </summary>
        /// <remarks>Get Saved book values from database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns saved books.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetSavedBooks")]
        public DomainModels.Books.Common.Books GetSavedBooks([FromQuery][Required] long VID, [FromQuery][Required] short SID, [FromQuery][Required] short IID, [FromQuery][Required] short CID, [FromQuery][Required] string vin, [FromQuery][Required] string manheimRegion, [FromQuery][Required] string color, [FromQuery][Required] int mileage, [FromQuery][Required] short bookId)
        {
            return _booksCommonLogic.GetSavedBooks(VID, SID, IID, vin, manheimRegion, color, mileage, bookId);
        }
    }
}
