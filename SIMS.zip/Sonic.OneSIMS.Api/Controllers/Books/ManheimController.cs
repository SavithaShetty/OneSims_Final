﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomainModels.Books.Common;
using Sonic.OneSIMS.DomainModels.Books.Manheim;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.DecodeVin;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.MakeModelTrim;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.Transaction;

namespace Sonic.OneSIMS.Api.Controllers.Books
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Books")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class ManheimController : ControllerBase
    {
        private readonly IManheimLogic _manheimLogic;
        private readonly IMapper _mapper;
        public IBooksCommonLogic _booksCommonLogic;

        public ManheimController(IManheimLogic manheimLogic, IMapper mapper, IBooksCommonLogic booksCommonLogic)
        {
            _manheimLogic = manheimLogic;
            _mapper = mapper;
            _booksCommonLogic = booksCommonLogic;
        }

        /// <summary>
        /// Get Transaction Data without Auction Name
        /// </summary>
        /// <param name="manheimId"></param>
        /// <param name="region"></param>
        /// <response code="200">Returns the transaction list </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetTransactionData/{manheimId}/{region}")]
        public IEnumerable<ManheimTransactionData> GetTransactionData([FromRoute][Required] string manheimId, [FromRoute][Required] string region)
        {
            return _manheimLogic.GetTransactionData(manheimId, region);
        }

        /// <summary>
        /// Get Transaction data with Auction Name
        /// </summary>
        /// <param name="manheimId"></param>
        /// <param name="region"></param>        
        /// <response code="200">Returns the transaction list </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetFullTransactionData/{manheimId}/{region}")]
        public Transaction GetFullTransactionData([FromRoute][Required] string manheimId, [FromRoute][Required] string region)
        {
            return _manheimLogic.GetFullTransactionData(manheimId, region);
        }

        /// <summary>
        /// Get Location Details based on the locationId
        /// </summary>
        /// <param name="locationId"></param>
        /// <response code="200">Returns the location details</response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetLocationDetails/{locationId}")]
        public LocationDetails GetLocationDetails([FromRoute][Required] string locationId)
        {
            return _manheimLogic.GetLocationDetails(locationId);
        }

        /// <summary>
        /// Get Makes based on the year
        /// </summary>
        /// <param name="year"></param>
        /// <response code="200">Returns the make list </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetMakes/{year}")]
        public List<IDValues> GetMakes([FromRoute][Required] string year)
        {
            return _manheimLogic.GetMakes(year);
        }

        /// <summary>
        /// Get Models based on year and make
        /// </summary>
        /// <param name="year"></param>
        /// <param name="make"></param>
        /// <response code="200">Returns the model list </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetModels/{year}/{make}")]
        public List<IDValues> GetModels([FromRoute][Required] string year, [FromRoute][Required] string make)
        {
            return _manheimLogic.GetModels(year, make);
        }

        /// <summary>
        /// Get Trims based on year, make and model
        /// </summary>
        /// <param name="year"></param>
        /// <param name="make"></param>
        /// <param name="model"></param>
        /// <response code="200">Returns the trims</response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetTrims/{year}/{make}/{model}")]
        public List<IDValues> GetTrims(string year, string make, string model)
        {
            return _manheimLogic.GetTrims(year, make, model);
        }

        /// <summary>
        /// Get the book value details based on vin, region and mileage.
        /// </summary>
        /// <param name="vin"></param>
        /// <param name="region"></param>
        /// <param name="mileage"></param>
        /// <response code="200">Returns the decoded vin details. </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetDecodedVin/{vin}/{region}/{mileage}")]
        public ManheimDecode GetDecodedVin(string vin, string region, int mileage)
        {
            return _manheimLogic.GetDecodedVin(vin, region, mileage);
        }

        [HttpPost("GetBookValuation")]
        public ActionResult<ManheimBookValuation> GetBookValution([FromBody] ManheimBookValuationRequest bookValuationRequest, [FromQuery] bool isEditMode)
        {
            var res = _manheimLogic.GetBookValution(bookValuationRequest, isEditMode);
            return Ok(res);
        }

        /// <summary>
        /// Get the book value details based on vin, manheimid, region, mileage and color.
        /// </summary>
        /// <param name="vin"></param>
        /// <param name="manheimId"></param>
        /// <param name="region"></param>
        /// <param name="mileage"></param>
        /// <param name="color"></param>
        /// <response code="200">Returns the Book Value details </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetBookValue/{vin}/{region}/{mileage}/{color}")]
        public VinVehicleDetail GetBookValue(string vin, string region, int mileage, string color)
        {
            return _manheimLogic.GetBookValue(vin, region, mileage, color);
        }

        /// <summary>
        /// Get the book value details based on year, make, model, mileage, region and color.
        /// </summary>
        /// <param name="year"></param>
        /// <param name="make"></param>
        /// <param name="model"></param>
        /// <param name="trim"></param>
        /// <param name="mileage"></param>
        /// <param name="region"></param>
        /// <param name="color"></param>
        /// <response code="200">Returns the Book Value details </response> 
        /// <response code="500">Internal server error</response>   
        /// <response code="400">Bad request</response>   
        [HttpGet("GetBookValue/{year}/{make}/{model}/{trim}/{region}/{color}/{mileage}")]
        public ManheimBookValue GetBookValue(string year, string make, string model, string trim, string region, string color, int mileage)
        {
            return _manheimLogic.GetBookValue(year, make, model, trim, mileage, region, color);
        }

        /// <summary>
        /// Save Manheim book values into database
        /// </summary>
        /// <remarks>Save Manheim book values into database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns true if book values saved successfully.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpPost("SaveManheimBooks")]
        public Boolean SaveManheimBooks([FromBody] DomainModels.Books.Common.Books books)
        {
            return _booksCommonLogic.SaveManheimBooks(books.Manheim, books.VehicleIdentity, books.Vin, books.UserName);
        }

        /// <summary>
        /// Get saved Manheim book values from database
        /// </summary>
        /// <remarks>Get Saved Manheim book values from database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns saved books.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetSavedManheimBooks/{vehicleId}/{storeId}/{invtrId}/{manheimRegion}/{color}/{mileage}")]
        public BookValuation GetSavedManheimBooks([FromRoute][Required] int vehicleId, [FromRoute][Required] int storeId, [FromRoute][Required] int invtrId, [FromQuery][Required] string manheimRegion, [FromQuery][Required] string color, [FromQuery][Required] int mileage)
        {
            return _booksCommonLogic.GetManheimSavedBooks(vehicleId, storeId, invtrId, manheimRegion, color, mileage);
        }
    }
}
