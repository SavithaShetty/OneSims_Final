﻿using System;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces.Appraisal.Books;
using Sonic.OneSIMS.DomainModels.Books.BlackBook;
using System.Collections.Generic;
using IDValues = Sonic.OneSIMS.DomainModels.Common.IDValues;
using Make = Sonic.OneSIMS.Infrastructure.Cdk.Entities.Make;
using Sonic.OneSIMS.DomainModels.Books.Common;
using System.ComponentModel.DataAnnotations;

namespace Sonic.OneSIMS.Api.Controllers.Books
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Books")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class BlackBookController : ControllerBase
    {

        private readonly IMapper _mapper;
        public readonly IConfiguration _configuration;
        public IBlackBookLogic _blackBookLogic;
        public IBooksCommonLogic _booksCommonLogic;
        public BlackBookController(IMapper mapper, IConfiguration configuration, IBlackBookLogic blackBookLogic, IBooksCommonLogic booksCommonLogic)
        {
            _mapper = mapper;
            _configuration = configuration;
            _blackBookLogic = blackBookLogic;
            _booksCommonLogic = booksCommonLogic;

        }

        /// <summary>
        /// Get make list for given year
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the make list and error list will be empty or contains the warnings</li>
        /// <li> For invalid payload request the response will have empty make list and contains the error list returns from CDK service</li>
        /// </ul>
        /// </remarks>  
        /// </response>                    
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>                   
        [HttpPost("Makes")]
        public ActionResult<List<IDValues>> GetMakes([FromBody] BBMakeRequest makeReq)
        {
            //_mapper.Map < DomainModels.Common.IDValues >=<Sonic.OneSIMS.Infrastructure.Cdk.Entities.IDValues > ();
            var makeList = _blackBookLogic.GetMakes(makeReq);
            //IEnumerable<DomainModels.Appraisal.Books.BlackBook.Make> makessList = _mapper.Map<IEnumerable<DomainModels.Appraisal.Books.BlackBook.Make>>(JsonConvert.DeserializeObject<List<Make>>(makeList.ToString()));

            return Ok(makeList);
        }

        /// <summary>
        /// Get model list for given year and make values
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the model list and error list will be empty or contains the warnings</li>
        /// <li> For invalid payload request the response will have empty model list and contains the error list returns from CDK service</li>
        /// <li> Note :- Few vehciles may not have model values  </li>
        /// </ul>
        /// </remarks>  
        /// </response>   
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("Models")]
        public ActionResult<List<IDValues>> GetModels([FromBody] BBModelRequest modelReq)
        {
            var modelsList = _blackBookLogic.GetModels(modelReq);
            return Ok(modelsList);
        }

        /// <summary>
        /// Get trim list for given year, make and model values
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the trim list and error list will be empty or contains the Warnings</li>
        /// <li> For invalid payload request the response will have empty trim list and contains the error list returns from CDK service</li>
        /// </ul>
        /// </remarks>  
        /// </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>
        [HttpPost("Trims")]
        public ActionResult<List<IDValues>> GetTrims([FromBody] BBTrimRequest trimReq)
        {
            var trimList = _blackBookLogic.GetTrims(trimReq);
            //IEnumerable<DomainModels.Appraisal.Books.BlackBook.Trim> trimList = _mapper.Map<IEnumerable<DomainModels.Appraisal.Books.BlackBook.Trim>>(JsonConvert.DeserializeObject<List<Sonic.OneSIMS.Infrastructure.Cdk.Entities.Trim>>(res.ToString()));
            return Ok(trimList);
        }

        /// <summary>
        /// Get BodyStyle list for given year, make, model and trim values
        /// </summary>
        /// <remarks>
        /// ### Service requires the Contract Details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// </ul>
        /// </remarks>      
        /// <response code="200">
        /// <remarks>
        /// Service Response details
        /// <ul>
        /// <li> For valid payload request the response will contains the bodystyle list and error list will be empty</li>
        /// <li> For invalid payload request the response will have empty bodystyle list and contains the error list returns from CDK service</li>
        /// </ul>
        /// </remarks>  
        /// </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>                
        [HttpPost("Bodystyles")]
        public ActionResult<List<IDValues>> GetBodyStyles([FromBody] BBBodyStyleRequest bodyStyleReq)
        {
            var bodyStyles = _blackBookLogic.GetBodyStyles(bodyStyleReq);
            //IEnumerable<DomainModels.Appraisal.Books.BlackBook.BodyStyle> bodyStyles = _mapper.Map<IEnumerable<DomainModels.Appraisal.Books.BlackBook.BodyStyle>>(JsonConvert.DeserializeObject<List<Sonic.OneSIMS.Infrastructure.Cdk.Entities.BodyStyle>>(res.ToString()));
            return Ok(bodyStyles);
        }

        /// <summary>
        /// Get the vehicle properties by VIN
        /// </summary>
        /// <remarks>
        /// ### Service requires below Contract Details with VIN
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// </ul>        
        /// </remarks>      
        /// <response code="200">
        /// <remarks>                
        /// Service Response Details <br />
        /// -  Given VIN may Partially or fully decode, in a response if the clarify flag is false then given VIN is fully decoded or else partially decoded and response will contains the multiple vehciles decode values in list of VinDecodeValue  <br />
        /// -  CDK service returns warrning in error list even in success case, so error can ignore if they contains only warnings. <br />
        /// -  A success response can identified based on the values in Vindecodevalue list <br />
        /// -  A Single VinDecodeValue will contains the below  values <br />        
        /// <ul>
        /// <li> VIN  </li>
        /// <li> Year </li>
        /// <li> Make  - single value</li>
        /// <li> Model - single value</li> 
        /// <li> Trim  - single vlaue</li> 
        /// <li> BodyStyle - single value </li>
        /// <li> ProviderId - the requested provider ID </li>
        /// <li> Region - value of region </li>
        /// <li> Odometer - value of odometer </li>
        /// <li> Location - value of location </li>
        /// <li> Makes  - Collection of makes with code and values</li>
        /// <li> Models - Collection of models with code and values</li> 
        /// <li> Trims  - Collection of Trims with code and values</li> 
        /// <li> BodyStyles - Collection of bodystyles with code and values </li>
        /// <li> PoviderDefCode - Provider defination code value or UVC value </li>
        /// <li> Options - Collection of option values</li>       
        /// </ul>                
        /// </remarks>
        /// </response>        
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("Decodevin")]
        public ActionResult<BBDecodeDetails> GetDecodeVIN([FromBody] BBDecodeRequest decodeVinRequest)
        {
            var res = _blackBookLogic.GetDecodeValues(decodeVinRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get the vehicle options list
        /// </summary>        
        /// <remarks>
        /// ### Service requires below Contract Details and additional details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> VIN, Year, Make, Model, Trim, BodyStyle, Odometer,Condition and LowVolume are optional paramter </li>
        /// <li> ProviderDefCode or BodyStyle ID is mandatory parameter </li>
        /// </ul>  
        /// </remarks>      
        /// <response code="200">
        /// <remarks>                
        /// ### Returns the options list
        /// </remarks>
        /// </response>        
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("Options")]
        public ActionResult<BBOptionResponse> GetOptions([FromBody] BBOptionsRequest optionsRequest)
        {
            var res = _blackBookLogic.GetOptions(optionsRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get the book values
        /// </summary>        
        /// <remarks>
        /// ### Service requires below Contract Details and additional details
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Vehicle Properties  like VIN, Year, Make, Model, Trim, BodyStyle, Odometer,Condition, ProviderDefCode or BodyStyle ID parameter </li>
        /// <li> Selected Options list can also be passed</li>
        /// </ul>  
        /// </remarks>                   
        /// <response code="200">Book Value will be return </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("BookValues")]
        public ActionResult<BBBookValue> GetBookValues([FromBody] BookValueRequest bookValueRequest)
        {
            var res = _blackBookLogic.GetBookValues(bookValueRequest);
            return Ok(res);
        }

        /// <summary>
        /// Get the Book valution
        /// </summary>        
        /// <remarks>
        /// ### Service requires Contract Details, Vehicle Identity and other information as request payload 
        /// <ul>
        /// <li> Dealer ID - Dealer ID provided from CDK</li>
        /// <li> Provider ID - for specific book value provider</li>
        /// <li> Region - value for specific book value provider</li> 
        /// <li> Vehicle identity details like VID(vehicle Id), IID(Inventory ID),SID (Store ID) and CID (Company ID)</li>
        /// <li> Mileage value</li>
        /// <li> VIN</li> 
        /// </ul>  
        /// </remarks>          
        /// <param name="isEditMode"> If this parameter values is true then it checks saved books values</param>
        /// <response code="200">Book valuation will returns if vehicle decode success or else the partial decoded values will returns </response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>  
        [HttpPost("GetBookValuation")]
        public ActionResult<BBBookValuation> GetBookValuation([FromBody] BBBookValuationRequest bookValuationRequest, [FromQuery] bool isEditMode)
        {
            var res = _blackBookLogic.GetBookValuation(bookValuationRequest,isEditMode);
            return Ok(res);
        }

        [HttpPost("SaveBookValuation")]
        public ActionResult<Boolean> SaveBookValution([FromBody] BBBookValuation bookValuation)
        {
            var res = _blackBookLogic.SaveBookValution(bookValuation);
            return Ok(res);
        }

        /// <summary>
        /// Save Black book values into database
        /// </summary>
        /// <remarks>Save Black book values into database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns true if book values saved successfully.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpPost("SaveBBBooks")]
        public Boolean SaveBBBooks([FromBody] DomainModels.Books.Common.Books books)
        {
            return _booksCommonLogic.SaveBBBooks(books.BlackBook, books.VehicleIdentity, books.Vin, books.UserName);
        }

        /// <summary>
        /// Get saved Black book values from database
        /// </summary>
        /// <remarks>Get Saved Black book values from database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns saved books.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetSavedBBBooks/{vehicleId}/{storeId}/{invtrId}")]
        public BookValuation GetSavedBBBooks([FromRoute][Required] int vehicleId, [FromRoute][Required] int storeId, [FromRoute][Required] int invtrId)
        {
            return _booksCommonLogic.GetBBSavedBooks(vehicleId, storeId, invtrId);
        }

        /// <summary>
        /// Save NADA book values into database
        /// </summary>
        /// <remarks>Save NADA book values into database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns true if book values saved successfully.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpPost("SaveNADABooks")]
        public Boolean SaveNADABooks([FromBody] DomainModels.Books.Common.Books books)
        {
            return _booksCommonLogic.SaveBBBooks(books.NADA, books.VehicleIdentity, books.Vin, books.UserName);
        }

        /// <summary>
        /// Get saved NADA book values from database
        /// </summary>
        /// <remarks>Get Saved NADA book values from database
        /// <br/>
        /// </remarks>        
        /// <response code="200">Success: Returns saved books.</response>               
        /// <response code="400">Bad Request or validation errors: Please check on the request parameter and their values.</response>        
        /// <response code="500">InternalServerError: A deep, internal error has occurred during the processing of your request. Please contact support..</response>         
        [HttpGet("GetSavedNADABooks/{vehicleId}/{storeId}/{invtrId}")]
        public BookValuation GetSavedNADABooks([FromRoute][Required] int vehicleId, [FromRoute][Required] int storeId, [FromRoute][Required] int invtrId)
        {
            return _booksCommonLogic.GetNADASavedBooks(vehicleId, storeId, invtrId);
        }
    }
}
