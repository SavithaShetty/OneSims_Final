﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.Graph.Auth;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.DTOs.Common;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.DTOs.User;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.Framework.Configuration;
using Sonic.OneSIMS.Framework.Constants;

namespace Sonic.OneSIMS.Api.Controllers.Users
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "User")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class UserConfigurationController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IUserLogic _userLogic;
        public readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserRoleConfiguration"/> class.
        /// </summary>
        /// <param name="UserLogic"></param>
        /// <param name="mapper"></param>
        public UserConfigurationController(IUserLogic userLogic, IMapper mapper, IConfiguration configuration)
        {
            _userLogic = userLogic;
            _mapper = mapper;
            _configuration = configuration;
        }
        /// <summary>
        /// Check Database connection
        /// </summary>
        /// <returns></returns>
        [HttpGet("checkconnection")]
        public virtual ActionResult<string> CheckDatabaseConnection()
        {
            try
            {
                var userslist = _userLogic.CheckDatabaseConnection();
                //List<DomailModels.Settings.User.UserDetails> users = _mapper.Map<List<DomailModels.Settings.User.UserDetails>>(userslist);
                return StatusCode(200, userslist);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        /// <summary>
        /// Return all active user of Sonic.
        /// </summary>
        /// <remarks>Get all active Users</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetallUsers/{CompanyId}")]
        public virtual ActionResult<UserLookup> GetallUsers([FromRoute][Required] short CompanyId)
        {
            var userslist = _userLogic.GetAllUsers(CompanyId);
            //List<DomailModels.Settings.User.UserDetails> users = _mapper.Map<List<DomailModels.Settings.User.UserDetails>>(userslist);
            return StatusCode(200, userslist);
        }
        /// <summary>
        /// Add a new user.
        /// </summary>
        /// <param name="Userdetails">Userdetails object that has user detail to add</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddNewUserDetails")]
        public virtual async Task<IActionResult> AddNewUserDetails([FromBody] UserDetails userDetails)
        {
            if (userDetails != null)
            {
                var userExist = await DoesUserExistsAsync(userDetails.UserName.Trim());
                if (userExist)
                {
                    bool isSIMSUser = _userLogic.GetExistingSIMSUser(userDetails.UserName.Trim());
                    if (!isSIMSUser)
                    {
                        string userId = _userLogic.AddUser(_mapper.Map<DomailModels.Settings.User.UserDetails>(userDetails));
                        if (!string.IsNullOrEmpty(userId))
                        {
                            return StatusCode(201, userId);
                        }
                        else
                        {
                            return Ok("User was not added");
                        }
                    }
                    else
                    {
                        return Ok("Already OneSIMS User");
                    }
                }
                else
                {
                    return Ok("Invalid Azure AD User");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        private async Task<bool> DoesUserExistsAsync(string user)
        {
            try
            {
                AzureADSettings azureADSettings = _configuration.GetSection("Settings").Get<Settings>().azureADSettings;

                IConfidentialClientApplication confidentialClientApplication = ConfidentialClientApplicationBuilder
                    .Create(azureADSettings.ServiceAccountClientId)
                    .WithTenantId(azureADSettings.TenantId)
                    .WithClientSecret(azureADSettings.ServiceAccountSecretKey)
                    .Build();

                ClientCredentialProvider authProvider = new ClientCredentialProvider(confidentialClientApplication);

                GraphServiceClient graphClient = new GraphServiceClient(authProvider);

                var payload = await graphClient.Users[user.Trim() + "@sonicautomotive.com"]
                    .Request()
                    .GetAsync();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Return user details like roles of user.
        /// </summary>
        /// <remarks>Get User details</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetUserDetails/{username}/{CompanyId}")]
        public virtual ActionResult<UserDetails> GetUserDetails([FromRoute][Required] string username, [FromRoute][Required] int CompanyID)
        {
            var userdetails = _userLogic.GetUserConfigurationDetails(username, CompanyID);
            IEnumerable<UserDetails> userindetails = _mapper.Map<IEnumerable<UserDetails>>(userdetails);
            return StatusCode(200, userindetails);
        }

        /// <summary>
        /// Add user Role Details.
        /// </summary>
        /// <param name="UserDetails">Userdetails object that has user detail to add</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("SaveUserConfigurations")]
        public virtual ActionResult<string> SaveUserConfigurations([FromBody] UserDetails userDetails)
        {
            if (userDetails != null)
            {
                bool isAddSuccess = _userLogic.SaveUserConfigurations(_mapper.Map<DomailModels.Settings.User.UserDetails>(userDetails));
                if (isAddSuccess)
                {
                    return StatusCode(201, "User Details created");
                }
                else
                {
                    return Ok("User Details was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes a user.
        /// </summary>
        /// <param name="username">Username to delete</param>
        /// <response code="400">Invalid Sotre ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpDelete("DeleteUser/{username}")]
        public virtual ActionResult DeleteUser([FromRoute][Required] string username)
        {
            if (username != null && username != "")
            {
                bool isDeleteSuccess = _userLogic.DeleteUserConfigurations(username);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }
        /// <summary>
        /// Return user Dealership role Associations.
        /// </summary>
        /// <remarks>Get user Dealership role Associations</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetRegionStoreUserAccess/{UserId}/{CompanyID}")]
        public virtual ActionResult<RegionStoreRole> GetRegionStoreUserAccess([FromRoute][Required] Guid UserId, [FromRoute][Required] int CompanyID)
        {
            var userdetails = _userLogic.GetRegionStoreUserAccess(UserId);
            RegionStoreRole regionStoreRoles = _mapper.Map<RegionStoreRole>(userdetails);
            return StatusCode(200, regionStoreRoles);
        }

        /// <summary>
        /// Get User Configuration Default Values
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        [HttpGet("GetUserConfigurationDefaultValues/{UserId}")]
        public virtual ActionResult<RegionStoreRole> GetUserConfigurationDefaultValues([FromRoute][Required] Guid UserId)
        {
            var userDetails = _userLogic.GetUserConfigurationDefaultValues(UserId);
            UserDetails userConfigDefaultValues = _mapper.Map<UserDetails>(userDetails);
            return StatusCode(200, userConfigDefaultValues);
        }


        /// <summary>
        /// Add user Dealership role Associations.
        /// </summary>
        /// <param name="UserConfigStoreList">UserConfigStoreList object that has user Dealership role Associations to add</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddStoreUserRoleAccess")]
        public virtual ActionResult<string> AddStoreUserRoleAccess([FromBody] UserConfigStoreList userconfigstorelist)
        {
            if (userconfigstorelist != null)
            {
                bool isAddSuccess = _userLogic.SaveDealershipUserAccess(_mapper.Map<DomailModels.Settings.User.UserConfigStoreList>(userconfigstorelist));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Store Association created");
                }
                else
                {
                    return Ok("Store Association was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes user Dealership role Associations.
        /// </summary>
        /// <param name="StoreId">Dealer id to delete</param>
        /// <param name="UserId">User id to delete</param>
        /// <response code="400">Invalid Sotre ID supplied</response>
        /// <response code="404">Dealership Association not found</response>        
        [HttpDelete("DeleteDealershipUserRoleAccess/{StoreId}/{UserId}")]
        public virtual ActionResult DeleteDealershipUserRoleAccess([FromRoute][Required] int StoreId, [FromRoute][Required] Guid UserId)
        {
            if (StoreId != 0)
            {
                bool isDeleteSuccess = _userLogic.DeleteUserDealershipAccess(StoreId, UserId);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Add user Region role Associations.
        /// </summary>
        /// <param name="Region">Region object that has user Region role Associations to add</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddRegionUserRoleAccess")]
        public virtual ActionResult AddRegionUserRoleAccess([FromBody] Region region)
        {
            if (region != null)
            {
                bool isAddSuccess = _userLogic.SaveRegionUserAccess(_mapper.Map<DomailModels.Settings.User.Region>(region));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Region Association created");
                }
                else
                {
                    return Ok("Region Association was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes user Dealership role Associations.
        /// </summary>
        /// <param name="RegionId">Region id to delete</param>
        /// <param name="UserId">userId to delete region access</param>
        /// <response code="400">Invalid Region Id supplied</response>
        /// <response code="404">RegionAssociation not found</response>
        [HttpDelete("DeleteRegionUserRoleAccess/{RegionId}/{UserId}")]
        public virtual ActionResult DeleteRegionUserRoleAccess([FromRoute][Required] int RegionId, [FromRoute][Required] Guid UserId)
        {
            if (RegionId != 0)
            {
                bool isDeleteSuccess = _userLogic.DeleteUserRoleRegionAccess(RegionId, UserId);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Return all roles based on the company Id
        /// </summary>
        /// <remarks>Get roles for usert configuration screen</remarks>
        /// <param name="companyId">company id</param>
        /// <param name="userId">company id</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetAllUserConfigRoles/{companyId}/{userId}")]
        public virtual ActionResult<UserDetails> GetAllUserConfigRoles([FromRoute][Required] int companyId, [FromRoute][Required] string userId)
        {
            var allRoles = _userLogic.GetAllUserConfigRoles(companyId, Guid.Parse(userId));
            UserConfigRoles allRolesOfCompany = _mapper.Map<UserConfigRoles>(allRoles);
            return StatusCode(200, allRolesOfCompany);
        }

        /// <summary>
        /// Return user roll up details.
        /// </summary>
        /// <remarks>Get user Rollup details</remarks>
        /// <param name="userId">User id to get rollup details</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetRollUpDetails/{userId}")]
        public virtual ActionResult<RollUp> GetRollUpDetails([FromRoute][Required] string userId)
        {
            var rollUpDetails = _userLogic.GetRollUpDetails(userId);
            //  IEnumerable<RollUp> userindetails = _mapper.Map<IEnumerable<RollUp>>(rollUpDetails);
            return StatusCode(200, rollUpDetails);
        }
    }
}
