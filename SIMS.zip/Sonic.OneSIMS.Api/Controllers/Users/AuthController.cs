﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.Api.DTOs.User;
using Sonic.OneSIMS.Framework.Configuration;
using Sonic.OneSIMS.Framework.Constants;
using Sonic.OneSIMS.Api.DTOs.Common;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Sonic.OneSIMS.Api.Controllers.Users
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "User")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class AuthController : ControllerBase
    {
        private readonly JwtSettings _jwtSettings;
        private readonly IMapper _mapper;
        private readonly IUserDefaultViewsLogic _userview;

        public AuthController(IOptionsSnapshot<Settings> setting, IUserDefaultViewsLogic userview, IMapper mapper)
        {
            _jwtSettings = setting.Value.jwtSettings;
            _userview = userview;
            _mapper = mapper;
        }

        [Authorize(AuthenticationSchemes = AuthConstants.AzureAdScheme)]
        [HttpGet("SignIn")]
        public async Task<IActionResult> SignIn()
        {

            if (User.Identity.Name is null)
            {
                return NotFound("User not found");
            }
            else
            {
                //Claim name = User.Claims.SingleOrDefault(x => x.Type == "name");                
                string namewithEmail = User.Identity.Name;
                string name = namewithEmail.Substring(0,namewithEmail.LastIndexOf('@'));
                var defaultview = _userview.GetUserDefaultViewDetails(name);
                //IEnumerable<UserView> userdefaultview = _mapper.Map<IEnumerable<UserView>>(defaultview);
                return Ok(defaultview);
                
                //    if (name.Value.ToLower() == "manjunath mk") // user exists in SIMS
                //    {
                //        List<string> roles = new List<string>();
                //        roles.Add("SIMSUser");
                //        roles.Add("CorporateEDIT");
                //        roles.Add("SIMSAdmin");
                //        return Ok(GenerateJwt(name.Value, roles));
                //    }
                //    else
                //    {
                //        List<string> roles = new List<string>();
                //        roles.Add("SIMSUser");
                //        roles.Add("CorporateEDIT");
                //        return Ok(GenerateJwt(name.Value, roles));
                //    }               
            }


        }

        /// <summary>
        /// Validate user and generate token for API testing.
        /// </summary>
        /// <remarks>Generate token here for testing the APIs.</remarks>
        /// <response code="200">Return the token for testing.</response>
        /// <response code="401">User not found in SIMS.</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [HttpGet("SignInTest/{Username}")]
        public async Task<IActionResult> SignInTest(string Username)
        {
            List<string> roles = new List<string>();
            roles.Add("SIMSAdmin");
            roles.Add("SIMSUser");

            if (Username != null)
            {

                return Ok(GenerateJwt(Username, roles));
            }
            else
            {
                return Unauthorized(new ProblemDetails()
                {
                    Detail = "UserName not exists in SIMS"
                });
            }
        }

        /// <summary>
        /// Get user Default View.
        /// </summary>
        /// <remarks>After User Authentication get default view and Features.</remarks>
        /// <response code="200">Return Default view.</response>
        /// <response code="401"> Nothing is assigned to perticular user.</response>
        [HttpGet("GetUserView/{UserID}/{Level}/{CompanyID}/{StoreID}")]
        public virtual ActionResult<UserView> GetUserDefaultView(string UserID,int Level,int CompanyID,int StoreID)
        {

            var defaultview = _userview.GetUserView(UserID, StoreID, CompanyID, Level);
            //IEnumerable<UserView> userdefaultview = _mapper.Map<IEnumerable<UserView>>(defaultview);
            return Ok(defaultview);
        }
        /// <summary>
        /// Get user Default View.
        /// </summary>
        /// <remarks>After User Authentication get default view and Features.</remarks>
        /// <response code="200">Return Default view.</response>
        /// <response code="401"> Nothing is assigned to perticular user.</response>
        [HttpGet("GetUserFeatures/{UserId}/{StoreId}/{CompanyId}/{RoleIds}/{Level}")]
        public virtual ActionResult<MenuNavigation> GetUserFeatures(string UserId, int StoreId, int CompanyId, string RoleIds, int Level)
        {

            var defaultview = _userview.GetUserFeaturesBasedonRole(UserId, StoreId, CompanyId, RoleIds, Level);
            //IEnumerable<MenuNavigation> userdefaultview = _mapper.Map<IEnumerable<MenuNavigation>>(defaultview);
            // var token = GenerateJwt(Username,userdefaultview.Roles.ToList()));
            return StatusCode(200, defaultview);
        }

        private string GenerateJwt(string username, IList<string> roles)
        {

            var claims = new List<Claim>
            {
                //new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                //new Claim(ClaimTypes.Name, username),
                new Claim("Name",username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                
                //new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
            };

            //var roleClaims = roles.Select(r => new Claim(ClaimTypes.Role, r));
            var roleClaims = roles.Select(r => new Claim("Role", r));
            claims.AddRange(roleClaims);


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Secret));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.Now.AddMinutes(Convert.ToDouble(_jwtSettings.ExpirationInMinutes));

            var token = new JwtSecurityToken(
                issuer: _jwtSettings.Issuer,
                audience: _jwtSettings.Audience,
                claims,
                expires: expires,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string GenerateIPAddress()
        {
            if (this.Request.Headers.ContainsKey("X-Forwarded-For"))
            {
                return this.Request.Headers["X-Forwarded-For"];
            }
            else
            {
                return this.HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();
            }
        }
    }
}
