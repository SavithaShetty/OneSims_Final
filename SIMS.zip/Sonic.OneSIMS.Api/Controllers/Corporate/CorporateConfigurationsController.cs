﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Corporate;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomailModels.Common;

namespace Sonic.OneSIMS.Api.Controllers.Corporate
{

    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class CorporateConfigurationsController : ControllerBase
    {
        private readonly ICorporateLogic _corporateLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="SonicStoreController"/> class.
        /// </summary>
        /// <param name="storeLogic"></param>
        /// <param name="mapper"></param>
        public CorporateConfigurationsController(ICorporateLogic corporateLogic, IMapper mapper)
        {
            _corporateLogic = corporateLogic;
            _mapper = mapper;
        }
        /// <summary>
        /// Get Corporate configuration.
        /// </summary>
        /// <remarks>Get Corporate configuration.</remarks> 
        /// <param name="">Only one corporate config so we will not pass any parameters</param>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetCorporateConfigInfo")]
        public virtual ActionResult<CorpGeneralOption> GetCorporateConfigInfo([FromQuery][Required] short CID)
        {
            var corporateconfiginfoItem = _corporateLogic.GetCorporateConfigInfo(CID);
           // IEnumerable<CorpGeneralOption> corporateconfiginfo = _mapper.Map<IEnumerable<CorpGeneralOption>>(corporateconfiginfoItem);
            return StatusCode(200, corporateconfiginfoItem);
        }
        /// <summary>
        /// Add Corporate Configuration.
        /// </summary>
        /// <remarks>  Add Corporate Configuration.</remarks> 
        /// <param name="CorpGeneralOption">CorpGeneralOption object that has to be add Corporate configuration for company</param>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("AddCorporateConfigInfo")]
        public virtual ActionResult<bool> AddCorporateConfigInfo([FromBody] CorpGeneralOption corpgeneralOption)
        {
           
                bool isAddSuccess = _corporateLogic.AddCorporateConfigInfo(_mapper.Map<Sonic.OneSIMS.DomainModels.Settings.Corporate.CorpGeneralOption>(corpgeneralOption));
            return StatusCode(200, isAddSuccess);

        }
        /// <summary>
        /// Add Used Vehicle Age Bucket
        /// </summary>
        /// <param name="Age Bucket"> Used Vehicle Age Bucket Configuration</param>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("AddUsedVehicleAgeBucket")]
        public virtual ActionResult<bool> AddUsedVehicleAgeBucket([FromBody] AgeBucket ageBucket)
        {
                bool isAddSuccess = _corporateLogic.AddUsedVehicleAgeBucket(ageBucket);
 
            return StatusCode(200, isAddSuccess);
        }
        /// <summary>
        /// Get Used Vehicle Age Bucket
        /// </summary>
        /// <param name="Age Bucket">Used Vehicle Age Bucket Configuration</param>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetUsedVehicleAgeBucket")]
        public virtual ActionResult<List<AgeBucket>> GetUsedVehicleAgeBucket([FromQuery][Required] short CID)
        {
            List<AgeBucket> ageBuckets = new List<AgeBucket>();
            ageBuckets = _corporateLogic.GetUsedVehicleAgeBucket(CID);
            return StatusCode(200, ageBuckets);
        }
        /// <summary>
        /// Delete Used Vehicle Age Bucket
        /// </summary>
        /// <param name="Age Bucket">Used Vehicle Age Bucket Configuration</param>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpDelete("DeleteUsedVehicleAgeBucket/{agBucketId}/{username}")]
        public virtual ActionResult<bool> DeleteUsedVehicleAgeBucket([FromRoute][Required] int agBucketId, [FromRoute][Required] string username)
        {
            bool isAddSuccess = false;
            if (agBucketId != null)
            {
                isAddSuccess = _corporateLogic.DeleteUsedVehicleAgeBucket(agBucketId, username);
            }
            else
            {
                isAddSuccess = false;
            }
            return StatusCode(200, isAddSuccess);
        }
    }
}
