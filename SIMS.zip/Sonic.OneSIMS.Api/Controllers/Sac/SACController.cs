﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Sonic.OneSIMS.BusinessLogic.Interfaces.SAC;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.DomainModels.SAC;
using System.ComponentModel.DataAnnotations;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.Api.DTOs.SAC;
using Sonic.OneSIMS.DomainModels.Sac;

namespace Sonic.OneSIMS.Api.Controllers.SAC
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "SAC")]
    [ApiConventionType(typeof(SIMSConventions))]

    public class SACController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly ISACLogic _SACLogic;
        public readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="SACController"/> class.
        /// </summary>
        /// <param name="appraisallogic"></param>
        /// <param name="configuration"></param>
        /// <param name="mapper"></param>
        public SACController(ISACLogic saclogic, IMapper mapper, IConfiguration configuration)
        {
            _SACLogic = saclogic;
            _mapper = mapper;
            _configuration = configuration;
        }


        /// <summary>
        /// Return SAC Log.
        /// </summary>
        /// <remarks>Get SAC log data</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetSacLog")]
        public virtual ActionResult<SacLoglist> GetSacLog([FromQuery][Required] short CID, [FromQuery] int Region_ID, [FromQuery] string AppraisalType, [FromQuery][Required] string SAC_Status, [FromQuery][Required] bool IsLease, [FromQuery] string VINOrStock)
        {
            var Sacdetails = _SACLogic.GetSacLog(CID, Region_ID, AppraisalType, SAC_Status, IsLease, VINOrStock);
            return StatusCode(200, Sacdetails);
        }

        /// <summary>
        /// Return SAC locked by info.
        /// </summary>
        /// <remarks>Get Locked by Info</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetLockedBy/{sacid}")]
        public virtual ActionResult<string> GetLockedBy([FromRoute][Required] int sacid)
        {
            object lokedby = _SACLogic.GetLockedBy(sacid);

            return StatusCode(200, lokedby);
        }


        /// <summary>
        /// Save the Sac Record Locked info 
        /// </summary>
        /// <param name="lockeddetail"></param>
        /// <returns></returns>
        ///  /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("LockUnlockSACRecord")]
        public ActionResult<bool> LockUnlockSACRecord([FromBody] LockedDetail lockeddetail)
        {
            //Boolean t = _photoLogic.UploadPhoto(_mapper.Map<DomainModels.Appraisal.PhotoSourceRequest>(photoUploadParams));
            bool t = _SACLogic.LockUnlockSACRecord(lockeddetail);
            return StatusCode(200, t);
        }

        /// <summary>
        /// Returns Trade Store List.
        /// </summary>
        /// <remarks>Get Store List data</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetTradeStoreList/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<List<TradeStoreDetails>> GetTradeStoreList([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            var tradeStoreDetails = _SACLogic.GetTradeStoreList(VID, SID, IID, CID);
            return StatusCode(200, tradeStoreDetails);
        }
        /// <summary>
        ///Get the Zipcode list with Distance
        /// </summary>
        /// <param name="sourcezipcode"></param>
        /// <param name="destzipcode"></param>
        /// <returns></returns>
        [HttpGet("GetZipcodeDistanceList/{sourcezipcode}/{destzipcode}")]
        public virtual ActionResult<List<TradeStoreDetails>> GetZipcodeDistanceList([FromRoute][Required] string sourcezipcode, [FromRoute][Required] string destzipcode)
        {
            var tradeStoreDetails = _SACLogic.GetZipcodeDistanceList(sourcezipcode, destzipcode);
            //string con = _zipcodeService.GetZipCodeService(sourcezipcode, destzipcode);
            return StatusCode(200, tradeStoreDetails);
        }
        /// <summary>
        /// Get ZipcodeDistanceListAPI
        /// </summary>
        /// <param name="zipcodeDetails"></param>
        /// <returns></returns>
        [HttpPost("GetZipcodeDistanceListAPI")]
        public ActionResult<bool> GetZipcodeDistanceListAPI([FromBody] ZipcodeDetails zipcodeDetails)
        {
            var tradeStoreDetails = _SACLogic.GetZipcodeDistanceList(zipcodeDetails.sourcezipcode, zipcodeDetails.destzipcode);
            //string con = _zipcodeService.GetZipCodeService(sourcezipcode, destzipcode);
            return StatusCode(200, tradeStoreDetails);
        }

        /// <summary>
        /// Returns Suggeted Price.
        /// </summary>
        /// <remarks>Get Suggeted Price of the vehicle i.e. CPO -Non_CPO_Sgst_Price from pricing</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetSuggetedPrice/{VID}/{SID}/{IID}/{CID}")]
        public virtual ActionResult<string> GetSuggestedPrice([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID)
        {
            decimal? suggestedPrice = _SACLogic.GetSuggestedPrice(VID, SID, IID, CID);
            string strPrice = suggestedPrice.ToString();
            // != null && suggestedPrice > 0 ? String.Format("{0:c0}", suggestedPrice) : "PriceNotFound";
            return StatusCode(200, strPrice);
        }


        /// <summary>
        /// Returns SAC Vehicle recommendation Details.
        /// </summary>
        /// <remarks>Get SAC vehicle Recommendation Details</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetSACVehicleRecommendation/{VID}/{SID}/{IID}/{CID}/{SACID}")]
        public virtual ActionResult<SACVehicle> GetSACVehicleRecommendation([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID, [FromRoute][Required] long SACID)
        {
            return _SACLogic.GetSACVehicleRecommendation(VID, SID, IID, CID, SACID);
        }

        /// <summary>
        /// Save SAC Vehicle recommendation Details.
        /// </summary>
        /// <remarks>Save SAC vehicle Recommendation Details</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpPost("PostSACVehicleRecommendation")]
        public virtual ActionResult<bool> PostSACVehicleRecommendation([FromBody] DomainModels.Sac.SaveSacRecommendationDetails sacVehicle)
        {
            return _SACLogic.SaveSACVehicleRecommendation(sacVehicle);
        }
        /// <summary>
        /// Get Next SAC Pending Appraisal details
        /// </summary>
        /// <param name="cid"></param>
        /// <param name="RegionId"></param>
        /// <returns>Returns Next SAC Pending Appraisal Details</returns>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetNextPendingAppraisal/{cid}/{RegionId}")]
        public ActionResult<SACNextAppraisal> GetNextPendingAppraisal(short cid, short RegionId)
        {
            var nextAppraisal = _SACLogic.GetNextPendingAppraisal(cid, RegionId);
            return StatusCode(200, nextAppraisal);
        }

        /// <summary>
        /// Get Next SAC Appraisal details
        /// </summary>
        /// <param name="sACNextAppraisalParameter"></param>
        /// <returns>Returns Next SAC Appraisal Details</returns>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>        
        [HttpPost("GetNextAppraisal")]
        public ActionResult<SACNextAppraisal> GetNextAppraisal([FromBody] SACNextAppraisalParameter sACNextAppraisalParameter)
        {
            var nextAppraisal = _SACLogic.GetNextAppraisal(sACNextAppraisalParameter);
            return StatusCode(200, nextAppraisal);
        }
    }
}
