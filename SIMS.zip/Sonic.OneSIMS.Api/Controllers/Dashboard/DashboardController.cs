﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels;
using Sonic.OneSIMS.DomainModels.Dashboard;

namespace Sonic.OneSIMS.Api.Controllers.Dashboard
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Dashboard")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class DashboardController: ControllerBase
    {

        private readonly IDashboardLogic _dashboardLogic;
        private readonly IMapper _mapper;

        public DashboardController(IDashboardLogic dashboardLogic, IMapper mapper)
        {
            _dashboardLogic = dashboardLogic;
            _mapper = mapper;
        }

        /// <summary>
        /// Return Dashboard details by store id.
        /// </summary>
        /// <remarks>Get the sonic store details</remarks>
        /// <param name="id">store id to get the store detail</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad request Invalid Store ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpGet("{StoreId}/{SelectedTimePeriod}/{InventoryType}/{DateFrom}/{DateTo}/{IsNew}/{Type}")]

        public virtual ActionResult GetDashboardData([FromRoute][Required] int? StoreId, [FromRoute][Required] string? SelectedTimePeriod, [FromRoute][Required] int? InventoryType, [FromRoute] DateTime? DateFrom, [FromRoute] DateTime? DateTo, [FromRoute][Required] bool IsNew, [FromRoute] int Type)
        {
            Stopwatch watch = new Stopwatch();
            watch.Start();
            DashboardRequest dashboardRequest = new DashboardRequest()
            {
                StoreID = StoreId,
                SelectedTimePeriod = SelectedTimePeriod,
                InventoryType = InventoryType,
                DateFrom = DateFrom,
                DateTo = DateTo,
                IsNew = IsNew,
                Type = Type
            };
            if (dashboardRequest.StoreID.HasValue)
            {
                var dashboardItem = _dashboardLogic.GetDashboardData(dashboardRequest);
                if (dashboardItem == null)
                {
                    return StatusCode(404, "Dashboard data not found");
                }

                Sonic.OneSIMS.DomainModels.Settings.Dashboard dashboardData = _mapper.Map<Sonic.OneSIMS.DomainModels.Settings.Dashboard>(dashboardItem);
                watch.Stop();
                if (Type == 0 || Type == 1)
                    dashboardData.mangerDailyCheckList.elapsedTime = watch.ElapsedMilliseconds;
                if (Type == 2)
                    dashboardData.usedVehInvSummary.elapsedTime = watch.ElapsedMilliseconds;
                if (Type == 3)
                    dashboardData.soldOwnedReport[0].elapsedTime = watch.ElapsedMilliseconds;
                 if (Type == 1)
                    return StatusCode(200, dashboardData.mangerDailyCheckList);
                else if (Type == 2)
                    return StatusCode(200, dashboardData.usedVehInvSummary);
                else if (Type == 3)
                    return StatusCode(200, dashboardData.soldOwnedReport);
                else if (Type == 4)
                    return StatusCode(200, dashboardData.performanceBudget);
                else 
                    return StatusCode(200, dashboardData);
            }
            else
                return StatusCode(400, "Bad Request");


        }

        /// <summary>
        /// Return appraisal bubble count.
        /// </summary>
        /// <remarks>Get Appraisal bubble count</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetBadgeCount/{storeId}/{CID}")]
        public virtual ActionResult<BadgeCount> GetBadgeCount( [FromRoute][Required] int storeId, [FromRoute][Required] short CID)
        {
            var appCount = _dashboardLogic.GetBadgeCount(storeId,CID);
            return StatusCode(200, appCount);
        }
    }
}
