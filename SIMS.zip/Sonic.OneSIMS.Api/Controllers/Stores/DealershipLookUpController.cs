﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;

namespace Sonic.OneSIMS.Api.Controllers.Stores
{

    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class DealershipLookUpController : ControllerBase
    {
        private readonly IStoreLogic _storeLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="DealershipLookUpController"/> class.
        /// </summary>
        /// <param name="storeLogic"></param>
        /// <param name="mapper"></param>
        public DealershipLookUpController(IStoreLogic storeLogic, IMapper mapper)
        {
            _storeLogic = storeLogic;
            _mapper = mapper;
        }
        /// <summary>
        /// Return all active stores of Sonic.
        /// </summary>
        /// <remarks>Get all active stores</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetAllStoresList/{StoreType?}/{ShowAll?}")]
        public virtual ActionResult<Store> GetAllStoresList([FromRoute] short? StoreType = 0, bool? ShowAll = false)
        {
            var stores1 = _storeLogic.GetAllStoresList(StoreType, ShowAll);
            List<DomailModels.Settings.Store> stores = _mapper.Map<List<DomailModels.Settings.Store>>(stores1);
            return StatusCode(200, stores1);
            //return List<Store>;
        }

    }
}
