﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Settings;
using Sonic.OneSIMS.Framework.Constants;
using Sonic.OneSIMS.Infrastructure.Persistence;
using Sonic.OneSIMS.Infrastructure.ExceptionLogging;
using FluentValidation.Results;
using Sonic.OneSIMS.Api.DTOs.User;
using Sonic.OneSIMS.Api.DTOs.Common;
using Sonic.OneSIMS.DomainModels.Settings.Regions;

namespace Sonic.OneSIMS.Api.Controllers.Stores
{

    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]
    //[Authorize(AuthenticationSchemes = AuthConstants.SIMSScheme)]
    // [Authorize(AuthenticationSchemes = BearerAuthenticationHandler.SchemeName)]
    public class SonicStoreController : ControllerBase
    {
        private readonly IStoreLogic _storeLogic;
        private readonly IMapper _mapper;
        IList<ValidationFailure> errorMessages = new List<ValidationFailure>();
        /// <summary>
        /// Initializes a new instance of the <see cref="SonicStoreController"/> class.
        /// </summary>
        /// <param name="storeLogic"></param>
        /// <param name="mapper"></param>
        public SonicStoreController(IStoreLogic storeLogic, IMapper mapper)
        {
            _storeLogic = storeLogic;
            _mapper = mapper;
        }

        /// <summary>
        /// Add a new store.
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost]

        public virtual ActionResult<string> AddStore([FromBody] Store store)
        {
            int count = 0;
            decimal avgCount = 5;
            string userName = "Test";
            string methodName = "WetherForecast";
            bool isAddSuccess = false;
            try
            {
                var httpContext = Request.HttpContext;
                if (store != null)
                {
                    //        bool isAddSuccess = _storeLogic.AddStore(_mapper.Map<DomailModels.Settings.Store>((object)store));
                    for (count = 0; count <= 5; count++)
                    {
                        avgCount = count / 0;
                    }

                    if (isAddSuccess)
                    {
                        return StatusCode(201, "Store created");
                    }
                    else
                    {
                        return Ok("Store was not added");
                    }
                }
                return StatusCode(400, "Bad Request");
            }
            catch (Exception ex)
            {
                //errorMessages.Add(new ValidationFailure("Arithmatic", $"AirthmaticOpertaion Error."));
                //throw new Infrastructure.ExceptionLogging.LogServies.ValidationException(errorMessages);
                ex.Data.Add("userName", userName);
                ex.Data.Add("methodName", methodName);
                ex.Data.Add("errorMessage","Error in Add store method");
                //  throw new Exceptions.ApiException("");
                //throw new Exception("Error in Add store method",ex);
                throw ex;
            }
            //return StatusCode(400, "Bad Request");

        }

        /// <summary>
        /// Deletes a Sonic store.
        /// </summary>
        /// <param name="id">Store id to delete</param>
        /// <response code="400">Invalid Sotre ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpDelete("{id}")]
        public virtual ActionResult DeleteStore([FromRoute][Required] int? id)
        {
            if (id.HasValue)
            {
                bool isDeleteSuccess = _storeLogic.DeleteStoreById(id.Value);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Return store details by store id.
        /// </summary>
        /// <remarks>Get the sonic store details</remarks>
        /// <param name="id">store id to get the store detail</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad request Invalid Store ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpGet("{id}")]

        public virtual ActionResult FindStorebyId([FromRoute][Required] int? id)
        {
            try
            {
                if (id.HasValue)
                {
                    var storeItem = _storeLogic.GetStoreById(id.Value);
                    if (storeItem == null)
                    {
                        return StatusCode(404, "Store not found");
                    }

                    Store store = _mapper.Map<Store>(storeItem);
                    return StatusCode(200, store);
                }
                else

                    return StatusCode(400, "Bad Request");
            }
            catch (Exception ex)
            {

            }

            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Returns active or inactive stores count .
        /// </summary>
        /// <remarks>Get the sonic store details</remarks>
        /// <param name="id">store id to get the store detail</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad request Invalid Store ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpGet]
        [Route("GetStoresCount/{isActiveStores}")]

        public virtual IActionResult GetStoresCount([FromRoute][Required] bool? isActiveStores = true)
        {
            if (isActiveStores.HasValue)
            {
                var storeCount = _storeLogic.GetStoresCount(isActiveStores.Value);
                if (storeCount == null)
                {
                    return StatusCode(404, "Store not found");
                }

                return StatusCode(200, (isActiveStores == true ? "Active Stores Count: " + storeCount : "In-Active Stores Count: " + storeCount));
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Return stores list by region ID.
        /// </summary>
        /// <remarks>Get the sonic stores by region Id</remarks>
        /// <param name="regionId">store id to get the store detail</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad request Invalid Store ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpGet("findByRegion/{regionId}")]

        public virtual ActionResult FindStorebyRegion([FromRoute][Required] int? regionId)
        {
            if (regionId.HasValue)
            {
                var storeItem = _storeLogic.GetStoreByRegionId(regionId.Value);
                IEnumerable<Store> store = _mapper.Map<IEnumerable<Store>>(storeItem);
                return StatusCode(200, store);
            }
            return StatusCode(400, "Bad Request");
        }

        [HttpGet("GetStoreRegion/{companyId}")]
        public virtual ActionResult GetStoreRegionForCompany([FromRoute][Required] int companyId)
        {
            var storeItem = _storeLogic.GetRegionsAndStores(companyId);
            IEnumerable<StoreRegion> store = _mapper.Map<IEnumerable<StoreRegion>>(storeItem);
            return StatusCode(200, store);
        }

        [HttpGet("GetBrands")]
        public virtual ActionResult GetBrands()
        {
            var storeItem = _storeLogic.GetBrands();
            IEnumerable<Brand> brands = _mapper.Map<IEnumerable<Brand>>(storeItem);
            return StatusCode(200, brands);
        }

        /// <summary>
        /// Return all active store of Sonic.
        /// </summary>
        /// <remarks>Get all active stores</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet]
        public virtual ActionResult<Store> GetStorelist()
        {

            var storeItem = _storeLogic.GetAllStores();
            IEnumerable<Store> stores = _mapper.Map<IEnumerable<Store>>(storeItem);
            return StatusCode(200, stores);
        }

        /// <summary>
        /// Update sonic store
        /// </summary>
        /// <param name="body">store object that has to be added to sonic company</param>
        /// <response code="200">Store details are updated</response>
        /// <response code="404">Store details are not udpated</response>
        /// <response code="400">Bad request</response>        
        [HttpPut]
        public virtual ActionResult UdpateStore([FromBody] Store store)
        {
            if (store != null)
            {
                bool isAddSuccess = _storeLogic.UpdateStore(_mapper.Map<DomailModels.Settings.Store>((object)store));
                if (isAddSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "Store was not added");
                }
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }
        }

        /// <summary>
        /// Get all the Regions
        /// </summary>
        /// <param name="CID">Company ID</param>
        /// <remarks>Get all active Regions</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("getRegion/{cid}")]
        public virtual ActionResult<RegionNames> getRegion([FromRoute][Required] short cid)
        {
            var region = _storeLogic.GetRegions(cid);
            return StatusCode(200, region);
        }

    }
}
