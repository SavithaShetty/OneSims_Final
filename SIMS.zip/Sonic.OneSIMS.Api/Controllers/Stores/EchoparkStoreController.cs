﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;

namespace Sonic.OneSIMS.Api.Controllers.Stores
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class EchoparkStoreController : ControllerBase
    {

        private readonly IStoreLogic _storeLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="EchoparkStoreController"/> class.
        /// </summary>
        /// <param name="storeLogic"></param>
        /// <param name="mapper"></param>
        public EchoparkStoreController(IStoreLogic storeLogic, IMapper mapper)
        {
            _storeLogic = storeLogic;
            _mapper = mapper;
        }
        /// <summary>
        /// Return all active store of Sonic.
        /// </summary>
        /// <remarks>Get all active stores</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("Stores")]
        public virtual ActionResult<Store> GetStorelist()
        {
            var storeItem = _storeLogic.GetAllStores();
            IEnumerable<DomailModels.Settings.Store> stores = _mapper.Map<IEnumerable<DomailModels.Settings.Store>>(storeItem);
            return StatusCode(200, stores);
        }

        /// <summary>
        /// Add a new store.
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddStore")]
        public virtual ActionResult<string> AddStore([FromBody] Store store)
        {
            if (store != null)
            {
                bool isAddSuccess = _storeLogic.AddStore(_mapper.Map<DomailModels.Settings.Store>((object)store));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Store created");
                }
                else
                {
                    return Ok("Store was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes a Sonic store.
        /// </summary>
        /// <param name="id">Store id to delete</param>
        /// <response code="400">Invalid Sotre ID supplied</response>
        /// <response code="404">Store not found</response>
        [HttpDelete("{id}")]
        public virtual ActionResult DeleteStore([FromRoute][Required] int? id)
        {
            if (id.HasValue)
            {
                bool isDeleteSuccess = _storeLogic.DeleteStoreById(id.Value);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }
        /// <summary>
        /// Get dealership Info.
        /// </summary>
        /// <param name="storeId">Store Id to get general info from DB</param>
        /// <response code="405">Invalid input</response>
        [HttpGet("GetDealershipInfo{StoreId}")]
        public virtual ActionResult<StoreDetails> GetDealershipInfo([FromRoute][Required] int? StoreId)
        {
            var StoreDetailInfo = _storeLogic.GetDealershipInfo(StoreId);
            IEnumerable<StoreDetails> StoreInfo = _mapper.Map<IEnumerable<StoreDetails>>(StoreDetailInfo);
            return StatusCode(200, StoreInfo);
        }
        /// <summary>
        /// Add Dealership General Information.
        /// </summary>
        /// <param name="storedetails">StoreDetails object that has to be added to Rcho Park Store</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddDealershipInfo")]
        public virtual ActionResult<string> AddDealershipInfo([FromBody] StoreDetails storedetails)
        {
            if (storedetails != null)
            {
                bool isAddSuccess = _storeLogic.AddDealershipInfo(_mapper.Map<DomailModels.Settings.StoreDetails>(storedetails));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Store created");
                }
                else
                {
                    return Ok("Store was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Add a new store.
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpGet("GetConfiguration")]
        public virtual ActionResult<DTOs.Store.Configurations> GetConfiguration()
        {
            var storeItem = _storeLogic.GetConfigurations();
            IEnumerable<Configurations> configDetails = _mapper.Map<IEnumerable<Configurations>>(storeItem);
            return StatusCode(200, configDetails);
        }
        /// <summary>
        /// Add a new store.
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddConfiguration")]
        public virtual ActionResult<DTOs.Store.Configurations> AddConfiguration([FromBody] Configurations configurations)
        {
            //var storeItem = _storeLogic.GetConfigurations();
            if (configurations != null)
            {
                bool isAddSuccess = _storeLogic.AddConfiguration(_mapper.Map<DomailModels.Settings.Configurations>((object)configurations));
                if (isAddSuccess)
                {
                    return StatusCode(201, "Additional Store Configuration Added");
                }
                else
                {
                    return Ok("Additional Store Configuration Not Added");
                }
            }
            return StatusCode(400, "Bad Request");
        }
        /// <summary>
        /// Get other Config information from DB.
        /// </summary>
        /// <param name="storeId">storeId object that has to get Other configuration for Dealers.</param>
        /// <response code="405">Invalid input</response>
        [HttpGet("GetotherConfig{StoreId}")]
        public virtual ActionResult<StoreOtherInfo> GetOtherConfig([FromRoute][Required] int? StoreId)
        {
            var storeOtherInfoItem = _storeLogic.GetOtherConfig(StoreId);
            IEnumerable<StoreOtherInfo> storesOtherInfo = _mapper.Map<IEnumerable<StoreOtherInfo>>(storeOtherInfoItem);
            return StatusCode(200, storesOtherInfo);
        }
        /// <summary>
        /// Add other configuration info for Dealership info.
        /// </summary>
        /// <param name="StoreOtherInfo">StoreOtherInfo object that has to add other configuration info for the dealership</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddotherConfig")]
        public virtual ActionResult<string> AddOtherConfig([FromBody] StoreOtherInfo storeotherInfo)
        {
            if(storeotherInfo!=null)
            { 
            var isAddSuccess = _storeLogic.AddOtherConfig(_mapper.Map<DomailModels.Settings.StoreOtherInfo>(storeotherInfo));
            if (isAddSuccess)
            {
                return StatusCode(201, "Store created");
            }
            else
            {
                return Ok("Store was not added");
            }
        }
            return StatusCode(400, "Bad Request");
    }
       
    }
}
