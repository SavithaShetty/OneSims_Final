﻿using AutoMapper;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.Framework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Controllers.Stores
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    public class StoreConfigurationController : ControllerBase
    {
        private readonly IStoreLogic _storeLogic;
        public IConfiguration _configuration { get; }
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="SonicStoreController"/> class.
        /// </summary>
        /// <param name="storeLogic"></param>
        /// <param name="mapper"></param>
        public StoreConfigurationController(IStoreLogic storeLogic, IMapper mapper, IConfiguration configuration)
        {
            _storeLogic = storeLogic;
            _mapper = mapper;
            _configuration = configuration;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
        }

        /// <summary>
        /// Add a new store.
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpGet("GetDealershipConfigurations/{store_Id}")]
        public virtual ActionResult<DealershipConfiguration> GetDealershipConfigurations([FromRoute][Required] int store_Id)
        {
            var configDetails = _storeLogic.GetDealershipConfigurations(store_Id);
            DTOs.Store.DealershipConfiguration mappedConfig = _mapper.Map<DTOs.Store.DealershipConfiguration>(configDetails);
            return StatusCode(200, mappedConfig);
        }

        /// <summary>
        /// Add a new store.
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpGet("GetDealershipInformation/{store_Id}")]
        public virtual ActionResult<DealershipInformation> GetDealershipInformation([FromRoute][Required] int store_Id)
        {
            var configDetails = _storeLogic.GetDealershipInformation(store_Id);
            DTOs.Store.DealershipInformation dealershipInfo = _mapper.Map<DTOs.Store.DealershipInformation>(configDetails);
            if (string.IsNullOrWhiteSpace(dealershipInfo.logoURL))
                dealershipInfo.logoURL = string.Empty;
            return StatusCode(200, dealershipInfo);
        }

        /// <summary>
        /// Store duplicate check
        /// </summary>
        /// <param name="store">store object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpGet("CheckForNameDuplicate/{storeName}/{store_Id}")]
        public virtual ActionResult<Boolean> CheckForNameDuplicate([FromRoute][Required] string storeName, [FromRoute][Required] int store_Id)
        {
            var configDetails = _storeLogic.CheckForNameDuplicate(storeName, store_Id);

            return StatusCode(200, configDetails);
        }

        [HttpPost("SaveOrUpdateDealershipInfo")]
        public virtual void SaveOrUpdateDealershipInfo(DealershipInformation dealrInfo)
        {
            OneSIMS.DomainModels.Settings.DealershipInformation domainDealerInfo = _mapper.Map<OneSIMS.DomainModels.Settings.DealershipInformation>(dealrInfo);
            domainDealerInfo.IsUsedStore = true;
            domainDealerInfo.Is_Act = !domainDealerInfo.Is_Act;
            string days_ToSend = string.Empty;
            foreach (WeekDays day in dealrInfo.WeekDaysClosed)
            {
                if (day.isSelected)
                    days_ToSend = days_ToSend + day.value + "|";
            }
            domainDealerInfo.SelectedWeekNonOprDays = days_ToSend;
            _storeLogic.SaveOrUpdateDealershipInfo(domainDealerInfo);
        }

        [HttpPost("SaveSonicConfigurationDetails")]
        public virtual void SaveSonicConfigurationDetails(DealershipConfiguration sonicConfigInfo)
        {
            OneSIMS.DomainModels.Settings.DealershipConfiguration soincConfig = _mapper.Map<OneSIMS.DomainModels.Settings.DealershipConfiguration>(sonicConfigInfo);

            _storeLogic.SaveSonicConfigurationDetails(soincConfig);
        }
        /// <summary>
        /// Add a new Store.
        /// </summary>
        /// <param name="Userdetails">Userdetails object that has user detail to add</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddNewStoreDetails")]
        public virtual ActionResult<int> AddNewStoreDetails([FromBody] NewStoreDetails storeDtls)
        {
            if (!string.IsNullOrWhiteSpace(storeDtls.storeName))
            {
                int storeId = _storeLogic.AddNewStoreDetails(storeDtls.storeName);
                return StatusCode(201, storeId);
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Add user Region role Associations.
        /// </summary>
        /// <param name="Region">Region object that has user Region role Associations to add</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddNonOpeDate")]
        public virtual ActionResult AddNonOpeDate([FromBody] DateClosed dateClosed)
        {
            if (dateClosed != null && dateClosed.Date != null&& !string.IsNullOrWhiteSpace(dateClosed.Date))
            {

                OneSIMS.DomainModels.Settings.DateClosed dateClosedDomain = _mapper.Map<OneSIMS.DomainModels.Settings.DateClosed>(dateClosed);
                dateClosedDomain.Recurrence = ((int)Enum.Parse(typeof(RecurrenceTypes), dateClosed.Recurrence)).ToString();               
                dateClosedDomain.Date = Convert.ToDateTime(dateClosedDomain.Date).ToString("MM/dd/yyyy");
                bool isAddSuccess = _storeLogic.SaveNonOperatingDate(dateClosedDomain);
                if (isAddSuccess)
                {
                    return StatusCode(201, isAddSuccess);
                }
                else
                {
                    return Ok("Non Operating date was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes user Non operating date entry
        /// </summary>
        /// <param name="RegionId">Region id to delete</param>
        /// <param name="UserId">userId to delete region access</param>
        /// <response code="400">Invalid Region Id supplied</response>
        /// <response code="404">RegionAssociation not found</response>
        [HttpDelete("DeleteNonOprDateClosedEndpoint/{non_Operation_ID}/{storeID}")]
        public virtual ActionResult DeleteNonOprDateClosedEndpoint([FromRoute][Required] int non_Operation_ID, [FromRoute][Required] int storeID)
        {
            if (storeID != 0 && non_Operation_ID != 0)
            {
                bool isDeleteSuccess = _storeLogic.DeleteNonOprDateClosedEndpoint(non_Operation_ID, storeID);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        [HttpPost("UploadLogo")]
        public virtual ActionResult UploadLogo()
        {
            var result = ""; 
            IFormFile file = Request.Form.Files[0];

            if (file == null)
            {
                return BadRequest();
            }
            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                var fileBytes = ms.ToArray();
                string imgBaseString = Convert.ToBase64String(fileBytes);
                Image image = Base64StringToImage(imgBaseString);
                byte[] oImage = ImageToByteArray(image);
                AzureBlobSettings blobSetting = _configuration.GetSection("Settings").Get<Settings>().azureBlobSettings;
                result = _storeLogic.UploadFileBlobAsync(oImage, file.ContentType, Guid.NewGuid().ToString()+"."+file.FileName.Split('.').GetValue(1), blobSetting.AzureKey,blobSetting.AzureAccountName, blobSetting.AzureContainer, blobSetting.AzureURL);
            }

            return Ok(new { path = result });
        }
        protected Image Base64StringToImage(string base64String)
        {
            Image image;
            byte[] bytes = Convert.FromBase64String(base64String);
            MemoryStream ms = new MemoryStream(bytes);
            ms.Position = 0;
            image = Image.FromStream(ms);

            ms = null;
            bytes = null;
            return image;
        }
        private static byte[] ImageToByteArray(System.Drawing.Image imageIn)
        {
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
            {
                imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                return ms.ToArray();
            }
        }


    }
    public enum RecurrenceTypes
    {
        Annual = 10,
        Once = 40
    }
}
public class NewStoreDetails
{
    public string storeName { get; set; }
}
