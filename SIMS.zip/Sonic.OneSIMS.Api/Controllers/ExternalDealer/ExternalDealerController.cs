﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Settings;
using Sonic.OneSIMS.Framework.Constants;

namespace Sonic.OneSIMS.Api.Controllers.ExternalDealer
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class ExternalDealerController : ControllerBase
    {
        private readonly IExternalDealerLogic _externalDealerLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExternalDealerController"/> class.
        /// </summary>
        /// <param name="ExternalDealer"></param>
        /// <param name="mapper"></param>
        public ExternalDealerController(IExternalDealerLogic externalDealerLogic, IMapper mapper)
        {
            _externalDealerLogic = externalDealerLogic;
            _mapper = mapper;
        }

        /// <summary>
        /// Add a new External Dealer.
        /// </summary>
        /// <param name="External Dealer">External Dealer object that has to be added to sonic company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddExternalDealer")]

        public virtual ActionResult<string> AddExternalDealer([FromBody] Store store)
        {
            if (store != null)
            {
              //  bool isAddSuccess = _storeLogic.AddStore(_mapper.Map<DomailModels.Settings.Store>((object)store));
                bool isAddSuccess = _externalDealerLogic.AddExternalDealer(_mapper.Map<DomailModels.Settings.Store>((object)store));
                if (isAddSuccess)
                {
                    return StatusCode(201, "External Dealer created");
                }
                else
                {
                    return Ok("External Dealer was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes a External Dealer.
        /// </summary>
        /// <param name="id">External Dealer id to delete</param>
        /// <response code="400">Invalid External Dealer ID supplied</response>
        /// <response code="404">External Dealer not found</response>
        [HttpDelete("DeleteExternalDealer/{id}")]
        public virtual ActionResult DeleteExternalDealer([FromRoute][Required] int? id)
        {
            if (id.HasValue)
            {
                bool isDeleteSuccess = _externalDealerLogic.DeleteExternalDealer(id.Value);
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Return External Dealer details by Dealer id.
        /// </summary>
        /// <remarks>Get the External Dealer details</remarks>
        /// <param name="id">External Dealer to get the store detail</param>
        /// <response code="200">successful operation</response>
        /// <response code="400">Bad request Invalid Store ID supplied</response>
        /// <response code="404">External Dealer id found</response>
        [HttpGet("FindExternalDealerbyId/{id}")]

        public virtual ActionResult FindExternalDealerbyId([FromRoute][Required] int? id)
        {
            if (id.HasValue)
            {
                var storeItem = _externalDealerLogic.FindExternalDealerbyId(id.Value);
                if (storeItem == null)
                {
                    return StatusCode(404, "External Dealer not found");
                }

                Store store = _mapper.Map<Store>(storeItem);
                return StatusCode(200, store);
            }
            else
                return StatusCode(400, "Bad Request");
        }


        /// <summary>
        /// Update External Dealer
        /// /// </summary>
        /// <param name="body">External Dealer object that has to be added to sonic company</param>
        /// <response code="200">External Dealer details are updated</response>
        /// <response code="404">External Dealer details are not udpated</response>
        /// <response code="400">Bad request</response>        
        [HttpPut("UdpateExternalDealer")]
        public virtual ActionResult UdpateExternalDealer([FromBody] Store store)
        {
            if (store != null)
            {
                bool isAddSuccess = _externalDealerLogic.UdpateExternalDealer(_mapper.Map<DomailModels.Settings.Store>((object)store));
                if (isAddSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "External Dealer was not added");
                }
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }
        }
    }
}
