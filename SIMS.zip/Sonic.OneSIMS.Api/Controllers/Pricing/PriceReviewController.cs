﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sonic.OneSIMS.DomainModels.Pricing;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using System.ComponentModel.DataAnnotations;
using Sonic.OneSIMS.Api.Helpers;

namespace Sonic.OneSIMS.Api.Controllers.Pricing
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Pricing")]
    [ApiConventionType(typeof(SIMSConventions))]
    public class PriceReviewController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IPriceReviewLogic _priceReviewLogic;
        public readonly IConfiguration _configuration;
        public PriceReviewController(IPriceReviewLogic priceReviewLogic, IMapper mapper, IConfiguration configuration)
        {
            _priceReviewLogic = priceReviewLogic;
            _mapper = mapper;
            _configuration = configuration;
        }

        /// <summary>
        /// Get the PriceReview Recomendation details
        /// </summary>
        /// <remarks>
        /// Get the recommendation and trade recommendation details in price review vdp page    
        /// </remarks>
        /// <response code="200">successful operation</response>
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpGet("GetPriceReviewRecommendation/{VID}/{SID}/{IID}/{CID}/{RVWID}")]
        public async Task<ActionResult<PriceReviewRecommendationInfo>> GetPriceReviewVDPTradeDetails([FromRoute][Required] long VID, [FromRoute][Required] short SID, [FromRoute][Required] short IID, [FromRoute][Required] short CID, [FromRoute][Required] long RVWID)
        {
            return Ok(_priceReviewLogic.GetPriceReviewRecommendation(CID, VID, SID, IID, RVWID));
        }
        /// <summary>
        /// Save PriceReview Price Recommendation
        /// </summary>
        /// <remarks>
        /// Save PriceReview Price Recommendation from the price review VDP     
        /// </remarks>
        /// <response code="200">successful operation</response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response> 
        [HttpPost("SavePriceReviewRecommendation")]
        public async Task<ActionResult<Boolean>> SavePriceReviewRecommendationDetails([FromBody] PriceReviewRecommendation priceReviewRecommendationDetails)
        {
            return Ok(_priceReviewLogic.SavePriceReviewRecommendation(priceReviewRecommendationDetails));
        }


        ///// <summary>
        ///// Get Price Review History Log.
        ///// </summary>
        ///// <remarks>
        ///// Get Price Review History Log.
        ///// </remarks>
        ///// <response code="200">successful operation</response>
        ///// <response code="401">Unauthorization</response>                    
        ///// <response code="400">Bad Request</response>                    
        ///// <response code="500">Internal Server Error</response> 
        [HttpGet("GetPriceReviewHistory")]
        public virtual ActionResult<List<PriceReviewHistory>> GetPriceReviewHistory([FromQuery][Required] short storeId, [FromQuery][Required] string sortByField, [FromQuery][Required] string sortByDirection)
        {
            return StatusCode(200, _priceReviewLogic.GetPriceReviewHistory(storeId, sortByField, sortByDirection));
        }

        #region Pricing
        /// <summary>
        /// Get PriceReviewLog Details
        /// </summary>
        /// <remarks>
        /// Get the PriceReview Log Details from the price review log table     
        /// </remarks>
        /// <response code="200">successful operation</response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>

        [HttpPost("GetPriceReviewLogDetails")]
        public virtual ActionResult<List<Sonic.OneSIMS.DomainModels.Pricing.PriceReviewLogData>> GetPriceReviewLogDetails([FromBody] Sonic.OneSIMS.DomainModels.Pricing.PriceReviewLogParams priceReviewLogParam)
        {
            return Ok(_priceReviewLogic.GetPriceReviewLogDetails(priceReviewLogParam));
        }

        /// <summary>
        /// Save the PriceReview Record Locked info 
        /// </summary>
        /// <param name="lockeddetail"></param>
        /// <returns></returns>
        ///  /// <response code="201">successful operation</response>
        /// <response code="400">Bad Request</response>
        [HttpPost("LockUnlockPriceReviewRecord")]
        public ActionResult<bool> LockUnlockSACRecord([FromBody] PriceReviewLockedDetails lockeddetail)
        {
            bool t = _priceReviewLogic.LockUnlockPriceReviewRecord(lockeddetail);
            return StatusCode(200, t);
        }
        /// <summary>
        /// Get price review log LockedBy details
        /// </summary>
        /// <remarks>
        /// Get price review log LockedBy details from the price review acess log    
        /// </remarks>
        /// <response code="200">successful operation</response> 
        /// <response code="401">Unauthorization</response>                    
        /// <response code="400">Bad Request</response>                    
        /// <response code="500">Internal Server Error</response>

        [HttpGet("GetLockedBy/{pricereviewlogid}")]
        public virtual ActionResult<string> GetLockedBy([FromRoute][Required] int pricereviewlogid)
        {
            string lokedby = _priceReviewLogic.GetLockedBy(pricereviewlogid);

            return StatusCode(200, lokedby);
        }

        #endregion
    }
}
