﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.Api.DTOs.Store;
using Sonic.OneSIMS.Api.DTOs.Sublet;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.BusinessLogic.Interfaces;
using Sonic.OneSIMS.DomainModels.Settings;
using Sonic.OneSIMS.Framework.Constants;

namespace Sonic.OneSIMS.Api.Controllers.Sublets
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(GroupName = "Settings")]
    [ApiConventionType(typeof(SIMSConventions))]

    public class SubletController : ControllerBase
    {
        private object sublet;

        private readonly IStoreLogic _subletLogic;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="SonicStoreController"/> class.
        /// </summary>
        /// <param name="storeLogic"></param>
        /// <param name="mapper"></param>
        public SubletController(IStoreLogic subletLogic, IMapper mapper)
        {
            _subletLogic = subletLogic;
            _mapper = mapper;
        }

        /// <summary>
        /// Add a new Sublets.
        /// </summary>
        /// <param name="subletDetails">Sublet object that has to be added to EchoPark company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddSublet")]

        public virtual ActionResult<string> AddSublet([FromBody] SubletDetails subletDetails)
        {
            if (subletDetails != null)
            {
                //bool isAddSuccess = _subletLogic.AddSublet(_mapper.Map<DomailModels.Settings.Store>((object)store));
                bool isAddSuccess = true;
                if (isAddSuccess)
                {
                    return StatusCode(201, "Sublet created");
                }
                else
                {
                    return Ok("Sublet was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes a Sublet of a store.
        /// </summary>
        /// <param name="id">Sublet id to delete</param>
        /// <response code="400">Invalid Sotre ID supplied</response>
        /// <response code="404">Sublet not found</response>
        [HttpDelete("Sublet/{id}")]
        public virtual ActionResult DeleteStore([FromRoute][Required] int? id)
        {
            if (id.HasValue)
            {
                //bool isDeleteSuccess = _subletLogic.DeleteSubletById(id.Value);
                bool isDeleteSuccess = true;
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }


        /// <summary>
        /// Add a new Auction.
        /// </summary>
        /// <param name="subletDetails">Auction object that has to be added to EchoPark company</param>
        /// <response code="405">Invalid input</response>
        [HttpPost("AddAuction")]

        public virtual ActionResult<string> AddAuction([FromBody] SubletDetails subletDetails)
        {
            if (subletDetails != null)
            {
                //bool isAddSuccess = _subletLogic.AddAction(_mapper.Map<DomailModels.Settings.Store>((object)store));
                bool isAddSuccess = true;
                if (isAddSuccess)
                {
                    return StatusCode(201, "Sublet created");
                }
                else
                {
                    return Ok("Sublet was not added");
                }
            }
            return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Deletes a Auction on a Perticular Store.
        /// </summary>
        /// <param name="id">Auction id to delete</param>
        /// <response code="400">Invalid Sotre ID supplied</response>
        /// <response code="404">Auction not found</response>
        [HttpDelete("DeleteAuction/{id}")]
        public virtual ActionResult DeleteAuction([FromRoute][Required] int? id)
        {
            if (id.HasValue)
            {
                //bool isDeleteSuccess = _subletLogic.DeleteAuctionById(id.Value);
                bool isDeleteSuccess = true;
                if (isDeleteSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "No record to delete");
                }
            }
            else
                return StatusCode(400, "Bad Request");
        }

        /// <summary>
        /// Return all active Sublets of EchoPark.
        /// </summary>
        /// <remarks>Get all active Sublets</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetAllSubletlist")]
        public virtual ActionResult<SubletDetails> GetAllSubletlist()
        {

            //var Sublet = _subletLogic.GetAllSublets();
            //IEnumerable<SubletDetails> sublet = _mapper.Map<IEnumerable<SubletDetails>>(Sublet);
            return StatusCode(200, sublet);
        }

        /// <summary>
        /// Update Sublet
        /// </summary>
        /// <param name="body">Sublet object that has to be added to EchoPark company</param>
        /// <response code="200">Store details are updated</response>
        /// <response code="404">Store details are not udpated</response>
        /// <response code="400">Bad request</response>        
        [HttpPut("UdpateSublet")]
        public virtual ActionResult UdpateSublet([FromBody] SubletDetails subletDetails)
        {
            if (subletDetails != null)
            {
                //bool isAddSuccess = _subletLogic.UdpateSublet(_mapper.Map<DomailModels.Settings.Store>((object)store));
                bool isAddSuccess = true;
                if (isAddSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "Store was not added");
                }
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }
        }

        /// <summary>
        /// Return all active Actions.
        /// </summary>
        /// <remarks>Get all active Actions</remarks>
        /// <response code="200">successful operation</response>
        /// <response code="400">Invalid status value</response>
        [HttpGet("GetActionlist")]
        public virtual ActionResult<SubletDetails> GetActionlist()
        {

            //var Sublet = _subletLogic.GetAllAuctions();
            //IEnumerable<SubletDetails> sublet = _mapper.Map<IEnumerable<SubletDetails>>(Sublet);
            return StatusCode(200, sublet);
        }

        /// <summary>
        /// Update Action 
        /// /// </summary>
        /// <param name="body">Action object that has to be updated to Echopark company</param>
        /// <response code="200">Action details are updated</response>
        /// <response code="404">Action details are not udpated</response>
        /// <response code="400">Bad request</response>        
        [HttpPut("UdpateAction")]
        public virtual ActionResult UdpateAction([FromBody] SubletDetails sublet)
        {
            if (sublet != null)
            {
                //  bool isAddSuccess = _subletLogic.UpdateAction(_mapper.Map<DomailModels.Settings.Store>((object)store));
                bool isAddSuccess = true;
                if (isAddSuccess)
                {
                    return StatusCode(200, "success");
                }
                else
                {
                    return StatusCode(404, "Store was not added");
                }
            }
            else
            {
                return StatusCode(400, "Bad Request");
            }
        }

    }
}
