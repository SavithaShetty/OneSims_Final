﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Exceptions
{
    public class RepositoryLogicException:Exception
    {
        public RepositoryLogicException() : base()
        {
        }

        public RepositoryLogicException(string message) : base(message)
        {
        }

        public RepositoryLogicException(string message, params object[] args)
            : base(String.Format(CultureInfo.CurrentCulture, message, args))
        {
        }
    }
}
