﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class AutocheckCredentials
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string MappedStoreId { get; set; }

    }
}
