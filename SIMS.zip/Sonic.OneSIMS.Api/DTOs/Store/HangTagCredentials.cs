﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class HangTagCredentials
    {
        public bool Is_hangTagEnabled { get; set; }
        public string HTUserName { get; set; }
        public string HTPassword { get; set; }
    }
}
