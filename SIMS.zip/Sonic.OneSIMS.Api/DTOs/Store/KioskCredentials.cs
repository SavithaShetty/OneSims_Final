﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class KioskCredentials
    {
        public bool Is_KioskEnabled { get; set; }

        public int StoreId { get; set; }

        public string LaneName { get; set; }
    }
}
