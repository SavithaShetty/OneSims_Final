﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class Configurations
    {
        public virtual short StoreId { get; set; }
        public virtual short CurrStoreID { get; set; }
        public virtual string StoreName { get; set; }

        public virtual List<AutocheckCredentials> AutocheckCredentials { get; set; }

        public virtual List<BooksConfiguration> BooksConfigurations { get; set; }

        public virtual List<CarfaxCredentials> CarfaxCredentials { get; set; }

        public virtual List<HangTagCredentials> HangTagCredentials { get; set; }

        public virtual List<KioskCredentials> KioskCredentials { get; set; }

        public virtual List<Options> DealerOptions { get; set; }
        public virtual Nullable<decimal> PackAmt
        {
            get;
            set;
        }
        public virtual Dictionary<int, string> Books
        {
            get;
            set;
        }
        //Recon Photo Mandatory, //Online Carcash Enabled,//CarCash Application Enabled
        //EchoPark Application Enabled,//DMV Check Required,//Create SAC Records for Dealership
        //Step 5 Appraisal Required
        public virtual bool[] Options
        {
            get;
            set;
        }

        public virtual List<string> PreviouslySelectedbooks
        {
            get;
            set;
        }
        public virtual decimal? DealerFeeAmountUsed
        {
            get;
            set;
        }

        public virtual Dictionary<int, string> ShowBooks
        {
            get;
            set;
        }
        public virtual List<string> PreviouslySetupSelectedbooks
        {
            get;
            set;
        }
        public virtual bool IsRASyncReqd
        {
            get;
            set;
        }
        public virtual bool IsADPSyncReqd
        {
            get;
            set;
        }
        public virtual bool IsCompletedVehicleIndicator
        {
            get;
            set;
        }
        public virtual bool isAutoPricingReqd
        {
            get;
            set;
        }
        public virtual bool isEndingDollerDisbd
        {
            get;
            set;
        }
        //public List<IDValues> Lanes { get; set; }




    }
}
