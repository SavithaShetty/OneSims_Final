﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public partial class StoreOtherInfo
    {
        public virtual Nullable<decimal> FixedOPS
        {
            get;
            set;
        }
        public virtual Nullable<decimal> FI
        {
            get;
            set;
        }
        public virtual Nullable<decimal> Pack
        {
            get;
            set;
        }
        public virtual Nullable<decimal> Doc
        {
            get;
            set;
        }
        public virtual bool? isVoucherDeduct
        {
            get;
            set;
        }

        public virtual decimal? VoucherAmount
        {
            get;
            set;
        }
        public virtual decimal? InspectionAmount
        {
            get;
            set;
        }
        public virtual List<StoreCDKDetails> StoreCDKDetails
        {
            get;
            set;
        }
        public virtual string CDM_Dealer_ID { get; set; }
        public virtual string Dealer_Com_Dealer_ID { get; set; }
        public virtual string DMV_Dealer_ID { get; set; }
        public virtual string AutoCheck_Dealer_ID { get; set; }
        public virtual string DAP_IP { get; set; }

    }
}
