﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public partial class StoreCDKDetails
    {
        public bool? CDK_Sync_Req { get; set; }
        public string CDK_Dealer_ID { get; set; }
        public string CDK_Region_ID { get; set; }
        public string Manheim_Region_ID { get; set; }
        public string KBB_Region_ID { get; set; }
        public string BB_Region_ID { get; set; }
        public string NADA_Region_ID { get; set; }
        public string CDK_GL_Prefix { get; set; }
        public string CDK_Company_ID { get; set; }
        public string Dealership_Name { get; set; }
        public string CDK_Login_ID { get; set; }
        public string CDK_FI_Retail_Login_ID { get; set; }
        public string CDK_FI_Retail_Cora_ID { get; set; }
        public string CDK_FI_Wholesale_Login_ID { get; set; }
        public string CDK_FI_Wholesale_Cora_ID { get; set; }
        public string CDK_Location_ID { get; set; }
        public string CDK_BB_Region_ID { get; set; }
        public string CDK_KBB_Region_ID { get; set; }
        public string CDK_NADA_Region_ID { get; set; }
    }
}
