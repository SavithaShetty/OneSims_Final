using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using FluentValidation;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public partial class Store
    {
        public int? StoreId { get; set; }

        public string StoreName { get; set; }
    }

    public class StoreValidator : AbstractValidator<Store>
    {
        public StoreValidator()
        {
            RuleFor(m => m.StoreId).NotNull().NotEmpty()
            .WithMessage("Store ID is requred");
            RuleFor(m => m.StoreName).NotEmpty().MinimumLength(3).MaximumLength(50);
        }
    }
}