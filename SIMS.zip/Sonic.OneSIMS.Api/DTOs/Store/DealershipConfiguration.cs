﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class DealershipConfiguration
    {
        public DealershipConfiguration()
        {
            //DealershipInfo = new DealershipInformation();
            sonicConfiguration = new SonicConfiguraion();
        }
        //public DealershipInformation DealershipInfo { get; set; }
        public SonicConfiguraion sonicConfiguration { get; set; }

        public int storeID  {get; set; }
    }
}
