﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class Options
    {
        #region StoreOptions
        public virtual string Name
        {
            get;
            set;
        }

        public virtual string Address
        {
            get;
            set;
        }

        public virtual string PhoneNumber
        {
            get;
            set;
        }

        public virtual string EmailAddress
        {
            get;
            set;
        }

        public virtual string TransportCompnayEmail
        {
            get;
            set;
        }

        public virtual string ExperiencedManagerEmail
        {
            get;
            set;
        }
        #endregion
    }
}
