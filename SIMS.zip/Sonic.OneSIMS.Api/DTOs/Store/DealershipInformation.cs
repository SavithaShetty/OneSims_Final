﻿using Sonic.OneSIMS.Api.DTOs.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public partial class DealershipInformation
    {
        public DealershipInformation()
        {
            WeekDaysClosed = new List<WeekDays>();
            StateList = new List<StateList>();
            DatesClosed = new List<DateClosed>();
            regionList = new List<StoreRegionMap>();
            logoURL = "";
        }
        public int? Store_id { get; set; }
        public string StoreName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public virtual List<StateList> StateList { get; set; }
        public string TimeZone { get; set; }
        public Int64 ZipCode { get; set; }
        public virtual List<WeekDays> WeekDaysClosed
        {
            get;
            set;
        }
        public virtual List<DateClosed> DatesClosed
        {
            get;
            set;
        }
        public virtual bool IsHub { get; set; }
      public string StoreLogoUrl { get; set; }
        public bool Is_External_Dealer { get; set; }
        public bool Is_Act { get; set; }
        public bool IsNewStore { get; set; }
        public bool IsUsedStore { get; set; }
        public bool IsEchoparkStore { get; set; }
        public string SelectedWeekNonOprDays { get; set; }

        public string logoURL { get; set; }

        public List<StoreRegionMap> regionList { get; set; }

        public int? selectedRegion { get; set; }
    }

    public class StoreRegionMap
    {
        public int regionId { get; set; }
        public string regionName { get; set; }
    }
   
    public class WeekDays
    {
        public string value { get; set; }

        public string viewValue { get; set; }

        public bool isSelected { get; set; }
    }

    public class StateList
    {
        public int State_ID { get; set; }

        public string State_Code { get; set; }

        public bool isSelected { get; set; }
    }
}
