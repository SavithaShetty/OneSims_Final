﻿using Sonic.OneSIMS.Api.DTOs.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public partial class StoreRegion
    {
        public int StoreId { get; set; }

        public string StoreName { get; set; }

        public int RegionId { get; set; }

        public string RegionName { get; set; }

    }
}
