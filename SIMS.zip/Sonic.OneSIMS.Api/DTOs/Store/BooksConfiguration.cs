﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class BooksConfiguration
    {
        public List<int> RequiredBookIds { get; set; }

        public List<int> SetupBookIds { get; set; }
    }
}
