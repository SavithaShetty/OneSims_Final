﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public class SonicConfiguraion
    {
        public SonicConfiguraion()
        {
            loanerConfiguration = new LoanerConfiguration();
            sonicOtherOptions = new SonicOtherOptions();
            sonicCdkDetails = new SonicCdkDetails();
            sonicUsedConfiguration = new SonicUsedConfiguration();
        }
        public int storeID { get; set; }
        public Boolean hangTagSyncRequired { get; set; }
        public string hangTagUserName { get; set; }

        public string hangTagPassword { get; set; }
        public Boolean isCDKSyncRequired { get; set; }

        public bool isActive { get; set; }

        public LoanerConfiguration loanerConfiguration { get; set; }

        public SonicOtherOptions sonicOtherOptions { get; set; }
        public SonicCdkDetails sonicCdkDetails { get; set; }

        public SonicUsedConfiguration sonicUsedConfiguration { get; set; }
    }

    public class SonicUsedConfiguration
    {
        public SonicUsedConfiguration()
        {
            dealershipParameter = new DealershipParameter();
            reconOptions = new ReconOptions();
            contactandFees = new ContactandFees();
            otherOptions = new UsedOtherOptions();
            certificateBrands = new List<CertificateBrands>();
        }
        public Boolean autoCheckReportRequired { get; set; }
        public string autoCheckUserName { get; set; }
        public string autoCheckPassword { get; set; }
        public Boolean carfaxReportRequired { get; set; }
        public string carfaxUserName { get; set; }
        public string carfaxPassword { get; set; }
        public Boolean kioskEnabled { get; set; }
        public string kioskLaneId { get; set; }
        public string kioskLaneName { get; set; }

        public DealershipParameter dealershipParameter { get; set; }

        public bool voucherDeduction { get; set; }

        public ReconOptions reconOptions { get; set; }

        public UsedBooks books { get; set; }

        public ContactandFees contactandFees { get; set; }

        public UsedOtherOptions otherOptions { get; set; }

        public List<CertificateBrands> certificateBrands { get; set; }

        public string brands_To_Send { get; set; }

    }

    public class CertificateBrands
    {
        public string brandID { get; set; }
        public string brandName { get; set; }

        public int storeID { get; set; }

        public bool defaultMarketReady { get; set; }

        public bool isCert { get; set; }
    }

    public class UsedOtherOptions
    {
        public Boolean driveTrainBodyStyleReq { get; set; }
    public Boolean completeVehIndicatorReq { get; set; }
public Boolean caracshApplicationEnabled { get; set; }
public Boolean missingDataCheckRequired { get; set; }
public Boolean intransitUsed { get; set; }
public Boolean autoUsed  { get; set; }
public Boolean dmvCheckRequired { get; set; }
public Boolean cerateSACRecForDealership { get; set; }
public Boolean serviceAppraisalforDealership { get; set; }
public Boolean fiveStepAppraisalForDealership  { get; set; }
    }

    public class ContactandFees
    {
        public string dealershipEmail { get; set; }
        public string defaultTradeEmail { get; set; }
        public string transportationEmail { get; set; }
        public double dealerFeeAmt { get; set; }
        public double packAmt { get; set; }
    }

    public class UsedBooks
    {
        public Boolean bbUsedForComparision { get; set; }
        public Boolean manheimUsedForComparision { get; set; }
        public Boolean nadaUsedForComparision { get; set; }
        public Boolean kbbUsedForComparision { get; set; }
    }

    public class ReconOptions
    {
        public double inspectionandDetails { get; set; }
        public double twoKeyPresentValue { get; set; }
    }

    public class DealershipParameter
    {
        public int physicalLogCapacity { get; set; }
        public int overflowLogCapacity { get; set; }
        public int fixedOpsOprMarginas { get; set; }
        public int fandiOprMarginas { get; set; }
        public int packOprMarginas { get; set; }
        public int docOprMarginas { get; set; }
    }

    public class SonicCdkDetails
    {
        public string cdkDealerID { get; set; }
        public string cdkRegionID { get; set; }
        public string manheimRegionID { get; set; }
        public string cdkBBRegionID { get; set; }
        public string cdkKBBRegionID { get; set; }
        public string cdkNadaRegionID { get; set; }
        public string cdkGlPrefix { get; set; }
        public string cdkCompanyID { get; set; }
        public string dealershipName { get; set; }
        public string cdkLoginID { get; set; }
        public string cdkFIRetailLoginID { get; set; }
        public int cdkFIRetailCoraID { get; set; }
        public string cdkFIWholesaleLoginID { get; set; }
        public int cdkFIWholesaleCoraID { get; set; }
        public string CdmDealerId { get; set; }
        public string DealerComDealerID { get; set; }
        public string dmvDealerID { get; set; }
        public string autoCheckDealerID { get; set; }
        public string dapIP { get; set; }
        public string dapComID { get; set; }
    }

    public class SonicOtherOptions
    {
        public bool raSyncRequired { get; set; }
        public bool completeVehIndicator { get; set; }
        public bool autoPricingRequired { get; set; }
        public bool endingDollerDisabled { get; set; }
        public bool reconPhotoMandatory { get; set; }
        public bool onlineCarcashEnabled { get; set; }
        public bool carcashApplicationEnabled { get; set; }
        public bool echoparkApplicationEnabled { get; set; }
        public bool dmvCheckRequired { get; set; }
        public bool createSACRecForDealership { get; set; }
        public bool step5AppraisalRequired { get; set; }
}

    public class LoanerConfiguration
    {
        public Boolean includeLoanersinHomeNetandDDC { get; set; }
        public Boolean loanersConsideredasNew { get; set; }
        public Boolean loanersConsideredasUsed { get; set; }
        public Boolean allowLoanerstoPushbackInvasNewVehicle { get; set; }
        public Boolean pricingShuoldbeUsedfromCDK { get; set; }
        public Boolean pricingShuoldbeUsedfromSIMS { get; set; }
    }
}
