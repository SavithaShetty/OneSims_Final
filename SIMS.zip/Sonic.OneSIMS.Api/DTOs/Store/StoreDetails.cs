﻿using Sonic.OneSIMS.Api.DTOs.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Store
{
    public partial class StoreDetails
    {
        public int? Store_id { get; set; }
        public string StoreName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public virtual Dictionary<int, string> State {get; set;}
        public virtual string TimeZone { get; set; }
        public virtual string ZipCode { get; set; }
        public virtual Dictionary<int, string> WeekDaysClosed
        {
            get;
            set;
        }
        public virtual List<DateClosed> DatesClosed
        {
            get;
            set;
        }
        public virtual bool IsHub { get; set; }
        public virtual string podname { get; set; }

        public virtual List<Locationlist> Locationlist
        {
            get;
            set;
        }

        public virtual byte[] StoreLogo
        {
            get;
            set;
        }
        public string StoreLogoUrl { get; set; }
    }
    public class Locationlist
    {
        public int? StoreId { get; set; }

        public string StoreName { get; set; }

        public string Lotidentifier { get; set; }
    }
}
