﻿using Sonic.OneSIMS.DomailModels.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public class RollUp
    {
        public virtual Company Company { get; set; }
        public virtual int StoreID { get; set; }
        public virtual string StoreName { get; set; }
        public virtual int RegionId { get; set; }
        public virtual string RegionName { get; set; }
        public virtual string RoleName { get; set; }
    }
}