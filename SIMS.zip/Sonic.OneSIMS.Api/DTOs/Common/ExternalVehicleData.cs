﻿using Sonic.OneSIMS.Api.DTOs.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public class ExternalVehicleData
    {
        //public VehicleIdentity vehicleIdentity { get; set; }
        public IntegrationType integrationType { get; set; }
        public Byte ReportIconId { get; set; }
        public string ReportURL { get; set; }
        public string CreatedBy { get; set; }
    }

}
