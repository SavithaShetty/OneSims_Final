﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sonic.OneSIMS.Api.DTOs.Store;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public partial class Region
    {
        public virtual string RegionName
        {
            get;
            set;
        }

        public int RegionId
        {
            get;
            set;
        }

        public virtual bool IsRegionSelected
        {
            get;
            set;
        }

        public virtual List<Store.Store> Stores { get; set; }

        public virtual Guid RoleId
        {
            get;
            set;
        }

        public virtual string RoleName
        {
            get;
            set;
        }

        public string Visible { get; set; }

        public string RegionClass
        {
            get;
            set;
        }
        public virtual int CompanyId { get; set; }

        public Guid UserId { get; set; }

        public string CreatedBy { get; set; }
    }
}
