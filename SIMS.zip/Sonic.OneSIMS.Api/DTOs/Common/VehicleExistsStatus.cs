﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public enum VehicleExistsStatus
    {
        NewlyCreatedVehicle = 0,
        AppraisalCompletedInSameSameStore = 1,
        AppraisalPendingInSameStore = 2,
        OnHandInSameStore = 3,
        OnHandInDiffStore = 4,
        OnHandInDiffCompany = 5, //retail side onhand status
        NotAllowedInRetailNewVehicleStatus = 6,//
        CrossCompanyAppraisal = 7,
        CCAAndPendingInSameStore = 8
    }
}
