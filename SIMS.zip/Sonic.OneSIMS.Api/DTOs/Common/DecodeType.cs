﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public enum DecodeType
    {
        None = 0,
        Chrome_Decode = 1,
        KBB_Book_Decode = 2,
        ICO_Kbb_Decode = 3,
        Reset_Trim_List = 4
    }
}
