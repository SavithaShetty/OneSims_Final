﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public class AgeBucket
    {

        public virtual String AgeRange
        {
            get;
            set;
        }

        public virtual int StartAgeRange
        {
            get;
            set;
        }

        public virtual int EndAgeRange
        {
            get;
            set;
        }

        public virtual int SalesTarget
        {
            get;
            set;
        }

        public virtual int OnhandTarget
        {
            get;
            set;
        }


        public virtual int EndingDollar
        {
            get;
            set;
        }

        public virtual int? BucketId
        {
            get;
            set;
        }

        public Nullable<bool> PriceRvwEnforcement //Iteration 9
        {
            get;
            set;
        }
    }
}
