﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sonic.OneSIMS.Api.DTOs
{
    public partial class DateClosed
    {
        public virtual string Date
        {
            get;
            set;
        }
        public virtual string Recurrence
        {
            get;
            set;
        }

        public string recurrenceViewValue { get; set; }

        public virtual int Non_Operation_ID
        {
            get;
            set;
        }
        public int storeID { get; set; }
    }
}
