﻿using Sonic.OneSIMS.Api.DTOs.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public class VehicleIdentity
    {
        public int VID { get; set; }
        public int SID { get; set; }
        public int IID { get; set; }
        public Company CID { get; set; }
    }
}
