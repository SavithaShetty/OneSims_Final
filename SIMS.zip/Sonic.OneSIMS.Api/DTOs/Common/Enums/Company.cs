﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common.Enums
{
    public enum Company
    {
        SU = 10,
        SN = 20,
        EP = 30
    }
}
