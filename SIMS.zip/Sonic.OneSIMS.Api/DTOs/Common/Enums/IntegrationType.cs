﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common.Enums
{
    public enum IntegrationType
    {
        AutoCheck = 10,
        CarFax = 20
    }
}
