﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Common
{
    public class MenuNavigation
    {
        public virtual int? FeatureID
        {
            get;
            set;
        }
        public virtual int ExpTime
        {
            get;
            set;
        }
        public virtual string FeatureName
        {
            get;
            set;
        }

        public virtual string FeatureUrl
        {
            get;
            set;
        }
        public virtual string FeatureGroupName
        {
            get;
            set;
        }

        public string SubFeatureName { get; set; }

        public int? SubFeatureID { get; set; }

        public bool IsEnabled { get; set; }
    }
}
