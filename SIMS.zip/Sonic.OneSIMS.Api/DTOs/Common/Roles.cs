﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sonic.OneSIMS.Api.DTOs.Common
{

    public class Roles
    {
        public virtual Guid RoleID { get; set; }
        public virtual string RoleName { get; set; }
        public virtual string LoweredRoleName { get; set; }
        public virtual bool IsSelected { get; set; }
    }
}
