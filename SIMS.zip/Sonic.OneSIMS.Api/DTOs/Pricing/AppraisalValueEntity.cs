﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{

    public partial class AppraisalValueEntity
    {
        #region Primitive Properties

        public virtual long AppraisalID
        {
            get;
            set;
        }

        public virtual Nullable<decimal> AppraisalValue
        {
            get;
            set;
        }

        public virtual bool IsSightUnseen
        {
            get;
            set;
        }

        public virtual short StatusID
        {
            get;
            set;
        }

        public virtual Nullable<decimal> UnseenValue
        {
            get;
            set;
        }
        public virtual Nullable<decimal> EstCondition
        {
            get;
            set;
        }
        public virtual Nullable<decimal> ActEstCondition
        {
            get;
            set;
        }
        public virtual Nullable<decimal> DefaultEstCondition
        {
            get;
            set;
        }
        public virtual Nullable<decimal> EstOffer
        {
            get;
            set;
        }
        public int? ReasonID { get; set; }

        public decimal NewAppValue { get; set; }

        public string BumpUser { get; set; }

        public long VehicleID { get; set; }

        public short StoreID { get; set; }

        public short InvtrID { get; set; }

        public Nullable<decimal> SACRecmAppValue { get; set; }

        public bool Step5_Exists { get; set; }
        //RetailICO Pricing
        public decimal InspectionDetailValue { get; set; }

        public virtual string AppraisedBy { get; set; }
        public virtual Nullable<DateTime> AppraisedDate { get; set; }
        public Nullable<short> StoreRecommendation { get; set; }
        #endregion
    }
}
