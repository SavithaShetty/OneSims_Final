﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    [Serializable]
    public partial class BumpHistoryData
    {
        #region Primitive Properties

        public virtual DateTime BumpDate
        {
            get;
            set;
        }

        public virtual string Appraiser
        {
            get;
            set;
        }

        public virtual string BumpReason
        {
            get;
            set;
        }

        public virtual Nullable<decimal> Variance
        {
            get;
            set;
        }

        public virtual Nullable<decimal> OldAppraisalValue
        {
            get;
            set;
        }

        public virtual Nullable<decimal> NewAppraisalValue
        {
            get;
            set;
        }

        public virtual long AppraisalID
        {
            get;
            set;
        }
        public string RTCAppraiser
        {
            get;
            set;
        }
        public string StoreName
        {
            get;
            set;
        }
        #endregion
    }
}
