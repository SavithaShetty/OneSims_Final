﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class PricingRequest
    {
        public long VehicleID { get; set; } //done
        /// <summary>
        /// Store Id
        /// </summary>
        public short StoreID { get; set; } //done
        /// <summary>
        /// Inventory Id
        /// </summary>
        public short InvtrID { get; set; } //done

        public string hdnnewconditionValue { get; set; } //done

        public string UserName { get; set; } //done
        public decimal? AppraisalValue { get; set; } //done

        public decimal? UnseenAppraisalValue { get; set; } //done

        public bool IsChecked { get; set; } //done

        public bool IsMarketReady { get; set; } //done

        public string SuggestedPrice { get; set; } //done
        public string RASuggestedPrice { get; set; } //done

        //public bool Certified { get; set; } //optional along with status
        public string RANonCPOSuggestedPrice { get; set; } //done

    }
}
