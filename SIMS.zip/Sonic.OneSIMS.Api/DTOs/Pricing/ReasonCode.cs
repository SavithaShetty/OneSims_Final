﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class ReasonCode
    {
        public int PriceChangeReasonId { get; set; }
        public string PriceChangeReasonCode { get; set; }
    }
}
