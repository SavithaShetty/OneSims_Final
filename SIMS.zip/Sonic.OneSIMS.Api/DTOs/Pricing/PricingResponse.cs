﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class PricingResponse
    {
        //Button
        public bool btnGetRetailPriceVisible { get; set; }

        //Retail Text
        public bool txtRetailPriceValueVisible { get; set; }
        public string txtRetailPriceValueText { get; set; }

        //RA Suggested 
        public string lblRetailPriceValueText { get; set; }
        public string lblRASuggestedPriceText { get; set; }

        //Retail
        public bool lblRetailPriceValueVisible { get; set; }
        public bool lblRetailPriceVisible { get; set; }
        public string lblRetailPriceText { get; set; }


        //Pricing Factors
        public string lblPeriodText { get; set; }
        public string lblMileageText { get; set; }
        public string lblRangeText { get; set; }
        public string lblSales0Text { get; set; }
        public string lblSales1Text { get; set; }
        public string lblSales2Text { get; set; }
        public string lblSales3Text { get; set; }
        public string lblSales4Text { get; set; }
        public string lblSales5Text { get; set; }
        public string lblSales6Text { get; set; }
        public string lblSales7Text { get; set; }
        public string lblSales8Text { get; set; }
        public string lblSales9Text { get; set; }

        public string lblListing0Text { get; set; }
        public string lblListing1Text { get; set; }
        public string lblListing2Text { get; set; }
        public string lblListing3Text { get; set; }
        public string lblListing4Text { get; set; }
        public string lblListing5Text { get; set; }
        public string lblListing6Text { get; set; }
        public string lblListing7Text { get; set; }
        public string lblListing8Text { get; set; }
        public string lblListing9Text { get; set; }
        public string lblListing10Text { get; set; }
        public string lblListing11Text { get; set; }
        public string lblListing12Text { get; set; }
        public string lblListing13Text { get; set; }
        public string lblListing14Text { get; set; }
        public string lblListing15Text { get; set; }

        public string hdnnewconditionValue { get; set; }

        //RetailICO Pricing
        public string lblRANonCPOSuggestedPriceText { get; set; }
        public bool chkMarketReadyEnabled { get; set; }
        public bool chkMarketReadyVisible { get; set; }
        public bool chkMarketReadyChecked { get; set; } //newly added now

        public bool chkPWChecked { get; set; }
        public bool chkPWEnabled { get; set; }
        public string lblCertText { get; set; }

        //Delete ! needed : instead Certified
        //public bool lblCPOSuggestedPriceVisible { get; set; }
        //public bool lblRASuggestedPriceTextVisible { get; set; }

        public bool txtRetailValidation { get; set; }
        public string AppIDValue { get; set; }
        public string lblConditionText { get; set; }

        public string lblMkvText { get; set; }

        public bool txtAppraisalValueVisible { get; set; }

        public bool lblAppraisalValueVisible { get; set; }

        public string lblAppraisalValueText { get; set; }

        public bool txtUnseenAppValueVisible { get; set; }
        public string lblUnseenAppraisalValueText { get; set; }

        public string txtUnseenAppValueText { get; set; }

        public string txtAppraisalValueText { get; set; }

        public bool Certified { get; set; }

        public bool RetailPriceSectionVisible { get; set; }

        public bool PricingAccessible { get; set; }
        public string PricingValidationMessage { get; set; }
    }

}
