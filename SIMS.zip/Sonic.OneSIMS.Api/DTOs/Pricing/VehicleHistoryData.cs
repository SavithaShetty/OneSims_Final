﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
    {
        [Serializable]
        public class VehicleHistoryData
        {

          public virtual decimal VehicleID
          {
            get;
            set;
          }
          public virtual decimal StoreID
         {
            get;
            set;
          }
        public virtual decimal InventoryId
        {
            get;
            set;
        }
        public virtual DateTime FromDate
          {
             get;
             set;
           }

           public virtual DateTime ToDate
          {
              get;
              set;
          }

           public virtual string Status
           {
               get;
               set;
           }

           public virtual string Dealership
           {
                get;
                set;
            }

           public virtual long Mileage
           {
                get;
                set;
            }
            public virtual string SoldAs
           {
                get;
                set;
            }
            public virtual decimal? SoldPrice
            {
                get;
                set;
            }
        }
    }

