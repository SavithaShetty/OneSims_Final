﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class CostInfoEdit
    {
        public virtual long VID { get; set; }
        public virtual short SID { get; set; }
        public virtual short IID { get; set; }
        public virtual string SalesPerson { get; set; }
        public virtual Nullable<short> SACRecommendation { get; set; }
        public virtual Nullable<short> SACStatus { get; set; }
        public virtual string StoreNote { get; set; }
        public virtual Nullable<decimal> SACRecomAppraisalValue { get; set; }
        public virtual Nullable<decimal> SACMatchTradePrice { get; set; }
        public virtual bool Step5Exist { get; set; }
        public virtual bool isSightUnseen { get; set; }
        public virtual short Curr_Status_Id { get; set; }
        public virtual short WizardPage { get; set; }

        public virtual bool SalesPersonAppraised { get; set; }
        public virtual bool AppraisalLabels { get; set; }
        public virtual Nullable<decimal> Variance { get; set; }
        public virtual bool Onchange { get; set; }
        public virtual short Vehicle_Src { get; set; }
        public virtual bool MarketValueLabel { get; set; }
        public virtual Nullable<decimal> MarketValue { get; set; }
        public AppraisalValueEntity appraisalValue { get; set; }
    }
}
