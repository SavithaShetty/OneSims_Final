﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class PriceReviewLogParam
    {
        #region Primitive Properties

        public virtual Nullable<short> RegionID
        {
            get;
            set;
        }

        public virtual string StatusList
        {
            get;
            set;
        }

        public virtual long StartRow
        {
            get;
            set;
        }

        public virtual long EndRow
        {
            get;
            set;
        }

        public virtual string SortByField
        {
            get;
            set;
        }

        public virtual string SortDirection
        {
            get;
            set;
        }

        public string VINOrStock
        {
            get;
            set;
        }

        public virtual int StoreLocationID { get; set; }

        public bool IsLease { get; set; }
        //AlternateSACLog
        public virtual string RegionName
        {
            get;
            set;
        }


        //DateRange filter
        public virtual DateTime? Fromdate
        {
            get;
            set;
        }

        public virtual DateTime? Todate
        {
            get;
            set;
        }

        public bool IsPurchase { get; set; }

        public virtual string AppraisalType
        {
            get;
            set;
        }
        #endregion
    }
}
