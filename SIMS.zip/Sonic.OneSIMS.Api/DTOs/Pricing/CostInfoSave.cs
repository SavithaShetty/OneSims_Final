﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class CostInfoSave
    {
      public virtual long vid { get; set; } 
      public virtual short sid { get; set; } 
      public virtual short iid { get; set; } 
      public virtual short cid { get; set; }
      public virtual string username { get; set; }
      public virtual string bumpusername { get; set; }
      public virtual decimal newappraisalvalue { get; set; }
      public virtual long appraisalid { get; set; }
      public virtual short reasoncode { get; set; }
      public virtual decimal purchasevalue { get; set; }

    }
}
