﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Pricing
{
    public class VDPCostInfoDetails
    {
        public virtual long VID { get; set; }
        public virtual short SID { get; set; }
        public virtual short IID { get; set; }
        public virtual string VIN { get; set; }
        public virtual string UVC { get; set; }
        public virtual Nullable<short> SACRecommendation { get; set; }
        public virtual Nullable<short> SACStatus { get; set; }

        public virtual string StoreNote { get; set; }

        public virtual Nullable<decimal> SACRecomAppraisalValue { get; set; }

        public virtual string DealershipNotes { get; set; }


        public virtual Nullable<decimal> SACMatchTradePrice { get; set; }

        public string SACMatchTradeStore { get; set; }

        public virtual string ModifiedBy { get; set; }

        public virtual Nullable<DateTime> ModifiedDate { get; set; }

        public virtual bool Step5Exist { get; set; }

        public virtual bool isSightUnseen { get; set; }
        public virtual short Curr_Status_Id { get; set; }

        public virtual short WizardPage { get; set; }

        public AppraisalValueEntity appraisalValue { get; set; }

    }

}
