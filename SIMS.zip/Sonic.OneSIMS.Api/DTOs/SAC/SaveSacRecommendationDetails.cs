﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sonic.OneSIMS.DomailModels.Common;
using Sonic.OneSIMS.DomailModels.Enums;
using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Enums;
namespace Sonic.OneSIMS.Api.DTOs.SAC
{
    public class SaveSacRecommendationDetails
    {
        public Int64 VID { get; set; }
        public int SID { get; set; }
        public int IID { get; set; }
        public int CID { get; set; }

        public Int64 SACID { get; set; }

        public int VehicleSource { get; set; }

        //public SACRecommendation? SACRecommendation { get; set; }

        public IDValues SACRecommendation { get; set; }

        public bool StopSale { get; set; }

        public IDValues InventorySegment { get; set; }

        public decimal? PushPrice { get; set; }

        public decimal? SuggestedPrice { get; set; }

        public decimal? RecommendationAppraisalPrice { get; set; }

        public decimal? RecommendationRetailPrice { get; set; }

        public string NoteForDealership { get; set; }

        public string NoteForSAC { get; set; }

        public int VehicleTradeToStore { get; set; }

        public Company VehicleTradeToCompany { get; set; }

        public decimal? TradePrice { get; set; }

        public bool TransportNeeded { get; set; }

        public bool PendingWholesale { get; set; }

        public decimal? EstimatedTransportationCost { get; set; }

        public string UserName { get; set; }

        public DateTime? LastModifiedTime { get; set; }
    }
}
