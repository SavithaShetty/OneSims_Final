﻿using Sonic.OneSIMS.DomailModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.SAC
{
    public class SACRequest
    {
        public VehicleIdentity VehicleIdentity { get; set; }
        public int SACID { get; set; }
    }
}
