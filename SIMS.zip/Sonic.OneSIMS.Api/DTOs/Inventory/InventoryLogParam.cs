﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Inventory
{
    public class InventoryLogParam
    {
        public short CID { get; set; }
        public short SID { get; set; }
        public string Status { get; set; }
        public Nullable<short> Age_Bucket_Id { get; set; }
        public string SortByField { get; set; }
        public string SortDirection { get; set; }
        public Nullable<bool> IncludeException { get; set; }
        public Nullable<bool> Recon { get; set; }
        public Nullable<bool> DataMissing { get; set; }
        public Nullable<bool> PhotosMissing { get; set; }
        public Nullable<bool> AdtextMissing { get; set; }
        public string AcquiredType { get; set; }
        public Nullable<bool> RetailPriceCheck { get; set; }
        public Nullable<bool> OpenDeals { get; set; }
        public Nullable<bool> BithdayList { get; set; }
        public Nullable<bool> UnitsNotOnline { get; set; }
        public string InventorylogParam { get; set; }
        public Nullable<bool> CPO { get; set; }
        public string Make { get; set; }
        public Nullable<bool> PendingWholesale { get; set; }
        public Nullable<bool> BVA { get; set; }
        public Nullable<bool> BodyShop { get; set; }
        public Nullable<bool> MarketReady { get; set; }

    }
}
