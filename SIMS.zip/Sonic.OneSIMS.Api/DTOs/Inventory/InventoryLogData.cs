﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;


namespace Sonic.OneSIMS.Api.DTOs.Inventory
{
    public class InventoryLogData
    {
            public string StockNumber
            {
                get;
                set;
            }
            public int Year
            {
                get;
                set;
            }
            public decimal? Invoice
            {
                get;
                set;
            }

            public decimal? Write_Down
            {
                get;
                set;
            }
            public string Make
            {
                get;
                set;
            }

            public string Model
            {
                get;
                set;
            }

            public string Series_Trim
            {
                get;
                set;
            }

            public string ExteriorColor
            {
                get;
                set;
            }

            public int Mileage
            {
                get;
                set;
            }

            public decimal? Wholesale_Average
            {
                get;
                set;
            }

            public string Status
            {
                get;
                set;
            }

            public decimal? GLBalance
            {
                get;
                set;
            }
            public decimal? FEGross
            {
                get;
                set;
            }
            public decimal? AcquiredValue
            {
                get;
                set;
            }
            public short CurrentAge
            {
                get;
                set;
            }
            public short GroupAge
            {
                get;
                set;
            }

            //public short ClickCount
            //{
            //    get;
            //    set;
            //}
            public int? ATClickCount
            {
                get;
                set;
            }
            public int? CarsClickCount
            {
                get;
                set;
            }
            public int? DDCClickCount
            {
                get;
                set;
            }

            public decimal? RetailPrice
            {
                get;
                set;
            }

            public int Photos
            {
                get;
                set;
            }
            public byte[] CarFax
            {
                get;
                set;
            }

            public Int64 VehicleID
            {
                get;
                set;
            }
            public Int16 StoreID
            {
                get;
                set;
            }

            public string Store_Name
            {
                get;
                set;
            }

            public Int16 InventoryID
            {
                get;
                set;
            }
            public short WizardPage
            {
                get;
                set;
            }

            public short CReportIconID
            {
                get;
                set;
            }
            public short AReportIconID
            {
                get;
                set;
            }

            public string CReportURL
            {
                get;
                set;
            }

            public string AReportURL
            {
                get;
                set;
            }
            public string Vin
            {
                get;
                set;
            }

            public decimal? MSRP
            {
                get;
                set;
            }
            public decimal? InvoicePrice
            {
                get;
                set;
            }
            public Boolean IsNew
            {
                get;
                set;
            }

            public string InteriorColor
            {
                get;
                set;
            }


            public decimal ReconAmount
            {
                get;
                set;
            }

            public short VehicleInMarket
            {
                get;
                set;
            }

            public int MarketPrice
            {
                get;
                set;
            }


            public DateTime? AcquiredDate
            {
                get;
                set;
            }


            public decimal PriceChanges
            {
                get;
                set;
            }
            public string CPO
            {
                get;
                set;
            }

            public bool SightUnseen
            {
                get;
                set;
            }

            public decimal? AppraisalValue
            {
                get;
                set;
            }

            public int PrintAppButton
            {
                get;
                set;
            }

            public string HasFactoryOptions { get; set; }

            public decimal? SuggestedPrice { get; set; }

            public string IsMissingData
            {
                get;
                set;
            }
            public short StatusID
            {
                get;
                set;
            }
            public short PriceStatusID
            {
                get;
                set;
            }
            public bool IsMarketReady
            {
                get;
                set;
            }
            public string EndingDoller
            {
                get;
                set;
            }
            public bool CAN_REQST_LOANER
            {
                get;
                set;
            }
            public string DifferenceImage
            {
                get;
                set;
            }

            public string ReconType
            {
                get;
                set;
            }

            public bool Is_Recon_Exists
            {
                get;
                set;
            }

            public bool IsPublished
            {
                get;
                set;
            }
            public bool IsPunched
            {
                get;
                set;
            }

            public string Punched { get; set; }

            public decimal? AmtPunched { get; set; }

            public string PunchedValue { get; set; }

            public Boolean? VehicleSrc
            {
                get;
                set;
            }

            public Boolean? IsKbbVehicle
            {
                get;
                set;
            }
            public Boolean? IsStep5Exists
            {
                get;
                set;
            }

            public int DaysInCurrentStatus
            {
                get;
                set;
            }
            public int DaysInTransit
            {
                get;
                set;
            }
            public int DaysInMarketReady
            {
                get;
                set;
            }
            public int DaysInRecon
            {
                get;
                set;
            }
            public int DaysOnLot
            {
                get;
                set;
            }
            public decimal? Discount
            {
                get;
                set;
            }
            public int AgeBucketID
            {
                get;
                set;
            }
            public string Demo_Assigned_To
            {
                get;
                set;
            }
            public Nullable<DateTime> Demo_Date
            {
                get;
                set;
            }
            public string Comments
            {
                get;
                set;
            }

            public bool Is_Certifiable
            { get; set; }

            public bool? Is_Certified
            { get; set; }

        }
    }

