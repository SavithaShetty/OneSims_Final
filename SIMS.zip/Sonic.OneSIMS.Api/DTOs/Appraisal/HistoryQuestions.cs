﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class HistoryQuestions
    {
        public string QuestionId { get; set; }
        public string QuestionType { get; set; }
        public string Description { get; set; }
        public string Answer { get; set; }        
    }
}
