﻿using Sonic.OneSIMS.Api.DTOs.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class VehicleFactoryOptions
    { 
        /// <summary>
        /// Contains VehicleId
        /// </summary>
        public long VID { get; set; }
        /// <summary>
        /// Contains InventoryID
        /// </summary>

        public short IID { get; set; }

        /// <summary>
        /// Contains StoreID
        /// </summary>

        public short SID { get; set; }

        public string UserName { get; set; }

        public List<GroupedFactoryOptionList> Options { get; set; }
        public string InServiceDate { get; set; }
    }
}
