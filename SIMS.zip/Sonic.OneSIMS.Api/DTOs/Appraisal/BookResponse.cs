﻿using Sonic.OneSIMS.Api.DTOs.Books.KBB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class BookResponse
    {
        public string Uvc { get; set; }
        public string ProviderId { get; set; }
        public string vin { get; set; }
        public uint year { get; set; }
        public bool newVehicle { get; set; }
        public uint BookValueProvider { get; set; }

        public decimal RegionalXClean { get; set; }
        public decimal RegionalAbove { get; set; }
        public decimal RegionalAverage { get; set; }
        public decimal RegionalBelow { get; set; }

        public decimal NationalXClean { get; set; }
        public decimal NationalAbove { get; set; }
        public decimal NationalAverage { get; set; }
        public decimal NationalBelow { get; set; }

        public decimal WholeSaleXClean { get; set; }
        public decimal WholeSaleAbove { get; set; }
        public decimal WholeSaleAverage { get; set; }
        public decimal WholeSaleBelow { get; set; }

        public decimal BaseTradeInXClean { get; set; }
        public decimal BaseTradeInAbove { get; set; }
        public decimal BaseTradeInAverage { get; set; }
        public decimal BaseTradeInBelow { get; set; }

        public decimal BaseRetailAbove { get; set; }
        //Added for Average Retail Prices-- By Sandeep on 09-MAR-2011
        //Begin
        public decimal BaseRetailAverage { get; set; }
        //End
        public decimal BaseLoanAbove { get; set; }
        //Added for wholesale values for BASE
        public decimal BaseWSaleXClean { get; set; }
        public decimal BaseWSaleAbove { get; set; }
        public decimal BaseWSaleAverage { get; set; }
        public decimal BaseWSaleBelow { get; set; }

        public decimal MileageTradeInXClean { get; set; }
        public decimal MileageTradeInAbove { get; set; }
        public decimal MileageTradeInAverage { get; set; }
        public decimal MileageTradeInBelow { get; set; }
        public decimal MileageRetailAbove { get; set; }
        public decimal MileageLoanAbove { get; set; }
        //Added for wholesale values for MILEAGE
        public decimal MileageWSaleXClean { get; set; }
        public decimal MileageWSaleAbove { get; set; }
        public decimal MileageWSaleAverage { get; set; }
        public decimal MileageWSaleBelow { get; set; }

        public decimal TotalTradeInXClean { get; set; }
        public decimal TotalTradeInAbove { get; set; }
        public decimal TotalTradeInAverage { get; set; }
        public decimal TotalTradeInBelow { get; set; }
        public decimal TotalLoanAbove { get; set; }
        public decimal TotalLoanAverage { get; set; }
        public decimal TotalLoanBelow { get; set; }

        public decimal OptionTotalTradeInAbove { get; set; }
        public decimal OptionTotalTradeInAverage { get; set; }
        public decimal OptionTotalTradeInBelow { get; set; }
        public decimal OptionTotalRetailAbove { get; set; }
        public decimal OptionTotalLoanAbove { get; set; }

        public decimal MSRP { get; set; }

        public int RegionalTotal { get; set; }
        public int NationalTotal { get; set; }

        public decimal TotalROPOCost { get; set; }

        public int AverageOdometer { get; set; }

        public int AverageGrade { get; set; }

        // MultiValues. May be infuture.
        public List<ProviderValues> make { get; set; }
        public List<ProviderValues> model { get; set; }
        public List<ProviderValues> bodyStyle { get; set; }
        public List<ProviderValues> trim { get; set; }
        public List<ProviderValues> Transmission { get; set; }
        public List<ProviderValues> Engine { get; set; }
        public List<ProviderValues> DriveTrain { get; set; }
        public List<OptionValues> Options { get; set; }
        public List<DVCPOValues> DVCPO { get; set; }
        public List<DVCROValues> DVCRO { get; set; }

        public string RequestXML { get; set; }
        public string FinalConfiguration { get; set; }
    }

    /// <summary>
    /// For multiple data which consist of IDs and Values.
    /// </summary>
    [Serializable]
    public class ProviderValues
    {
        public string ID { get; set; }
        public string Value { get; set; }
        public bool Selected { get; set; }

    }

    [Serializable]
    public class DVCPOValues
    {
        public string PONumber { get; set; }
        public string PODescr { get; set; }
        public string POStatus { get; set; }
        public decimal POCost { get; set; }
        public decimal POItemCost { get; set; }
        public string PODealerShipID { get; set; }
        public DateTime PODateClosed { get; set; }

    }

    [Serializable]
    public class DVCROValues
    { 
        public string RONumber { get; set; }
        public string RODescr { get; set; }
        public string ROStatus { get; set; }
        public decimal ROCost { get; set; }
        public decimal ROItemCost { get; set; }
        public string RODealerShipID { get; set; }
        public DateTime RODateClosed { get; set; }
    }
}
