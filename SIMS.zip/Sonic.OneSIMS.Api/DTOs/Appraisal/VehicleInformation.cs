﻿using Sonic.OneSIMS.DomainModels.Common;
using Sonic.OneSIMS.DomainModels.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class VehicleInfoReadDto
    {
        /// <summary>
        /// Vin for the vehicle
        /// </summary>
        public string VIN { get; set; }

        /// <summary>
        /// List of years
        /// </summary>
        public List<IDValues> Years { get; set; }

        /// <summary>
        /// make details of vehicle
        /// </summary>
        public List<IDValues> Make { get; set; }

        /// <summary>
        /// Engine 
        /// </summary>
        public List<IDValues> Engine { get; set; }

        /// <summary>
        /// Model Details of vehicle
        /// </summary>
        public List<IDValues> Model { get; set; }

        /// <summary>
        ///Body Style Details of vehicle
        /// </summary>
        public List<IDValues> BodyStyle { get; set; }

        /// <summary>
        /// Series Details of vehicle
        /// </summary>
        public List<IDValues> Series { get; set; }

        /// <summary>
        /// Transmission Details of vehicle
        /// </summary>
        public List<IDValues> Transmission { get; set; }

        /// <summary>
        /// DriveTrain Details of vehicle
        /// </summary>
        public List<IDValues> DriveTrain { get; set; }
        /// <summary>
        /// Exterior color Details of vehicle
        /// </summary>
        public List<IDValues> ExteriorColor { get; set; }

        /// <summary>
        /// Interior color Details of vehicle
        /// </summary>
        public List<IDValues> InteriorColor { get; set; }

        /// <summary>
        /// Interior type Details of vehicle
        /// </summary>
        public List<IDValues> InteriorType { get; set; }

        /// <summary>
        ///Fuel Details of vehicle
        /// </summary>
        public List<IDValues> Fuel { get; set; }

        /// <summary>
        ///  Details of vehicle type
        /// </summary>
        public List<IDValues> VehicleType { get; set; }
        /// <summary>
        ///  Details of vehicle type
        /// </summary>
        public List<IDValues> OdometerOptions { get; set; }
         /// <summary>
        /// sight Unseen of Vehicle
        /// </summary>
        public bool? SightUnseen { get; set; }

        /// <summary>
        /// sight Unseen of Vehicle
        /// </summary>
        public long Mileage { get; set; }

        /// <summary>
        ///  Kisok Req
        /// </summary>
        public bool? iSKioskReq { get; set; }

        /// <summary>
        /// Sales Person created Vehicle
        /// </summary>
        public bool? isSalesPerson { get; set; }

        /// <summary>
        /// Lane ID
        /// </summary>
        public int? LaneId { get; set; }

        /// <summary>
        /// Source of Vehicle
        /// </summary>
        public VehicleSource vehicleSource { get; set; }

        public bool IsDecodeSuccess { get; set; }

        /// <summary>
        /// Bank price for lease appraisal
        /// </summary>
        public decimal? BankPrice { get; set; }

        /// <summary>
        ///  Acquisition Type for Inventory Add 
        /// </summary>
        public List<IDValues> AcquisitionType { get; set; }

    }


      
}
