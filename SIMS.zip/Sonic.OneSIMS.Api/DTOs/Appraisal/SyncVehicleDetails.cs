﻿using Sonic.OneSIMS.DomainModels.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class SyncVehicleDetails
    {
        public Int64 VID { get; set; }
        public Int32 SID { get; set; }
        public Int16 IID { get; set; }
        public Int16 CID { get; set; }
        public CCASyncIdentifier sectionIdentifier { get; set; }
        public string username { get; set; }
    }
}
