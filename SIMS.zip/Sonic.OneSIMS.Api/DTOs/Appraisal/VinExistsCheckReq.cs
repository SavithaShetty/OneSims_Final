﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class VinExistsCheckReq
    {
        public string VIN { get; set; }
        public int VehicleSource { get; set; }
        public int StoreID { get; set; }
        public int CompanyID { get; set; }
    }
}
