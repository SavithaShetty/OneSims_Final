﻿using Sonic.OneSIMS.DomainModels.Common;

namespace Sonic.OneSIMS.Api.DTOs
{
    public class BookRequest
    {
        public string dealerId { get; set; }
        public string regionId { get; set; } 
        public ValuationData valuationData { get; set; }
    }
   // [Serializable]
    //public class ValuationData
    //{
    //    public ValuationData()
    //    {
    //        this.Year = new DomainModels.Common.IDValues();
    //        this.Make = new DomainModels.Common.IDValues();
    //        this.Model = new DomainModels.Common.IDValues();
    //        this.Engine = new DomainModels.Common.IDValues();
    //        this.BodyStyle = new DomainModels.Common.IDValues();
    //        this.Series = new DomainModels.Common.IDValues();
    //        this.DriveTrain = new DomainModels.Common.IDValues();
    //        this.Transmission = new DomainModels.Common.IDValues();
    //        this.Options = new List<DomainModels.Common.OptionValue>();
    //        this.SavedDBOptions = new List<DomainModels.Common.OptionValue>();
    //    }
    //    public string Vin { get; set; }
    //    public string Uvc { get; set; }
    //    public decimal Mileage { get; set; }
    //    public DomainModels.Common.IDValues Year { get; set; }
    //    public DomainModels.Common.IDValues Make { get; set; }
    //    public DomainModels.Common.IDValues Engine { get; set; }
    //    public DomainModels.Common.IDValues Model { get; set; }
    //    public DomainModels.Common.IDValues BodyStyle { get; set; }
    //    public DomainModels.Common.IDValues Series { get; set; }
    //    public DomainModels.Common.IDValues Transmission { get; set; }
    //    public DomainModels.Common.IDValues DriveTrain { get; set; }
    //    public List<DomainModels.Common.OptionValue> Options { get; set; }
    //    public string RequestXML { get; set; }
    //    public List<DomainModels.Common.OptionValue> SavedDBOptions { get; set; }
    //}
}
