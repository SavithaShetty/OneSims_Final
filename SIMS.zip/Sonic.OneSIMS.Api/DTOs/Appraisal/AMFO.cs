﻿using Sonic.OneSIMS.Api.DTOs.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class AMFO
    {
        public VehicleIdentity VehicleIdentity { get; set; }
        public List<AfterMarketQuestions> AfterMarketQuestions { get; set; }
        public string UserName { get; set; }
    }
}
