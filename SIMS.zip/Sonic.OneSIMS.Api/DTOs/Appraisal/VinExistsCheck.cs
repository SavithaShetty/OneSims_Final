﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class VinExistsCheck
    {
        public string VIN { get; set; }
        public int CompanyID { get; set; }
        public int SourceStoreId { get; set; }
        public int DecodeSource { get; set; }
        public string VehicleInStatus { get; set; }
        public int VehicleID { get; set; }
        public int InvtrID { get; set; }
    }
}
