﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class UpdateVehicleStatusReq
    {
        public Int64 VID { get; set; }
        public Int32 SID { get; set; }
        public int IID { get; set; }
        public int CID { get; set; }
        public string username { get; set; }
    }
}
