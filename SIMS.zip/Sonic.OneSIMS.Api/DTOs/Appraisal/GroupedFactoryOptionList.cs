﻿using Sonic.OneSIMS.Api.DTOs.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class GroupedFactoryOptionList
    {
        public string Header { get; set; }

        public List<FactoryOptions> factoryOptions { get; set; }
    }
}
