﻿using Sonic.OneSIMS.DomainModels.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Appraisal
{
    public class BasicAppraisalInfoCreateDto
    {
        public string VIN { get; set; }
        public string CustomerFirstName { get; set; }
        public string CustomerLastName { get; set; }
        public VehicleSource VehicleSrc { get; set; }
        public Boolean IsSalesPerson { get; set; }                
        public int StoreID { get; set; }        
        public int? LaneID { get; set; }
        public Boolean? KioskReq { get; set; }
        public DateTime? ServiceAppraisalDate { get; set; }
        public string? username { get; set; }
        public bool IsDecodeSuccess { get; set; }
    }

    
}
