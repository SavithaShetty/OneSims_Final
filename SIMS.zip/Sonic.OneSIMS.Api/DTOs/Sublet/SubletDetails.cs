﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Sublet
{
    public class SubletDetails
    {
        public Int64? Sublet_ID { get; set; }
        public string Sublet_Name { get; set; }
        public Int16 Store_ID { get; set; }
        public string Store_Name { get; set; }
        public string Street_1 { get; set; }
        public string Street_2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Zipcode { get; set; }
        public string Phone_Number { get; set; }
        public string Sublet_Address { get; set; }
        public string Sublet_Email { get; set; }
        public string Transportation_Email { get; set; }
        public bool Is_Act { get; set; }
        public List<Sublets> Sublets { get; set; }

    }
    public class States
    {
        public byte StateID { get; set; }
        public string State { get; set; }
    }
}
