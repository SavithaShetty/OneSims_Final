﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Sublet
{
    public class SubletLog
    {
        public string VIN { get; set; }
        public Int16 Year { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Series_Trim { get; set; }
        public string Location { get; set; }
        public string SubletName { get; set; }
        public Int16 StatusID { get; set; }
        public string Status { get; set; }
        public string Image { get; set; }
        public Int64 VehicleID { get; set; }
        public Int16 StoreID { get; set; }
        public Int16 InvtrID { get; set; }
        public Int16 LocationID { get; set; }
        public Int16 SubletID { get; set; }
        public string StockNo { get; set; }
        public bool IsCustomersVehicle { get; set; }
        public Int16 SourceStoreID { get; set; }
        public Int16 DestinationId { get; set; }
        public int MovementType { get; set; }
        public string SpecialInstructions { get; set; }
        public string ExtColor { get; set; }
        public string IntColor { get; set; }
    }
}
