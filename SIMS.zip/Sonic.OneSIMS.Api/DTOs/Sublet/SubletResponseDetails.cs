﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Sublet
{
    public class SubletResponseDetailsByVIN
    {
        public string VIN { get; set; }
        public Int16 Year { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Series { get; set; }
        public string Extcolor { get; set; }
        public string Intcolor { get; set; }
        public string status { get; set; }
        public Int64 VehicleID { get; set; }
        public Int16 VIN_StoreID { get; set; }
        public Int16 Invtr_ID { get; set; }
        public string Stock_No { get; set; }
        public Int16 Curr_Store_ID { get; set; }
        public string Location { get; set; }
        public List<SubletDetailsByVIN> Sublets { get; set; }
        public List<States> States { get; set; }
        public bool IsCustomersVehicle { get; set; }
        public bool IsVehicleExistInSublet { get; set; }
    }

    public class SubletDetailsByVIN
    {
        public Int64 Sublet_ID { get; set; }
        public Int16 Store_ID { get; set; }
        public string Sublet_Name { get; set; }
        public string Street_1 { get; set; }
        public string Street_2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Zipcode { get; set; }
        public string Phone_Number { get; set; }
    }
}
