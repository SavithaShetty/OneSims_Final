﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class NewRegionDetails
    {

        public  string RegionName
        {
            get;
            set;
        }

        public  short CID
        {
            get;
            set;
        }


        public  string Type
        {
            get;
            set;
        }
        public  string UserName
        {
            get;
            set;
        }
        public  Nullable<short> RegionID
        {
            get;
            set;
        }
        public bool IsEnableSAC
        {
            get;
            set;
        }
        public short StoreID
        {
            get;
            set;
        }


    }
}
