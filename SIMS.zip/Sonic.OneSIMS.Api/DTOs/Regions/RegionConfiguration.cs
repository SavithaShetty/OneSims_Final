﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class RegionConfiguration
    {
        public Region Region { get; set; }

        public List<Pod> PodsInRegion { get; set; }
        public List<Pod> AllPods { get; set; }

        public bool IsRegionActive
        {
            get;
            set;
        }
        public bool IsEnableSAC
        {
            get;
            set;
        }
        public string UserName
        {
            get;
            set;
        }
        public short CID
        {
            get;
            set;
        }

    }
}
