﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class RegionNames
    {
        #region Primitive Properties

        public  string RegionName
        {
            get;
            set;
        }

        public  short RegionID
        {
            get;
            set;
        }


        #endregion
    }
}
