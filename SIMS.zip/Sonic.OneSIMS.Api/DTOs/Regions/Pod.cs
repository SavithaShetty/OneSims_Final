﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
   [Serializable]
    public class Pod
    {
        #region Primitive Properties

        public Int64 Pod_ID { get; set; }

        public string Pod_Name { get; set; }

        public string Rolename { get; set; }

        public System.Guid RoleId { get; set; }

        public string Hub_Class { get; set; }

        #endregion
    }
}
