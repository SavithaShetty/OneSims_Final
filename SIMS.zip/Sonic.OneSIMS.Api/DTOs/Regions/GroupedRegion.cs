﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class GroupedRegion
    {
        #region Primitive Properties

        public virtual string RegionName
        {
            get;
            set;
        }

        public virtual byte RegionClassification
        {
            get;
            set;
        }

        public virtual short RegionID
        {
            get;
            set;
        }

        public virtual string GroupedRegionName
        {
            get;
            set;
        }

        #endregion
    }
}
