﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sonic.OneSIMS.Api.DTOs.Store;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class RegionDealership
    {
        #region Primitive Properties

        public virtual List<GroupedRegion> Regions
        {
            get;
            set;
        }

        public virtual List<Store.Store> Stores
        {
            get;
            set;
        }

        public List<Pod> Pods { get; set; }


        #endregion

        public List<MakeConfiguration> Brands { get; set; }

        public string UserRole { get; set; }

    }
}

