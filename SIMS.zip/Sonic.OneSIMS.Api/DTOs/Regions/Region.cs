﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class Region
    {
        #region Primitive Properties

        public string RegionName
        {
            get;
            set;
        }

        public int RegionId
        {
            get;
            set;
        }

        public string Visible
        {
            get;
            set;
        }

        #endregion
    }
}
