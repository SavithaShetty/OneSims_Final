﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class MakeConfiguration
    {
        public class MakeConfuguration
        {
            public long MakeID { get; set; }

            public string MakeName { get; set; }

            public bool IsActive { get; set; }

            public short StatusId { get; set; }

            public string StatusName { get; set; }
        }
    }
}
