﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Regions
{
    public class RegionStore
    {
        public string RegionStoreName { get; set; }
        public short RegionStoreID { get; set; }
    }
}
