﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    public class StyleRequest
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// Provide Id of Model Ex:46 
        /// </summary>
        public string ModelId { get; set; }

    }

   
}
