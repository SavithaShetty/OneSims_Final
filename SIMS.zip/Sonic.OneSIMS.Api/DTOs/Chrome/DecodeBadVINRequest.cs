﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    public class DecodeBadVINRequest 
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: OneSIMS Portal, Service, Mobile, OnlineWidget, CDK etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// VIN to be decoded
        /// </summary>
        public string VIN { get; set; } 

        public string TrimName { get; set; }
    }

    
}
