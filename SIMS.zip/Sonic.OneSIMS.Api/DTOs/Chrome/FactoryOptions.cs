﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    [Serializable]
    public class FactoryOptions
    {
        public string Description { get; set; }

        public string OptionKindId { get; set; }

        public decimal? Price { get; set; }

        public int[] StyleId { get; set; }

        public string OemCode { get; set; }
        public bool isSelected { get; set; }
        public string optionid { get; set; }
        public decimal? MSRP { get; set; }
    }
}
