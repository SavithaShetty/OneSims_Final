﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    public class TrimRequest
    {
        /// <summary>
        /// Year 
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Make 
        /// </summary>
        public string Make { get; set; }

        /// <summary>
        /// Model
        /// </summary>
        public string Model { get; set; }
    }
}
