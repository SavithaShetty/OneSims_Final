﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    /// <summary>
    ///  Trim
    /// </summary>
    public class Trim
    {
        /// <summary>
        /// ID 
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// Value
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        ///Selected or not
        /// </summary>
        public bool Selected { get; set; }
        /// <summary>
        /// Code
        /// </summary>
        public string Code { get; set; }
    }
}
