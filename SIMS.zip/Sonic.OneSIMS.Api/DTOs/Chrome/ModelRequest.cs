﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    public class ModelRequest
    {
        /// <summary>
        /// Source of the request, where it is getting called from. Ex: SIMS, OnlineWidget, CDK, Mobile etc..
        /// </summary>
        public string RequestSource { get; set; }
        /// <summary>
        /// Provide a Year to retrieve list of Makes. Ex: 2020 or 2021
        /// </summary>
        public int YearId { get; set; }

        /// <summary>
        /// MakeId for the selected YearId
        /// </summary>
        public string MakeId { get; set; }
    }

   
}
