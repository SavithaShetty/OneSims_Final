﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Chrome
{
    [Serializable]
    public class ColorOptions
    {

        public GenericColors[] genericColorField { get; set; }

        public int[] styleIdField { get; set; }

        public InstallationCause installationCause{ get; set; }

        public string colorCodeField { get; set; }

        public string colorNameField { get; set; }

        public string rgbValueField { get; set; }


    }

    public class GenericColors
    {
        //private InstallationCause installedField{get;set;}

        public string nameField{get;set;}

        public bool primaryField{get;set;}

        public bool primaryFieldSpecified{get;set;}
    }

    public class InstallationCause
{
      //  private InstallationCauseCause causeField;

        public string detailField { get; set; }

    }
}
