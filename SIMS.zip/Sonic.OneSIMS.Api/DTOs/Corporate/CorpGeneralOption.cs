﻿using Sonic.OneSIMS.Api.DTOs.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Corporate
{
    public class CorpGeneralOption
    {

        public short Corp_ID
        {
            get;
            set;
        }
        public string STCPhone
        {
            get;
            set;
        }
        public int SAC_Mileage_Limit_for_Rec_Match
        {
            get;
            set;
        }

        public int SAC_Green_to_Yellow_time_frame
        {
            get;
            set;
        }

        public int SAC_Yellow_to_Red_time_frame
        {
            get;
            set;
        }
        public decimal? TradePrice
        {
            get;
            set;
        }
        public bool SAC_Disable_Rvw_Comp_Recom
        {
            get;
            set;
        }

        public bool IsFactoryOptionsRequired
        {
            get;
            set;
        }
        public int Apprsl_Green_to_Yellow_time_frame
        {
            get;
            set;
        }

        public int Apprsl_Yellow_to_Red_time_frame
        {
            get;
            set;
        }
        public short Dashboard_Exp_Time
        {
            get;
            set;
        }
        public short Target_Apprsl_Close_Percentage
        {
            get;
            set;
        }

        public short Expire_Trial_List_Vehicles
        {
            get;
            set;
        }

        public int Store_Frcst_Deviation_Max
        {
            get;
            set;
        }

        public short Pend_to_Pri_Apprsl_time
        {
            get;
            set;
        }

        public short Old_Rec_in_Pend_Apprsl
        {
            get;
            set;
        }

        public short Old_Rec_in_Pend_Aquisition
        {
            get;
            set;
        }
        public short eLeads_Comp_Apprsl_Date_Limiter
        {
            get;
            set;
        }
        public short Print_Apprsl_Exp_Days
        {
            get;
            set;
        }
        public short Print_Apprsl_Exp_Mileage
        {
            get;
            set;
        }
        public short Print_Apprsl_Exp_Days_osoe
        {
            get;
            set;
        }


        public short Print_Apprsl_Exp_Mileage_osoe
        {
            get;
            set;
        }

        public short Pri_Apprsl_Date_Limiter
        {
            get;
            set;
        }
        public short Old_SAC_Rec_in_Incoming_status
        {
            get;
            set;
        }
        public short Target_Acceptance
        {
            get;
            set;
        }

        public short Price_Performance_Target
        {
            get;
            set;
        }

        public decimal Price_To_Sale_Gap_Target
        {
            get;
            set;
        }
        public short Price_Recom_Tlrnc_Prcnt_Variance
        {
            get;
            set;
        }

        public decimal Price_Recom_Tlrnc_Max_Variance
        {
            get;
            set;
        }

        public short Recom_Flag_Decay
        {
            get;
            set;
        }
        public short Trade_Walk_Decay
        {
            get;
            set;
        }

        public short Buy_List_Priority_Thrs
        {
            get;
            set;
        }
        public Int16 PendingServiceAppraisalTime
        {
            get;
            set;
        }

        public Int16 ServiceAppraisalSalesHistory
        {
            get;
            set;
        }

        public Int16 PriorAppraisalToRemoved
        {
            get;
            set;
        }
        public string userName
        {
            get;
            set;
        }
        public Int16 cid
        {
            get;
            set;
        }
    }
}
