﻿using Sonic.OneSIMS.Api.DTOs.Books.KBB;
using Sonic.OneSIMS.Infrastructure.Cdk.Entities;
using Sonic.OneSIMS.Infrastructure.Manheim.Entities.DecodeVin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books
{
    public partial class VinVehicleDetailBooks
    {
        public DecodeVinResponse BlackBook { get; set; }
        public DecodeVinResponse NADA { get; set; }
        public KBBBookValuation KBB { get; set; }
        public VinVehicleDetail Mainhaim { get; set; }
        public string dealerId { get; set; }
        public string regionId { get; set; }
        public string blackBookRegionId { get; set; }
        public string nadaRegionId { get; set; }
        public string kbbRegionId { get; set; }
        public string MainhaimdRegionId { get; set; }

    }
}
