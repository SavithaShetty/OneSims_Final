﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books
{
    public class ManagerNotes
    {
        public int VID { get; set; }
        public int SID { get; set; }
        public int IID { get; set; }
        public int CID { get; set; }
        public int Aditionalamount { get; set; }
        public string Comments { get; set; }
    }
}
