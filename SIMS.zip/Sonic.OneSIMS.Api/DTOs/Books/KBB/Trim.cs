﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class Trim
    {
        public int vehicleId { get; set; }
        public string vehicleClass { get; set; }
        public string vehicleName { get; set; }
        public int yearId { get; set; }
        public int makeId { get; set; }
        public string makeName { get; set; }
        public int modelId { get; set; }
        public string modelName { get; set; }
        public int modelYearId { get; set; }
        public int trimId { get; set; }
        public string trimName { get; set; }
        public string modelPlusTrimName { get; set; }
        public int doors { get; set; }
        public string bodyStyle { get; set; }
        public string genericBodyStyle { get; set; }
        public string oemBodyStyle { get; set; }
        public int sortOrder { get; set; }
        public string standardEngine { get; set; }
        public string standardDrivetrain { get; set; }
        public string standardTransmission { get; set; }
        public bool isConsumer { get; set; }
        public List<int> relatedVehicleIds { get; set; }
        public double originalMSRP { get; set; }
        public int generationId { get; set; }
        public int generationInstanceId { get; set; }
        public int generationSequence { get; set; }
        public string generationName { get; set; }
        public string generationStartYear { get; set; }
        public string generationEndYear { get; set; }
        public string size { get; set; }
        public string luxuryType { get; set; }
        public string sportType { get; set; }
        public List<string> marketingCategories { get; set; }
        public List<string> kbbCategories { get; set; }
    }
}
