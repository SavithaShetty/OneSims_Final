﻿using System;
using System.Collections.Generic;
using Sonic.OneSIMS.Infrastructure.KBB.Entities;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class KBBBookValuation
    {
        public string vin { get; set; }

        public bool IsDecodeSuccess { get; set; }
        public List<IDValues> years { get; set; }
        public List<IDValues> make { get; set; }
        public List<IDValues> Engine { get; set; }
        public List<IDValues> model { get; set; }
        public List<IDValues> bodyStyle { get; set; }
        public List<IDValues> series { get; set; }
        public List<IDValues> Transmission { get; set; }
        public List<IDValues> DriveTrain { get; set; }
        public List<OptionValues> Options { get; set; }
        public uint year { get; set; }
        public int vehicleId { get; set; }
        public string Uvc { get; set; }
        public DTOs.Appraisal.BookResponse BookValue { get; set; }
    }



    /// <summary>
    /// Holds the Optional details
    /// </summary>
    [Serializable]
    public class OptionValues : IDValues
    {
        public decimal Cost { get; set; }
        public decimal TradeInCost { get; set; }
        public decimal RetailCost { get; set; }
        public string Oa { get; set; }
    }

}
