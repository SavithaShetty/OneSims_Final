﻿using System.Collections.Generic;
using Sonic.OneSIMS.Infrastructure.KBB.Entities;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class Options
    {
        public int VehicleOptionId { get; set; }

        public int vehicleId { get; set; }

        public string optionType { get; set; }

        public string optionName { get; set; }

        public string categoryName { get; set; }

        public string categoryGroup { get; set; }

        public int sortOrder { get; set; }

        public bool isConsumer { get; set; }

        public bool isTypical { get; set; }

        public bool isConfigurable { get; set; }

        public bool hasRelationships { get; set; }
    }

    public class TrimOptionValues
    {
        public TrimOptionValues()
        {
            this.Engine = new List<IDValues>();
            this.Transmission = new List<IDValues>();
            this.DriveTrain = new List<IDValues>();
        }
        public List<IDValues> Engine { get; set; }
        public List<IDValues> Transmission { get; set; }
        public List<IDValues> DriveTrain { get; set; }
    }
}
