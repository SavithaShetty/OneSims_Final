﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class VINDecode
    {
        public List<VinResult> vinResults { get; set; }
    }
    public class VinResult
    {
        public int vehicleId { get; set; } 
        public int yearId { get; set; }
        public int makeId { get; set; }
        public string makeName { get; set; }
        public int modelId { get; set; }
        public string modelName { get; set; }
        public int modelYearId { get; set; }
        public int trimId { get; set; }
        public string trimName { get; set; }
        public List<Options> vehicleOptions { get; set; }
    }
    public class VehicleOption
    {
        public bool isVinDecoded { get; set; }
        public int vehicleOptionId { get; set; }
        public int vehicleId { get; set; }
        public string optionType { get; set; }
        public string optionName { get; set; }
        public string categoryName { get; set; }
        public string categoryGroup { get; set; }
        public bool isTypical { get; set; }
        public bool isConfigurable { get; set; }
    }
}
