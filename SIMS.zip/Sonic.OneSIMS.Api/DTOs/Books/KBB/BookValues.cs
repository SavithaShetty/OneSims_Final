﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class BookValues
    {
        public string Uvc { get; set; }
        public decimal TotalTradeInXClean { get; set; }
        public decimal TotalTradeInAbove { get; set; }
        public decimal TotalTradeInAverage { get; set; }
        public decimal TotalTradeInBelow { get; set; }
        public decimal TotalLoanAbove { get; set; }
        public decimal TotalLoanAverage { get; set; }
        public decimal TotalLoanBelow { get; set; }

        public decimal BaseTradeInXClean { get; set; }
        public decimal BaseTradeInAbove { get; set; }
        public decimal BaseTradeInAverage { get; set; }
        public decimal BaseTradeInBelow { get; set; }

        public decimal BaseRetailAbove { get; set; }
        //Added for Average Retail Prices-- By Sandeep on 09-MAR-2011
        //Begin
        public decimal BaseRetailAverage { get; set; }
        //End
        public decimal BaseLoanAbove { get; set; }
        //Added for wholesale values for BASE
        public decimal BaseWSaleXClean { get; set; }
        public decimal BaseWSaleAbove { get; set; }
        public decimal BaseWSaleAverage { get; set; }
        public decimal BaseWSaleBelow { get; set; }

        public decimal OptionTotalTradeInAbove { get; set; }
        public decimal OptionTotalTradeInAverage { get; set; }
        public decimal OptionTotalTradeInBelow { get; set; }
        public decimal OptionTotalRetailAbove { get; set; }
        public decimal OptionTotalLoanAbove { get; set; }

        public decimal MileageTradeInXClean { get; set; }
        public decimal MileageTradeInAbove { get; set; }
        public decimal MileageTradeInAverage { get; set; }
        public decimal MileageTradeInBelow { get; set; }
        public decimal MileageRetailAbove { get; set; }
        public decimal MileageLoanAbove { get; set; }
        //Added for wholesale values for MILEAGE
        public decimal MileageWSaleXClean { get; set; }
        public decimal MileageWSaleAbove { get; set; }
        public decimal MileageWSaleAverage { get; set; }
        public decimal MileageWSaleBelow { get; set; }
    }
}
