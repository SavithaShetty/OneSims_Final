﻿using Sonic.OneSIMS.Api.DTOs.Appraisal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Sonic.OneSIMS.Infrastructure.KBB.Entities;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class BookValueSaveParams
    {
        [DataMember]
        public BookValue BookValues
        {
            get;
            set;
        }
        [DataMember]
        public long VehicleId
        {
            get;
            set;
        }
        [DataMember]
        public short StoreId
        {
            get;
            set;
        }
        [DataMember]
        public short InvtryId
        {
            get;
            set;
        }
        [DataMember]
        public bool UpdateResponseTableOnly
        {
            get;
            set;
        }
        [DataMember]
        public short LaneId
        {
            get;
            set;
        }
        [DataMember]
        public string UserName
        {
            get;
            set;
        }
    }
    public class BookValue
    {
        [DataMember]
        public ValuationData ValuationData { get; set; }
        [DataMember]
        public string ProviderId { get; set; }
        [DataMember]
        public uint BookValueProvider { get; set; }

        [DataMember]
        public decimal RegionalXClean { get; set; }
        [DataMember]
        public decimal RegionalAbove { get; set; }
        [DataMember]
        public decimal RegionalAverage { get; set; }
        [DataMember]
        public decimal RegionalBelow { get; set; }

        [DataMember]
        public decimal NationalXClean { get; set; }
        [DataMember]
        public decimal NationalAbove { get; set; }
        [DataMember]
        public decimal NationalAverage { get; set; }
        [DataMember]
        public decimal NationalBelow { get; set; }

        [DataMember]
        public decimal WholeSaleXClean { get; set; }
        [DataMember]
        public decimal WholeSaleAbove { get; set; }
        [DataMember]
        public decimal WholeSaleAverage { get; set; }
        [DataMember]
        public decimal WholeSaleBelow { get; set; }

        [DataMember]
        public decimal BaseTradeInXClean { get; set; }
        [DataMember]
        public decimal BaseTradeInAbove { get; set; }
        [DataMember]
        public decimal BaseTradeInAverage { get; set; }
        [DataMember]
        public decimal BaseTradeInBelow { get; set; }
        [DataMember]
        public decimal BaseRetailAbove { get; set; }
        [DataMember]
        public decimal BaseRetailAverage { get; set; }
        [DataMember]
        public decimal BaseLoanAbove { get; set; }

        //Added for wholesale values for BASE
        [DataMember]
        public decimal BaseWSaleXClean { get; set; }
        [DataMember]
        public decimal BaseWSaleAbove { get; set; }
        [DataMember]
        public decimal BaseWSaleAverage { get; set; }
        [DataMember]
        public decimal BaseWSaleBelow { get; set; }

        [DataMember]
        public decimal MileageTradeInXClean { get; set; }
        [DataMember]
        public decimal MileageTradeInAbove { get; set; }
        [DataMember]
        public decimal MileageTradeInAverage { get; set; }
        [DataMember]
        public decimal MileageTradeInBelow { get; set; }
        [DataMember]
        public decimal MileageRetailAbove { get; set; }
        [DataMember]
        public decimal MileageLoanAbove { get; set; }

        //Added for wholesale values for MILEAGE
        [DataMember]
        public decimal MileageWSaleXClean { get; set; }
        [DataMember]
        public decimal MileageWSaleAbove { get; set; }
        [DataMember]
        public decimal MileageWSaleAverage { get; set; }
        [DataMember]
        public decimal MileageWSaleBelow { get; set; }

        [DataMember]
        public decimal TotalTradeInXClean { get; set; }
        [DataMember]
        public decimal TotalTradeInAbove { get; set; }
        [DataMember]
        public decimal TotalTradeInAverage { get; set; }
        [DataMember]
        public decimal TotalTradeInBelow { get; set; }

        [DataMember]
        public decimal TotalLoanAbove { get; set; }
        [DataMember]
        public decimal TotalLoanAverage { get; set; }
        [DataMember]
        public decimal TotalLoanBelow { get; set; }

        [DataMember]
        public decimal OptionTotalTradeInAbove { get; set; }
        [DataMember]
        public decimal OptionTotalTradeInAverage { get; set; }
        [DataMember]
        public decimal OptionTotalTradeInBelow { get; set; }
        [DataMember]
        public decimal OptionTotalRetailAbove { get; set; }
        [DataMember]
        public decimal OptionTotalLoanAbove { get; set; }

        [DataMember]
        public decimal MSRP { get; set; }

        [DataMember]
        public int RegionalTotal { get; set; }
        [DataMember]
        public int NationalTotal { get; set; }

        [DataMember]
        public decimal TotalROPOCost { get; set; }

        [DataMember]
        public string RequestXML { get; set; }
    }
}
