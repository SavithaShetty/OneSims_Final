﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class ModelYear
    {
        public int modelYearId { get; set; }
        public int yearId { get; set; }
        public int makeId { get; set; }
        public string makeName { get; set; }
        public int modelId { get; set; }
        public string modelName { get; set; }
    }
}
