﻿namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class Year
    {
        public int yearId { get; set; }
    }
}
