﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class Model
    {
        public int modelId { get; set; }
        public string modelName { get; set; }
    }
}
