﻿using System;
using System.Collections.Generic;
using Sonic.OneSIMS.Infrastructure.KBB.Entities;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class BookDetails
    {
        public BookDetails()
        {
            this.valuationData = new ValuationData();
            this.bookValue = new BookValues();
        }
        public ValuationData valuationData { get; set; }

        public BookValues bookValue { get; set; }

        public short WizardPage { get; set; }
        public string ExtColor { get; set; }

        public int BookEndPoint { get; set; }
    }
    //public class ValuationData
    //{
    //    public string Vin { get; set; }
    //    public string Uvc { get; set; }
    //    public decimal Mileage { get; set; }
    //    public DomainModels.Common.IDValues Year { get; set; }
    //    public DomainModels.Common.IDValues Make { get; set; }
    //    public DomainModels.Common.IDValues Engine { get; set; }
    //    public DomainModels.Common.IDValues Model { get; set; }
    //    public DomainModels.Common.IDValues BodyStyle { get; set; }
    //    public DomainModels.Common.IDValues Series { get; set; }
    //    public DomainModels.Common.IDValues Transmission { get; set; }
    //    public DomainModels.Common.IDValues DriveTrain { get; set; }
    //    public List<DomainModels.Common.OptionValue> Options { get; set; }
    //    public string RequestXML { get; set; }
    //    public List<DomainModels.Common.OptionValue> SavedDBOptions { get; set; }
    //}
    
    ///// <summary>
    ///// Holds the Optional details
    ///// </summary>
    //[Serializable]
    //public class OptionValue : IDValues
    //{
    //    public decimal Cost { get; set; }
    //    public decimal TradeInCost { get; set; }
    //    public decimal RetailCost { get; set; }
    //    public string Oa { get; set; }
    //}

}
