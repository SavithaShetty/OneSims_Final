﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.KBB
{
    public class Make
    {
        public int makeId { get; set; }
        public string makeName { get; set; }
    }
}
