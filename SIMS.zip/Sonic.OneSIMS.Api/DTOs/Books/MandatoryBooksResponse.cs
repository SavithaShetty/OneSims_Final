﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;


namespace Sonic.OneSIMS.Api.DTOs.Books
{
    [DataContract]
    public class MandatoryBooksResponse
    {
       
        [DataMember]
        public List<int> BookIDs { get; set; }

        [DataMember]
        public List<int> SetupBookIds { get; set; }

    }
}
