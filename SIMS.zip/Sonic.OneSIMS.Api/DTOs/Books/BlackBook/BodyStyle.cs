﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.BlackBook
{
    public class BodyStyle
    {
        /// <summary>
        /// The Code value of BodyStyle
        /// </summary>
        /// <example>1</example>
        public string Code { get; set; }

        /// <summary>
        /// The value of BodyStyle
        /// </summary>
        public string Value { get; set; }
    }
}
