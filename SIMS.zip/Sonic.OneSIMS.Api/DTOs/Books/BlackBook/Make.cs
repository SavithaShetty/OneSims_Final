﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Books.BlackBook
{
    /// <summary>
    /// A Make model
    /// </summary>
    public class Make
    {
        /// <summary>
        /// The code of the Make
        /// </summary>
        /// <example>1</example>
        public string Code { get; set; }

        /// <summary>
        /// The value of Make
        /// </summary>
        public string Value { get; set; }
    }
}
