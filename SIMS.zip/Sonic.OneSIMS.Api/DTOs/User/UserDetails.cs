﻿using Sonic.OneSIMS.Api.DTOs.Common;
using Sonic.OneSIMS.DomailModels.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Sonic.OneSIMS.Api.DTOs.User
{
    public partial class UserDetails
    {
        public virtual Guid UserId { get; set; }
        public virtual string UserName { get; set; }
        public virtual AccessLevel UserLevel { get; set; }
        public virtual int StoreID { get; set; }
        public virtual string StoreName { get; set; }
        public virtual List<Roles> Roles { get; set; }
        public virtual Company Company { get; set; }
        public virtual bool IsAuthenticated { get; set; }
        public virtual bool IsRequireRollup { get; set; }

        public virtual string DefaultCompany { get; set; }
        public virtual string DefaultLevel { get; set; }
        public virtual string DefaultStore { get; set; }        
        public virtual List<Roles> AdminRoles { get; set; }
        public virtual List<Roles> SecurityRoles { get; set; }
        public virtual List<Roles> CorporateRoles { get; set; }
        public virtual List<Region> RegionRoles { get; set; }
        public virtual List<UserConfigStoreList> StoreRoles { get; set; }
    }

}
