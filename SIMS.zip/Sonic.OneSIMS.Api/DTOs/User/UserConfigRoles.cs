﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sonic.OneSIMS.Api.DTOs.Common;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public partial class UserConfigRoles
    {
        public List<Roles> AdminRoles { get; set; }
        public List<Roles> SecurityRoles { get; set; }
        public List<Roles> CorporateRoles { get; set; }       
        public List<Roles> RegionRoles { get; set; }
        public List<Roles> StoreRoles { get; set; }
    }
}
