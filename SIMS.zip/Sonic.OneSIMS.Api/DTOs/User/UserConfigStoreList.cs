﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public partial class UserConfigStoreList
    {
        public virtual short StoreId
        {
            get;
            set;
        }

        public virtual string StoreName
        {
            get;
            set;
        }
        public virtual System.Guid RoleId
        {
            get;
            set;
        }
        public virtual string RoleName
        {
            get;
            set;
        }
        public virtual int CompanyId { get; set; }

        public Guid UserId { get; set; }

        public string CreatedBy { get; set; }
    }
}
