﻿using Sonic.OneSIMS.Api.DTOs.Common;
using Sonic.OneSIMS.DomailModels.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Company = Sonic.OneSIMS.DomailModels.Enums.Company;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public  class UserView
    {
        public virtual Guid UserId { get; set; }
        public virtual string UserName { get; set; }
        public virtual AccessLevel UserLevel { get; set; }
        public virtual int StoreID { get; set; }
        public virtual string StoreName { get; set; }
        public virtual List<Roles> Roles { get; set; }
        public virtual Company Company { get; set; }
        public virtual bool IsAuthenticated { get; set; }
        public virtual bool IsRequireRollup { get; set; }
    }
}
