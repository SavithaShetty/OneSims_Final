﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public class UserLookup
    {
        public virtual string UserId { get; set; }
        public virtual string UserName { get; set; }
        public virtual string UserAccess { get; set; }
    }
}
