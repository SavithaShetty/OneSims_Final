﻿using Sonic.OneSIMS.Api.DTOs.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public partial class RegionStoreRole
    {
        public List<Region> regions { get; set; }
        public List<UserConfigStoreList> stores { get; set; }
    }
}
