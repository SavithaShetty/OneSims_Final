﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public class UserProfileReadDto
    {
        public virtual Guid UserId { get; set; }        
        public virtual string UserName { get; set; }
        //public virtual string FirstName { get; set; }
        //public virtual string LastName { get; set; }
        public virtual string UserEmail { get; set; }        
        public virtual string DefaultCompany { get; set; }        
        public virtual string DefaultLevel { get; set; }
        public virtual string DefaultSotre { get; set; }
        public virtual List<string> Roles { get; set; }
        public virtual string UserStatus { get; set; }
    }
}
