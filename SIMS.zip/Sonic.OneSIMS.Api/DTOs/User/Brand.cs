﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.User
{
    public class Brand
    {
        public int BrandId { get; set; }

        public string BrandName { get; set; }
    }
}
