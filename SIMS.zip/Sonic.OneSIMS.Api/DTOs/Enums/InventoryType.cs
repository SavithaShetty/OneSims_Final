﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.DTOs.Enums
{
    public enum InventoryType
    {
        CoreInventory = 1,
        //BuyList = 2,
        //WatchList = 3,
        Used = 10,
        New = 20
    }
}

