﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Sonic.OneSIMS.Framework.Constants;
using Sonic.OneSIMS.Framework.Configuration;

namespace Sonic.OneSIMS.Api.Security.AzureAd
{
    public static class AzureAdExtension
    {
        public static IServiceCollection AddAzureAdAuthorization(this IServiceCollection services,  AzureADSettings azureADSettings)
        {
            //var policy = new AuthorizationPolicyBuilder()
            //   .AddAuthenticationSchemes(AuthConstants.AzureAdScheme)
            //   .RequireAuthenticatedUser()
            //   .Build();

            services.AddAuthorization(options =>
            {
                options.AddAzureAdPolicy();
            })
            .AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = AuthConstants.AzureAdScheme;
                options.DefaultChallengeScheme = AuthConstants.AzureAdScheme;
            })
            .AddJwtBearer(AuthConstants.AzureAdScheme, options =>
            {
                options.Authority = String.Format(azureADSettings.Instance + azureADSettings.TenantId);
                options.Audience = azureADSettings.ClientId;
            });

            return services;
        }

        public static AuthorizationOptions AddAzureAdPolicy(this AuthorizationOptions options)
        {
            var policy = new AuthorizationPolicyBuilder()
                .AddAuthenticationSchemes(AuthConstants.AzureAdScheme)
                .RequireAuthenticatedUser()
                .Build();

            options.AddPolicy(AuthConstants.AzureAdPolicy, policy);
            return options;
        }
    }
}
