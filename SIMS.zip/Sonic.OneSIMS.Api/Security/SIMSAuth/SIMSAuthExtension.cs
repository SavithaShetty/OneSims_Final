﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sonic.OneSIMS.Framework.Constants;
using Sonic.OneSIMS.Framework.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Sonic.OneSIMS.Framework.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;

namespace Sonic.OneSIMS.Api.Security.SIMSAuth
{
    public static class SIMSAuthExtension
    {
        public static IServiceCollection AddSIMSAuthorization(this IServiceCollection services,JwtSettings jwtSettings)
        {
            services.AddAuthorization(options =>
            {
                options.AddSIMSPolicy();
            })
            .AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = AuthConstants.SIMSScheme;
                options.DefaultChallengeScheme = AuthConstants.SIMSScheme;
            })
            .AddJwtBearer(AuthConstants.SIMSScheme, options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = jwtSettings.Issuer,
                    ValidAudience = jwtSettings.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.Secret)),                    
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero,
                    ValidateIssuer = true,
                    ValidateAudience = true
                };
                options.Events=new JwtBearerEvents()
                {
                    OnAuthenticationFailed = context =>
                    {                        
                        context.NoResult();
                        context.Response.StatusCode = 500;
                        context.Response.ContentType = "text/plain";                        
                        ProblemDetails problemDetails = new ProblemDetails();
                        problemDetails.Detail = "Authentication Failed";
                        problemDetails.Status = 500;
                        var result = JsonConvert.SerializeObject(problemDetails);
                        return context.Response.WriteAsync(result);
                        //return context.Response.WriteAsync(context.Exception.ToString());
                    },
                    OnChallenge = context =>
                    {
                        ProblemDetails problemDetails = new ProblemDetails();
                        if (!context.Response.HasStarted)
                        {
                            context.Response.StatusCode = 401;
                            context.Response.ContentType = "application/json";
                            context.HandleResponse();
                            problemDetails.Detail = "You are not Authorized";
                            var result = JsonConvert.SerializeObject(problemDetails);
                            return context.Response.WriteAsync(result);
                        }
                        else
                        {
                            problemDetails.Detail = "Token Expired";
                            var result = JsonConvert.SerializeObject(problemDetails);
                            return context.Response.WriteAsync(result);
                        }
                    },
                    OnForbidden = context =>
                    {
                        ProblemDetails problemDetails = new ProblemDetails();
                        context.Response.StatusCode = 403;
                        context.Response.ContentType = "application/json";
                        problemDetails.Detail = "You are not authorized to access this resource";
                        var result = JsonConvert.SerializeObject(problemDetails);
                        return context.Response.WriteAsync(result);
                    },
                };
                //options.Authority = "http://localhost:63736/";
                //options.Audience = "http://localhost:63736/";                     
            });

            return services;
        }

        public static AuthorizationOptions AddSIMSPolicy(this AuthorizationOptions options)
        {
            var policy = new AuthorizationPolicyBuilder()
                .AddAuthenticationSchemes(AuthConstants.SIMSScheme)
                .RequireAuthenticatedUser()
                .Build();

            options.AddPolicy(AuthConstants.SIMSPolicy, policy);
            return options;
        }
    }
}
