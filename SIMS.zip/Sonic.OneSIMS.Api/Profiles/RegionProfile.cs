﻿using AutoMapper;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.DomailModels.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Profiles
{
    public class RegionProfile:Profile
    {
        public RegionProfile()
        {
            CreateMap<DomainModels.Settings.Regions.Region, DTOs.Regions.Region>().ReverseMap();
            CreateMap<DomainModels.Settings.Regions.RegionConfiguration, DTOs.Regions.RegionConfiguration>().ReverseMap();
            CreateMap<DomainModels.Settings.Regions.NewRegionDetails, DTOs.Regions.NewRegionDetails>().ReverseMap();
            CreateMap<DomainModels.Settings.Regions.NewRegionDetails, DTOs.Regions.NewRegionDetails>().ReverseMap();
            CreateMap<DomainModels.Settings.Regions.RegionStore, DTOs.Regions.RegionStore>().ReverseMap();
        }
    }
}
