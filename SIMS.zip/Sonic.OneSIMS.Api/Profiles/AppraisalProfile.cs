﻿using AutoMapper;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.DomailModels.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Profiles
{
    public class AppraisalProfile : Profile
    {
        public AppraisalProfile()
        {
            CreateMap<DomainModels.Pricing.ReasonCode, DTOs.Pricing.ReasonCode>().ReverseMap();
            CreateMap<DomainModels.Pricing.CostInfoSave, DTOs.Pricing.CostInfoSave>().ReverseMap();
            CreateMap<DomainModels.Pricing.VDPCostInfoDetails, DTOs.Pricing.VDPCostInfoDetails>().ReverseMap();
            CreateMap<DomainModels.Pricing.PricingResponse, DTOs.Pricing.PricingResponse>().ReverseMap();
            CreateMap<DomainModels.Pricing.PricingRequest, DTOs.Pricing.PricingRequest>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.Year, DTOs.Books.KBB.Year>().ReverseMap();
            // CreateMap<DomailModels.Appraisal.BasicVehicleInfo, DTOs.Appraisal.BasicVehicleInfo>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.BookDetails, DTOs.Books.KBB.BookDetails>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.BookRequest, DTOs.BookRequest>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.BookValues, DTOs.Books.KBB.BookValues>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.BookResponse, DTOs.Appraisal.BookResponse>().ReverseMap();
            //  CreateMap<DomainModels.Appraisal.Books.KBB.OptionValues, DTOs.Books.KBB.OptionValues>().ReverseMap();
            // CreateMap<DomainModels.Appraisal.Books.KBB.ValuationData, DTOs.Books.KBB.ValuationData>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.ProviderValues, DTOs.Appraisal.ProviderValues>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.DVCPOValues, DTOs.Appraisal.DVCPOValues>().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.DVCROValues, DTOs.Appraisal.DVCROValues>().ReverseMap();
            // CreateMap<OneSIMS.DomainModels.Common.IDValues, IDValues >().ReverseMap();
            CreateMap<Infrastructure.KBB.Entities.Year, DTOs.Books.KBB.Year>().ReverseMap();

            CreateMap<DomainModels.Appraisal.BasicAppraisalInfo, DTOs.Appraisal.BasicAppraisalInfoCreateDto>().ReverseMap();
            CreateMap<DomainModels.Appraisal.HistoryQuestions, DTOs.Appraisal.HistoryQuestions>().ReverseMap();
            CreateMap<DomainModels.Appraisal.HistoryAnswers, DTOs.Appraisal.HistoryAnswers>().ReverseMap();
            
            CreateMap<DomainModels.Common.ExternalVehicleData, DTOs.Common.ExternalVehicleData>().ReverseMap();
            CreateMap<DomailModels.Common.VehicleIdentity, DTOs.Common.VehicleIdentity>().ReverseMap();
            CreateMap<DomainModels.Enums.IntegrationType, DTOs.Common.Enums.IntegrationType>().ReverseMap();
            CreateMap<DomailModels.Enums.Company, DTOs.Common.Enums.Company>().ReverseMap();
            CreateMap<DomainModels.Appraisal.AfterMarketQuestions, DTOs.Appraisal.AfterMarketQuestions>().ReverseMap();
            CreateMap<DomainModels.Appraisal.AMFO, DTOs.Appraisal.AMFO>().ReverseMap();
            CreateMap<DomainModels.Appraisal.FactoryOptions, DTOs.Chrome.FactoryOptions>().ReverseMap();
            CreateMap<DomainModels.Appraisal.VehicleFactoryOptions, DTOs.Appraisal.VehicleFactoryOptions>().ReverseMap();
            CreateMap<DomainModels.Appraisal.GroupedFactoryOptionList, DTOs.Appraisal.GroupedFactoryOptionList>().ReverseMap();

            CreateMap<DomainModels.Appraisal.VehicleDecodeDetails, DTOs.Appraisal.VehicleInfoReadDto>();
            CreateMap<DomainModels.Appraisal.VehicleInformation, DTOs.Appraisal.VehicleInfoReadDto>()
                               .ForMember(d => d.Mileage, a => a.MapFrom(s => s.Mileage))
                               .ForMember(d => d.SightUnseen, a => a.MapFrom(s => s.SightUnseen));
            CreateMap<DomainModels.Appraisal.UpdateVehicleStatusReq, DTOs.Appraisal.UpdateVehicleStatusReq>().ReverseMap();
            CreateMap<DomainModels.Appraisal.SyncVehicleDetails, DTOs.Appraisal.SyncVehicleDetails>().ReverseMap();
            

        }
    }
}
