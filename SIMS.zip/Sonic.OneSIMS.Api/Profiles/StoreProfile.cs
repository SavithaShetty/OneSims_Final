﻿using AutoMapper;
using Sonic.OneSIMS.Api.DTOs;
using Sonic.OneSIMS.DomailModels.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Profiles
{
    public class StoreProfile : Profile
    {
        public StoreProfile()
        {
            CreateMap<DomailModels.Settings.Store, DTOs.Store.Store>().ReverseMap();
            CreateMap<DomailModels.Settings.StoreDetails, DTOs.Store.StoreDetails>().ReverseMap();
            CreateMap<DomailModels.Settings.StoreOtherInfo, DTOs.Store.StoreOtherInfo>().ReverseMap();
            CreateMap<DomailModels.Settings.DateClosed, DTOs.DateClosed>().ReverseMap();
            CreateMap<DomainModels.Settings.Corporate.CorpGeneralOption, DTOs.Corporate.CorpGeneralOption>().ReverseMap();
            CreateMap<DomailModels.Settings.Configurations, DTOs.Store.Configurations>().ReverseMap();
            CreateMap<DomailModels.Settings.User.UserConfigStoreList, DTOs.User.UserConfigStoreList>().ReverseMap();
            CreateMap<DomailModels.Settings.User.UserDetails, DTOs.User.UserDetails>().ReverseMap();
            CreateMap<DomailModels.Settings.User.Region, DTOs.Common.Region>().ReverseMap();
            CreateMap<DomainModels.Settings.User.UserView, DTOs.User.UserView>().ReverseMap();
            CreateMap<DomailModels.Settings.Store, DTOs.Store.StoreRegion>().ReverseMap();
            CreateMap<DomainModels.Settings.User.Brand, DTOs.User.Brand>().ReverseMap();
            CreateMap<DomainModels.Settings.User.UserConfigRoles, DTOs.User.UserConfigRoles>().ReverseMap();
            CreateMap<DomainModels.Settings.User.RegionStoreRole, DTOs.User.RegionStoreRole>().ReverseMap();
            CreateMap<DomainModels.Common.Roles, DTOs.Common.Roles>().ReverseMap();
            CreateMap<DomainModels.Settings.DealershipInformation, DTOs.Store.DealershipInformation>().ReverseMap();
            CreateMap<DomainModels.Settings.WeekDays, DTOs.Store.WeekDays>().ReverseMap();
            CreateMap<DomainModels.Settings.StoreRegionMap, DTOs.Store.StoreRegionMap>().ReverseMap();
            CreateMap<DomainModels.Settings.StateList, DTOs.Store.StateList>().ReverseMap();
            CreateMap<DomainModels.Settings.DateClosed, DTOs.DateClosed>().ReverseMap();
            CreateMap<DomainModels.Settings.DealershipConfiguration, DTOs.Store.DealershipConfiguration>().ReverseMap();
            CreateMap<DomainModels.Settings.SonicConfiguraion, DTOs.Store.SonicConfiguraion>().ReverseMap();
            CreateMap<DomainModels.Settings.LoanerConfiguration, DTOs.Store.LoanerConfiguration>().ReverseMap();
            CreateMap<DomainModels.Settings.SonicOtherOptions, DTOs.Store.SonicOtherOptions>().ReverseMap();
            CreateMap<DomainModels.Settings.SonicCdkDetails, DTOs.Store.SonicCdkDetails>().ReverseMap();
            CreateMap<DomainModels.Settings.SonicUsedConfiguration, DTOs.Store.SonicUsedConfiguration>().ReverseMap();
            
            CreateMap<DomainModels.Settings.DealershipParameter, DTOs.Store.DealershipParameter>().ReverseMap();
            CreateMap<DomainModels.Settings.ReconOptions, DTOs.Store.ReconOptions>().ReverseMap();
            CreateMap<DomainModels.Settings.UsedBooks, DTOs.Store.UsedBooks>().ReverseMap();
            CreateMap<DomainModels.Settings.ContactandFees, DTOs.Store.ContactandFees>().ReverseMap();
            CreateMap<DomainModels.Settings.UsedOtherOptions, DTOs.Store.UsedOtherOptions>().ReverseMap();
            CreateMap<DomainModels.Settings.CertificateBrands, DTOs.Store.CertificateBrands>().ReverseMap();

            

        }
    }
}
