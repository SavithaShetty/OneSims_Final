using AutoMapper;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Sinks.MSSqlServer;
using Sonic.OneSIMS.Api.Extensions;
using Sonic.OneSIMS.Api.Helpers;
using Sonic.OneSIMS.Api.Middlewares;
using Sonic.OneSIMS.Api.Security.AzureAd;
using Sonic.OneSIMS.Api.Security.SIMSAuth;
using Sonic.OneSIMS.Framework.Configuration;
using Sonic.OneSIMS.Framework.Constants;
using Sonic.OneSIMS.Infrastructure.ExceptionLogging;
using Sonic.OneSIMS.Infrastructure.Persistence;
using System;

namespace Sonic.OneSIMS.Api
{
    public class Startup
    {
        private ColumnOptions columnOptions;
        private bool loggingAISource;
        private bool loggingDBSource;
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        [Obsolete]
        public void ConfigureServices(IServiceCollection services)
        {

            services.Configure<Settings>(options => Configuration.GetSection("Settings").Bind(options));

            services.AddAzureAdAuthorization(Configuration.GetSection("Settings").Get<Settings>().azureADSettings);

            services.AddSIMSAuthorization(Configuration.GetSection("Settings").Get<Settings>().jwtSettings);

            services.AddControllers(options =>
            {
                options.Filters.Add(typeof(ValidateModelStateAttribute));
            })
            .AddFluentValidation(config => config.RegisterValidatorsFromAssemblyContaining<Startup>());

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });


            ConfigureDatabase(services);

            // AutoMapper
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

            // Fluent validator
            //services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            // services.RegisterTypes();
            // services.AddScoped<IStoreLogic, StoreLogic>();
            // services.AddScoped<IStoreRepository, StoreRepository>();
            services.RegisterTypes(AssemblyNames.PhotoUpload, AssemblyTypeSuffix.ServiceTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.ZipCode, AssemblyTypeSuffix.ServiceTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.Chrome, AssemblyTypeSuffix.ServiceTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.Cdk, AssemblyTypeSuffix.ServiceTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.Manheim, AssemblyTypeSuffix.ServiceTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.Kbb, AssemblyTypeSuffix.ServiceTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.BusinessLogic, AssemblyTypeSuffix.LogicTypeSuffix, (itype, type) => services.AddScoped(itype, type));
            services.RegisterTypes(AssemblyNames.DataAccess, AssemblyTypeSuffix.RepositoryTypeSuffix, (itype, type) => services.AddScoped(itype, type));

            services.AddSwaggerService();

            services.AddCors();
            //services.AddPersistenceInfrastructure(Configuration);
            services.AddLoggerInfrastructure(Configuration, Configuration.GetSection("Settings").Get<Settings>().loggerDetail, Configuration.GetSection("Settings").Get<Settings>().serilog);

        }

        public virtual void ConfigureDatabase(IServiceCollection services)
        {
            // Add functionality to inject IOptions<T>
            services.AddOptions();

            // Add our Config object so it can be injected
            services.Configure<DataConnection>(Configuration.GetSection("ConnectionStrings"));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            loggerFactory.AddSerilog();
            app.UseCors(builder => builder.AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod());

            app.UseRouting();

            app.UseAuthorization();

            app.AddSwaggerMidleware();

            app.UseMiddleware<ErrorHandlerMiddleware>();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
