﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Sonic.OneSIMS.Api.Helpers
{
    public static class AssemblyRegistrationHelper
    {
        public static void RegisterTypes(this IServiceCollection services, string assemblyName,string typeSuffix,Action<Type,Type> scopedRegistration)
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(x => string.Equals(x.GetName().Name.ToUpperInvariant(), assemblyName));

            if(assembly==null)
            {
                assembly = AppDomain.CurrentDomain.Load(assemblyName);
            }

            var allServices = assembly.GetTypes().Where(p => p.GetTypeInfo().IsClass && !p.GetTypeInfo().IsAbstract && p.FullName.EndsWith(typeSuffix));

            foreach(var type in allServices)
            {
                var allInterfaces = type.GetInterfaces();

                var mainInterfaces = allInterfaces.Except(allInterfaces.SelectMany(t => t.GetInterfaces()));

                foreach(var itype in mainInterfaces)
                {
                    scopedRegistration(itype, type);
                }

            }

        }
    }
}
